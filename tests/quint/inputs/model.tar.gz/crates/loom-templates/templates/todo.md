# Todo Decomposition

{{ self.output_contract() }}{% if self.dossier_manifest().is_none() %}{% match package_context %}{% when Some with (context) %}

{{ context }}
{% when None %}{% endmatch %}{% endif %}

You are decomposing the driver-injected changed-spec roster into bead work. The driver has already created or reused the `loom:todo` work epic for this batch; do not create a molecule epic yourself.

{% include "partial/context_pinning.md" %}

## Spec Index

{{ spec_index }}

## Todo Batch

- **Work epic**: {{ work_epic }}
- **Todo head**: {{ todo_head }}
- **Todo fingerprint**: {{ todo_fingerprint }}

## Changed Specs

Decompose exactly the specs listed here. Every label in this roster must appear exactly once in the final `LOOM_TODO:` payload.

{% if changed_specs.is_empty() %}_No changed specs were injected. Treat this as a preflight problem and self-report instead of emitting success._
{% else %}{% for spec in changed_specs %}

### {{ spec.label }}

- Spec file: `{{ spec.spec_path }}`

{% if spec.acceptance_path != spec.spec_path %}
- Acceptance file: `{{ spec.acceptance_path }}`
{% endif -%}
{% if spec.input_scope != spec.spec_path %}
- Tracked package inputs: `{{ spec.input_scope }}` (models/supporting files load on demand)
{% endif -%}
{% if self.dossier_manifest().is_none() %}{% match spec.diff %}{% when Some with (diff) %}
Diff:

```diff
{{ diff }}
```

{% when None %}

- Diff: not provided; read the spec file and use the criterion-status evidence below.

{% endmatch %}{% endif %}
{% endfor %}{% endif %}

## Spec Epic Metadata

{% if spec_epics.is_empty() %}_No cached spec epic metadata was injected._
{% else %}{% for epic in spec_epics %}

- **{{ epic.label }}** · epic {% match epic.epic_id %}{% when Some with (id) %}{{ id }}{% when None %}—{% endmatch %} · todo cursor {% match epic.todo_cursor %}{% when Some with (cursor) %}`{{ cursor }}`{% when None %}—{% endmatch %}

{% endfor %}{% endif %}

{% include "partial/companions_context.md" %}

{% include "partial/scratchpad.md" %}
{% include "partial/skill_index.md" %}{% match self.dossier_manifest() %}{% when Some with (manifest) %}

## Evidence Dossier and Resumption

Read `{{ manifest }}` first. It identifies this fixed batch's complete per-spec criterion, implementation-note, and diff pages. Page paths are relative to that manifest. Read pages one owner/topic at a time; do not concatenate the entire dossier into context. Nothing was truncated or inferred from missing cache rows.

Every implementation note describes work that must become one or more beads unless a genuinely unresolved choice requires a dedicated child decision brief and nonterminal Clarify reporting; reconcile decomposition independently. Before decomposing an owner, inspect all its criterion/status and implementation-note pages. Consult diff pages and representative source as needed; formatting or ownership changes and `Missing` evidence do not by themselves require implementation beads. Preserve every owner in the final result, including justified no-work outcomes. A partial audit is not success.

Before creating tasks, inspect durable drafts with `bd show {{ work_epic }} --json` and `bd list --parent {{ work_epic }} --all --limit 0 --json`. Reconcile and reuse existing children rather than duplicating them. Merge concise progress (audited owners, child IDs, evidence references and remaining questions) into the work epic's **description** after each topic, preserving prior human decisions; driver diagnostics may replace its notes. This checkpoint is a hint to recheck, not authoritative acceptance or permission to advance cursors. Scratch pages are regenerated on retry; the work epic and child beads survive.

{% when None %}{% if self.has_implementation_notes() %}

## Implementation Notes

The following implementation notes were captured during planning. **Every note below describes work that MUST become one or more beads in this session** unless a genuinely unresolved choice requires a dedicated child decision brief and nonterminal Clarify reporting; reconcile decomposition independently.

{% for group in implementation_notes %}{% if !group.notes.is_empty() %}

### {{ group.label }}

{% for note in group.notes %}<implementation-note>
<agent-output>
{{ note }}
</agent-output>
</implementation-note>
{% endfor %}{% endif %}{% endfor %}{% endif %}

## Criterion Status

The rows below are historical observations of the latest cached verifier verdict, not current coverage admission. `Current` means the cached annotation matches; it does not establish current policy, trust, retained-history or blocker admission, even at zero commit distance. No current coverage projection was supplied to this dispatch: coverage is unavailable, not passing. Inspect implementation and verifier bodies; preserve uncertainty and unresolved blockers.

{% if criterion_status.is_empty() %}_No parsed criterion-status rows were injected. Treat this as a preflight problem, not as evidence of no work._
{% else %}{% for row in criterion_status %}

- {{ row }}

{% endfor %}{% endif %}{% endmatch %}

{% include "partial/decomposition_discipline.md" %}

## Task Breakdown Guidelines

- Create implementation beads only as children of the injected work epic `{{ work_epic }}`.
- Label every bead with `spec:<label>` for the changed spec it implements and the appropriate `profile:<name>` label.
- Keep each bead self-contained with enough context for a fresh `loom loop` agent.
- Set dependencies with `bd dep add` when one bead must land before another.
- Include the criterion-status row or source-inspection evidence that justified each non-audit bead.

## Profile Assignment

| Task Type             | Profile          | When to Use                                    |
| --------------------- | ---------------- | ---------------------------------------------- |
| Rust implementation   | `profile:rust`   | Tasks touching `.rs` files or using cargo      |
| Python implementation | `profile:python` | Tasks touching `.py` files or using pytest/pip |
| Nix/shell/docs        | `profile:base`   | Tasks touching only `.nix`, `.sh`, `.md` files |

## Instructions

1. Use the injected changed-spec roster, diffs, implementation notes, and Criterion Status rows as the starting evidence. Do **not** perform a blanket full-file read of every changed spec; read only targeted spec sections, companion manifests, representative code, or verifier bodies needed to resolve an actual ambiguity.
2. Audit the Criterion Status rows before fan-out. `EvidenceState::Missing` and `EvidenceState::StaleAnnotation` are absence or staleness of evidence; inspect representative code and verifier bodies before creating non-audit beads.
3. Create needed beads under the driver-created work epic:
   ```bash
   TASK_ID=$(bd create --title="<task title>" --description="<detailed description>" \
     --type=task --labels="spec:<label>,profile:<profile>" --parent="{{ work_epic }}" --silent)
   ```
4. Set execution order with `bd dep add <later-task> <earlier-task>` where required.
5. When finished, stop using tools and emit success only through the typed todo payload described below as your final assistant message. Do not use `bash`, `python`, `echo`, `printf`, or any other tool to print the terminal line.

{% include "partial/self_report_markers.md" %}

{% include "partial/dependency_wait.md" %}

{% include "partial/todo_success.md" %}
