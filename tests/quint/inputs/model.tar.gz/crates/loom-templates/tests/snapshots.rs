//! `insta` snapshot tests for every Askama template × representative input set.
//!
//! The rendered template body is the contract we ship to the agent — layout
//! drift slips silently past substring assertions. Snapshots surface the diff
//! in PR review. Updates require an explicit "snapshot updated because: ..."
//! line in the PR description (see `docs/style-rules.md`).
//!
//! One snapshot per typed context struct, named after the test function via
//! `insta::assert_snapshot!`'s default file naming.

use anyhow::Result;
use askama::Template;
use loom_events::identifier::{BeadId, MoleculeId, ProfileName, SpecLabel};
use loom_protocol::todo::{GitSha, TodoFingerprint};
use loom_templates::SkillIndexMarkdown;
use loom_templates::criterion_status::{
    AnnotationTarget, AnnotationTier, CriterionAnnotation, CriterionId, CriterionResult,
    CriterionStatus, EvidenceState,
};
use loom_templates::finding::{ConcernToken, FindingTarget};
use loom_templates::inbox::{ClarifyOption, InboxContext, InboxItem, ItemKind};
use loom_templates::plan::PlanContext;
use loom_templates::review::{ReviewContext, ReviewLane, ReviewSource};
use loom_templates::run::{
    DriverNoticeCause, LoopContext, PreviousFailure, RecoveryStash, VerifierFailure,
    WorkspaceAlignment, WorkspaceRecovery,
};
use loom_templates::todo::{
    SpecEpicContext, SpecImplementationNotes, TodoChangedSpec, TodoContext,
};

const PINNED_CONTEXT_BODY: &str =
    "# Project Overview\n\nLoom orchestrates the spec-to-implementation workflow.";
const SCRATCHPAD_PATH_BODY: &str = "/workspace/.loom/scratch/harness/scratch.md";
const TEST_SHA: &str = "0123456789abcdef0123456789abcdef01234567";
const TEST_SHA_2: &str = "1111111111111111111111111111111111111111";
const TEST_SHA_3: &str = "2222222222222222222222222222222222222222";
const TEST_FINGERPRINT: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

fn inbox_item(id: &str, spec: &str, title: &str, kind: ItemKind) -> InboxItem {
    InboxItem {
        index: 1,
        id: id.to_string(),
        bead_id: id.to_string(),
        spec_label: spec.to_string(),
        title: title.to_string(),
        body: String::new(),
        notes: None,
        options_summary: None,
        options: Vec::new(),
        kind,
        infra: None,
        tune: None,
    }
}

#[expect(
    clippy::unwrap_used,
    reason = "fixture literals are part of the snapshot contract; parse failure means the test fixture is invalid"
)]
fn git_sha(raw: &str) -> GitSha {
    GitSha::new(raw).unwrap()
}

fn criterion_id(raw: &str) -> Result<CriterionId> {
    Ok(CriterionId::new(raw)?)
}

fn workspace_recovery(alignment: WorkspaceAlignment) -> WorkspaceRecovery {
    WorkspaceRecovery {
        pre_stash_status:
            "## loom/lm-3hhwq.10\n M crates/loom-templates/src/run/mod.rs\n?? scratch.txt".into(),
        stash: RecoveryStash {
            selector: "stash@{0}".into(),
            commit: git_sha(TEST_SHA_2),
            message: "loom workspace-recovery lm-3hhwq.10 1716250000".into(),
        },
        integration_tip: git_sha(TEST_SHA_3),
        alignment,
    }
}

#[expect(
    clippy::unwrap_used,
    reason = "fixture identifiers are parsed once so snapshots exercise production newtypes"
)]
fn todo_ctx() -> Result<TodoContext> {
    Ok(TodoContext {
        package_context: None,
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        spec_index: "# Loom Docs\n| Spec | Purpose |\n| [harness](../specs/harness.md) | Harness |"
            .to_string(),
        changed_specs: vec![TodoChangedSpec {
            label: SpecLabel::new("harness").unwrap(),
            spec_path: "specs/harness.md".to_string(),
            acceptance_path: "specs/harness.md".to_string(),
            input_scope: "specs/harness.md".to_string(),
            diff: Some("=== specs/harness.md ===\n+ new requirement".to_string()),
        }],
        work_epic: BeadId::new("lm-work").unwrap(),
        todo_head: git_sha(TEST_SHA),
        todo_fingerprint: TodoFingerprint::new(TEST_FINGERPRINT).unwrap(),
        spec_epics: vec![SpecEpicContext {
            label: SpecLabel::new("harness").unwrap(),
            epic_id: Some(MoleculeId::new("lm-spec").unwrap()),
            todo_cursor: Some(TEST_SHA.to_string()),
        }],
        companion_paths: vec!["lib/sandbox/".into()],
        implementation_notes: vec![SpecImplementationNotes {
            label: SpecLabel::new("harness").unwrap(),
            notes: vec!["Carry the unified todo protocol into snapshots.".into()],
        }],
        criterion_status: snapshot_criterion_status()?,
        scratchpad_path: SCRATCHPAD_PATH_BODY.to_string(),
        skill_index: SkillIndexMarkdown::empty(),
        evidence_delivery: loom_templates::todo::EvidenceDelivery::Inline,
    })
}

fn snapshot_criterion_status() -> Result<Vec<CriterionStatus>> {
    Ok(vec![
        CriterionStatus {
            spec_label: SpecLabel::new("templates")?,
            criterion_id: criterion_id("criterion-0000000000000001")?,
            criterion_text: "All workflow templates compile under Askama.".into(),
            annotation: ann(AnnotationTier::Check, "cargo build -p loom-templates"),
            evidence: EvidenceState::Current {
                result: CriterionResult::Pass,
                last_timestamp_ms: 1_716_300_000_000,
                last_commit: git_sha(TEST_SHA),
                commits_since: 0,
            },
        },
        CriterionStatus {
            spec_label: SpecLabel::new("templates")?,
            criterion_id: criterion_id("criterion-0000000000000002")?,
            criterion_text: "Rendered output is stable across runs.".into(),
            annotation: ann(
                AnnotationTier::Test,
                "template_renders_are_byte_stable_across_runs",
            ),
            evidence: EvidenceState::Current {
                result: CriterionResult::Fail,
                last_timestamp_ms: 1_716_200_000_000,
                last_commit: git_sha(TEST_SHA_2),
                commits_since: 7,
            },
        },
        CriterionStatus {
            spec_label: SpecLabel::new("templates")?,
            criterion_id: criterion_id("criterion-0000000000000003")?,
            criterion_text: "Todo prompts render typed criterion status rows.".into(),
            annotation: ann(
                AnnotationTier::Test,
                "todo_template_renders_typed_criterion_status_rows",
            ),
            evidence: EvidenceState::Missing,
        },
        CriterionStatus {
            spec_label: SpecLabel::new("templates")?,
            criterion_id: criterion_id("criterion-0000000000000004")?,
            criterion_text: "Every non-pending pinning cell matches the include graph.".into(),
            annotation: ann(
                AnnotationTier::Check,
                "cargo run -p loom-walk -- template_pinning_matrix",
            ),
            evidence: EvidenceState::Current {
                result: CriterionResult::Skipped,
                last_timestamp_ms: 1_716_250_000_000,
                last_commit: git_sha(TEST_SHA_3),
                commits_since: 3,
            },
        },
    ])
}

fn ann(tier: AnnotationTier, target: &str) -> CriterionAnnotation {
    CriterionAnnotation {
        tier,
        target: AnnotationTarget::new(target),
        pending: false,
    }
}

fn plan_snapshot() -> Result<()> {
    let ctx = PlanContext {
        package_context: None,
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        anchor_labels: vec![SpecLabel::new("harness")?, SpecLabel::new("future-spec")?],
        spec_index: "# Loom Docs\n| Spec | Purpose |\n| [harness](../specs/harness.md) | Harness |"
            .to_string(),
        companion_paths: vec![
            "lib/sandbox/".into(),
            "crates/loom-templates/templates/".into(),
        ],
        scratchpad_path: SCRATCHPAD_PATH_BODY.to_string(),
        spec_conventions: "docs/spec-conventions.md".to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render()?);
    Ok(())
}

fn todo_snapshot() -> Result<()> {
    insta::assert_snapshot!(todo_ctx()?.render()?);
    Ok(())
}

fn run_snapshot() -> Result<()> {
    let ctx = LoopContext {
        package_context: None,
        acceptance: None,
        bead_base: git_sha(TEST_SHA),
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        label: SpecLabel::new("harness")?,
        spec_path: "specs/harness.md".to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        molecule_id: Some(MoleculeId::new("lm-3hhwq")?),
        issue_id: Some(BeadId::new("lm-3hhwq.10")?),
        title: Some("port templates".into()),
        description: Some("Port templates to Askama.".into()),
        previous_failure: Some(PreviousFailure::from_agent_error(
            "error: cargo test failed",
        )),
        workspace_recovery: None,
        review_notes: None,
        attempt: 1,
        scratchpad_path: "/workspace/.loom/scratch/lm-3hhwq.10/scratch.md".to_string(),
        style_rules: "docs/style-rules.md".to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render()?);
    Ok(())
}

#[test]
fn recovery_display_snapshots() {
    let message = loom_protocol::gate::parse_exit_signal(
        r#"LOOM_RETRY: {"reason":"socket vanished\nretry 🧶"}"#,
        loom_protocol::output::Phase::Loop,
    )
    .unwrap();
    let loom_protocol::output::Message::Retry(payload) = message else {
        panic!("retry fixture must decode");
    };
    insta::assert_snapshot!(
        "agent_retry_display",
        PreviousFailure::AgentRetry {
            reason: payload.reason.to_string(),
        }
        .to_string()
    );
    let first = r#"LOOM_FINDING: {"token":"mock-discipline","route":"deferred","bonds":["alpha"],"target":{"kind":"TestPath","path":"tests/check.rs"},"evidence":"first\nsecond 🧶"}"#;
    let last = first.replace("first\\nsecond 🧶", "last finding");
    let invalid_target = first.replace("mock-discipline", "verifier-bypass");
    for (error_name, error) in [
        ("validation", invalid_target.as_str()),
        ("syntax", "LOOM_FINDING: {not json}"),
    ] {
        for (terminal_name, terminal) in [
            ("decoded", r#"LOOM_CONCERN: {"summary":"review summary"}"#),
            ("malformed", r#"LOOM_RETRY: {"reason":""}"#),
            ("missing", ""),
        ] {
            let walk = loom_protocol::gate::WalkOutput::from_stdout(
                &format!("{first}\n{error}\n{last}\n{terminal}"),
                loom_protocol::gate::DispatchScope::Tree,
                &loom_test_support::finding::FixtureSymbols,
            );
            insta::assert_snapshot!(
                format!("mixed_bad_walk_{error_name}_{terminal_name}"),
                PreviousFailure::BadWalk(walk.bad_walk().unwrap()).to_string(),
            );
        }
    }
}

/// Fresh dispatch: `attempt = 0` with `previous_failure = None` must render
/// the false branch of the first-instruction reframe — no blockquote, no
/// retry line — so a clean run prompt is byte-stable against the false
/// branch.
#[test]
fn run_snapshot_no_failure() {
    let ctx = LoopContext {
        package_context: None,
        acceptance: None,
        bead_base: git_sha(TEST_SHA),
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        label: SpecLabel::new("harness").unwrap(),
        spec_path: "specs/harness.md".to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        molecule_id: Some(MoleculeId::new("lm-3hhwq").unwrap()),
        issue_id: Some(BeadId::new("lm-3hhwq.10").unwrap()),
        title: Some("port templates".into()),
        description: Some("Port templates to Askama.".into()),
        previous_failure: None,
        workspace_recovery: None,
        review_notes: None,
        attempt: 0,
        scratchpad_path: "/workspace/.loom/scratch/lm-3hhwq.10/scratch.md".to_string(),
        style_rules: "docs/style-rules.md".to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render().unwrap());
}

#[test]
fn run_snapshot_workspace_recovery() {
    let ctx = LoopContext {
        package_context: None,
        acceptance: None,
        bead_base: git_sha(TEST_SHA_3),
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        label: SpecLabel::new("harness").unwrap(),
        spec_path: "specs/harness.md".to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        molecule_id: Some(MoleculeId::new("lm-3hhwq").unwrap()),
        issue_id: Some(BeadId::new("lm-3hhwq.10").unwrap()),
        title: Some("port templates".into()),
        description: Some("Port templates to Askama.".into()),
        previous_failure: Some(PreviousFailure::DriverNotice {
            cause: DriverNoticeCause::ZeroProgress,
            detail: "Marker `LOOM_COMPLETE` emitted with empty diff.".into(),
        }),
        workspace_recovery: Some(workspace_recovery(WorkspaceAlignment::Conflict {
            files: vec!["crates/loom-templates/src/run/mod.rs".into()],
        })),
        review_notes: None,
        attempt: 1,
        scratchpad_path: "/workspace/.loom/scratch/lm-3hhwq.10/scratch.md".to_string(),
        style_rules: "docs/style-rules.md".to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render().unwrap());
}

/// Retry with the `DriverNotice` variant: pins the reframe + framing prefix
/// for procedural failures like `incomplete-signaling`.
#[test]
fn run_snapshot_driver_notice() {
    let ctx = LoopContext {
        package_context: None,
        acceptance: None,
        bead_base: git_sha(TEST_SHA),
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        label: SpecLabel::new("harness").unwrap(),
        spec_path: "specs/harness.md".to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        molecule_id: Some(MoleculeId::new("lm-3hhwq").unwrap()),
        issue_id: Some(BeadId::new("lm-3hhwq.10").unwrap()),
        title: Some("port templates".into()),
        description: Some("Port templates to Askama.".into()),
        previous_failure: Some(PreviousFailure::DriverNotice {
            cause: DriverNoticeCause::IncompleteSignaling,
            detail: "Marker `LOOM_COMPLETE` emitted but bead `lm-3hhwq.10` was not bd-closed."
                .into(),
        }),
        workspace_recovery: None,
        review_notes: None,
        attempt: 1,
        scratchpad_path: "/workspace/.loom/scratch/lm-3hhwq.10/scratch.md".to_string(),
        style_rules: "docs/style-rules.md".to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render().unwrap());
}

/// Retry with the `VerifyFailures` variant: pins the reframe alongside the
/// collective verifier-failures framing.
#[test]
fn run_snapshot_verify_failures() {
    let ctx = LoopContext {
        package_context: None,
        acceptance: None,
        bead_base: git_sha(TEST_SHA),
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        label: SpecLabel::new("harness").unwrap(),
        spec_path: "specs/harness.md".to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        molecule_id: Some(MoleculeId::new("lm-3hhwq").unwrap()),
        issue_id: Some(BeadId::new("lm-3hhwq.10").unwrap()),
        title: Some("port templates".into()),
        description: Some("Port templates to Askama.".into()),
        previous_failure: Some(PreviousFailure::VerifyFailures(vec![VerifierFailure::new(
            "tests/run-tests.sh",
            1,
            "assertion failed: expected reframe in prompt\n",
        )])),
        workspace_recovery: None,
        review_notes: None,
        attempt: 1,
        scratchpad_path: "/workspace/.loom/scratch/lm-3hhwq.10/scratch.md".to_string(),
        style_rules: "docs/style-rules.md".to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render().unwrap());
}

/// Retry with the `ReviewConcern` variant: pins the reframe alongside the
/// review concern framing and its token prefix.
#[test]
fn run_snapshot_review_concern() {
    let ctx = LoopContext {
        package_context: None,
        acceptance: None,
        bead_base: git_sha(TEST_SHA),
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        label: SpecLabel::new("harness").unwrap(),
        spec_path: "specs/harness.md".to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        molecule_id: Some(MoleculeId::new("lm-3hhwq").unwrap()),
        issue_id: Some(BeadId::new("lm-3hhwq.10").unwrap()),
        title: Some("port templates".into()),
        description: Some("Port templates to Askama.".into()),
        previous_failure: Some(PreviousFailure::ReviewConcern {
            summary: "test mocks the agent backend instead of running the live driver".into(),
            findings: vec![
                loom_test_support::finding::resolve(loom_protocol::gate::RawFinding {
                    token: ConcernToken::VerifierBypass,
                    route: loom_protocol::gate::FindingRoute::Deferred,
                    bonds: vec![SpecLabel::new("harness").unwrap()],
                    target: FindingTarget::Annotation {
                        target_string: "cargo test --lib parse_walks_all_md_files".into(),
                    },
                    evidence: "test mocks the agent backend instead of running the live driver"
                        .into(),
                })
                .expect("valid fixture finding"),
            ],
        }),
        workspace_recovery: None,
        review_notes: None,
        attempt: 1,
        scratchpad_path: "/workspace/.loom/scratch/lm-3hhwq.10/scratch.md".to_string(),
        style_rules: "docs/style-rules.md".to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render().unwrap());
}

/// Retry with the `BuildFailure` variant: pins the reframe alongside the
/// compiler/build framing. Companion to the legacy `run_snapshot` which uses
/// `PreviousFailure::from_agent_error` (`stage = "agent"`); this variant pins
/// a real stage name.
#[test]
fn run_snapshot_build_failure() {
    let ctx = LoopContext {
        package_context: None,
        acceptance: None,
        bead_base: git_sha(TEST_SHA),
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        label: SpecLabel::new("harness").unwrap(),
        spec_path: "specs/harness.md".to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        molecule_id: Some(MoleculeId::new("lm-3hhwq").unwrap()),
        issue_id: Some(BeadId::new("lm-3hhwq.10").unwrap()),
        title: Some("port templates".into()),
        description: Some("Port templates to Askama.".into()),
        previous_failure: Some(PreviousFailure::BuildFailure {
            stage: "cargo check".into(),
            output: "error[E0382]: borrow of moved value: `ctx`".into(),
        }),
        workspace_recovery: None,
        review_notes: None,
        attempt: 1,
        scratchpad_path: "/workspace/.loom/scratch/lm-3hhwq.10/scratch.md".to_string(),
        style_rules: "docs/style-rules.md".to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render().unwrap());
}

fn review_snapshot() -> Result<()> {
    let ctx = ReviewContext {
        package_context: None,
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        label: SpecLabel::new("harness")?,
        spec_path: "specs/harness.md".to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        beads_summary: Some("- lm-3hhwq.10: closed".into()),
        base_commit: Some("abc1234".into()),
        molecule_id: Some(MoleculeId::new("lm-3hhwq")?),
        test_sources: vec![ReviewSource {
            path: "tests/run-tests.sh".into(),
            body: "test_review_inputs() { :; }\n".into(),
        }],
        judge_rubrics: vec![ReviewSource {
            path: "tests/judges/loom.sh".into(),
            body: "judge_live_path_coverage() { :; }\n".into(),
        }],
        scratchpad_path: SCRATCHPAD_PATH_BODY.to_string(),
        style_rules: "docs/style-rules.md".to_string(),
        lane: ReviewLane::Both,
        default_profile: ProfileName::new("rust")?,
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render()?);
    Ok(())
}

fn inbox_snapshot() -> Result<()> {
    let mut item = inbox_item(
        "lm-clar.1",
        "harness",
        "State storage choice",
        ItemKind::Clarify,
    );
    item.options_summary = Some("State JSON vs. dedicated table".into());
    item.options = vec![
        ClarifyOption {
            n: 1,
            title: Some("Keep state in JSON".into()),
            body: Some("Add a companions array.".into()),
        },
        ClarifyOption {
            n: 2,
            title: Some("Migrate to a table".into()),
            body: Some("Use a SQLite table.".into()),
        },
    ];
    let ctx = InboxContext {
        pinned_context: PINNED_CONTEXT_BODY.to_string(),
        companion_paths: vec!["lib/sandbox/".into()],
        inbox_items: vec![item],
        scratchpad_path: SCRATCHPAD_PATH_BODY.to_string(),
        skill_index: SkillIndexMarkdown::empty(),
    };
    insta::assert_snapshot!(ctx.render()?);
    Ok(())
}

#[test]
fn every_askama_template_has_snapshot() -> Result<()> {
    plan_snapshot()?;
    todo_snapshot()?;
    run_snapshot()?;
    review_snapshot()?;
    inbox_snapshot()?;
    Ok(())
}
