//! `loom loop` template: the per-bead implementation prompt with retry context.

use askama::Template;
use loom_events::identifier::{BeadId, MoleculeId, SpecLabel};
use loom_protocol::todo::GitSha;

use crate::SkillIndexMarkdown;

pub use crate::previous_failure::{
    BadWalk, DriverNoticeCause, PREVIOUS_FAILURE_MAX_LEN, PreviousFailure, STDERR_TAIL_PER_BLOCK,
    VerifierFailure,
};
pub use crate::workspace_recovery::{RecoveryStash, WorkspaceAlignment, WorkspaceRecovery};

/// Context for `loom loop` executing a single bead.
#[derive(Template)]
#[template(path = "loop.md", escape = "none")]
pub struct LoopContext {
    /// Immutable driver-selected package snapshot; None supports partial composition only.
    pub package_context: Option<loom_protocol::context::Context>,
    /// Resolved instructions supplied by the driver; absent only for partial composition.
    pub acceptance: Option<loom_protocol::acceptance::dispatch::Context>,
    pub pinned_context: String,
    pub label: SpecLabel,
    pub spec_path: String,
    pub companion_paths: Vec<String>,
    pub molecule_id: Option<MoleculeId>,
    pub issue_id: Option<BeadId>,
    /// Exact integration tip resolved for this dispatch, independent of worker HEAD.
    pub bead_base: GitSha,
    pub title: Option<String>,
    pub description: Option<String>,
    /// Typed retry context — variants render with their documented framing
    /// (see `crate::previous_failure::PreviousFailure`'s `Display` impl).
    pub previous_failure: Option<PreviousFailure>,
    /// Dirty-workspace recovery stash context, independent of retry state.
    pub workspace_recovery: Option<WorkspaceRecovery>,
    /// Optional caller-supplied compatibility block rendered as `Review notes:`.
    /// Workflow drivers leave this unset; reviewer evidence travels in typed
    /// `PreviousFailure` findings. Direct template callers own this block's budget.
    pub review_notes: Option<String>,
    /// In-session per-bead retry counter, populated by the driver. `0` on
    /// fresh dispatch; `loop.md` omits the retry line when zero.
    pub attempt: u32,
    pub scratchpad_path: String,
    pub style_rules: String,
    pub skill_index: SkillIndexMarkdown,
}

impl LoopContext {
    pub fn output_contract(&self) -> String {
        crate::output::contract(self.output_phase())
    }

    pub const fn output_phase(&self) -> loom_protocol::output::Phase {
        loom_protocol::output::Phase::Loop
    }
}
