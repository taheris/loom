//! `loom review` template: the LLM-judged rubric prompt.

use askama::Template;
use loom_events::identifier::{MoleculeId, ProfileName, SpecLabel};

use crate::SkillIndexMarkdown;

/// One file body included in the review prompt.
///
/// A `[test]` source or `[judge]` rubric, not evidence of verifier execution.
/// `path` is the workspace-relative source location used as the section title.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ReviewSource {
    pub path: String,
    pub body: String,
}

/// Review lanes requested by the prompt.
///
/// `Both` drives the full `loom gate review` path (criterion-attached `[judge]`
/// rubrics *and* the rubric walk over the diff). `Judge` and `Rubric` are
/// the focused per-lane re-runs surfaced by `loom gate judge` /
/// `loom gate rubric` respectively, used when iterating on one lane
/// without paying the cost of the other.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum ReviewLane {
    /// Both lanes — the default for `loom gate review`.
    #[default]
    Both,
    /// `[judge]`-tier rubrics only; rubric walk suppressed.
    Judge,
    /// Rubric walk only; `[judge]` rubric bodies suppressed.
    Rubric,
}

impl ReviewLane {
    /// True when the lane includes the `[judge]` rubric evaluation.
    pub const fn includes_judge(self) -> bool {
        matches!(self, Self::Both | Self::Judge)
    }

    /// True when the lane includes the rubric walk over the diff.
    pub const fn includes_rubric(self) -> bool {
        matches!(self, Self::Both | Self::Rubric)
    }
}

/// Context for `loom review` reviewing a completed molecule.
#[derive(Template)]
#[template(path = "review.md", escape = "none")]
pub struct ReviewContext {
    /// Immutable driver-selected package snapshot; None supports partial composition only.
    pub package_context: Option<loom_protocol::context::Context>,
    pub pinned_context: String,
    pub label: SpecLabel,
    pub spec_path: String,
    pub companion_paths: Vec<String>,
    pub beads_summary: Option<String>,
    pub base_commit: Option<String>,
    pub molecule_id: Option<MoleculeId>,
    pub test_sources: Vec<ReviewSource>,
    pub judge_rubrics: Vec<ReviewSource>,
    pub scratchpad_path: String,
    /// Workspace-relative path to the project's style-rules document
    /// (`docs/style-rules.md` by default). Pinned in the review prompt so
    /// the LLM walks the rules rule-by-rule and cites each violation by
    /// rule id + file/line.
    pub style_rules: String,
    /// Which lane(s) the agent is being asked to run. Drives the template's
    /// per-lane section gates.
    pub lane: ReviewLane,
    /// Default profile for driver-minted fix-up and clarify beads under
    /// this spec.
    pub default_profile: ProfileName,
    pub skill_index: SkillIndexMarkdown,
}

impl ReviewContext {
    pub const fn finding_tokens(&self) -> &'static [loom_protocol::gate::ConcernToken] {
        loom_protocol::gate::ConcernToken::prompt_visible()
    }

    pub fn output_contract(&self) -> String {
        crate::output::contract(self.output_phase())
    }

    pub const fn output_phase(&self) -> loom_protocol::output::Phase {
        loom_protocol::output::Phase::Review
    }
}
