use askama::Template;
use loom_events::identifier::SpecLabel;

use crate::SkillIndexMarkdown;

/// Context for `loom plan [SPEC_LABEL ...]`.
#[derive(Template)]
#[template(path = "plan.md", escape = "none")]
pub struct PlanContext {
    /// Immutable driver-selected package snapshot; None supports partial composition only.
    pub package_context: Option<loom_protocol::context::Context>,
    pub pinned_context: String,
    pub anchor_labels: Vec<SpecLabel>,
    pub spec_index: String,
    pub companion_paths: Vec<String>,
    pub scratchpad_path: String,
    pub spec_conventions: String,
    pub skill_index: SkillIndexMarkdown,
}

impl PlanContext {
    pub fn output_contract(&self) -> String {
        crate::output::contract(self.output_phase())
    }

    pub const fn output_phase(&self) -> loom_protocol::output::Phase {
        loom_protocol::output::Phase::Plan
    }
}
