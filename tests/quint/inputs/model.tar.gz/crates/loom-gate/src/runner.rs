//! Runner discovery for batched tiers (`[test]`, `[judge]`).
//!
//! Toolchain-detection defaults per `specs/gate.md` § Runners
//! (`Cargo.toml` → nextest, `pyproject.toml` → pytest, `go.mod` →
//! `go test`). Per-tier overrides flow in from `LoomConfig`'s
//! `[runner.<tier>.<name>]` blocks at `<workspace>/loom.toml`; this
//! module never reads TOML from disk itself. The module also surfaces
//! silent-zero-match cases in cargo / nextest / pytest output so a
//! filtered run that matches no tests fails loudly rather than passing
//! silently — other runners are expected to fail on zero-match themselves
//! and are passed through.

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};

use displaydoc::Display;
use loom_driver::config::{self, LoomConfig, RunnerEntry};
use regex::Regex;
use thiserror::Error;

pub mod result;

use crate::annotation::{Annotation, Tier};
use crate::cache::Verdict;
use result::{Execution, SkipReason, Token};

/// Template string for a batched-tier runner.
///
/// Its placeholder is substituted at invocation time. Defaults come from toolchain
/// detection; overrides come from `LoomConfig`'s `[runner.<tier>.<name>]`
/// blocks at `<workspace>/loom.toml`.
///
/// Placeholder vocabulary, all rendered by [`RunnerTemplate::render`]:
///
/// - `{paths}` — slot-replicated and joined with ` | `. The slot is the
///   single-quoted phrase containing the placeholder (or the placeholder
///   token itself if no quotes wrap it). Matches `cargo nextest`'s
///   `-E 'test(p1) | test(p2)'` filter-expression shape.
/// - `{paths_or}` — replaced with the target list joined by ` or `
///   (pytest `-k` expression syntax).
/// - `{paths_alt}` — replaced with the target list joined by `|`
///   (regex alternation; `go test -run`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RunnerTemplate {
    pub command: String,
}

impl RunnerTemplate {
    /// Construct from a raw template string.
    pub fn new(command: impl Into<String>) -> Self {
        Self {
            command: command.into(),
        }
    }

    /// Substitute the placeholder for the joined target list and return
    /// the final command string ready to hand to a subprocess runner.
    pub fn render(&self, paths: &[&str]) -> String {
        render_template(&self.command, paths)
    }
}

/// Detect the runner template for `tier` at `repo_root`.
///
/// Per-tier overrides from `LoomConfig`'s
/// `[runner.<tier>.<name>]` blocks are resolved by the caller (the
/// dispatcher in `loom-workflow` / `main.rs`) and passed in to the
/// dispatch layer directly; this function performs detection only.
///
/// Detection order:
/// 1. `Cargo.toml` → `cargo nextest`.
/// 2. `pyproject.toml` → `pytest`.
/// 3. `go.mod` → `go test`.
/// 4. [`RunnerError::UnknownToolchain`] when nothing matches.
///
/// Only batched tiers ([`Tier::Test`], [`Tier::Judge`]) are supported;
/// other tiers receive [`RunnerError::NotBatched`].
///
/// # Errors
///
/// Returns an error when runner configuration or verifier execution fails.
pub fn discover(repo_root: &Path, tier: Tier) -> Result<RunnerTemplate, RunnerError> {
    if !matches!(tier, Tier::Test | Tier::Judge) {
        return Err(RunnerError::NotBatched { tier });
    }

    if let Some(default) = detect_default(repo_root) {
        return Ok(default);
    }

    Err(RunnerError::UnknownToolchain {
        root: repo_root.to_path_buf(),
    })
}

/// Classification of a (template or rendered) command string for the
/// purposes of silent-zero-match sniffing.
///
/// `Unknown` covers any runner the gate does not know how to sniff —
/// the spec documents that those runners are responsible for failing on
/// zero-match themselves.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RunnerKind {
    CargoTest,
    CargoNextest,
    Pytest,
    Unknown,
}

impl RunnerKind {
    /// Inspect the leading tokens of `command` and return the matching
    /// runner kind. The check is token-boundary aware, so a hypothetical
    /// `cargo testify` does not classify as `cargo test`.
    pub fn classify(command: &str) -> Self {
        let trimmed = command.trim_start();
        if starts_with_token(trimmed, "cargo nextest") {
            Self::CargoNextest
        } else if starts_with_token(trimmed, "cargo test") {
            Self::CargoTest
        } else if starts_with_token(trimmed, "pytest") {
            Self::Pytest
        } else {
            Self::Unknown
        }
    }

    /// Human-readable name embedded in zero-match diagnostics.
    pub const fn name(self) -> &'static str {
        match self {
            Self::CargoTest => "cargo test",
            Self::CargoNextest => "cargo nextest",
            Self::Pytest => "pytest",
            Self::Unknown => "unknown",
        }
    }
}

/// Post-process the runner's stdout / stderr after a successful exit and
/// surface [`RunnerError::ZeroMatch`] when the run silently matched
/// nothing.
///
/// Returns `Ok(())` for [`RunnerKind::Unknown`] — per the spec, the gate
/// documents the fail-on-zero-match expectation for unrecognised runners
/// but does not enforce it.
///
/// # Errors
///
/// Returns an error when runner configuration or verifier execution fails.
pub fn check_zero_match(command: &str, stdout: &str, stderr: &str) -> Result<(), RunnerError> {
    let kind = RunnerKind::classify(command);
    if let Some(evidence) = detect_zero_match(kind, stdout, stderr) {
        return Err(RunnerError::ZeroMatch {
            runner: kind.name(),
            evidence,
        });
    }
    Ok(())
}

/// A legacy, unstructured test batch containing skips cannot certify every target.
/// Per-target parser configurations avoid this conservative batch-wide result.
pub(crate) fn unstructured_test_outcome(
    command: &str,
    stdout: &str,
    stderr: &str,
) -> Option<(Verdict, String)> {
    let kind = RunnerKind::classify(command);
    let count = Regex::new(r"\b[1-9][0-9]* (failed|skipped|ignored)\b").ok()?;
    let mut skipped = None;
    for line in stdout.lines().chain(stderr.lines()).map(str::trim) {
        let summary = match kind {
            RunnerKind::CargoTest => line.starts_with("test result:"),
            RunnerKind::CargoNextest => line.contains("tests run:") || line.contains("test run:"),
            RunnerKind::Pytest => line.starts_with('=') && line.ends_with('='),
            RunnerKind::Unknown => false,
        };
        if !summary {
            continue;
        }
        for captures in count.captures_iter(line) {
            if captures
                .get(1)
                .is_some_and(|kind| kind.as_str() == "failed")
            {
                return Some((Verdict::Fail, batch_diagnostics(kind, stdout, stderr)));
            }
            skipped = Some((
                Verdict::Skipped,
                format!(
                    "per-target outcomes unavailable; test batch contains skips: {}",
                    batch_diagnostics(kind, stdout, stderr)
                ),
            ));
        }
    }
    skipped
}

fn batch_diagnostics(kind: RunnerKind, stdout: &str, stderr: &str) -> String {
    stdout
        .lines()
        .chain(stderr.lines())
        .filter(|line| {
            let line = line.trim_start();
            kind != RunnerKind::CargoNextest
                || !(line.starts_with("PASS [") || line.starts_with("SKIP ["))
        })
        .collect::<Vec<_>>()
        .join("\n")
}

/// Human nextest summaries count filtered tests as skips. Only explicit pass
/// receipts for every requested target can discharge that conservative fallback.
pub(crate) fn nextest_targets_passed(targets: &[&str], stdout: &str, stderr: &str) -> bool {
    !targets.is_empty()
        && targets.iter().all(|target| {
            let mut passed = false;
            for line in stdout.lines().chain(stderr.lines()).map(str::trim) {
                let Some((status, rest)) = line.split_once(" [") else {
                    continue;
                };
                let Some(name) = rest.split_whitespace().last() else {
                    continue;
                };
                if name != *target
                    && !name
                        .strip_suffix(target)
                        .is_some_and(|prefix| prefix.ends_with("::"))
                {
                    continue;
                }
                match status {
                    "PASS" => passed = true,
                    "SKIP" | "FAIL" | "TIMEOUT" | "LEAK" => return false,
                    _ => {}
                }
            }
            passed
        })
}

fn detect_zero_match(kind: RunnerKind, stdout: &str, stderr: &str) -> Option<String> {
    match kind {
        RunnerKind::CargoTest => {
            let ran_tests = stdout.lines().map(str::trim).any(|line| {
                line.strip_prefix("running ")
                    .and_then(|rest| {
                        rest.strip_suffix(" tests")
                            .or_else(|| rest.strip_suffix(" test"))
                    })
                    .and_then(|count| count.parse::<usize>().ok())
                    .is_some_and(|count| count > 0)
            });
            if ran_tests {
                None
            } else {
                stdout
                    .lines()
                    .find(|line| line.trim() == "running 0 tests")
                    .map(|line| line.trim().to_string())
            }
        }
        RunnerKind::CargoNextest => stdout
            .lines()
            .chain(stderr.lines())
            .map(str::trim)
            .find(|t| {
                t.starts_with("Starting 0 tests")
                    || t.contains(" 0 tests run:")
                    || t.contains("no tests to run")
            })
            .map(str::to_string),
        RunnerKind::Pytest => stdout
            .lines()
            .chain(stderr.lines())
            .map(str::trim)
            .find(|t| t.contains("no tests ran") || t.contains("collected 0 items"))
            .map(str::to_string),
        RunnerKind::Unknown => None,
    }
}

fn detect_default(repo_root: &Path) -> Option<RunnerTemplate> {
    if repo_root.join("Cargo.toml").is_file() {
        return Some(RunnerTemplate::new(
            "cargo nextest run --status-level skip -E 'test({paths})'",
        ));
    }
    if repo_root.join("pyproject.toml").is_file() {
        return Some(RunnerTemplate::new("pytest -k '{paths_or}'"));
    }
    if repo_root.join("go.mod").is_file() {
        return Some(RunnerTemplate::new("go test -run '{paths_alt}' ./..."));
    }
    None
}

#[expect(
    clippy::literal_string_with_formatting_args,
    reason = "runner templates intentionally use braces for dispatch-time placeholders"
)]
fn render_template(template: &str, paths: &[&str]) -> String {
    let mut s = template.to_string();
    if s.contains("{paths_or}") {
        s = s.replace("{paths_or}", &paths.join(" or "));
    }
    if s.contains("{paths_alt}") {
        s = s.replace("{paths_alt}", &paths.join("|"));
    }
    if let Some(start) = s.find("{paths}") {
        s = render_slot(&s, start, paths);
    }
    s
}

/// Replicate the slot surrounding `{paths}` per target and join with
/// ` | `. The slot is bounded by the nearest `'` on either side, or by
/// the start / end of the template when no quote is present. This makes
/// `cargo nextest run -E 'test({paths})'` expand to
/// `cargo nextest run -E 'test(p1) | test(p2)'`.
fn render_slot(template: &str, start: usize, paths: &[&str]) -> String {
    const PLACEHOLDER: &str = "{paths}";
    let end = start + PLACEHOLDER.len();

    let before = &template[..start];
    let after = &template[end..];

    let slot_lstart = before.rfind('\'').map_or(0, |i| i + 1);
    let slot_rend_local = after.find('\'').unwrap_or(after.len());

    let slot_prefix = &before[slot_lstart..];
    let slot_suffix = &after[..slot_rend_local];

    let joined = paths
        .iter()
        .map(|p| format!("{slot_prefix}{p}{slot_suffix}"))
        .collect::<Vec<_>>()
        .join(" | ");

    let before_slot = &template[..slot_lstart];
    let after_slot = &template[end + slot_rend_local..];

    format!("{before_slot}{joined}{after_slot}")
}

fn starts_with_token(input: &str, token: &str) -> bool {
    input
        .strip_prefix(token)
        .is_some_and(|rest| rest.is_empty() || rest.starts_with(char::is_whitespace))
}

/// Failures surfaced by runner discovery and zero-match sniffing.
#[derive(Debug, Clone, Display, Error)]
pub enum RunnerError {
    /// invalid {parser} runner output: {detail}
    InvalidOutput {
        parser: &'static str,
        detail: String,
    },
    /// no configured test runner claims target `{target}`; configure a tier-default runner
    UnclaimedTestTarget { target: String },
    /// runner discovery only applies to batched tiers (test, judge); got [{tier}]
    NotBatched { tier: Tier },
    /// no Cargo.toml / pyproject.toml / go.mod under {root}
    UnknownToolchain { root: PathBuf },
    /// {runner} reported zero matched tests; filter likely missed every target: {evidence}
    ZeroMatch {
        runner: &'static str,
        evidence: String,
    },
    /// runner `{name}` has invalid match regex `{pattern}`: {source}
    InvalidMatch {
        name: String,
        pattern: String,
        #[source]
        source: regex::Error,
    },
    /// runner `{name}` missing `command`
    MissingCommand { name: String },
}

/// Built-in parser for per-target runner verdicts.
///
/// The set is closed by loom; the schema-side equivalent in
/// `loom_driver::config::runner::Parser` round-trips into this enum at the
/// translation boundary (e.g. `loom-workflow` building a [`RunnerSpec`] list).
///
/// Per-tier semantics:
///
/// - [`Self::LibtestJson`] — Rust `cargo test` / `nextest`
///   `--message-format` output. One JSON event per line; this parser folds
///   `{"type":"test","event":"ok|failed|started|ignored","name":"..."}`
///   into a per-target verdict.
/// - [`Self::JunitXml`] — JUnit-XML reports. Each `<testcase classname="..."
///   name="...">` becomes one verdict; a nested `<failure>` / `<error>`
///   produces a failure, and `<skipped>` preserves an unevaluated result.
/// - [`Self::NixBuildStatus`] — `nix build`'s per-derivation output.
/// - [`Self::JsonLines`] — one
///   `{"target":"<name>","pass":bool,"evidence":"<msg>"}` per line.
/// - [`Self::ExitCode`] — the runner emits no structured stdout; the
///   process exit code is the verdict. Only meaningful for non-batched
///   runners (one annotation per invocation).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BuiltinParser {
    LibtestJson,
    JunitXml,
    NixBuildStatus,
    JsonLines,
    ExitCode,
}

/// One per-target verdict recovered from a batched runner's stdout, keyed
/// by the annotation target string the parser found in the output.
///
/// Distinct from `dispatch::VerifierVerdict` so the parser layer stays
/// free of the dispatch error type — the dispatcher walks the parser's
/// map and folds matches into `VerifierVerdict` records on the way out.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ParsedVerdict {
    pub target: String,
    pub outcome: Verdict,
    pub evidence: String,
    pub execution: Option<Execution>,
    pub skip_reason: Option<SkipReason>,
}

/// Runtime form of one `[runner.<tier>.<name>]` entry.
///
/// Its regex is compiled, parser tag normalised, and templates retained as raw strings ready
/// for substitution. Consumers translate from the TOML schema in
/// `loom_driver::config::runner::RunnerEntry` to this type at the binary
/// boundary.
#[derive(Debug, Clone)]
pub struct RunnerSpec {
    /// Identifier from the TOML key (`[runner.<tier>.<name>]`). Surfaced in
    /// errors and progress output so consumers can pinpoint the offending
    /// runner.
    pub name: String,
    /// Compiled match regex over the annotation target. `None` means the
    /// runner is the tier default (matches every annotation in the tier).
    pub match_regex: Option<Regex>,
    /// Command template; substitutes `{filter}` / `{targets}` with the
    /// joined per-target string and `{capture_N}` with the corresponding
    /// capture from the first matched target.
    pub command: String,
    /// Per-target template; substitutes `{name}` with the full target and
    /// `{capture_N}` with the corresponding regex capture.
    pub target_template: String,
    /// Separator inserted between formatted targets to build
    /// `{filter}` / `{targets}`.
    pub join: String,
    /// Built-in parser that recovers per-target verdicts from stdout.
    pub parse: BuiltinParser,
    /// Repo-relative cwd override. Resolution against the workspace root
    /// happens in the dispatcher.
    pub cwd: Option<PathBuf>,
    /// Tier this runner belongs to. `None` is reserved for tests that
    /// construct runner specs directly; production-compiled runners carry
    /// their tier so integrity and input-query paths cannot cross-claim a
    /// sibling tier's annotation.
    pub tier: Option<Tier>,
    /// Optional command template for the runner's input-query. A
    /// `{print_inputs}` placement marks where the `--print-inputs` flag
    /// lands in the verifier's own argv; omitting it appends the flag after
    /// the verifier's own arguments. `Some(..)` opts the runner's verifiers
    /// into the input-query protocol; `None` leaves them on the
    /// conservative always-run default. See `specs/gate.md` § Runners.
    pub inputs: Option<String>,
    pub skip_policy: config::SkipPolicy,
    pub skip_capabilities: Vec<Token>,
}

impl RunnerSpec {
    /// Compile a runner spec from its raw schema fields. Validates the
    /// regex eagerly so dispatch never fails partway through a tier.
    ///
    /// # Errors
    ///
    /// Returns an error when runner configuration or verifier execution fails.
    pub fn compile(
        name: impl Into<String>,
        match_regex: Option<&str>,
        command: impl Into<String>,
        target_template: impl Into<String>,
        join: impl Into<String>,
        parse: BuiltinParser,
        cwd: Option<PathBuf>,
    ) -> Result<Self, RunnerError> {
        let name = name.into();
        let match_regex = match match_regex {
            Some(pattern) => {
                Some(
                    Regex::new(pattern).map_err(|source| RunnerError::InvalidMatch {
                        name: name.clone(),
                        pattern: pattern.to_string(),
                        source,
                    })?,
                )
            }
            None => None,
        };
        Ok(Self {
            name,
            match_regex,
            command: command.into(),
            target_template: target_template.into(),
            join: join.into(),
            parse,
            cwd,
            tier: None,
            inputs: None,
            skip_policy: config::SkipPolicy::Deny,
            skip_capabilities: Vec::new(),
        })
    }

    /// Attach the owning annotation tier, chained after [`Self::compile`].
    #[must_use]
    pub const fn with_tier(mut self, tier: Tier) -> Self {
        self.tier = Some(tier);
        self
    }

    /// Attach the input-query template (the `inputs` schema field),
    /// chained after [`Self::compile`]. `None` leaves the runner on the
    /// conservative always-run default.
    #[must_use]
    pub fn with_inputs(mut self, inputs: Option<String>) -> Self {
        self.inputs = inputs;
        self
    }

    /// Whether `target` matches this runner. A default runner
    /// (`match_regex = None`) matches everything; otherwise the compiled
    /// regex decides.
    pub fn matches(&self, target: &str) -> bool {
        self.match_regex
            .as_ref()
            .is_none_or(|re| re.is_match(target))
    }

    /// Whether this runner may own an annotation in `tier`.
    pub fn applies_to(&self, tier: Tier) -> bool {
        self.tier.is_none_or(|owning_tier| owning_tier == tier)
    }
}

/// Built-in batcher for `loom-walk` `[check]` annotations.
///
/// Ships in code (not `loom.toml`) so the batching is the
/// default behaviour; operators can layer overrides via
/// `[runner.check.<name>]` entries but cannot accidentally remove it.
///
/// Declares an `inputs` query (`cargo run -p loom-walk -- {targets}
/// {print_inputs}`) so each walk answers `--print-inputs` with its scanned
/// file set: the gate scopes the ~77 loom-walk verifiers precisely under
/// `loom gate verify --files` instead of always-running them, and the
/// integrity gate holds the walks to the inputs-protocol contract.
///
/// # Errors
///
/// Returns an error when runner configuration or verifier execution fails.
pub fn builtin_loom_walk_runner() -> Result<RunnerSpec, RunnerError> {
    Ok(RunnerSpec::compile(
        "builtin-loom-walk",
        Some(r"^cargo run -p loom-walk -- (\S+)$"),
        "cargo run -p loom-walk -- {targets}",
        "{capture_1}",
        " ",
        BuiltinParser::JsonLines,
        None,
    )?
    .with_tier(Tier::Check)
    .with_inputs(Some(
        "cargo run -p loom-walk -- {targets} {print_inputs}".to_string(),
    )))
}

/// Compile one `[runner.<tier>.<name>]` schema entry into runtime form.
/// The `command` field is required; missing it is a
/// [`RunnerError::MissingCommand`].
///
/// # Errors
///
/// Returns an error when runner configuration or verifier execution fails.
#[expect(
    clippy::literal_string_with_formatting_args,
    reason = "runner templates intentionally use braces for dispatch-time placeholders"
)]
pub fn compile_runner_entry(name: &str, entry: &RunnerEntry) -> Result<RunnerSpec, RunnerError> {
    let command = entry
        .command
        .as_deref()
        .ok_or_else(|| RunnerError::MissingCommand {
            name: name.to_string(),
        })?;
    let target = entry.target.as_deref().unwrap_or("{name}");
    let join = entry.join.as_deref().unwrap_or(" ");
    let parse = match entry.parse {
        Some(config::Parser::LibtestJson) => BuiltinParser::LibtestJson,
        Some(config::Parser::JunitXml) => BuiltinParser::JunitXml,
        Some(config::Parser::NixBuildStatus) => BuiltinParser::NixBuildStatus,
        Some(config::Parser::JsonLines) | None => BuiltinParser::JsonLines,
        Some(config::Parser::ExitCode) => BuiltinParser::ExitCode,
    };
    let cwd = entry.cwd.as_deref().map(PathBuf::from);
    let skip_capabilities = entry
        .skip_capabilities
        .iter()
        .cloned()
        .map(Token::try_from)
        .collect::<Result<Vec<_>, _>>()
        .map_err(|detail| RunnerError::InvalidOutput {
            parser: "skip-policy",
            detail,
        })?;
    if entry.skip_policy != config::SkipPolicy::Deny && parse != BuiltinParser::JsonLines {
        return Err(RunnerError::InvalidOutput {
            parser: "skip-policy",
            detail: "sandbox-capability requires json-lines metadata".into(),
        });
    }
    let mut spec = RunnerSpec::compile(
        name,
        entry.match_regex.as_deref(),
        command,
        target,
        join,
        parse,
        cwd,
    )?
    .with_inputs(entry.inputs.clone());
    spec.skip_policy = entry.skip_policy;
    spec.skip_capabilities = skip_capabilities;
    Ok(spec)
}

/// Compile declared runners into runtime [`RunnerSpec`] values.
///
/// Includes named `[runner.<tier>.<name>]` runners and the implicit tier-default runner.
/// Matching keys on target shape, not tier, so the caller decides which
/// annotations flow through the returned specs; the `[check]`-tier builtin
/// batcher is layered by the caller, not here.
///
/// # Errors
///
/// Returns an error when runner configuration or verifier execution fails.
pub fn compile_tier_runners(
    config: &LoomConfig,
    tier: &str,
) -> Result<Vec<RunnerSpec>, RunnerError> {
    let owning_tier = Tier::from_wire(tier);
    let mut specs = Vec::new();
    if let Some(tier_block) = config.runner.tier(tier) {
        for (name, entry) in &tier_block.runners {
            let mut spec = match owning_tier {
                Some(t) => compile_runner_entry(name, entry)?.with_tier(t),
                None => compile_runner_entry(name, entry)?,
            };
            if spec.cwd.is_none() {
                spec.cwd = tier_block.cwd.as_ref().map(PathBuf::from);
            }
            specs.push(spec);
        }
        if let Some(default_entry) = tier_block.default_runner() {
            let mut spec = match owning_tier {
                Some(t) => compile_runner_entry("default", &default_entry)?.with_tier(t),
                None => compile_runner_entry("default", &default_entry)?,
            };
            if spec.cwd.is_none() {
                spec.cwd = tier_block.cwd.as_ref().map(PathBuf::from);
            }
            specs.push(spec);
        }
    }
    Ok(specs)
}

/// Resolve runner specifications for forward-integrity checks.
///
/// The gate checks every annotation regardless of tier, so it
/// receives the tagged union of the builtin loom-walk batcher plus
/// `[check]`- and `[system]`-tier runners. Matching remains tier-specific:
/// a `[check]` annotation can be owned only by a `[runner.check.*]` runner,
/// and a `[system]` annotation only by `[runner.system.*]`.
///
/// # Errors
///
/// Returns an error when runner configuration or verifier execution fails.
pub fn integrity_runner_specs(config: &LoomConfig) -> Result<Vec<RunnerSpec>, RunnerError> {
    let mut specs = vec![builtin_loom_walk_runner()?];
    specs.extend(compile_tier_runners(config, "check")?);
    specs.extend(compile_tier_runners(config, "system")?);
    Ok(specs)
}

/// One annotation matched by a [`RunnerSpec`].
///
/// Carries its rendered per-target string and the captures the regex produced. Carried through
/// dispatch so the parser can map verdicts back to the original
/// annotation by target name.
#[derive(Debug, Clone)]
pub struct MatchedAnnotation<'a> {
    pub annotation: &'a Annotation,
    /// `target_template` rendered against `{name}` + `{capture_N}`. This is
    /// what appears inside the joined batch string; this is also the key
    /// the parser uses when reporting per-target results.
    pub rendered_target: String,
}

/// First-match-wins grouping of `annotations` against `specs`. Annotations
/// whose target none of `specs` accept fall into `unmatched` and are
/// dispatched by the caller's per-annotation fallback.
///
/// Group ordering follows `specs` declaration order. Within a group,
/// matched annotations preserve their order in `annotations`.
pub fn group_by_runner<'s, 'a>(
    specs: &'s [RunnerSpec],
    annotations: &'a [Annotation],
) -> (Vec<RunnerGroup<'s, 'a>>, Vec<&'a Annotation>) {
    let mut groups: Vec<RunnerGroup<'s, 'a>> = specs
        .iter()
        .map(|spec| RunnerGroup {
            spec,
            matched: Vec::new(),
        })
        .collect();
    let mut unmatched: Vec<&'a Annotation> = Vec::new();

    for annotation in annotations {
        let mut placed = false;
        for group in &mut groups {
            if group.spec.applies_to(annotation.tier) && group.spec.matches(&annotation.target) {
                let rendered_target = render_target(group.spec, &annotation.target);
                group.matched.push(MatchedAnnotation {
                    annotation,
                    rendered_target,
                });
                placed = true;
                break;
            }
        }
        if !placed {
            unmatched.push(annotation);
        }
    }

    groups.retain(|g| !g.matched.is_empty());
    (groups, unmatched)
}

/// All annotations a single [`RunnerSpec`] claimed, in input order.
#[derive(Debug)]
pub struct RunnerGroup<'s, 'a> {
    pub spec: &'s RunnerSpec,
    pub matched: Vec<MatchedAnnotation<'a>>,
}

impl RunnerGroup<'_, '_> {
    /// Render the runner's batch command for this group: join every
    /// matched annotation's `rendered_target` with `spec.join` to form
    /// `{filter}` / `{targets}`, then substitute into `spec.command`.
    /// `{capture_N}` in `command` references the first matched target's
    /// captures so command-template captures are well-defined.
    pub fn render_command(&self) -> String {
        let joined = self.joined_targets();
        let first_target = self.matched.first().map(|m| m.annotation.target.as_str());
        substitute_command(
            &self.spec.command,
            &joined,
            self.spec.match_regex.as_ref(),
            first_target,
        )
    }

    /// Render the runner's input-query command for this group, or `None`
    /// when the runner declares no `inputs` query and so stays on the
    /// conservative always-run default. `{filter}` / `{targets}` /
    /// `{capture_N}` substitute exactly as in [`Self::render_command`]; the
    /// `--print-inputs` flag lands at the template's `{print_inputs}`
    /// marker, or is appended after the verifier's own arguments when the
    /// marker is absent. Per `specs/gate.md` § Runners the query is issued
    /// through this template — never by prepending the flag to the
    /// command's first token.
    pub fn render_inputs_query(&self) -> Option<String> {
        let template = self.spec.inputs.as_deref()?;
        let joined = self.joined_targets();
        let first_target = self.matched.first().map(|m| m.annotation.target.as_str());
        let rendered = substitute_command(
            template,
            &joined,
            self.spec.match_regex.as_ref(),
            first_target,
        );
        Some(place_print_inputs(&rendered))
    }

    fn joined_targets(&self) -> String {
        let mut seen = HashSet::new();
        self.matched
            .iter()
            .map(|matched| matched.rendered_target.as_str())
            .filter(|target| seen.insert(*target))
            .collect::<Vec<_>>()
            .join(&self.spec.join)
    }
}

/// The `--print-inputs` query flag, placed where the runner's `inputs`
/// template marks it.
const PRINT_INPUTS_FLAG: &str = "--print-inputs";

/// Substitute the `{print_inputs}` marker with the query flag, or append
/// the flag after the verifier's own arguments when the template omits the
/// marker. Per `specs/gate.md` § Runners the flag's placement is the
/// template's decision, never a prepend to `tokens[0]`.
fn place_print_inputs(rendered: &str) -> String {
    const MARKER: &str = "{print_inputs}";
    if rendered.contains(MARKER) {
        rendered.replace(MARKER, PRINT_INPUTS_FLAG)
    } else {
        format!("{rendered} {PRINT_INPUTS_FLAG}")
    }
}

fn render_target(spec: &RunnerSpec, annotation_target: &str) -> String {
    let mut rendered = spec.target_template.replace("{name}", annotation_target);
    if let Some(re) = &spec.match_regex {
        rendered = substitute_captures(&rendered, re, annotation_target);
    }
    rendered
}

fn substitute_command(
    template: &str,
    joined: &str,
    match_regex: Option<&Regex>,
    first_target: Option<&str>,
) -> String {
    let mut out = template
        .replace("{filter}", joined)
        .replace("{targets}", joined);
    if let (Some(re), Some(target)) = (match_regex, first_target) {
        out = substitute_captures(&out, re, target);
    }
    out
}

fn substitute_captures(template: &str, re: &Regex, target: &str) -> String {
    let Some(caps) = re.captures(target) else {
        return template.to_string();
    };
    let mut out = template.to_string();
    for i in 1..caps.len() {
        let needle = format!("{{capture_{i}}}");
        if let Some(m) = caps.get(i) {
            out = out.replace(&needle, m.as_str());
        }
    }
    out
}

/// Parse per-target verdicts from batched runner output.
///
/// Missing targets remain dispatch failures. Structured test reports retain
/// passes, failures and skips separately; a skip is never an observed pass.
///
/// # Errors
/// Returns an error for malformed or unsupported `JUnit` reports.
pub fn parse_runner_output(
    parser: BuiltinParser,
    stdout: &str,
    stderr: &str,
    exit_success: bool,
) -> Result<HashMap<String, ParsedVerdict>, RunnerError> {
    Ok(match parser {
        BuiltinParser::JsonLines => parse_json_lines(stdout)?,
        BuiltinParser::LibtestJson => parse_libtest_json(stdout)?,
        BuiltinParser::JunitXml => parse_junit_xml(stdout)?,
        BuiltinParser::NixBuildStatus => parse_nix_build_status(stdout, stderr),
        BuiltinParser::ExitCode => parse_exit_code(stdout, stderr, exit_success),
    })
}

fn parse_json_lines(stdout: &str) -> Result<HashMap<String, ParsedVerdict>, RunnerError> {
    let mut out = HashMap::new();
    for (index, raw) in stdout.lines().enumerate() {
        let line = raw.trim();
        if line.is_empty() {
            continue;
        }
        let invalid = |detail| RunnerError::InvalidOutput {
            parser: "json-lines",
            detail: format!("line {}: {detail}", index + 1),
        };
        let wire = serde_json::from_str::<result::Wire>(line)
            .map_err(|error| invalid(error.to_string()))?;
        let verdict = wire.resolve().map_err(invalid)?;
        if out.contains_key(&verdict.target) {
            return Err(invalid(format!("duplicate target `{}`", verdict.target)));
        }
        out.insert(verdict.target.clone(), verdict);
    }
    Ok(out)
}

fn parse_libtest_json(stdout: &str) -> Result<HashMap<String, ParsedVerdict>, RunnerError> {
    let mut out = HashMap::new();
    for (index, raw) in stdout.lines().enumerate() {
        let invalid = |detail| RunnerError::InvalidOutput {
            parser: "libtest-json",
            detail: format!("line {}: {detail}", index + 1),
        };
        let line = raw.trim();
        if line.is_empty() || !line.starts_with('{') {
            continue;
        }
        let value = serde_json::from_str::<serde_json::Value>(line)
            .map_err(|error| invalid(error.to_string()))?;
        let Some(obj) = value.as_object() else {
            continue;
        };
        if obj.get("type").and_then(|v| v.as_str()) != Some("test") {
            continue;
        }
        let name = obj
            .get("name")
            .and_then(|value| value.as_str())
            .filter(|name| !name.trim().is_empty())
            .ok_or_else(|| invalid("missing test name".into()))?;
        let event = obj.get("event").and_then(|v| v.as_str()).unwrap_or("");
        let (outcome, evidence) = match event {
            "ok" => (Verdict::Pass, String::from("ok")),
            "failed" => {
                let stdout_field = obj
                    .get("stdout")
                    .and_then(|v| v.as_str())
                    .unwrap_or("")
                    .to_string();
                (Verdict::Fail, stdout_field)
            }
            "ignored" => (
                Verdict::Skipped,
                obj.get("message")
                    .and_then(serde_json::Value::as_str)
                    .unwrap_or("ignored")
                    .to_string(),
            ),
            "started" => continue,
            _ => return Err(invalid(format!("unknown test event `{event}`"))),
        };
        if out.contains_key(name) {
            return Err(invalid(format!("duplicate terminal result `{name}`")));
        }
        out.insert(
            name.to_string(),
            ParsedVerdict {
                target: name.to_string(),
                outcome,
                evidence,
                execution: None,
                skip_reason: None,
            },
        );
    }
    Ok(out)
}

fn parse_junit_xml(stdout: &str) -> Result<HashMap<String, ParsedVerdict>, RunnerError> {
    let invalid = |detail: String| RunnerError::InvalidOutput {
        parser: "junit-xml",
        detail,
    };
    let document =
        roxmltree::Document::parse(stdout).map_err(|error| invalid(error.to_string()))?;
    let root = document.root_element();
    if !root.has_tag_name("testsuites") && !root.has_tag_name("testsuite") {
        return Err(invalid("expected a testsuite or testsuites root".into()));
    }
    let mut out = HashMap::new();
    for case in document
        .descendants()
        .filter(|node| node.has_tag_name("testcase"))
    {
        if !case
            .parent()
            .is_some_and(|parent| parent.has_tag_name("testsuite"))
        {
            return Err(invalid(
                "testcase must be a direct child of testsuite".into(),
            ));
        }
        let name = case
            .attribute("name")
            .filter(|name| !name.trim().is_empty())
            .ok_or_else(|| invalid("testcase has no nonempty name".into()))?;
        let classname = case.attribute("classname").unwrap_or("");
        let key = if classname.is_empty() {
            name.to_string()
        } else {
            format!("{classname}.{name}")
        };
        let children = case
            .children()
            .filter(roxmltree::Node::is_element)
            .collect::<Vec<_>>();
        if children.iter().any(|node| {
            node.tag_name().namespace().is_some()
                || !matches!(
                    node.tag_name().name(),
                    "failure" | "error" | "skipped" | "system-out" | "system-err" | "properties"
                )
        }) {
            return Err(invalid(format!("unsupported testcase child in `{key}`")));
        }
        let failed = children
            .iter()
            .find(|node| node.has_tag_name("failure") || node.has_tag_name("error"));
        let skipped = children.iter().find(|node| node.has_tag_name("skipped"));
        let (outcome, reason) = if let Some(node) = failed {
            (Verdict::Fail, Some(node))
        } else if let Some(node) = skipped {
            (Verdict::Skipped, Some(node))
        } else {
            if case
                .attribute("status")
                .is_some_and(|status| status != "run")
                || case
                    .attribute("result")
                    .is_some_and(|result| result != "completed")
            {
                return Err(invalid(format!(
                    "unsupported testcase status/result in `{key}`"
                )));
            }
            (Verdict::Pass, None)
        };
        let evidence = reason.map_or_else(
            || "ok".to_string(),
            |node| {
                node.attribute("message")
                    .filter(|message| !message.trim().is_empty())
                    .map_or_else(
                        || {
                            let text = node
                                .descendants()
                                .filter(roxmltree::Node::is_text)
                                .filter_map(|part| part.text())
                                .collect::<String>();
                            if text.trim().is_empty() {
                                outcome.as_wire().to_string()
                            } else {
                                text.trim().to_string()
                            }
                        },
                        str::to_string,
                    )
            },
        );
        if out
            .insert(
                key.clone(),
                ParsedVerdict {
                    target: key.clone(),
                    outcome,
                    evidence,
                    execution: None,
                    skip_reason: None,
                },
            )
            .is_some()
        {
            return Err(invalid(format!("duplicate testcase identity `{key}`")));
        }
    }
    Ok(out)
}

fn parse_nix_build_status(stdout: &str, stderr: &str) -> HashMap<String, ParsedVerdict> {
    let mut out = HashMap::new();
    let combined: Vec<&str> = stdout.lines().chain(stderr.lines()).collect();
    let Ok(derivation_re) = Regex::new(r"/nix/store/[a-z0-9]+-([^/'\s]+?)\.drv") else {
        return out;
    };
    let mut failed: HashMap<String, String> = HashMap::new();
    for line in &combined {
        if (line.starts_with("error: builder for ") || line.starts_with("error: build of "))
            && let Some(cap) = derivation_re.captures(line)
            && let Some(name) = cap.get(1)
        {
            failed.insert(name.as_str().to_string(), (*line).to_string());
        }
    }
    let mut built = HashSet::new();
    for line in &combined {
        if (line.starts_with("building ") || line.contains("building '"))
            && let Some(cap) = derivation_re.captures(line)
            && let Some(name) = cap.get(1)
        {
            built.insert(name.as_str().to_string());
        }
    }
    for name in &built {
        let (pass, evidence) = match failed.get(name) {
            Some(line) => (false, line.clone()),
            None => (true, String::from("built")),
        };
        out.insert(
            name.clone(),
            ParsedVerdict {
                target: name.clone(),
                outcome: pass_outcome(pass),
                evidence,
                execution: None,
                skip_reason: None,
            },
        );
    }
    for (name, line) in failed {
        out.entry(name.clone()).or_insert(ParsedVerdict {
            target: name,
            outcome: Verdict::Fail,
            evidence: line,
            execution: None,
            skip_reason: None,
        });
    }
    out
}

const fn pass_outcome(pass: bool) -> Verdict {
    if pass { Verdict::Pass } else { Verdict::Fail }
}

fn parse_exit_code(
    stdout: &str,
    stderr: &str,
    exit_success: bool,
) -> HashMap<String, ParsedVerdict> {
    let mut out = HashMap::new();
    let evidence = if exit_success {
        stdout.trim().to_string()
    } else {
        stderr.trim().to_string()
    };
    out.insert(
        String::new(),
        ParsedVerdict {
            target: String::new(),
            outcome: pass_outcome(exit_success),
            evidence,
            execution: None,
            skip_reason: None,
        },
    );
    out
}

#[cfg(test)]
mod tests {
    #![expect(
        clippy::literal_string_with_formatting_args,
        reason = "runner fixtures intentionally contain dispatch-time template placeholders"
    )]
    #![allow(clippy::unwrap_used)]
    use super::*;

    use std::fs;

    use tempfile::tempdir;

    #[test]
    fn detect_default_for_cargo_repo() {
        let dir = tempdir().unwrap();
        fs::write(dir.path().join("Cargo.toml"), "[workspace]\n").unwrap();

        let template = discover(dir.path(), Tier::Test).unwrap();
        assert_eq!(
            template.command,
            "cargo nextest run --status-level skip -E 'test({paths})'"
        );

        let judge = discover(dir.path(), Tier::Judge).unwrap();
        assert_eq!(
            judge.command,
            "cargo nextest run --status-level skip -E 'test({paths})'"
        );
    }

    #[test]
    fn detect_default_for_python_repo() {
        let dir = tempdir().unwrap();
        fs::write(dir.path().join("pyproject.toml"), "[project]\nname='x'\n").unwrap();

        let template = discover(dir.path(), Tier::Test).unwrap();
        assert_eq!(template.command, "pytest -k '{paths_or}'");
    }

    #[test]
    fn detect_default_for_go_repo() {
        let dir = tempdir().unwrap();
        fs::write(dir.path().join("go.mod"), "module example.com/x\n").unwrap();

        let template = discover(dir.path(), Tier::Test).unwrap();
        assert_eq!(template.command, "go test -run '{paths_alt}' ./...");
    }

    #[test]
    fn unknown_toolchain_errors_cleanly() {
        let dir = tempdir().unwrap();
        let err = discover(dir.path(), Tier::Test).unwrap_err();
        assert!(matches!(err, RunnerError::UnknownToolchain { .. }));
        let msg = err.to_string();
        assert!(
            msg.contains("Cargo.toml") && msg.contains("pyproject.toml") && msg.contains("go.mod"),
            "message names the detected markers: {msg}"
        );
    }

    #[test]
    fn discover_ignores_legacy_loom_config_toml() {
        // The retired second config-file read path used to read
        // `.loom/config.toml`; the module must not see it any more.
        let dir = tempdir().unwrap();
        fs::write(dir.path().join("Cargo.toml"), "[workspace]\n").unwrap();
        let legacy = dir.path().join(".loom");
        fs::create_dir_all(&legacy).unwrap();
        fs::write(
            legacy.join("config.toml"),
            "[runner]\ntest = \"should-never-be-read {paths}\"\n",
        )
        .unwrap();

        let template = discover(dir.path(), Tier::Test).unwrap();
        assert_eq!(
            template.command, "cargo nextest run --status-level skip -E 'test({paths})'",
            "discover must use toolchain detection only; .loom/config.toml is retired"
        );
    }

    #[test]
    fn check_and_system_tiers_are_not_batched() {
        let dir = tempdir().unwrap();
        fs::write(dir.path().join("Cargo.toml"), "[workspace]\n").unwrap();

        let check = discover(dir.path(), Tier::Check).unwrap_err();
        assert!(matches!(
            check,
            RunnerError::NotBatched { tier: Tier::Check }
        ));
        let system = discover(dir.path(), Tier::System).unwrap_err();
        assert!(matches!(
            system,
            RunnerError::NotBatched { tier: Tier::System }
        ));
    }

    #[test]
    fn render_substitutes_paths_or_with_or_join() {
        let t = RunnerTemplate::new("pytest -k '{paths_or}'");
        assert_eq!(t.render(&["a", "b", "c"]), "pytest -k 'a or b or c'");
    }

    #[test]
    fn render_substitutes_paths_alt_with_pipe_join() {
        let t = RunnerTemplate::new("go test -run '{paths_alt}' ./...");
        assert_eq!(
            t.render(&["TestA", "TestB"]),
            "go test -run 'TestA|TestB' ./..."
        );
    }

    #[test]
    fn render_slot_replicates_within_single_quotes_for_nextest() {
        let t = RunnerTemplate::new("cargo nextest run -E 'test({paths})'");
        assert_eq!(
            t.render(&["p1", "p2", "p3"]),
            "cargo nextest run -E 'test(p1) | test(p2) | test(p3)'"
        );
    }

    #[test]
    fn render_slot_with_single_target_emits_single_slot() {
        let t = RunnerTemplate::new("cargo nextest run -E 'test({paths})'");
        assert_eq!(t.render(&["solo"]), "cargo nextest run -E 'test(solo)'");
    }

    #[test]
    fn render_slot_without_quotes_uses_whole_template_as_slot() {
        let t = RunnerTemplate::new("mytool {paths}");
        assert_eq!(t.render(&["a", "b"]), "mytool a | mytool b");
    }

    #[test]
    fn render_passes_through_template_with_no_placeholder() {
        let t = RunnerTemplate::new("no-placeholder-here");
        assert_eq!(t.render(&["a"]), "no-placeholder-here");
    }

    #[test]
    fn render_full_toolchain_defaults_round_trip() {
        let cargo = RunnerTemplate::new("cargo nextest run -E 'test({paths})'");
        let pytest = RunnerTemplate::new("pytest -k '{paths_or}'");
        let go = RunnerTemplate::new("go test -run '{paths_alt}' ./...");

        assert_eq!(
            cargo.render(&["mod::a", "mod::b"]),
            "cargo nextest run -E 'test(mod::a) | test(mod::b)'"
        );
        assert_eq!(
            pytest.render(&["test_a", "test_b"]),
            "pytest -k 'test_a or test_b'"
        );
        assert_eq!(
            go.render(&["TestA", "TestB"]),
            "go test -run 'TestA|TestB' ./..."
        );
    }

    #[test]
    fn classify_recognises_cargo_test_cargo_nextest_pytest() {
        assert_eq!(
            RunnerKind::classify("cargo test --workspace"),
            RunnerKind::CargoTest
        );
        assert_eq!(
            RunnerKind::classify("cargo nextest run -E 'test(x)'"),
            RunnerKind::CargoNextest
        );
        assert_eq!(RunnerKind::classify("pytest -k x"), RunnerKind::Pytest);
        assert_eq!(RunnerKind::classify("my-runner"), RunnerKind::Unknown);
        assert_eq!(RunnerKind::classify(""), RunnerKind::Unknown);
    }

    #[test]
    fn classify_token_boundary_avoids_false_positive_on_cargo_testify() {
        assert_eq!(
            RunnerKind::classify("cargo testify --foo"),
            RunnerKind::Unknown
        );
        assert_eq!(
            RunnerKind::classify("pytest-something"),
            RunnerKind::Unknown
        );
    }

    #[test]
    fn zero_match_detects_cargo_test_running_zero_tests() {
        let stdout = "\
running 0 tests

test result: ok. 0 passed; 0 failed; 0 ignored; 0 measured; 1 filtered out
";
        let err = check_zero_match("cargo test -- missing_name", stdout, "").unwrap_err();
        match err {
            RunnerError::ZeroMatch { runner, evidence } => {
                assert_eq!(runner, "cargo test");
                assert_eq!(evidence, "running 0 tests");
            }
            other => panic!("expected ZeroMatch, got {other:?}"),
        }
    }

    #[test]
    fn zero_match_detects_cargo_nextest_starting_zero_tests() {
        let stdout =
            "    Starting 0 tests across 5 binaries (run ID: abc, nextest profile: default)\n";
        let err = check_zero_match("cargo nextest run -E 'test(nope)'", stdout, "").unwrap_err();
        assert!(matches!(
            err,
            RunnerError::ZeroMatch {
                runner: "cargo nextest",
                ..
            }
        ));
    }

    #[test]
    fn zero_match_detects_cargo_nextest_summary_zero_tests_run() {
        let stdout = "------------\n     Summary [   0.011s] 0 tests run: 0 passed, 0 skipped\n";
        let err = check_zero_match("cargo nextest run", stdout, "").unwrap_err();
        assert!(matches!(err, RunnerError::ZeroMatch { .. }));
    }

    #[test]
    fn zero_match_does_not_false_positive_on_nextest_count_ending_in_zero() {
        let stdout =
            "------------\n     Summary [   0.840s] 310 tests run: 310 passed, 1105 skipped\n";
        check_zero_match("cargo nextest run", stdout, "").unwrap();
    }

    #[test]
    fn zero_match_detects_pytest_no_tests_ran() {
        let stdout =
            "collected 0 items\n\n================= no tests ran in 0.01s =================\n";
        let err = check_zero_match("pytest -k missing", stdout, "").unwrap_err();
        assert!(matches!(
            err,
            RunnerError::ZeroMatch {
                runner: "pytest",
                ..
            }
        ));
    }

    #[test]
    fn zero_match_passes_when_runner_actually_ran_tests() {
        let stdout = "\
running 3 tests
test alpha ... ok
test beta ... ok
test gamma ... ok

test result: ok. 3 passed; 0 failed
";
        check_zero_match("cargo test", stdout, "").unwrap();
    }

    #[test]
    fn zero_match_passes_for_unrecognised_runner_even_with_zero_in_output() {
        let stdout = "running 0 tests\n";
        check_zero_match("my-custom-runner --tests x", stdout, "").unwrap();
    }

    #[test]
    fn zero_match_inspects_stderr_for_pytest_and_nextest() {
        let stderr = "Starting 0 tests across 1 binaries (run ID: abc, nextest profile: default)";
        let err = check_zero_match("cargo nextest run", "", stderr).unwrap_err();
        assert!(matches!(err, RunnerError::ZeroMatch { .. }));
    }

    #[test]
    fn not_batched_error_message_names_the_tier() {
        let err = RunnerError::NotBatched { tier: Tier::Check };
        assert_eq!(
            err.to_string(),
            "runner discovery only applies to batched tiers (test, judge); got [check]"
        );
    }

    fn ann(tier: Tier, target: &str) -> Annotation {
        Annotation {
            tier,
            target: target.into(),
            source_spec: PathBuf::from("specs/a.md"),
            line: 1,
            criterion_line: 1,
            pending: false,
        }
    }

    #[test]
    fn runner_spec_compile_rejects_invalid_regex() {
        let err = RunnerSpec::compile(
            "bad",
            Some("("),
            "cmd",
            "{name}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap_err();
        match err {
            RunnerError::InvalidMatch { name, pattern, .. } => {
                assert_eq!(name, "bad");
                assert_eq!(pattern, "(");
            }
            other => panic!("expected InvalidMatch, got {other:?}"),
        }
    }

    #[test]
    fn runner_spec_compile_defaults_inputs_to_none() {
        let spec = RunnerSpec::compile(
            "default",
            None,
            "cmd {targets}",
            "{name}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap();
        assert!(
            spec.inputs.is_none(),
            "compile leaves the runner on the always-run default"
        );
    }

    #[test]
    fn runner_spec_with_inputs_attaches_query_template() {
        let spec = RunnerSpec::compile(
            "walk",
            Some(r"^cargo run -p loom-walk -- (\S+)$"),
            "cargo run -p loom-walk -- {targets}",
            "{capture_1}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap()
        .with_inputs(Some(
            "cargo run -p loom-walk -- {targets} {print_inputs}".to_string(),
        ));
        assert_eq!(
            spec.inputs.as_deref(),
            Some("cargo run -p loom-walk -- {targets} {print_inputs}")
        );
    }

    #[test]
    fn runner_spec_with_inputs_none_keeps_default() {
        let spec = RunnerSpec::compile(
            "default",
            None,
            "cmd {targets}",
            "{name}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap()
        .with_inputs(None);
        assert!(spec.inputs.is_none());
    }

    #[test]
    fn runner_spec_with_no_regex_matches_every_target() {
        let spec = RunnerSpec::compile(
            "default",
            None,
            "cmd {targets}",
            "{name}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap();
        assert!(spec.matches("crate::a::ok"));
        assert!(spec.matches("anything"));
    }

    #[test]
    fn runner_spec_with_regex_matches_only_when_pattern_matches() {
        let spec = RunnerSpec::compile(
            "nix",
            Some(r"^nix (build|run) \.#(\S+)$"),
            "nix build {targets}",
            ".#{capture_2}",
            " ",
            BuiltinParser::NixBuildStatus,
            None,
        )
        .unwrap();
        assert!(spec.matches("nix build .#test-loom"));
        assert!(spec.matches("nix run .#test-loom"));
        assert!(!spec.matches("cargo nextest run"));
    }

    #[test]
    fn group_by_runner_first_match_wins_in_declaration_order() {
        let nix = RunnerSpec::compile(
            "nix",
            Some(r"^nix "),
            "nix build {targets}",
            "{name}",
            " ",
            BuiltinParser::NixBuildStatus,
            None,
        )
        .unwrap();
        let fallback = RunnerSpec::compile(
            "default",
            None,
            "default {targets}",
            "{name}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap();
        let specs = vec![nix, fallback];
        let inputs = vec![
            ann(Tier::System, "nix build .#a"),
            ann(Tier::Check, "other-thing"),
            ann(Tier::System, "nix run .#b"),
        ];
        let (groups, unmatched) = group_by_runner(&specs, &inputs);
        assert!(unmatched.is_empty(), "fallback runner claims everything");
        assert_eq!(groups.len(), 2);
        assert_eq!(groups[0].spec.name, "nix");
        assert_eq!(groups[0].matched.len(), 2);
        assert_eq!(groups[1].spec.name, "default");
        assert_eq!(groups[1].matched.len(), 1);
        assert_eq!(groups[1].matched[0].annotation.target, "other-thing");
    }

    #[test]
    fn group_by_runner_emits_unmatched_when_no_spec_matches() {
        let nix = RunnerSpec::compile(
            "nix",
            Some(r"^nix "),
            "nix build {targets}",
            "{name}",
            " ",
            BuiltinParser::NixBuildStatus,
            None,
        )
        .unwrap();
        let specs = vec![nix];
        let inputs = vec![ann(Tier::Check, "other-thing")];
        let (groups, unmatched) = group_by_runner(&specs, &inputs);
        assert!(groups.is_empty());
        assert_eq!(unmatched.len(), 1);
        assert_eq!(unmatched[0].target, "other-thing");
    }

    #[test]
    fn render_target_substitutes_name_and_capture_n() {
        let spec = RunnerSpec::compile(
            "nix",
            Some(r"^nix (build|run) \.#(\S+)$"),
            "nix build {targets}",
            ".#{capture_2}",
            " ",
            BuiltinParser::NixBuildStatus,
            None,
        )
        .unwrap();
        assert_eq!(render_target(&spec, "nix build .#test-loom"), ".#test-loom");
        assert_eq!(render_target(&spec, "nix run .#bar"), ".#bar");
    }

    #[test]
    fn render_target_uses_name_placeholder_when_no_regex() {
        let spec = RunnerSpec::compile(
            "default",
            None,
            "cmd {targets}",
            "test({name})",
            " | ",
            BuiltinParser::LibtestJson,
            None,
        )
        .unwrap();
        assert_eq!(render_target(&spec, "crate::a::ok"), "test(crate::a::ok)");
    }

    #[test]
    fn render_command_joins_targets_and_substitutes_filter_and_targets() {
        let spec = RunnerSpec::compile(
            "nextest",
            None,
            "cargo nextest run -E '{filter}' --format={targets}",
            "test({name})",
            " + ",
            BuiltinParser::LibtestJson,
            None,
        )
        .unwrap();
        let inputs = vec![ann(Tier::Test, "a::one"), ann(Tier::Test, "b::two")];
        let specs = [spec];
        let (groups, _) = group_by_runner(&specs, &inputs);
        let rendered = groups[0].render_command();
        assert!(
            rendered.contains("test(a::one) + test(b::two)"),
            "rendered = {rendered}"
        );
        assert!(
            rendered.starts_with("cargo nextest run -E 'test(a::one) + test(b::two)'"),
            "rendered = {rendered}"
        );
    }

    #[test]
    fn builtin_loom_walk_runner_opts_into_the_input_query_protocol() {
        let spec = builtin_loom_walk_runner().unwrap();
        assert_eq!(
            spec.inputs.as_deref(),
            Some("cargo run -p loom-walk -- {targets} {print_inputs}"),
            "the builtin runner must declare an inputs query so the ~77 loom-walk verifiers are scoped, not always-run",
        );
        let annotations = vec![ann(
            Tier::Check,
            "cargo run -p loom-walk -- no_thread_sleep",
        )];
        let specs = [spec];
        let (groups, _) = group_by_runner(&specs, &annotations);
        let query = groups[0].render_inputs_query().unwrap();
        assert_eq!(
            query,
            "cargo run -p loom-walk -- no_thread_sleep --print-inputs",
        );
    }

    #[test]
    fn render_inputs_query_places_flag_at_marker_not_command_head() {
        let spec = RunnerSpec::compile(
            "walk",
            Some(r"^cargo run -p loom-walk -- (\S+)$"),
            "cargo run -p loom-walk -- {targets}",
            "{capture_1}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap()
        .with_inputs(Some(
            "cargo run -p loom-walk -- {targets} {print_inputs}".to_string(),
        ));
        let inputs = vec![ann(Tier::Check, "cargo run -p loom-walk -- foo")];
        let specs = [spec];
        let (groups, _) = group_by_runner(&specs, &inputs);
        let query = groups[0].render_inputs_query().unwrap();
        assert_eq!(query, "cargo run -p loom-walk -- foo --print-inputs");
        assert!(
            !query.starts_with("cargo --print-inputs"),
            "flag must not prepend to tokens[0]: {query}"
        );
    }

    #[test]
    fn render_inputs_query_appends_flag_when_template_omits_marker() {
        let spec = RunnerSpec::compile(
            "walk",
            Some(r"^cargo run -p loom-walk -- (\S+)$"),
            "cargo run -p loom-walk -- {targets}",
            "{capture_1}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap()
        .with_inputs(Some("cargo run -p loom-walk -- {targets}".to_string()));
        let inputs = vec![ann(Tier::Check, "cargo run -p loom-walk -- foo")];
        let specs = [spec];
        let (groups, _) = group_by_runner(&specs, &inputs);
        let query = groups[0].render_inputs_query().unwrap();
        assert_eq!(query, "cargo run -p loom-walk -- foo --print-inputs");
    }

    #[test]
    fn render_inputs_query_is_none_without_inputs_template() {
        let spec = RunnerSpec::compile(
            "walk",
            Some(r"^cargo run -p loom-walk -- (\S+)$"),
            "cargo run -p loom-walk -- {targets}",
            "{capture_1}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap();
        let inputs = vec![ann(Tier::Check, "cargo run -p loom-walk -- foo")];
        let specs = [spec];
        let (groups, _) = group_by_runner(&specs, &inputs);
        assert!(
            groups[0].render_inputs_query().is_none(),
            "no inputs query template means the runner stays always-run"
        );
    }

    #[test]
    fn render_command_substitutes_capture_n_from_first_matched_target() {
        let spec = RunnerSpec::compile(
            "nix",
            Some(r"^nix (build|run) \.#(\S+)$"),
            "nix {capture_1} {targets}",
            ".#{capture_2}",
            " ",
            BuiltinParser::NixBuildStatus,
            None,
        )
        .unwrap();
        let inputs = vec![
            ann(Tier::System, "nix build .#a"),
            ann(Tier::System, "nix build .#b"),
        ];
        let specs = [spec];
        let (groups, _) = group_by_runner(&specs, &inputs);
        let rendered = groups[0].render_command();
        assert_eq!(rendered, "nix build .#a .#b");
    }

    #[test]
    fn parse_json_lines_recovers_each_target() {
        let stdout = concat!(
            "{\"target\":\"a\",\"pass\":true,\"evidence\":\"ok\"}\n",
            "{\"target\":\"b\",\"pass\":false,\"evidence\":\"bad\"}\n",
        );
        let map = parse_runner_output(BuiltinParser::JsonLines, stdout, "", true).unwrap();
        assert_eq!(map.len(), 2);
        assert_eq!(map["a"].outcome, Verdict::Pass);
        assert_eq!(map["a"].evidence, "ok");
        assert_eq!(map["b"].outcome, Verdict::Fail);
        assert_eq!(map["b"].evidence, "bad");
    }

    #[test]
    fn parse_json_lines_rejects_malformed_duplicate_and_incomplete_records() {
        for stdout in [
            "{\"target\":\"a\",\"pass\":true}\n",
            "{\"target\":\"missing_pass\"}\n",
            "{\"pass\":true,\"evidence\":\"no target\"}\n",
            "{\"target\":\"a\",\"pass\":false\n{\"target\":\"a\",\"pass\":true,\"evidence\":\"ok\"}",
            "{\"target\":\"a\",\"pass\":false,\"evidence\":\"failed\"}\n{\"target\":\"a\",\"pass\":true,\"evidence\":\"overwritten\"}",
            "diagnostic on stdout",
        ] {
            assert!(
                parse_runner_output(BuiltinParser::JsonLines, stdout, "", true).is_err(),
                "{stdout}"
            );
        }
    }

    #[test]
    fn parse_libtest_json_maps_ok_and_failed_events() {
        let stdout = concat!(
            "{\"type\":\"suite\",\"event\":\"started\"}\n",
            "{\"type\":\"test\",\"event\":\"started\",\"name\":\"crate::a::one\"}\n",
            "{\"type\":\"test\",\"event\":\"ok\",\"name\":\"crate::a::one\"}\n",
            "{\"type\":\"test\",\"event\":\"failed\",\"name\":\"crate::b::two\",\"stdout\":\"boom\"}\n",
            "{\"type\":\"test\",\"event\":\"ignored\",\"name\":\"crate::c::three\"}\n",
        );
        let map = parse_runner_output(BuiltinParser::LibtestJson, stdout, "", true).unwrap();
        assert_eq!(map["crate::a::one"].outcome, Verdict::Pass);
        assert_eq!(map["crate::b::two"].outcome, Verdict::Fail);
        assert_eq!(map["crate::b::two"].evidence, "boom");
        assert_eq!(map["crate::c::three"].outcome, Verdict::Skipped);
    }

    #[test]
    fn parse_junit_xml_extracts_testcases_and_failure_marks_fail() {
        let stdout = concat!(
            "<?xml version=\"1.0\"?>\n",
            "<testsuite>\n",
            "  <testcase classname=\"mod\" name=\"ok_one\"/>\n",
            "  <testcase classname=\"mod\" name=\"fail_two\">\n",
            "    <failure message=\"oops\">stack</failure>\n",
            "  </testcase>\n",
            "</testsuite>\n",
        );
        let map = parse_runner_output(BuiltinParser::JunitXml, stdout, "", false).unwrap();
        assert_eq!(map.len(), 2);
        assert_eq!(map["mod.ok_one"].outcome, Verdict::Pass);
        assert_eq!(map["mod.fail_two"].outcome, Verdict::Fail);
        assert_eq!(map["mod.fail_two"].evidence, "oops");
    }

    #[test]
    fn parse_nix_build_status_classifies_built_vs_failed() {
        let stderr = concat!(
            "building '/nix/store/aaa-pkg-good.drv'...\n",
            "building '/nix/store/bbb-pkg-bad.drv'...\n",
            "error: builder for '/nix/store/bbb-pkg-bad.drv' failed with exit code 1\n",
        );
        let map = parse_runner_output(BuiltinParser::NixBuildStatus, "", stderr, false).unwrap();
        assert_eq!(map.len(), 2);
        assert_eq!(map["pkg-good"].outcome, Verdict::Pass);
        assert_eq!(map["pkg-bad"].outcome, Verdict::Fail);
    }

    #[test]
    fn parse_exit_code_uses_status_for_single_verdict() {
        let map = parse_runner_output(BuiltinParser::ExitCode, "stdout body", "", true).unwrap();
        assert_eq!(map.len(), 1);
        let only = map.values().next().unwrap();
        assert_eq!(only.outcome, Verdict::Pass);
        assert_eq!(only.evidence, "stdout body");

        let fail = parse_runner_output(BuiltinParser::ExitCode, "", "stderr body", false).unwrap();
        let only = fail.values().next().unwrap();
        assert_eq!(only.outcome, Verdict::Fail);
        assert_eq!(only.evidence, "stderr body");
    }

    #[test]
    fn junit_preserves_skips_entities_and_cdata_without_textual_tag_guessing() {
        let report = r"<testsuites><testsuite>
          <testcase classname='mod' name='skipped'><skipped message='needs A&amp;B &gt; C'/></testcase>
          <testcase name='pass'><system-out><![CDATA[<failure message='not a verdict'/>]]></system-out></testcase>
          <testcase name='fail'><error><![CDATA[broken <resource>]]></error></testcase>
        </testsuite></testsuites>";
        let verdicts = parse_runner_output(BuiltinParser::JunitXml, report, "", false).unwrap();
        assert_eq!(verdicts.len(), 3);
        assert_eq!(verdicts["mod.skipped"].outcome, Verdict::Skipped);
        assert_eq!(verdicts["mod.skipped"].evidence, "needs A&B > C");
        assert_eq!(verdicts["pass"].outcome, Verdict::Pass);
        assert_eq!(verdicts["fail"].outcome, Verdict::Fail);
        assert_eq!(verdicts["fail"].evidence, "broken <resource>");
    }

    #[test]
    fn junit_rejects_malformed_unsupported_and_ambiguous_reports() {
        for report in [
            "<testsuite><testcase name='a'/>",
            "<report><testcase name='a'/></report>",
            "<testsuite><testcase/></testsuite>",
            "<testsuite><testcase name='a'><ignored/></testcase></testsuite>",
            "<testsuite><testcase name='a' status='notrun'/></testsuite>",
            "<testsuite><testcase name='a'><skip:skipped xmlns:skip='urn:x'/></testcase></testsuite>",
            "<testsuite><testcase name='a'><failure/></testcase><testcase name='a'/></testsuite>",
        ] {
            assert!(
                matches!(
                    parse_runner_output(BuiltinParser::JunitXml, report, "", true),
                    Err(RunnerError::InvalidOutput { .. })
                ),
                "{report}"
            );
        }
    }

    #[test]
    fn json_lines_rejects_conflicting_legacy_pass_and_skip_flags() {
        assert!(
            parse_runner_output(
                BuiltinParser::JsonLines,
                "{\"target\":\"a\",\"pass\":true,\"skipped\":true,\"evidence\":\"unavailable\"}",
                "",
                true,
            )
            .is_err()
        );
    }

    #[test]
    fn empty_doctest_suite_does_not_erase_executed_unit_tests() {
        assert!(
            check_zero_match(
                "cargo test",
                "running 1 test\ntest example ... ok\nrunning 0 tests\n",
                ""
            )
            .is_ok()
        );
        assert!(check_zero_match("cargo test", "running 0 tests\nrunning 0 tests\n", "").is_err());
    }

    #[test]
    fn failed_nextest_batch_retains_test_identities_and_output_from_both_streams() {
        let stdout = "---- failed stdout ----\nassertion failed: expected receipt\n";
        let stderr = concat!(
            "PASS [ 0.010s] crate tests::passing\n",
            "SKIP [ 0.000s] crate tests::filtered\n",
            "FAIL [ 0.020s] crate tests::broken\n",
            "EXECFAIL [ 0.000s] crate tests::spawn_failed\n",
            "Resource temporarily unavailable\n",
            "Summary [ 0.030s] 3 tests run: 1 passed, 1 failed, 1 exec failed\n",
        );
        let (verdict, evidence) =
            unstructured_test_outcome("cargo nextest run", stdout, stderr).unwrap();
        assert_eq!(verdict, Verdict::Fail);
        for diagnostic in [
            "tests::broken",
            "tests::spawn_failed",
            "assertion failed: expected receipt",
            "Resource temporarily unavailable",
            "Summary",
        ] {
            assert!(evidence.contains(diagnostic), "{evidence}");
        }
        assert!(!evidence.contains("tests::passing"), "{evidence}");
        assert!(!evidence.contains("tests::filtered"), "{evidence}");
    }

    #[test]
    fn incomplete_nextest_batch_retains_leaky_test_identity() {
        let stderr = concat!(
            "PASS [ 0.010s] crate tests::passing\n",
            "LEAK [ 0.010s] crate tests::leaky\n",
            "SKIP [ 0.000s] crate tests::filtered\n",
            "Summary [ 0.030s] 2 tests run: 2 passed (1 leaky), 1 skipped\n",
        );
        let (verdict, evidence) =
            unstructured_test_outcome("cargo nextest run", "", stderr).unwrap();
        assert_eq!(verdict, Verdict::Skipped);
        assert!(evidence.contains("tests::leaky"), "{evidence}");
        assert!(!evidence.contains("tests::passing"), "{evidence}");
        assert!(!evidence.contains("tests::filtered"), "{evidence}");
        assert!(!nextest_targets_passed(&["leaky"], "", stderr));
    }

    #[test]
    fn nextest_filtered_skips_require_receipts_for_every_selected_target() {
        let receipts = "PASS [0.01s] (1/2) crate mod::first\nPASS [0.01s] (2/2) crate mod::second\nSKIP [ ] (---) crate mod::unselected\nSummary [0.02s] 2 tests run: 2 passed, 500 skipped";
        assert!(nextest_targets_passed(
            &["first", "mod::second"],
            "",
            receipts
        ));
        assert!(!nextest_targets_passed(&["first", "missing"], "", receipts));
        assert!(!nextest_targets_passed(
            &["first", "unselected"],
            "",
            receipts
        ));
        assert!(!nextest_targets_passed(
            &["first"],
            "",
            "Summary [0.01s] 1 tests run: 1 passed, 500 skipped"
        ));
        assert!(!nextest_targets_passed(
            &["first"],
            receipts,
            "SKIP [ ] (---) other-crate mod::first"
        ));
    }

    #[test]
    fn unstructured_test_skip_summaries_do_not_certify_a_whole_batch() {
        for (command, summary) in [
            (
                "cargo test",
                "test result: ok. 1 passed; 0 failed; 1 ignored; 0 measured",
            ),
            (
                "cargo nextest run",
                "Summary [0.1s] 2 tests run: 1 passed, 1 skipped",
            ),
            ("pytest", "==== 1 passed, 1 skipped in 0.1s ===="),
        ] {
            assert!(
                matches!(
                    unstructured_test_outcome(command, "", summary),
                    Some((Verdict::Skipped, _))
                ),
                "{command}"
            );
        }
        assert!(
            unstructured_test_outcome(
                "cargo test",
                "test result: ok. 1 passed; 0 failed; 0 ignored",
                ""
            )
            .is_none()
        );
        assert!(unstructured_test_outcome("cargo test", "test output: 10 ignored", "").is_none());
        assert!(matches!(
            unstructured_test_outcome(
                "cargo test",
                "test result: FAILED. 0 passed; 1 failed; 1 ignored",
                ""
            ),
            Some((Verdict::Fail, _))
        ));
    }

    fn config_with_check_and_system_runners() -> LoomConfig {
        let dir = tempdir().unwrap();
        fs::write(
            dir.path().join("loom.toml"),
            r#"
[runner.check.grep]
match   = '^grep '
command = "{targets}"

[runner.system.nix]
match   = '^nix (build|run) \.#(\S+)$'
command = "nix build {targets}"
parse   = "nix-build-status"
"#,
        )
        .unwrap();
        LoomConfig::load(LoomConfig::resolve_path(dir.path())).unwrap()
    }

    #[test]
    fn integrity_runner_specs_carries_builtin_loom_walk_batcher() {
        let specs = integrity_runner_specs(&LoomConfig::default()).unwrap();
        assert!(
            specs.iter().any(|s| s.name == "builtin-loom-walk"
                && s.matches("cargo run -p loom-walk -- inputs-check")),
            "the builtin loom-walk batcher must always be present and own its target",
        );
    }

    #[test]
    fn integrity_runner_specs_unions_check_and_system_runners() {
        let config = config_with_check_and_system_runners();
        let specs = integrity_runner_specs(&config).unwrap();
        assert!(
            specs
                .iter()
                .any(|s| s.applies_to(Tier::Check) && s.matches("grep -q X file")),
            "a [check] target must resolve through its [runner.check.<name>] runner",
        );
        assert!(
            specs
                .iter()
                .any(|s| s.applies_to(Tier::System) && s.matches("nix run .#test-loom")),
            "a [system] target must resolve through its [runner.system.<name>] runner",
        );
    }

    #[test]
    fn group_by_runner_does_not_cross_claim_sibling_tier_runner() {
        let check_runner = RunnerSpec::compile(
            "check-default",
            None,
            "check {targets}",
            "{name}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap()
        .with_tier(Tier::Check);
        let system_runner = RunnerSpec::compile(
            "system-default",
            None,
            "system {targets}",
            "{name}",
            " ",
            BuiltinParser::JsonLines,
            None,
        )
        .unwrap()
        .with_tier(Tier::System);
        let system = Annotation {
            tier: Tier::System,
            target: "nix run .#test-loom".to_owned(),
            pending: false,
            source_spec: PathBuf::from("specs/gate.md"),
            line: 1,
            criterion_line: 1,
        };

        let specs = [check_runner, system_runner];
        let annotations = [system];
        let (groups, unmatched) = group_by_runner(&specs, &annotations);

        assert!(
            unmatched.is_empty(),
            "system runner should claim the target"
        );
        assert_eq!(groups.len(), 1);
        assert_eq!(groups[0].spec.name, "system-default");
    }

    #[test]
    fn compile_runner_entry_without_command_is_missing_command_error() {
        let entry = RunnerEntry {
            match_regex: Some("^x".into()),
            ..RunnerEntry::default()
        };
        let err = compile_runner_entry("orphan", &entry).unwrap_err();
        assert!(matches!(err, RunnerError::MissingCommand { name } if name == "orphan"));
    }
}
