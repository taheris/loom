//! Shared test-support items for loom tests.
//!
//! Per `specs/tests.md` (Architecture / Property-Based Testing), property
//! case counts come from one shared configuration rather than literals
//! scattered across `proptest!` blocks.

pub mod acceptance;
pub mod compile_fixture;
pub mod finding;
pub mod git_policy;
pub mod parallel_process;
pub mod profile_manifest;

use proptest::test_runner::Config as ProptestConfig;

/// Number of cases each property runs when `PROPTEST_CASES` is absent or
/// invalid.
pub const CI_PROPTEST_CASES: u32 = 32;

/// Shared property-test configuration with an environment override.
pub fn proptest_config() -> ProptestConfig {
    let cases = std::env::var("PROPTEST_CASES")
        .ok()
        .and_then(|raw| raw.parse::<u32>().ok())
        .filter(|cases| *cases > 0)
        .unwrap_or(CI_PROPTEST_CASES);
    ProptestConfig::with_cases(cases)
}

pub const GIT_LOCAL_ENV_VARS: &[&str] = &[
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_CONFIG",
    "GIT_CONFIG_PARAMETERS",
    "GIT_CONFIG_COUNT",
    "GIT_OBJECT_DIRECTORY",
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_IMPLICIT_WORK_TREE",
    "GIT_GRAFT_FILE",
    "GIT_INDEX_FILE",
    "GIT_NO_REPLACE_OBJECTS",
    "GIT_REPLACE_REF_BASE",
    "GIT_PREFIX",
    "GIT_SHALLOW_FILE",
    "GIT_COMMON_DIR",
];

pub fn scrub_git_local_env(command: &mut std::process::Command) {
    for &name in GIT_LOCAL_ENV_VARS {
        command.env_remove(name);
    }
}

/// Prevents test Git processes from inheriting operator signing configuration.
pub fn configure_hermetic_git(command: &mut std::process::Command) {
    let config = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../tests/fixtures/git/test-gitconfig");
    command.env("GIT_CONFIG_GLOBAL", config);
}

pub fn bash_path() -> std::path::PathBuf {
    if let Some(path) = std::env::var_os("PATH") {
        for dir in std::env::split_paths(&path) {
            let candidate = dir.join("bash");
            if candidate.is_file() {
                return candidate;
            }
        }
    }
    std::path::PathBuf::from("/usr/bin/env bash")
}

pub fn bash_script(body: &str) -> String {
    format!("#!{}\n{body}", bash_path().display())
}

#[cfg(unix)]
fn cleanup_temp_file(path: &std::path::Path, original: std::io::Error) -> std::io::Error {
    match std::fs::remove_file(path) {
        Ok(()) => original,
        Err(cleanup) if cleanup.kind() == std::io::ErrorKind::NotFound => original,
        Err(cleanup) => std::io::Error::new(
            cleanup.kind(),
            format!(
                "{original}; also failed to remove temporary script {}: {cleanup}",
                path.display()
            ),
        ),
    }
}

#[cfg(unix)]
/// Writes a Bash script and atomically marks it executable.
///
/// # Errors
///
/// Returns an I/O error when the temporary file cannot be written, permission
/// changes fail, or the completed script cannot be moved into place.
pub fn write_executable_bash_script(
    path: impl AsRef<std::path::Path>,
    body: &str,
) -> std::io::Result<()> {
    use std::io::{Error, ErrorKind, Write};
    use std::os::unix::fs::PermissionsExt;
    use std::sync::atomic::{AtomicU64, Ordering};

    static TEMP_COUNTER: AtomicU64 = AtomicU64::new(0);

    let path = path.as_ref();
    let parent = path.parent().unwrap_or_else(|| std::path::Path::new("."));
    let script = bash_script(body);

    for _ in 0..32 {
        let nonce = TEMP_COUNTER.fetch_add(1, Ordering::Relaxed);
        let temp_path = parent.join(format!(".loom-script-{}-{nonce}.tmp", std::process::id()));
        let mut file = match std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temp_path)
        {
            Ok(file) => file,
            Err(error) if error.kind() == ErrorKind::AlreadyExists => continue,
            Err(error) => return Err(error),
        };

        if let Err(error) = file.write_all(script.as_bytes()) {
            return Err(cleanup_temp_file(&temp_path, error));
        }
        if let Err(error) = file.sync_all() {
            return Err(cleanup_temp_file(&temp_path, error));
        }
        drop(file);

        if let Err(error) =
            std::fs::set_permissions(&temp_path, std::fs::Permissions::from_mode(0o755))
        {
            return Err(cleanup_temp_file(&temp_path, error));
        }
        if let Err(error) = std::fs::rename(&temp_path, path) {
            return Err(cleanup_temp_file(&temp_path, error));
        }
        return Ok(());
    }

    Err(Error::new(
        ErrorKind::AlreadyExists,
        "could not allocate a temporary executable-script path",
    ))
}

#[cfg(test)]
mod tests {
    #[test]
    fn hermetic_git_command_disables_operator_signing() {
        let mut command = std::process::Command::new("true");
        super::configure_hermetic_git(&mut command);
        let config = command
            .get_envs()
            .find_map(|(key, value)| (key == "GIT_CONFIG_GLOBAL").then_some(value).flatten())
            .expect("GIT_CONFIG_GLOBAL");
        let body = std::fs::read_to_string(config).expect("read hermetic Git config");

        assert!(body.contains("gpgsign = false"), "config={body}");
    }
}
