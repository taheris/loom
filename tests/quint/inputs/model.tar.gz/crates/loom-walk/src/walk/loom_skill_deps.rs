//! `loom-skill` is a public-contract crate for skill artifacts and
//! registry stages. It may depend on `loom-events` for shared newtypes,
//! but not on runtime, agent, template, tune, or workflow crates.

use super::util::{read_to_string, verdict_from, workspace_root};
use super::{Verdict, WalkInput};

super::manifest::registration!("loom_skill_deps", "loom-skill");

const RULE: &str =
    "loom_skill_deps — `loom-skill` depends on `loom-events` and not on runtime crates";

const REQUIRED: &[&str] = &["loom-events"];

const FORBIDDEN: &[&str] = &[
    "loom-driver",
    "loom-agent",
    "loom-templates",
    "loom-tune",
    "loom-workflow",
    "loom-llm",
    "loom-render",
    "loom-gate",
];

fn rule(input: &WalkInput) -> Verdict {
    let root = workspace_root(input);
    let manifest = root.join(MANIFEST);
    let mut violations = Vec::new();

    let Some(body) = read_to_string(input, &manifest) else {
        violations.push("crates/loom-skill/Cargo.toml:1 manifest not readable".to_string());
        return verdict_from(RULE, violations);
    };

    analyze(&body)
}

fn analyze(body: &str) -> Verdict {
    let mut violations = Vec::new();

    let Some(section) = section_body(body, "[dependencies]") else {
        violations
            .push("crates/loom-skill/Cargo.toml:1 [dependencies] section missing".to_string());
        return verdict_from(RULE, violations);
    };
    let keys = section_keys(section);

    for required in REQUIRED {
        if !keys.iter().any(|k| k == required) {
            violations.push(format!(
                "crates/loom-skill/Cargo.toml:1 missing required dependency `{required}`",
            ));
        }
    }

    for forbidden in FORBIDDEN {
        if keys.iter().any(|k| k == forbidden) {
            violations.push(format!(
                "crates/loom-skill/Cargo.toml:1 forbidden internal dep `{forbidden}` — `loom-skill` may depend only on `loom-events` among internal crates",
            ));
        }
    }

    verdict_from(RULE, violations)
}

fn section_body<'a>(body: &'a str, header: &str) -> Option<&'a str> {
    let start = body.find(header)?;
    let after_header_offset = body[start..].find('\n').map(|n| start + n + 1)?;
    let tail = &body[after_header_offset..];
    let end_rel = tail.find("\n[").unwrap_or(tail.len());
    Some(&tail[..end_rel])
}

fn section_keys(section: &str) -> Vec<String> {
    let mut out = Vec::new();
    for raw in section.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let key = match line.split_once('=') {
            Some((k, _)) => k.trim().trim_matches('"'),
            None => continue,
        };
        if key.is_empty() {
            continue;
        }
        out.push(key.to_string());
    }
    out
}

/// Standalone and checked dispatch execute the identical rule body.
pub fn run(input: &WalkInput) -> Verdict {
    input.finish(rule(input))
}
