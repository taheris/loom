//! `templates` is a public-contract near-leaf alongside `loom-events`,
//! `loom-protocol`, and `llm`. Its `[dependencies]` table may depend on no
//! internal crate other than `loom-events` and `loom-protocol` — references to
//! `loom-driver`, `agent`, `loom-workflow`, `llm`, `loom-skill`, `loom-tune`,
//! etc. would either re-shape the consumer-facing dependency graph or pull the
//! runtime into the template surface.

use super::util::{read_to_string, verdict_from, workspace_root};
use super::{Verdict, WalkInput};

super::manifest::registration!("loom_templates_deps", "loom-templates");

const RULE: &str = "loom_templates_deps — `templates` may depend only on `loom-events` and `loom-protocol` among internal `loom-*` crates";

const FORBIDDEN: &[&str] = &[
    "loom-driver",
    "loom-agent",
    "loom-workflow",
    "loom-render",
    "loom-llm",
    "loom-skill",
    "loom-tune",
    "loom-gate",
];

fn rule(input: &WalkInput) -> Verdict {
    let root = workspace_root(input);
    let manifest = root.join(MANIFEST);
    let mut violations = Vec::new();

    let Some(body) = read_to_string(input, &manifest) else {
        violations.push("crates/loom-templates/Cargo.toml:1 manifest not readable".to_string());
        return verdict_from(RULE, violations);
    };

    analyze(&body)
}

fn analyze(body: &str) -> Verdict {
    let mut violations = Vec::new();

    for (lineno, raw) in body.lines().enumerate() {
        let trimmed = raw.trim_start();
        for forbidden in FORBIDDEN {
            if trimmed.starts_with(forbidden)
                && trimmed[forbidden.len()..]
                    .chars()
                    .next()
                    .is_some_and(|c| c == ' ' || c == '\t' || c == '=')
            {
                violations.push(format!(
                    "crates/loom-templates/Cargo.toml:{} forbidden internal dep `{}` — `templates` depends only on `loom-events` and `loom-protocol` among internal crates",
                    lineno + 1,
                    forbidden,
                ));
            }
        }
    }

    verdict_from(RULE, violations)
}

/// Standalone and checked dispatch execute the identical rule body.
pub fn run(input: &WalkInput) -> Verdict {
    input.finish(rule(input))
}
