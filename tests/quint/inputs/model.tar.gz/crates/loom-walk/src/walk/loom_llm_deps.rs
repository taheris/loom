//! `llm` is a public-contract leaf alongside `loom-events`,
//! `loom-protocol`, `templates`, and `loom-skill`. Its
//! `[dependencies]` table must depend on no internal crate other than
//! `loom-events` — pulling `loom-driver`,
//! `agent`, `loom-workflow`, `loom-skill`, or `loom-tune` would invert
//! the consumer-facing dependency direction the spec preserves.

use super::util::{read_to_string, verdict_from, workspace_root};
use super::{Verdict, WalkInput};

super::manifest::registration!("loom_llm_deps", "loom-llm");

const RULE: &str =
    "loom_llm_deps — `llm` may depend only on `loom-events` among internal `loom-*` crates";

const FORBIDDEN: &[&str] = &[
    "loom-driver",
    "loom-agent",
    "loom-workflow",
    "loom-render",
    "loom-templates",
    "loom-skill",
    "loom-tune",
    "loom-gate",
];

fn rule(input: &WalkInput) -> Verdict {
    let root = workspace_root(input);
    let manifest = root.join(MANIFEST);
    let mut violations = Vec::new();

    let Some(body) = read_to_string(input, &manifest) else {
        violations.push("crates/loom-llm/Cargo.toml:1 manifest not readable".to_string());
        return verdict_from(RULE, violations);
    };

    analyze(&body)
}

fn analyze(body: &str) -> Verdict {
    let mut violations = Vec::new();

    for (lineno, raw) in body.lines().enumerate() {
        let trimmed = raw.trim_start();
        for forbidden in FORBIDDEN {
            if trimmed.starts_with(forbidden)
                && trimmed[forbidden.len()..]
                    .chars()
                    .next()
                    .is_some_and(|c| c == ' ' || c == '\t' || c == '=')
            {
                violations.push(format!(
                    "crates/loom-llm/Cargo.toml:{} forbidden internal dep `{}` — `llm` depends only on `loom-events`",
                    lineno + 1,
                    forbidden,
                ));
            }
        }
    }

    verdict_from(RULE, violations)
}

/// Standalone and checked dispatch execute the identical rule body.
pub fn run(input: &WalkInput) -> Verdict {
    input.finish(rule(input))
}
