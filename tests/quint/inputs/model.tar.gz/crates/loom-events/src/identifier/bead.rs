use std::fmt;
use std::str::FromStr;

use serde::{Deserialize, Deserializer, Serialize};
use thiserror::Error;

#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize)]
#[serde(transparent)]
pub struct BeadId(String);

impl BeadId {
    /// Parse a bead id from a raw string. Validates the canonical
    /// `<prefix>-<base32>(.<digits>)*` shape so that subprocess output
    /// drift (banners, warnings, empty lines) and external input (JSON
    /// from `bd`) is caught at the boundary rather than producing a
    /// malformed [`BeadId`] downstream.
    ///
    /// `<prefix>` is one or more lowercase ASCII letters, `<base32>` is
    /// one or more lowercase ASCII alphanumerics. Each optional
    /// `.<digits>` suffix is a nonempty ASCII numeric child segment;
    /// nested children may have multiple segments.
    ///
    /// # Errors
    ///
    /// Returns [`ParseBeadIdError`] when the input is not a canonical bead id.
    pub fn new(s: &str) -> Result<Self, ParseBeadIdError> {
        let (prefix, rest) = s
            .split_once('-')
            .ok_or_else(|| ParseBeadIdError(s.to_owned()))?;
        if prefix.is_empty() || !prefix.bytes().all(|b| b.is_ascii_lowercase()) {
            return Err(ParseBeadIdError(s.to_owned()));
        }
        let (body, suffix) = match rest.split_once('.') {
            Some((body, suffix)) => (body, Some(suffix)),
            None => (rest, None),
        };
        if body.is_empty()
            || !body
                .bytes()
                .all(|b| b.is_ascii_lowercase() || b.is_ascii_digit())
        {
            return Err(ParseBeadIdError(s.to_owned()));
        }
        if let Some(suffix) = suffix
            && suffix
                .split('.')
                .any(|segment| segment.is_empty() || !segment.bytes().all(|b| b.is_ascii_digit()))
        {
            return Err(ParseBeadIdError(s.to_owned()));
        }
        Ok(Self(s.to_owned()))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl fmt::Display for BeadId {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.0)
    }
}

impl FromStr for BeadId {
    type Err = ParseBeadIdError;

    fn from_str(s: &str) -> Result<Self, Self::Err> {
        Self::new(s)
    }
}

impl<'de> Deserialize<'de> for BeadId {
    fn deserialize<D: Deserializer<'de>>(d: D) -> Result<Self, D::Error> {
        let s = String::deserialize(d)?;
        BeadId::new(&s).map_err(serde::de::Error::custom)
    }
}

#[derive(Debug, displaydoc::Display, Error, PartialEq, Eq)]
/// invalid bead id `{0}`: expected `<prefix>-<base32>(.<digits>)*`
pub struct ParseBeadIdError(pub String);

#[cfg(test)]
mod tests {
    use super::{BeadId, ParseBeadIdError};
    use anyhow::Result;

    #[test]
    fn display_round_trips_with_as_str() -> Result<()> {
        let id = BeadId::new("lm-3hhwq.2")?;
        assert_eq!(id.as_str(), "lm-3hhwq.2");
        assert_eq!(id.to_string(), "lm-3hhwq.2");
        Ok(())
    }

    #[test]
    fn serde_round_trips_as_plain_string() -> Result<()> {
        let id = BeadId::new("lm-abc123")?;
        let json = serde_json::to_string(&id)?;
        assert_eq!(json, "\"lm-abc123\"");
        let back: BeadId = serde_json::from_str(&json)?;
        assert_eq!(back, id);
        Ok(())
    }

    #[test]
    fn serde_round_trips_nested_child_ids() -> Result<()> {
        for input in ["wd-p7z.8.1", "wd-p7z.8.1.2"] {
            let json = format!("\"{input}\"");
            let id: BeadId = serde_json::from_str(&json)?;
            assert_eq!(id.as_str(), input);
            assert_eq!(serde_json::to_string(&id)?, json);
        }
        Ok(())
    }

    #[test]
    fn deserialize_rejects_malformed_string() {
        let err = serde_json::from_str::<BeadId>("\"not a bead\"").unwrap_err();
        assert!(err.to_string().contains("invalid bead id"), "{err}");
    }

    #[test]
    fn parse_accepts_canonical_shapes() -> Result<()> {
        for input in [
            "lm-abc123",
            "lm-3hhwq.2",
            "lm-3hhwq.20",
            "loom-a1b2c3",
            "wd-p7z.8.1",
            "wd-p7z.8.1.2",
        ] {
            let id = BeadId::new(input)?;
            assert_eq!(id.as_str(), input);
        }
        Ok(())
    }

    #[test]
    fn parse_rejects_malformed_inputs() {
        let cases = [
            "",
            "wx",
            "lm-",
            "-abc",
            "lm-ABC",
            "lm-abc.",
            "lm-abc.x",
            "lm-abc..1",
            "lm-abc.1.",
            "lm-abc.1..2",
            "lm-abc.1.x",
            "lm-abc.x.1",
            "lm-abc.1.-2",
            "lm-abc.1.٢",
            "lm-abc.1.2/3",
            "lm-abc.1.2\n",
            "WX-abc",
            "warning: foo\nlm-abc123",
            "lm-abc 123",
            "lm-abc-def",
        ];
        for input in cases {
            let err = BeadId::new(input).expect_err(input);
            assert_eq!(err, ParseBeadIdError(input.to_owned()));
        }
    }
}
