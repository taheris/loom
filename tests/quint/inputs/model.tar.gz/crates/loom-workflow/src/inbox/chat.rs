//! `loom inbox chat` — interactive human-decision session.
//!
//! Mirrors `loom plan`'s Claude runner shape for Claude-backed chat. Pi-backed
//! chat prefers the native Pi TUI when attached to a real terminal, with a
//! controlled RPC bridge retained for non-TTY execution and tests.

use std::fs;
use std::io::{IsTerminal, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

use askama::Template;
use displaydoc::Display;
use loom_agent::PiBackend;
use loom_driver::agent::{
    Active, AgentBackend, AgentEvent, AgentKind, AgentSession, ModelSelection, ProtocolError,
    SpawnConfig,
};
use loom_driver::bd::{BdClient, ListOpts};
use loom_driver::clock::{Clock, SystemClock};
use loom_driver::config::{AgentSelection, LoomConfig, Phase};
use loom_driver::git::GitError;
use loom_driver::identifier::{BeadId, ParseSpecLabelError, ProfileName, SpecLabel};
use loom_driver::profile_manifest::{ImageEntry, ProfileError, ProfileImageManifest};
use loom_driver::scratch::{ScratchSession, resolve_scratch_key};
use loom_driver::state::CacheDb;
use loom_events::identifier::SessionId;
use loom_events::{EnvelopeBuilder, InputKind, SessionScope, Source};
use thiserror::Error;
use tracing::{info, warn};

use crate::r#loop::{dolt_socket_mount, sccache_mount};
use crate::pi_tui;
use crate::redaction::redact_agent_input;
use crate::skill::{SkillError, SkillPlan};
use crate::spawn::container_workspace_path;

use super::context::build_inbox_context;
use super::list::{
    InboxItem, InboxKind, build_queue, find_by_bead_id, find_by_index, find_by_proposal_id,
    frame_unavailable_tune_items,
};
use super::terminal::{TerminalMarker, TerminalMarkerError, parse as parse_terminal_marker};
use super::{ApplyError, apply_proposals, ensure_integration_clean_after_chat};

const INBOX_NON_CLOSED_STATUSES: [loom_driver::bd::Status; 4] = [
    loom_driver::bd::Status::Open,
    loom_driver::bd::Status::InProgress,
    loom_driver::bd::Status::Blocked,
    loom_driver::bd::Status::Deferred,
];

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ChatTarget {
    Index(u32),
    Bead(String),
    Proposal(String),
}

/// Inputs to one [`run`] call.
#[derive(Debug)]
pub struct ChatOpts {
    /// Optional `-s <label>` filter.
    pub spec_filter: Option<SpecLabel>,
    /// Optional `-k <kind>` filter.
    pub kind_filter: Option<InboxKind>,
    /// Optional target. Absent means the session walks the visible queue.
    pub target: Option<ChatTarget>,
    /// Optional profile override.
    pub cli_profile: Option<ProfileName>,
    /// CLI `--agent` override.
    pub agent_override: Option<AgentKind>,
    /// Resolved profile-image manifest.
    pub manifest: ProfileImageManifest,
    /// Explicit raw launcher override; never changes the selected profile config.
    pub wrix_bin: Option<PathBuf>,
    /// Repository key paths for Wrix launcher processes.
    pub launcher_env: Vec<(String, String)>,
}

/// Outcome of one `loom inbox chat` session.
#[derive(Debug, Clone)]
pub struct ChatReport {
    /// Number of inbox items surfaced into the rendered prompt at session start.
    pub items_surfaced: usize,
    /// Number of inbox items still visible after the session exited.
    pub items_remaining: usize,
    /// Number of tune proposals applied by a trusted driver handoff.
    pub applied_proposals: usize,
}

#[derive(Debug, Display, Error)]
pub enum ChatError {
    /// profile resolution failed
    Profile(#[from] ProfileError),
    /// config load failed: {0}
    Config(String),
    /// inbox data carried an invalid spec label
    InvalidSpecLabel(#[from] ParseSpecLabelError),
    /// bd list failed: {0}
    BdList(String),
    /// render inbox.md template: {0}
    Render(String),
    /// cache db operation failed while running `loom inbox chat`
    State(#[from] loom_driver::state::CacheError),
    /// scratch session io failed
    Scratch(#[from] std::io::Error),
    /// wrix exited with status {status}
    WrixExit { status: String },
    /// agent backend protocol failure during `loom inbox chat`
    Protocol(#[from] ProtocolError),
    /// agent selection: {0}
    AgentSelection(String),
    /// git step failed while running `loom inbox chat`
    Git(#[from] GitError),
    /// skill resolution failed while running `loom inbox chat`
    Skill(#[from] SkillError),
    /// inbox terminal marker error
    Terminal(#[from] TerminalMarkerError),
    /// native assistant capture settings failed
    CaptureSettings(#[from] serde_json::Error),
    /// tune proposal apply failed
    Apply(#[from] ApplyError),
    /// attributed scheduling wait reconciliation failed
    Wait(#[from] Box<crate::r#loop::LoopError>),
    /// no inbox item at index {index} ({total} outstanding)
    IndexOutOfRange { index: u32, total: u32 },
    /// no inbox item with bead id {id}
    BeadNotFound { id: String },
    /// no tune proposal with id {id}
    ProposalNotFound { id: String },
}

/// Run one `loom inbox chat` session against `workspace`.
///
/// # Errors
///
/// Returns an error when inbox state, interaction, or persistence fails.
pub fn run(workspace: &Path, opts: &ChatOpts) -> Result<ChatReport, ChatError> {
    let cfg = LoomConfig::load(LoomConfig::resolve_path(workspace))
        .map_err(|e| ChatError::Config(e.to_string()))?;
    let selection = resolve_chat_selection(opts.cli_profile.as_ref(), opts.agent_override, &cfg)?;
    let image: &ImageEntry = opts.manifest.lookup(&selection.profile, selection.kind())?;

    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .map_err(|e| ChatError::Config(format!("tokio runtime: {e}")))?;
    let beads = runtime
        .block_on(async {
            let bd = BdClient::new();
            bd.list(inbox_list_opts()).await
        })
        .map_err(|e| ChatError::BdList(e.to_string()))?;
    let mut queue = build_queue(&beads, opts.spec_filter.as_ref(), opts.kind_filter, false);
    frame_unavailable_tune_items(workspace, &mut queue);
    let visible = select_visible(queue, opts.target.as_ref())?;
    let items_surfaced = visible.len();
    if visible.is_empty() {
        return Ok(ChatReport {
            items_surfaced: 0,
            items_remaining: 0,
            applied_proposals: 0,
        });
    }

    let scope_label = opts
        .spec_filter
        .clone()
        .or_else(|| visible.iter().find_map(|item| item.spec.clone()))
        .unwrap_or_else(SpecLabel::inbox_chat);
    let key = resolve_scratch_key(
        Phase::Inbox,
        std::slice::from_ref(&scope_label),
        single_bead(&visible),
    );
    let scratchpad_path = ScratchSession::scratchpad_path_for(workspace, &key);
    let scratch_dir = scratchpad_path.parent().ok_or_else(|| {
        ChatError::Scratch(std::io::Error::other("scratchpad path has no parent"))
    })?;
    let skill_plan = SkillPlan::resolve_from_workspace_sync(
        workspace,
        Phase::Inbox.as_str(),
        &selection.profile,
        selection.kind(),
        &cfg.skills,
    )?;
    let skill_session = skill_plan.materialize(scratch_dir, workspace)?;
    let companion_paths = load_companion_paths(workspace, opts.spec_filter.as_ref(), &visible)?;
    let prompt_scratchpad_path = container_workspace_path(workspace, &scratchpad_path);
    let ctx = build_inbox_context(
        workspace,
        String::new(),
        companion_paths,
        &visible,
        prompt_scratchpad_path.to_string_lossy().into_owned(),
        skill_session.skill_index,
    );
    let prompt_body = ctx.render().map_err(|e| ChatError::Render(e.to_string()))?;

    let scratch = ScratchSession::open(workspace, &key, &prompt_body, "loom inbox chat")?;
    let restored_skills = skill_plan.materialize(scratch.path(), workspace)?;
    let bin = loom_driver::wrix::resolve_launcher(&image.launcher, opts.wrix_bin.as_deref());

    let stdout = match selection.kind() {
        AgentKind::Claude => {
            install_claude_capture(workspace, &scratch)?;
            let claude_settings_path =
                container_workspace_path(workspace, &scratch.claude_settings());
            let argv = build_wrix_argv(
                workspace,
                &prompt_body,
                selection.kind(),
                Some(&claude_settings_path),
            );
            info!(
                wrix_bin = %bin.display(),
                items_surfaced,
                profile = %selection.profile,
                agent = ?selection.kind(),
                image_ref = %image.r#ref,
                scratch_dir = %scratch.path().display(),
                "loom inbox chat: shelling out to interactive wrix run",
            );

            let mut command = loom_driver::wrix::command(bin.as_os_str(), &image.profile_config);
            command
                .args(&argv)
                .envs(opts.launcher_env.iter().map(|(key, value)| (key, value)));
            run_native(command)?;
            let raw = fs::read_to_string(scratch.path().join("native-transcript.jsonl"))?;
            session_transcript_from_str(&raw, AgentKind::Claude)?
        }
        AgentKind::Pi => {
            if should_use_pi_tui_shell_out() {
                let launch = prepare_pi_tui_launch(workspace, &selection, scratch.path())?;
                info!(
                    wrix_bin = %bin.display(),
                    items_surfaced,
                    profile = %selection.profile,
                    agent = ?selection.kind(),
                    image_ref = %image.r#ref,
                    scratch_dir = %scratch.path().display(),
                    "loom inbox chat: shelling out to native pi TUI",
                );
                let mut command =
                    loom_driver::wrix::command(bin.as_os_str(), &image.profile_config);
                command
                    .args(&launch.argv)
                    .envs(opts.launcher_env.iter().map(|(key, value)| (key, value)));
                run_pi_tui_shell_out(command, &launch.session_dir)?
            } else {
                let mut spawn_config = build_pi_bridge_spawn_config(
                    workspace,
                    image,
                    &selection,
                    prompt_body,
                    scratch.path().to_path_buf(),
                    &cfg,
                    &opts.launcher_env,
                )?;
                spawn_config.skills = Some(restored_skills.registered);
                info!(
                    wrix_bin = %bin.display(),
                    items_surfaced,
                    profile = %selection.profile,
                    agent = ?selection.kind(),
                    image_ref = %image.r#ref,
                    scratch_dir = %scratch.path().display(),
                    "loom inbox chat: starting controlled pi RPC bridge",
                );
                runtime.block_on(run_pi_bridge(spawn_config, &bin))?
            }
        }
        AgentKind::Direct => {
            return Err(ChatError::AgentSelection(
                "direct backend cannot run interactive `loom inbox chat`".to_string(),
            ));
        }
    };
    drop(scratch);
    runtime
        .block_on(
            crate::r#loop::DecisionWaitJournal::new(workspace).refresh_native_waits(
                &BdClient::new(),
                None,
                None,
            ),
        )
        .map_err(|error| ChatError::Wait(Box::new(error)))?;

    let marker = parse_terminal_marker(&stdout)?;
    ensure_integration_clean_after_chat(workspace)?;
    let applied_proposals = if let TerminalMarker::Apply(payload) = marker {
        apply_proposals(workspace, payload.proposals.into_vec())?
            .proposals
            .len()
    } else {
        0
    };

    let beads_after = runtime
        .block_on(async {
            let bd = BdClient::new();
            bd.list(inbox_list_opts()).await
        })
        .map_err(|e| ChatError::BdList(e.to_string()))?;
    let mut remaining = build_queue(
        &beads_after,
        opts.spec_filter.as_ref(),
        opts.kind_filter,
        false,
    );
    frame_unavailable_tune_items(workspace, &mut remaining);
    Ok(ChatReport {
        items_surfaced,
        items_remaining: remaining.len(),
        applied_proposals,
    })
}

fn inbox_list_opts() -> ListOpts {
    ListOpts {
        statuses: INBOX_NON_CLOSED_STATUSES.to_vec(),
        ..ListOpts::default()
    }
}

fn build_pi_bridge_spawn_config(
    workspace: &Path,
    image: &ImageEntry,
    selection: &AgentSelection,
    prompt_body: String,
    scratch_dir: PathBuf,
    cfg: &LoomConfig,
    launcher_env: &[(String, String)],
) -> Result<SpawnConfig, ChatError> {
    let mut mounts: Vec<_> = dolt_socket_mount(workspace).into_iter().collect();
    if let Some(spec) = sccache_mount(&cfg.loom)? {
        mounts.push(spec);
    }
    let mut spawn_config = crate::spawn::build_spawn_config(
        image,
        AgentKind::Pi,
        workspace.to_path_buf(),
        prompt_body,
        scratch_dir,
        cfg.loom.container_sccache_env(),
        vec![],
        mounts,
        launcher_env.to_vec(),
    );
    if let (Some(provider), Some(model_id)) = (&selection.provider, &selection.model_id) {
        spawn_config.model = Some(ModelSelection {
            provider: provider.to_string(),
            model_id: model_id.to_string(),
        });
    }
    spawn_config.thinking_level = selection.thinking_level;
    Ok(spawn_config)
}

async fn run_pi_bridge(config: SpawnConfig, launcher: &Path) -> Result<String, ChatError> {
    let session = PiBackend::spawn_bridge_with_wrix_bin(&config, launcher.as_os_str()).await?;
    let mut output = String::new();
    let mut envelope_builder = pi_bridge_envelope_builder();
    emit_pi_bridge_agent_input(
        &mut envelope_builder,
        &config,
        InputKind::InitialPrompt,
        &config.initial_prompt,
        &mut output,
    )?;
    let mut session = session.prompt(&config.initial_prompt).await?;
    loop {
        let parsed = session
            .next_event()
            .await?
            .ok_or(ProtocolError::UnexpectedEof)?;
        let event = AgentEvent::from_parsed(parsed, envelope_builder.build());
        render_pi_bridge_event(&event, &mut output)?;
        if matches!(event, AgentEvent::CompactionStart { .. })
            && let Some(payload) = PiBackend::compaction_repin(&config)?
        {
            emit_pi_bridge_agent_input(
                &mut envelope_builder,
                &config,
                InputKind::Repin,
                &payload,
                &mut output,
            )?;
            session.steer(&payload).await?;
        }
        match event {
            AgentEvent::AgentEnd { .. } => match parse_terminal_marker(&output) {
                Ok(_) => {
                    ensure_bridge_output_newline(&mut output)?;
                    return Ok(output);
                }
                Err(err) if err.is_conversation() => {
                    if !read_pi_bridge_follow_up(
                        &mut session,
                        &config,
                        &mut envelope_builder,
                        &mut output,
                    )
                    .await?
                    {
                        return Ok(output);
                    }
                }
                Err(err) => return Err(ChatError::Terminal(err)),
            },
            AgentEvent::SessionComplete { exit_code, .. } => {
                if exit_code != 0 {
                    return Err(ChatError::Protocol(ProtocolError::ProcessExit(exit_code)));
                }
                match parse_terminal_marker(&output) {
                    Ok(_) => {
                        ensure_bridge_output_newline(&mut output)?;
                        return Ok(output);
                    }
                    Err(err) if err.is_conversation() => return Ok(output),
                    Err(err) => return Err(ChatError::Terminal(err)),
                }
            }
            _ => {}
        }
    }
}

fn pi_bridge_envelope_builder() -> EnvelopeBuilder {
    let clock = SystemClock::new();
    let started_ms = unix_timestamp_millis(clock);
    EnvelopeBuilder::new(
        SessionScope::phase(
            SessionId::generated(format!("inbox-pi-{}-{started_ms}", std::process::id())),
            None,
        ),
        Source::Agent,
        move || unix_timestamp_millis(clock),
    )
}

fn unix_timestamp_millis(clock: SystemClock) -> i64 {
    match clock.wall_now().duration_since(std::time::UNIX_EPOCH) {
        Ok(duration) => match i64::try_from(duration.as_millis()) {
            Ok(timestamp) => timestamp,
            Err(err) => {
                warn!(error = ?err, "pi bridge event timestamp exceeded i64 range");
                i64::MAX
            }
        },
        Err(err) => {
            warn!(error = ?err, "system clock is before unix epoch while stamping pi bridge event");
            match i64::try_from(err.duration().as_millis()) {
                Ok(timestamp) => -timestamp,
                Err(err) => {
                    warn!(error = ?err, "pi bridge event timestamp exceeded negative i64 range");
                    i64::MIN
                }
            }
        }
    }
}

fn emit_pi_bridge_agent_input(
    envelope_builder: &mut EnvelopeBuilder,
    config: &SpawnConfig,
    input_kind: InputKind,
    text: &str,
    output: &mut String,
) -> Result<(), std::io::Error> {
    let redacted = redact_agent_input(text, config);
    let event = AgentEvent::AgentInput {
        envelope: envelope_builder.build_with_source(Source::Driver),
        input_kind,
        text: redacted.text,
        redactions: redacted.redactions,
    };
    render_pi_bridge_event(&event, output)
}

fn render_pi_bridge_event(event: &AgentEvent, output: &mut String) -> Result<(), std::io::Error> {
    crate::agent::capture_text(event, output);
    let stdout = std::io::stdout();
    let mut stdout = stdout.lock();
    match event {
        AgentEvent::AgentInput {
            input_kind,
            text,
            redactions,
            ..
        } => {
            writeln!(stdout, "\n[agent input: {input_kind:?}]\n{text}")?;
            if let Some(redactions) = redactions {
                for redaction in redactions {
                    writeln!(
                        stdout,
                        "[redaction] {} ({})",
                        redaction.marker,
                        redaction.class.as_wire(),
                    )?;
                }
            }
            stdout.flush()?;
        }
        AgentEvent::TextDelta { text, .. } => {
            write!(stdout, "{text}")?;
            stdout.flush()?;
        }
        AgentEvent::ToolCall { tool, params, .. } => {
            if verbose_pi_bridge_tools() {
                writeln!(stdout, "\n[tool] {tool} {params}")?;
            } else {
                writeln!(stdout, "\n[tool] {tool}")?;
            }
        }
        AgentEvent::ToolResult {
            output: body,
            is_error,
            ..
        } => {
            if (*is_error || verbose_pi_bridge_tools())
                && let Some(body) = renderable_tool_body(body, *is_error)
            {
                let label = if *is_error {
                    "tool error"
                } else {
                    "tool result"
                };
                writeln!(stdout, "\n[{label}] {body}")?;
            }
        }
        AgentEvent::ToolProgress { text, .. } => {
            if verbose_pi_bridge_tools()
                && let Some(body) = renderable_tool_body(text, false)
            {
                writeln!(stdout, "\n[tool progress] {body}")?;
            }
        }
        AgentEvent::Error { message, .. } => {
            writeln!(std::io::stderr().lock(), "\n[agent error] {message}")?;
        }
        _ => {}
    }
    Ok(())
}

fn renderable_tool_body(body: &str, is_error: bool) -> Option<&str> {
    let trimmed = body.trim();
    if !is_error && (trimmed.is_empty() || trimmed == "(no output)") {
        return None;
    }
    Some(trimmed)
}

async fn read_pi_bridge_follow_up(
    session: &mut AgentSession<Active>,
    config: &SpawnConfig,
    envelope_builder: &mut EnvelopeBuilder,
    output: &mut String,
) -> Result<bool, ChatError> {
    {
        let stdout = std::io::stdout();
        let mut stdout = stdout.lock();
        write!(stdout, "\nloom inbox pi> ")?;
        stdout.flush()?;
    }
    let mut line = String::new();
    let n = std::io::stdin().read_line(&mut line)?;
    if n == 0 {
        return Ok(false);
    }
    while line.ends_with('\n') || line.ends_with('\r') {
        line.pop();
    }
    emit_pi_bridge_agent_input(envelope_builder, config, InputKind::FollowUp, &line, output)?;
    session.follow_up(&line).await?;
    Ok(true)
}

fn ensure_bridge_output_newline(output: &mut String) -> Result<(), std::io::Error> {
    if !output.ends_with('\n') {
        let stdout = std::io::stdout();
        let mut stdout = stdout.lock();
        writeln!(stdout)?;
        stdout.flush()?;
        output.push('\n');
    }
    Ok(())
}

const LOOM_INBOX_PI_FORCE_BRIDGE: &str = "LOOM_INBOX_PI_FORCE_BRIDGE";
const LOOM_INBOX_PI_VERBOSE_TOOLS: &str = "LOOM_INBOX_PI_VERBOSE_TOOLS";

fn should_use_pi_tui_shell_out() -> bool {
    if truthy_env(LOOM_INBOX_PI_FORCE_BRIDGE) {
        return false;
    }
    std::io::stdin().is_terminal() && std::io::stdout().is_terminal()
}

fn truthy_env(name: &str) -> bool {
    std::env::var(name).is_ok_and(|value| {
        let value = value.trim();
        value == "1" || value.eq_ignore_ascii_case("true") || value.eq_ignore_ascii_case("yes")
    })
}

fn verbose_pi_bridge_tools() -> bool {
    truthy_env(LOOM_INBOX_PI_VERBOSE_TOOLS)
}

type PiTuiLaunch = pi_tui::Launch;

fn prepare_pi_tui_launch(
    workspace: &Path,
    selection: &AgentSelection,
    scratch_dir: &Path,
) -> Result<PiTuiLaunch, ChatError> {
    pi_tui::prepare_launch(workspace, selection, scratch_dir).map_err(ChatError::Scratch)
}

fn run_native(mut command: Command) -> Result<(), ChatError> {
    let status = command
        .stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()?;
    if status.success() {
        Ok(())
    } else {
        Err(ChatError::WrixExit {
            status: status.to_string(),
        })
    }
}

fn run_pi_tui_shell_out(command: Command, session_dir: &Path) -> Result<String, ChatError> {
    run_native(command)?;
    read_pi_session_transcript(session_dir)
}

fn read_pi_session_transcript(session_dir: &Path) -> Result<String, ChatError> {
    let Some(path) = latest_pi_session_file(session_dir)? else {
        return Ok(String::new());
    };
    let raw = fs::read_to_string(path)?;
    session_transcript_from_str(&raw, AgentKind::Pi)
}

fn latest_pi_session_file(session_dir: &Path) -> Result<Option<PathBuf>, ChatError> {
    let entries = match fs::read_dir(session_dir) {
        Ok(entries) => entries,
        Err(err) if err.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(err) => return Err(ChatError::Scratch(err)),
    };
    let mut newest: Option<(std::time::SystemTime, PathBuf)> = None;
    for entry in entries {
        let entry = entry?;
        let path = entry.path();
        if path.extension().and_then(|ext| ext.to_str()) != Some("jsonl") {
            continue;
        }
        let modified = entry.metadata()?.modified()?;
        if newest
            .as_ref()
            .is_none_or(|(newest_modified, _)| modified > *newest_modified)
        {
            newest = Some((modified, path));
        }
    }
    Ok(newest.map(|(_, path)| path))
}

fn session_transcript_from_str(raw: &str, kind: AgentKind) -> Result<String, ChatError> {
    let mut messages = Vec::new();
    for line in raw.lines() {
        if line.trim().is_empty() {
            continue;
        }
        let entry = serde_json::from_str::<serde_json::Value>(line)
            .map_err(|err| ProtocolError::invalid_protocol_line(line, err))?;
        let expected_type = match kind {
            AgentKind::Pi => "message",
            AgentKind::Claude => "assistant",
            AgentKind::Direct => {
                return Err(ChatError::AgentSelection(
                    "Direct has no native transcript".into(),
                ));
            }
        };
        if entry.get("type").and_then(serde_json::Value::as_str) != Some(expected_type)
            || entry
                .get("isSidechain")
                .and_then(serde_json::Value::as_bool)
                == Some(true)
        {
            continue;
        }
        let Some(message) = entry.get("message") else {
            continue;
        };
        if message.get("role").and_then(serde_json::Value::as_str) != Some("assistant") {
            continue;
        }
        let text = pi_content_text(message.get("content"));
        if !text.trim().is_empty() {
            messages.push(text);
        }
    }
    Ok(messages.join("\n"))
}

fn pi_content_text(content: Option<&serde_json::Value>) -> String {
    match content {
        Some(serde_json::Value::String(text)) => text.clone(),
        Some(serde_json::Value::Array(blocks)) => blocks
            .iter()
            .filter_map(|block| {
                if block.get("type").and_then(serde_json::Value::as_str) != Some("text") {
                    return None;
                }
                block
                    .get("text")
                    .and_then(serde_json::Value::as_str)
                    .or_else(|| block.get("content").and_then(serde_json::Value::as_str))
            })
            .collect::<Vec<_>>()
            .join(""),
        _ => String::new(),
    }
}

fn install_claude_capture(workspace: &Path, scratch: &ScratchSession) -> Result<(), ChatError> {
    let script = scratch.path().join("capture-claude.sh");
    fs::write(
        &script,
        "#!/usr/bin/env bash\nset -euo pipefail\ncapture_dir=\"$(cd -- \"$(dirname -- \"${BASH_SOURCE[0]}\")\" && pwd)\"\nrm -f -- \"$capture_dir/native-transcript.jsonl\"\ntranscript=\"$(jq -er '.transcript_path | strings')\"\ncp -- \"$transcript\" \"$capture_dir/native-transcript.jsonl.tmp\"\nmv -- \"$capture_dir/native-transcript.jsonl.tmp\" \"$capture_dir/native-transcript.jsonl\"\n",
    )?;
    let relative = script
        .strip_prefix(workspace)
        .map_err(|error| ChatError::Config(error.to_string()))?;
    let command = format!(
        "bash '{}'",
        relative.to_string_lossy().replace('\'', "'\\''")
    );
    let mut settings: serde_json::Value =
        serde_json::from_slice(&fs::read(scratch.claude_settings())?)?;
    settings["hooks"]["SessionEnd"] =
        serde_json::json!([{"hooks":[{"type":"command","command":command}]}]);
    fs::write(
        scratch.claude_settings(),
        format!("{}\n", serde_json::to_string_pretty(&settings)?),
    )?;
    Ok(())
}

pub fn build_wrix_argv(
    workspace: &Path,
    prompt_body: &str,
    agent_kind: AgentKind,
    claude_settings: Option<&Path>,
) -> Vec<String> {
    let mut argv = vec![
        "run".to_string(),
        workspace.to_string_lossy().into_owned(),
        agent_command(agent_kind).to_string(),
    ];
    if matches!(agent_kind, AgentKind::Claude) {
        if let Some(settings) = claude_settings {
            argv.push("--settings".to_string());
            argv.push(settings.to_string_lossy().into_owned());
        }
        argv.push("--dangerously-skip-permissions".to_string());
    }
    argv.push(prompt_body.to_string());
    argv
}

const fn agent_command(kind: AgentKind) -> &'static str {
    match kind {
        AgentKind::Claude => "claude",
        AgentKind::Pi => "pi",
        AgentKind::Direct => "loom-direct-runner",
    }
}

fn select_visible(
    queue: Vec<InboxItem>,
    target: Option<&ChatTarget>,
) -> Result<Vec<InboxItem>, ChatError> {
    let Some(target) = target else {
        return Ok(queue);
    };
    let total = u32::try_from(queue.len()).unwrap_or(u32::MAX);
    let item = match target {
        ChatTarget::Index(index) => {
            find_by_index(&queue, *index).ok_or(ChatError::IndexOutOfRange {
                index: *index,
                total,
            })?
        }
        ChatTarget::Bead(id) => {
            find_by_bead_id(&queue, id).ok_or_else(|| ChatError::BeadNotFound { id: id.clone() })?
        }
        ChatTarget::Proposal(id) => find_by_proposal_id(&queue, id)
            .ok_or_else(|| ChatError::ProposalNotFound { id: id.clone() })?,
    };
    Ok(vec![item.clone()])
}

const fn single_bead(items: &[InboxItem]) -> Option<&BeadId> {
    if items.len() == 1 {
        Some(&items[0].bead.id)
    } else {
        None
    }
}

fn load_companion_paths(
    workspace: &Path,
    spec_filter: Option<&SpecLabel>,
    items: &[InboxItem],
) -> Result<Vec<String>, ChatError> {
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let mut labels: std::collections::BTreeSet<String> = std::collections::BTreeSet::new();
    if let Some(label) = spec_filter {
        labels.insert(label.as_str().to_string());
    } else {
        for item in items {
            if let Some(label) = &item.spec {
                labels.insert(label.as_str().to_string());
            }
        }
    }
    let mut paths: std::collections::BTreeSet<String> = std::collections::BTreeSet::new();
    for label in &labels {
        let spec_label: SpecLabel = label.parse()?;
        for path in db.companions(&spec_label)? {
            paths.insert(path);
        }
    }
    Ok(paths.into_iter().collect())
}

fn resolve_chat_selection(
    cli_profile: Option<&ProfileName>,
    agent_override: Option<AgentKind>,
    config: &LoomConfig,
) -> Result<AgentSelection, ChatError> {
    let mut selection = config.agent_for(Phase::Inbox);
    if let Some(p) = cli_profile {
        selection.profile = p.clone();
    }
    if let Some(kind) = agent_override {
        selection.backend = config.backend_settings(kind);
    }
    if matches!(selection.kind(), AgentKind::Direct) {
        return Err(ChatError::AgentSelection(
            "direct backend cannot run interactive `loom inbox chat`".to_string(),
        ));
    }
    Ok(selection)
}

#[cfg(test)]
mod tests {
    use super::*;
    use loom_driver::bd::{Bead, Label};
    use std::path::PathBuf;

    fn bead(id: &str, labels: &[&str]) -> Bead {
        Bead {
            id: BeadId::new(id).expect("valid bead id"),
            title: id.to_string(),
            description: String::new(),
            status: loom_driver::bd::Status::Open,
            priority: loom_driver::bd::Priority::P2,
            issue_type: loom_driver::bd::IssueType::Task,
            labels: labels
                .iter()
                .map(|label| Label::new(*label).expect("valid Label"))
                .collect(),
            parent: None,
            metadata: std::collections::BTreeMap::default(),
            notes: None,
        }
    }

    #[test]
    fn pi_bridge_suppresses_empty_success_tool_bodies() {
        assert_eq!(renderable_tool_body("", false), None);
        assert_eq!(renderable_tool_body("  (no output)\n", false), None);
        assert_eq!(renderable_tool_body("failure", true), Some("failure"));
    }

    #[test]
    fn argv_starts_with_wrix_run_and_workspace() {
        let settings = PathBuf::from("/workspace/.loom/scratch/inbox/claude-settings.json");
        let argv = build_wrix_argv(
            &PathBuf::from("/work"),
            "PROMPT",
            AgentKind::Claude,
            Some(&settings),
        );
        assert_eq!(argv[0], "run");
        assert_eq!(argv[1], "/work");
        assert_eq!(argv[2], "claude");
    }

    #[test]
    fn argv_passes_prompt_to_claude_with_skip_permissions() {
        let settings = PathBuf::from("/workspace/.loom/scratch/inbox/claude-settings.json");
        let argv = build_wrix_argv(
            &PathBuf::from("/work"),
            "PROMPT BODY",
            AgentKind::Claude,
            Some(&settings),
        );
        assert_eq!(argv[2], "claude");
        assert_eq!(argv[3], "--settings");
        assert_eq!(argv[4], settings.to_string_lossy());
        assert_eq!(argv[5], "--dangerously-skip-permissions");
        assert_eq!(argv[6], "PROMPT BODY");
    }

    #[test]
    fn argv_passes_prompt_to_pi_without_claude_flags() {
        let argv = build_wrix_argv(&PathBuf::from("/work"), "PROMPT BODY", AgentKind::Pi, None);
        assert_eq!(argv[2], "pi");
        assert_eq!(argv[3], "PROMPT BODY");
        assert!(!argv.iter().any(|a| a == "--dangerously-skip-permissions"));
        assert!(!argv.iter().any(|a| a == "--settings"));
    }

    #[test]
    fn pi_tui_argv_uses_wrix_run_with_session_extension_and_model_args() {
        let selection = AgentSelection {
            profile: ProfileName::new("base").unwrap(),
            backend: loom_driver::config::BackendSettings::Pi,
            provider: Some("openai".parse().unwrap()),
            model_id: Some("gpt-4o".parse().unwrap()),
            thinking_level: Some(loom_driver::agent::ThinkingLevel::High),
        };
        let argv = pi_tui::build_wrix_argv(
            &PathBuf::from("/work"),
            &PathBuf::from("/workspace/.loom/scratch/inbox/prompt.txt"),
            &selection,
            &PathBuf::from("/workspace/.loom/scratch/inbox/pi-sessions"),
            &PathBuf::from("/workspace/.loom/scratch/inbox/loom-pi-repin-extension.js"),
        );
        assert_eq!(argv[0], "run");
        assert_eq!(argv[1], "/work");
        assert_eq!(argv[2], "pi");
        assert!(
            argv.windows(2)
                .any(|w| w[0] == "--provider" && w[1] == "openai")
        );
        assert!(
            argv.windows(2)
                .any(|w| w[0] == "--model" && w[1] == "gpt-4o")
        );
        assert!(
            argv.windows(2)
                .any(|w| w[0] == "--thinking" && w[1] == "high")
        );
        assert!(argv.iter().any(|a| a == "-e"));
        assert!(argv.iter().any(|a| a == "--session-dir"));
        assert_eq!(
            argv.last().map(String::as_str),
            Some("@/workspace/.loom/scratch/inbox/prompt.txt")
        );
        assert!(!argv.iter().any(|a| a == "spawn"));
        assert!(!argv.iter().any(|a| a == "--stdio"));
    }

    #[test]
    fn pi_repin_extension_raises_errors_when_repin_files_cannot_be_read() {
        let source = pi_tui::repin_extension_source(
            &PathBuf::from("/workspace/.loom/scratch/inbox/prompt.txt"),
            &PathBuf::from("/workspace/.loom/scratch/inbox/scratch.md"),
        );

        assert!(source.contains("readRequiredText(promptPath, \"prompt\")"));
        assert!(source.contains("readRequiredText(scratchpadPath, \"scratchpad\")"));
        assert!(source.contains("Loom compaction recovery could not read"));
        assert!(!source.contains("catch (_err)"));
    }

    #[test]
    fn chat_kind_filter_can_surface_infra_items() {
        let beads = vec![
            bead("lm-blocked", &["loom:blocked"]),
            bead("lm-infra", &["loom:infra"]),
        ];
        let queue = build_queue(&beads, None, Some(InboxKind::Infra), false);
        let visible = select_visible(queue, Some(&ChatTarget::Index(1))).expect("visible infra");
        assert_eq!(visible.len(), 1);
        assert_eq!(visible[0].kind, InboxKind::Infra);
        assert_eq!(visible[0].bead.id, BeadId::new("lm-infra").expect("valid"));
    }

    #[test]
    fn pi_session_transcript_extracts_assistant_text_blocks_for_marker_parse() {
        let raw = [
            serde_json::json!({"type":"session","version":3,"id":"s","timestamp":"now","cwd":"/work"}).to_string(),
            serde_json::json!({"type":"message","id":"u","parentId":null,"timestamp":"now","message":{"role":"user","content":"hi"}}).to_string(),
            serde_json::json!({"type":"message","id":"a","parentId":"u","timestamp":"now","message":{"role":"assistant","content":[{"type":"text","text":"Done\n"},{"type":"text","text":"LOOM_COMPLETE"}]}}).to_string(),
        ]
        .join("\n");
        let transcript =
            session_transcript_from_str(&raw, AgentKind::Pi).expect("transcript parses");
        assert_eq!(transcript, "Done\nLOOM_COMPLETE");
    }

    #[test]
    fn native_claude_session_end_capture_is_authoritative_and_not_appended_twice() {
        use std::io::Write as _;

        let workspace = tempfile::tempdir().unwrap();
        let scratch = ScratchSession::open(
            workspace.path(),
            "native-capture",
            "LOOM_APPLY: prompt echo",
            "test",
        )
        .unwrap();
        install_claude_capture(workspace.path(), &scratch).unwrap();
        let transcript = scratch.path().join("fixture.jsonl");
        let raw = [
            serde_json::json!({"type":"user","message":{"role":"user","content":"LOOM_APPLY: {\"proposals\":[\"lm-prompt.1\"]}"}}),
            serde_json::json!({"type":"assistant","isSidechain":true,"message":{"role":"assistant","content":"LOOM_NOOP"}}),
            serde_json::json!({"type":"driver_event","message":{"role":"assistant","content":"LOOM_RETRY"}}),
            serde_json::json!({"type":"assistant","message":{"role":"assistant","content":[{"type":"tool_use","text":"LOOM_WAITING"},{"type":"text","text":"Hello"}]}}),
            serde_json::json!({"type":"assistant","message":{"role":"assistant","content":[{"type":"text","text":"LOOM_COMPLETE"}]}}),
        ].into_iter().map(|value| value.to_string()).collect::<Vec<_>>().join("\n");
        fs::write(&transcript, raw).unwrap();
        let settings: serde_json::Value =
            serde_json::from_slice(&fs::read(scratch.claude_settings()).unwrap()).unwrap();
        let hook = settings["hooks"]["SessionEnd"][0]["hooks"][0]["command"]
            .as_str()
            .unwrap();
        for _ in 0..2 {
            let mut child = Command::new("bash")
                .args(["-c", hook])
                .current_dir(workspace.path())
                .stdin(Stdio::piped())
                .spawn()
                .unwrap();
            write!(
                child.stdin.take().unwrap(),
                "{}",
                serde_json::json!({"transcript_path":transcript})
            )
            .unwrap();
            assert!(child.wait().unwrap().success());
        }
        let captured = fs::read_to_string(scratch.path().join("native-transcript.jsonl")).unwrap();
        let text = session_transcript_from_str(&captured, AgentKind::Claude).unwrap();
        assert_eq!(text, "Hello\nLOOM_COMPLETE");
        assert!(matches!(
            parse_terminal_marker(&text).unwrap(),
            TerminalMarker::Complete
        ));
    }

    #[test]
    fn native_capture_failure_cannot_reuse_an_earlier_snapshot() {
        let workspace = tempfile::tempdir().unwrap();
        let scratch =
            ScratchSession::open(workspace.path(), "failed-capture", "prompt", "test").unwrap();
        install_claude_capture(workspace.path(), &scratch).unwrap();
        let snapshot = scratch.path().join("native-transcript.jsonl");
        fs::write(&snapshot, "stale admitted transcript").unwrap();
        let settings: serde_json::Value =
            serde_json::from_slice(&fs::read(scratch.claude_settings()).unwrap()).unwrap();
        let hook = settings["hooks"]["SessionEnd"][0]["hooks"][0]["command"]
            .as_str()
            .unwrap();
        let mut child = Command::new("bash")
            .args(["-c", hook])
            .current_dir(workspace.path())
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .unwrap();
        child.stdin.take().unwrap().write_all(b"{}").unwrap();
        let output = child.wait_with_output().unwrap();
        assert!(!output.status.success());
        assert!(!snapshot.exists());
    }

    #[test]
    fn native_pi_never_promotes_stdout_when_session_text_is_absent() {
        let directory = tempfile::tempdir().unwrap();
        let mut command = Command::new("bash");
        command.args([
            "-c",
            "set -euo pipefail\nprintf 'LOOM_APPLY: {\"proposals\":[\"lm-false.1\"]}\\n'",
        ]);
        let captured = run_pi_tui_shell_out(command, directory.path()).unwrap();
        assert_eq!(captured, "");
        assert!(
            parse_terminal_marker(&captured)
                .unwrap_err()
                .is_conversation()
        );
    }

    #[test]
    fn pi_session_transcript_rejects_malformed_jsonl_record() {
        let err = session_transcript_from_str("{not json}\n", AgentKind::Pi)
            .expect_err("malformed record");
        assert!(
            matches!(err, ChatError::Protocol(ProtocolError::InvalidJson { .. })),
            "malformed transcript record must surface the parse error: {err}"
        );
    }

    #[test]
    fn argv_never_contains_profile_spawn_or_stdio_or_spawn_config() {
        let settings = PathBuf::from("/workspace/.loom/scratch/inbox/claude-settings.json");
        let argv = build_wrix_argv(
            &PathBuf::from("/work"),
            "PROMPT",
            AgentKind::Claude,
            Some(&settings),
        );
        assert!(!argv.iter().any(|a| a == "--profile"));
        assert!(!argv.iter().any(|a| a == "spawn"));
        assert!(!argv.iter().any(|a| a == "--stdio"));
        assert!(!argv.iter().any(|a| a == "--spawn-config"));
    }
}
