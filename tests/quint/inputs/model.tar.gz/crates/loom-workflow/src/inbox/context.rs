use std::path::Path;

use loom_templates::SkillIndexMarkdown;
use loom_templates::inbox::{
    ClarifyOption, InboxContext, InboxItem as TemplateItem, InfraItem, ItemKind, TuneItem,
};

use super::list::{InboxItem, InboxKind};

/// Build the typed [`InboxContext`] consumed by the `inbox.md` Askama template.
pub fn build_inbox_context(
    workspace: &Path,
    pinned_context: String,
    companion_paths: Vec<String>,
    items: &[InboxItem],
    scratchpad_path: String,
    skill_index: SkillIndexMarkdown,
) -> InboxContext {
    InboxContext {
        pinned_context,
        companion_paths,
        inbox_items: items
            .iter()
            .map(|item| to_template_item(workspace, item))
            .collect(),
        scratchpad_path,
        skill_index,
    }
}

fn to_template_item(workspace: &Path, item: &InboxItem) -> TemplateItem {
    let (options_summary, options) = match &item.brief {
        Ok(brief) => (
            Some(brief.summary().to_owned()),
            brief
                .options()
                .iter()
                .map(|opt| ClarifyOption {
                    n: opt.n,
                    title: Some(opt.title.clone()),
                    body: Some(opt.body.clone()),
                })
                .collect(),
        ),
        Err(_) => (None, Vec::new()),
    };
    let mut notes = item.bead.notes.clone().filter(|notes| !notes.is_empty());
    if let Some(repair) = item.brief_repair() {
        notes = Some(match notes {
            Some(notes) => format!("{notes}\n\n{repair}"),
            None => repair,
        });
    }
    TemplateItem {
        index: item.index,
        id: item.durable_id().to_owned(),
        bead_id: item.bead.id.to_string(),
        spec_label: item
            .spec
            .as_ref()
            .map_or_else(|| "—".to_owned(), ToString::to_string),
        title: item.bead.title.clone(),
        body: item.bead.description.clone(),
        notes,
        options_summary,
        options,
        kind: match item.kind {
            InboxKind::Clarify => ItemKind::Clarify,
            InboxKind::Blocked => ItemKind::Blocked,
            InboxKind::Infra => ItemKind::Infra,
            InboxKind::Tune => ItemKind::Tune,
        },
        infra: item.infra.as_ref().map(|infra| InfraItem {
            phase: infra.phase.clone(),
            first_event_seen: infra.first_event_seen,
            attempt: infra.attempt.clone(),
            max_attempts: infra.max_attempts.clone(),
            exit_status: infra.exit_status.clone(),
            stderr_tail: infra.stderr_tail.clone(),
            spawn_error_tail: infra.spawn_error_tail.clone(),
            log_path: infra.log_path.clone(),
        }),
        tune: item.tune.as_ref().map(|tune| {
            let envelope = workspace.join(".loom/tune").join(&tune.proposal_id);
            TuneItem {
                state: tune.state.clone(),
                proposal_branch: tune.proposal_branch.clone(),
                proposal_head: tune.proposal_head.clone(),
                base_commit: tune.base_commit.clone(),
                envelope_path: envelope.to_string_lossy().into_owned(),
                repo_path: envelope.join("repo").to_string_lossy().into_owned(),
                manifest_path: envelope
                    .join("manifest.json")
                    .to_string_lossy()
                    .into_owned(),
                evidence_path: envelope.join("evidence.md").to_string_lossy().into_owned(),
            }
        }),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use loom_driver::bd::{Bead, Label};
    use loom_driver::identifier::BeadId;
    use serde_json::json;

    fn bead(id: &str, title: &str, desc: &str, labels: &[&str]) -> Bead {
        Bead {
            id: BeadId::new(id).expect("valid bead id"),
            title: title.into(),
            description: desc.into(),
            status: loom_driver::bd::Status::Open,
            priority: loom_driver::bd::Priority::P2,
            issue_type: loom_driver::bd::IssueType::Task,
            labels: labels
                .iter()
                .map(|s| Label::new(*s).expect("valid Label"))
                .collect(),
            parent: None,
            metadata: std::collections::BTreeMap::default(),
            notes: None,
        }
    }

    #[test]
    fn rendered_inbox_template_lists_each_item() {
        let beads = [
            bead(
                "lm-2",
                "Title A",
                "## Options — sum A\n\n### Option 1 — t1\nbody1\n",
                &["spec:harness", "loom:clarify"],
            ),
            bead(
                "lm-3",
                "Title B",
                "no options",
                &["spec:profiles", "loom:blocked"],
            ),
        ];
        let items = super::super::list::build_queue(&beads, None, None, true);
        let ctx = build_inbox_context(
            Path::new("/workspace"),
            "PIN".into(),
            vec!["lib/sandbox/".into()],
            &items,
            "/workspace/.loom/scratch/inbox/scratch.md".into(),
            SkillIndexMarkdown::empty(),
        );
        let body = askama::Template::render(&ctx).expect("render");
        assert!(body.contains("lm-2"), "{body}");
        assert!(body.contains("lm-3"), "{body}");
        assert!(body.contains("spec:harness"), "{body}");
        assert!(body.contains("Title A"), "{body}");
        assert!(body.contains("sum A"), "{body}");
        assert!(body.contains("- lib/sandbox/"), "{body}");
    }

    #[test]
    fn tune_template_item_carries_artifact_paths() {
        let mut tune = bead("lm-tune", "Tune proposal", "body", &["loom:tune"]);
        tune.metadata
            .insert("loom.tune.state".into(), json!("pending"));
        tune.metadata.insert(
            "loom.tune.proposal_branch".into(),
            json!("loom/tune/lm-tune"),
        );
        let items = super::super::list::build_queue(&[tune], None, None, true);
        let item = to_template_item(Path::new("/work"), &items[0]);
        let tune = item.tune.expect("tune metadata");
        assert_eq!(tune.state, "pending");
        assert_eq!(tune.repo_path, "/work/.loom/tune/lm-tune/repo");
        assert_eq!(item.spec_label, "—");
    }

    #[test]
    fn infra_template_item_carries_diagnostics() {
        let mut infra = bead("lm-infra", "Infra issue", "diag", &["loom:infra"]);
        infra
            .metadata
            .insert("loom.infra.phase".into(), json!("interrupted"));
        infra
            .metadata
            .insert("loom.infra.first_event_seen".into(), json!(true));
        infra.metadata.insert("loom.infra.attempt".into(), json!(1));
        infra
            .metadata
            .insert("loom.infra.max_attempts".into(), json!(3));
        infra
            .metadata
            .insert("loom.infra.exit_status".into(), json!(137));
        infra
            .metadata
            .insert("loom.infra.stderr_tail".into(), json!("stderr tail"));
        infra
            .metadata
            .insert("loom.infra.spawn_error_tail".into(), json!("spawn tail"));
        infra
            .metadata
            .insert("loom.infra.log_path".into(), json!("log.jsonl"));

        let items = super::super::list::build_queue(&[infra], None, None, true);
        let ctx = build_inbox_context(
            Path::new("/workspace"),
            String::new(),
            Vec::new(),
            &items,
            "/workspace/.loom/scratch/inbox/scratch.md".into(),
            SkillIndexMarkdown::empty(),
        );
        let body = askama::Template::render(&ctx).expect("render");
        assert!(body.contains("[infra]"), "{body}");
        assert!(
            body.contains("worker did not reach semantic judgement"),
            "{body}"
        );
        assert!(body.contains("Phase: `interrupted`"), "{body}");
        assert!(body.contains("First event seen: `true`"), "{body}");
        assert!(body.contains("Attempt: `1/3`"), "{body}");
        assert!(body.contains("Exit status: `137`"), "{body}");
        assert!(body.contains("stderr tail"), "{body}");
        assert!(body.contains("spawn tail"), "{body}");
        assert!(body.contains("Log path: `log.jsonl`"), "{body}");
    }

    #[test]
    fn missing_spec_label_renders_em_dash() {
        let beads = [bead("lm-2", "t", "", &["loom:clarify"])];
        let items = super::super::list::build_queue(&beads, None, None, true);
        let rendered = to_template_item(Path::new("/work"), &items[0]);
        assert_eq!(rendered.spec_label, "—");
    }
}
