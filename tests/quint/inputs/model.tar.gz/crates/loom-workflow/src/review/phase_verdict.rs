//! Per-phase verdict gate (`specs/harness.md` § Verdict Gate).
//!
//! After every agent phase ends, `loom review` evaluates the result through
//! this deterministic gate before the bead's state can advance. The gate
//! combines four mechanical/agent-judged signals — exit marker, bd-closed,
//! diff emptiness, and the review verdict — into one of `done`, `blocked`,
//! `clarify`, or `recovery` with a typed cause.
//!
//! Logic is a pure function of the four signals; the binary owns the
//! plumbing that produces them and the recovery-loop dispatch on the other
//! side.

use loom_protocol::gate::WalkOutput;
use loom_templates::finding::Finding;
use loom_templates::previous_failure::BadWalk;

use super::verify_fail::VerifyFailure;
use crate::todo::ExitSignal;

/// Compatibility vocabulary for consumers displaying legacy concern labels.
///
/// Current review protocol classification uses each [`Finding`]'s typed token,
/// not this smaller display vocabulary or free-form terminal-summary parsing.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReviewConcern {
    VerifierBypass,
    FabricatedResult,
    WeakAssertion,
    CoincidentalPass,
    Mock,
    Scope,
    Judge,
    StyleRule,
    SurfaceDrift,
    CrossSpecClash,
    TemplateSpecDrift,
    SpecConventionsViolation,
}

impl ReviewConcern {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::VerifierBypass => "verifier-bypass",
            Self::FabricatedResult => "fabricated-result",
            Self::WeakAssertion => "weak-assertion",
            Self::CoincidentalPass => "coincidental-pass",
            Self::Mock => "mock",
            Self::Scope => "scope",
            Self::Judge => "judge",
            Self::StyleRule => "style-rule",
            Self::SurfaceDrift => "surface-drift",
            Self::CrossSpecClash => "cross-spec-clash",
            Self::TemplateSpecDrift => "template-spec-drift",
            Self::SpecConventionsViolation => "spec-conventions-violation",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s.trim() {
            "verifier-bypass" => Some(Self::VerifierBypass),
            "fabricated-result" => Some(Self::FabricatedResult),
            "weak-assertion" => Some(Self::WeakAssertion),
            "coincidental-pass" => Some(Self::CoincidentalPass),
            "mock" => Some(Self::Mock),
            "scope" => Some(Self::Scope),
            "judge" => Some(Self::Judge),
            "style-rule" => Some(Self::StyleRule),
            "surface-drift" => Some(Self::SurfaceDrift),
            "cross-spec-clash" => Some(Self::CrossSpecClash),
            "template-spec-drift" => Some(Self::TemplateSpecDrift),
            "spec-conventions-violation" => Some(Self::SpecConventionsViolation),
            _ => None,
        }
    }
}

/// Why the gate routes to recovery. Mirrors the cause strings in the spec
/// table so they show up unchanged in `bd update --notes` when retries are
/// exhausted.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RecoveryCause {
    /// No exit marker found in the agent output.
    SwallowedMarker,
    /// Marker was emitted but the bead was not bd-closed.
    IncompleteSignaling,
    /// `LOOM_COMPLETE` with an empty worktree diff. `LOOM_NOOP` is the
    /// legitimate path for an empty diff and never produces this cause.
    ZeroProgress,
    /// Deterministic-tier failures retained for the bounded recovery body.
    /// Review findings use the independent typed `ReviewConcern` path.
    VerifyFail { failures: Vec<VerifyFailure> },
    /// Verify passed but the reviewer raised a concern. Carries the parsed
    /// `summary` field from the terminal `LOOM_CONCERN: {"summary": "..."}`
    /// marker and the buffered list of streamed `LOOM_FINDING:` records so
    /// downstream surfaces (`bd update --notes`, `previous_failure`) can
    /// derive the human-readable concern label from `findings[0].token`
    /// (or compute a "multiple" label when heterogeneous) per
    /// `specs/gate.md` § Findings and Minting — the terminal `summary`
    /// rides through for the verdict log only.
    ReviewConcern {
        summary: String,
        findings: Vec<Finding>,
    },
    /// An `EventSink::react()` returned `SessionCommand::Abort` and the
    /// driver cancelled the session before the agent emitted a marker.
    /// Disambiguates "no marker" from `swallowed-marker` per
    /// `specs/harness.md` §"Disambiguating no marker". `reason` is
    /// the verbatim payload the observer emitted.
    ObserverAbort { reason: String },
    /// Agent emitted `LOOM_COMPLETE` / `LOOM_NOOP` and bd-closed the bead,
    /// but the bead's worktree left `git status --porcelain` non-empty.
    /// Routes BEFORE verify-fail / review-concern (`specs/harness.md`
    /// §"Verdict Gate · Tree-clean check") so verifiers do not run
    /// against a half-staged tree. `dirty_paths` is the already-capped
    /// list (up to 30 entries; an extra `"+N more"` element follows when
    /// the underlying set was larger). Driver caps before construction;
    /// the variant carries already-capped paths.
    TreeNotClean { dirty_paths: Vec<String> },
    /// Review walk's terminal signal was malformed or mismatched with
    /// the streamed-findings count. Wraps the typed
    /// [`BadWalk`](loom_templates::previous_failure::BadWalk) variant from
    /// `loom-templates` so the recovery prompt can render per-variant
    /// framing (per `specs/templates.md` § Typed `PreviousFailure`).
    /// Mirrors [`RecoveryCause::ReviewConcern`]'s wrapped pattern at the
    /// type level.
    BadWalk(BadWalk),
    /// Worker phase emitted `LOOM_RETRY` — the agent self-reported that
    /// this attempt cannot finish but a fresh dispatch is likely to
    /// succeed (environmental failure or agent self-reset per
    /// `specs/harness.md` § Marker definitions). `reason` is the
    /// verbatim prose the agent wrote on the line preceding the marker.
    /// Consumes one `[loop] max_retries` slot; consecutive `LOOM_RETRY`
    /// exits that exhaust the counter escalate to `loom:blocked` with
    /// cause `retry-exhausted` (`DriverNoticeCause::RetryExhausted`).
    AgentRetry { reason: String },
    /// Defense-in-depth: a worker-phase-only marker (`LOOM_RETRY`,
    /// `LOOM_BLOCKED`, `LOOM_CLARIFY`), a loop/todo-only direct
    /// `LOOM_CLARIFY`, or a review-phase-only marker (`LOOM_CONCERN`) was
    /// emitted from a phase that does not admit it. `marker_name` is the
    /// literal marker text; `phase_kind` names the rejecting phase class
    /// (`"interactive"`, `"review"`, or `"worker"`). The agent
    /// should never reach this branch because the partial-pinning matrix
    /// scopes each marker per phase; the gate enforces the rule
    /// mechanically per `specs/harness.md` § Marker definitions.
    WrongPhaseMarker {
        marker_name: &'static str,
        phase_kind: &'static str,
    },
}

impl RecoveryCause {
    /// Stable spec-table label used in user-facing surfaces (logs, bd notes).
    /// The label is the same for every review-concern variant; per-concern
    /// detail lives in [`RecoveryCause::ReviewConcern`]'s payload.
    pub const fn as_str(&self) -> &'static str {
        match self {
            Self::SwallowedMarker => "swallowed-marker",
            Self::IncompleteSignaling => "incomplete-signaling",
            Self::ZeroProgress => "zero-progress",
            Self::VerifyFail { .. } => "verify-fail",
            Self::ReviewConcern { .. } => "review-concern",
            Self::ObserverAbort { .. } => "observer-abort",
            Self::TreeNotClean { .. } => "tree-not-clean",
            Self::BadWalk(_) => "bad-walk",
            Self::AgentRetry { .. } => "agent-retry",
            Self::WrongPhaseMarker { .. } => "wrong-phase-marker",
        }
    }
}

/// One of the five post-gate branches. The driver maps `Recovery` onto
/// `retry` (under `[loop] max_iterations`) or `blocked` (cap exhausted) one
/// layer up.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PhaseVerdict {
    /// Phase passed every gate stage — caller advances state.
    Done,
    /// Loop worker requested a dependency wait. The workflow must validate
    /// open-bead and active-blocker state before accepting it.
    Waiting,
    /// Agent emitted `LOOM_BLOCKED` with a non-empty reason — surface to
    /// user without retry.
    Blocked { reason: String },
    /// Agent emitted `LOOM_CLARIFY` — apply `loom:clarify` and stop.
    Clarify { question: String },
    /// Mechanical or review failure — caller resolves to retry/blocked
    /// against the iteration counter.
    Recovery { cause: RecoveryCause },
}

/// Mechanical inputs the gate consumes alongside the parsed exit marker.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub struct GateInputs {
    /// Bead carries `closed` status after the phase ran.
    pub bd_closed: bool,
    /// `git diff` against the driver branch produced no output.
    pub diff_empty: bool,
    /// Dirty entries reported by `git status --porcelain` on the bead's
    /// worktree, **already capped** (up to 30 entries with an extra
    /// `"+N more"` element when the underlying set was larger; see
    /// [`crate::loop::dirty_paths_from_porcelain`]). Empty when the tree
    /// is clean. Non-empty drives the gate to
    /// [`RecoveryCause::TreeNotClean`] BEFORE verify-fail /
    /// review-concern, so verifiers do not run against a half-staged
    /// tree (`specs/harness.md` §"Verdict Gate · Tree-clean check").
    pub tree_dirty_paths: Vec<String>,
    /// Failure record for every deterministic-tier verifier that exited non-zero.
    /// Empty when every script passed; the gate routes to
    /// [`RecoveryCause::VerifyFail`] when this is non-empty and threads the
    /// list through so downstream surfaces can format `previous_failure`.
    pub verify_failures: Vec<VerifyFailure>,
    /// Complete sealed Review decode/resolution context; absent for non-review phases.
    pub review_walk: Option<WalkOutput>,
}

/// Apply the spec's decision table to the parsed marker plus mechanical
/// signals.
///
/// `None` means no admitted terminal proposal is available.
pub fn decide(marker: Option<&ExitSignal>, mut inputs: GateInputs) -> PhaseVerdict {
    if let Some(walk) = inputs.review_walk.take() {
        if let Some(badwalk) = walk.bad_walk() {
            return PhaseVerdict::Recovery {
                cause: RecoveryCause::BadWalk(badwalk),
            };
        }
        if let Some(ExitSignal::Concern(payload)) =
            walk.context().terminal().map(|located| &located.message)
        {
            return PhaseVerdict::Recovery {
                cause: RecoveryCause::ReviewConcern {
                    summary: payload.summary.to_string(),
                    findings: walk.findings().to_vec(),
                },
            };
        }
        return decide(
            walk.context().terminal().map(|located| &located.message),
            inputs,
        );
    }
    match marker {
        None => PhaseVerdict::Recovery {
            cause: RecoveryCause::SwallowedMarker,
        },
        Some(ExitSignal::Blocked(payload)) => PhaseVerdict::Blocked {
            reason: payload.reason.to_string(),
        },
        Some(ExitSignal::Complete) => decide_progress_marker(false, inputs),
        Some(ExitSignal::Noop) => decide_progress_marker(true, inputs),
        Some(ExitSignal::Waiting) => PhaseVerdict::Waiting,
        Some(ExitSignal::Retry(payload)) => PhaseVerdict::Recovery {
            cause: RecoveryCause::AgentRetry {
                reason: payload.reason.to_string(),
            },
        },
        Some(message) => PhaseVerdict::Recovery {
            cause: RecoveryCause::WrongPhaseMarker {
                marker_name: message.marker(),
                phase_kind: "terminal",
            },
        },
    }
}

/// Compatibility workflow grouping projected onto canonical phase admission.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PhaseKind {
    /// `loom loop` — admits progress, self-report, and dependency-wait
    /// terminals.
    Loop,
    /// `loom todo` — admits worker self-reports; typed `LOOM_TODO` success is
    /// validated by the todo protocol outside this generic marker surface.
    Todo,
    /// `loom gate review` — single-shot inspection phase with a
    /// review-specific terminal contract.
    Review,
    /// `plan_*`, `inbox` — multi-turn interactive sessions handled by the
    /// generic completion surface at this layer.
    Interactive,
}

impl PhaseKind {
    const fn label(self) -> &'static str {
        match self {
            Self::Loop => "loop",
            Self::Todo => "todo",
            Self::Review => "review",
            Self::Interactive => "interactive",
        }
    }
}

/// Apply [`decide`] only to canonical phase-permitted terminal proposals.
#[must_use]
pub fn decide_for_phase(
    marker: Option<&ExitSignal>,
    inputs: GateInputs,
    phase: PhaseKind,
) -> PhaseVerdict {
    if let Some(rejected) = reject_marker_for_phase(marker, phase) {
        return rejected;
    }
    decide(marker, inputs)
}

fn reject_marker_for_phase(marker: Option<&ExitSignal>, phase: PhaseKind) -> Option<PhaseVerdict> {
    let message = marker?;
    let projection = match phase {
        PhaseKind::Loop => loom_protocol::output::Phase::Loop,
        PhaseKind::Todo => loom_protocol::output::Phase::Todo,
        PhaseKind::Review => loom_protocol::output::Phase::Review,
        PhaseKind::Interactive => loom_protocol::output::Phase::Plan,
    };
    if projection.admits(message) && message.role() == loom_protocol::output::Role::Terminal {
        return None;
    }
    let name = message.marker();
    Some(PhaseVerdict::Recovery {
        cause: RecoveryCause::WrongPhaseMarker {
            marker_name: name,
            phase_kind: phase.label(),
        },
    })
}

/// Branch shared by `LOOM_COMPLETE` and `LOOM_NOOP`: both require the bead
/// to be closed and both gate on verify+review. They differ only in how an
/// empty diff is treated — Complete demands non-empty, Noop accepts any.
fn decide_progress_marker(is_noop: bool, inputs: GateInputs) -> PhaseVerdict {
    if !inputs.bd_closed {
        return PhaseVerdict::Recovery {
            cause: RecoveryCause::IncompleteSignaling,
        };
    }
    if !is_noop && inputs.diff_empty {
        return PhaseVerdict::Recovery {
            cause: RecoveryCause::ZeroProgress,
        };
    }
    // Tree-clean check precedes verify-fail / review-concern per
    // `specs/harness.md` §"Verdict Gate · Tree-clean check" — verifiers
    // do NOT run against a half-staged tree because that would conflate
    // the agent's intended diff with its leftover scratch.
    if !inputs.tree_dirty_paths.is_empty() {
        return PhaseVerdict::Recovery {
            cause: RecoveryCause::TreeNotClean {
                dirty_paths: inputs.tree_dirty_paths,
            },
        };
    }
    if !inputs.verify_failures.is_empty() {
        return PhaseVerdict::Recovery {
            cause: RecoveryCause::VerifyFail {
                failures: inputs.verify_failures,
            },
        };
    }
    // The review-concern path is reachable only through
    // [`ExitSignal::Concern`] under the streaming-finding contract;
    // `LOOM_COMPLETE` / `LOOM_NOOP` with no streamed findings is a
    // clean review by construction.
    PhaseVerdict::Done
}

#[cfg(test)]
mod tests {
    use super::*;
    use loom_protocol::output::{Decisions, Reason, Summary};
    use loom_protocol::todo::{NonEmptyString, NonEmptyVec};

    fn reason(text: &str) -> Reason {
        Reason {
            reason: NonEmptyString::new(text).unwrap(),
        }
    }

    fn summary(text: &str) -> Summary {
        Summary {
            summary: NonEmptyString::new(text).unwrap(),
        }
    }

    fn decision_record() -> ExitSignal {
        ExitSignal::Clarify(Decisions {
            decisions: NonEmptyVec::new(vec!["lm-decision".parse().unwrap()]).unwrap(),
        })
    }
    use loom_events::identifier::SpecLabel;
    use loom_templates::finding::{ConcernToken, FindingTarget};

    fn inputs(bd_closed: bool, diff_empty: bool, verify_pass: bool) -> GateInputs {
        let verify_failures = if verify_pass {
            Vec::new()
        } else {
            vec![sample_failure()]
        };
        GateInputs {
            bd_closed,
            diff_empty,
            verify_failures,
            ..GateInputs::default()
        }
    }

    fn sample_failure() -> VerifyFailure {
        VerifyFailure {
            script_path: std::path::PathBuf::from("tests/sample.sh"),
            exit_code: 1,
            stderr: "boom\n".into(),
        }
    }

    fn spec_label(s: &str) -> SpecLabel {
        s.parse().expect("valid spec label")
    }

    fn streamed_finding(token: ConcernToken) -> Finding {
        loom_test_support::finding::resolve(loom_protocol::gate::RawFinding {
            token,
            route: crate::review::FindingRoute::Deferred,
            bonds: vec![spec_label("gate")],
            target: if token == ConcernToken::JudgeFlag {
                FindingTarget::Criterion {
                    spec: spec_label("gate"),
                    anchor: "sample".into(),
                }
            } else {
                FindingTarget::Annotation {
                    target_string: "cargo test --lib sample".into(),
                }
            },
            evidence: "streamed via LOOM_FINDING".to_owned(),
        })
        .expect("valid fixture finding")
    }

    fn review_walk(marker: &ExitSignal, findings: &[Finding]) -> WalkOutput {
        use std::fmt::Write as _;
        let mut output = String::new();
        for finding in findings {
            writeln!(
                output,
                "LOOM_FINDING: {}",
                serde_json::to_string(finding).unwrap()
            )
            .unwrap();
        }
        output.push_str(&marker.to_wire().unwrap());
        WalkOutput::from_stdout(
            &output,
            loom_protocol::gate::DispatchScope::Tree,
            &loom_test_support::finding::FixtureSymbols,
        )
    }

    #[test]
    fn concern_marker_with_streamed_findings_routes_to_review_concern_recovery() {
        let m = ExitSignal::Concern(summary("verifier-bypass -- one finding"));
        let g = GateInputs {
            review_walk: Some(review_walk(
                &m,
                &[streamed_finding(ConcernToken::VerifierBypass)],
            )),
            ..inputs(true, false, true)
        };
        match decide(Some(&m), g) {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::ReviewConcern { summary, findings },
            } => {
                assert_eq!(summary, "verifier-bypass -- one finding");
                assert_eq!(findings.len(), 1);
                assert_eq!(findings[0].token(), ConcernToken::VerifierBypass);
            }
            other => panic!("expected Recovery::ReviewConcern, got {other:?}"),
        }
    }

    /// Under the new streaming-finding contract, an unrecognised
    /// summary with at least one streamed finding routes to
    /// `RecoveryCause::ReviewConcern { summary, findings }`, NOT
    /// `RecoveryCause::SwallowedMarker`. The legacy
    /// `summary`-as-`ReviewConcern`-token fallthrough is excised — the
    /// terminator's role is the verdict-log only. Criterion:
    /// `decide_concern_unrecognized_summary_with_findings_routes_to_review_concern_not_swallowed`.
    #[test]
    fn decide_concern_unrecognized_summary_with_findings_routes_to_review_concern_not_swallowed() {
        let m = ExitSignal::Concern(summary("fictional-concern not in 12-variant enum"));
        let g = GateInputs {
            review_walk: Some(review_walk(
                &m,
                &[streamed_finding(ConcernToken::WeakAssertion)],
            )),
            ..inputs(true, false, true)
        };
        match decide(Some(&m), g) {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::ReviewConcern { summary, findings },
            } => {
                assert_eq!(summary, "fictional-concern not in 12-variant enum");
                assert_eq!(findings.len(), 1);
                assert_eq!(findings[0].token(), ConcernToken::WeakAssertion);
            }
            other => {
                panic!("expected Recovery::ReviewConcern (not SwallowedMarker), got {other:?}")
            }
        }
    }

    #[test]
    fn concern_without_streamed_findings_routes_to_badwalk_concern_without_findings() {
        let m = ExitSignal::Concern(summary("scope drift around the mint pipeline"));
        let g = GateInputs {
            review_walk: Some(review_walk(&m, &[])),
            ..GateInputs::default()
        };
        match decide(Some(&m), g) {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::BadWalk(BadWalk::ConcernWithoutFindings { summary, .. }),
            } => {
                assert_eq!(summary, "scope drift around the mint pipeline");
            }
            other => panic!("expected Recovery::BadWalk(ConcernWithoutFindings), got {other:?}"),
        }
    }

    #[test]
    fn findings_streamed_with_complete_terminator_routes_to_badwalk_findings_without_concern() {
        let streamed = vec![
            streamed_finding(ConcernToken::VerifierBypass),
            streamed_finding(ConcernToken::WeakAssertion),
            streamed_finding(ConcernToken::JudgeFlag),
        ];
        let g = GateInputs {
            bd_closed: true,
            diff_empty: false,
            review_walk: Some(review_walk(&ExitSignal::Complete, &streamed)),
            ..GateInputs::default()
        };
        match decide(Some(&ExitSignal::Complete), g) {
            PhaseVerdict::Recovery {
                cause:
                    RecoveryCause::BadWalk(BadWalk::FindingsWithoutConcern {
                        finding_count,
                        findings,
                        ..
                    }),
            } => {
                assert_eq!(finding_count, 3);
                assert_eq!(findings, streamed, "findings ride through verbatim");
            }
            other => panic!("expected Recovery::BadWalk(FindingsWithoutConcern), got {other:?}"),
        }
    }

    #[test]
    fn malformed_concern_is_not_a_constructible_terminal_proposal() {
        let failure = crate::todo::parse_exit_signal(
            "LOOM_CONCERN: verifier-bypass -- legacy wire format",
            loom_protocol::output::Phase::Review,
        )
        .unwrap_err();
        assert!(failure.context().terminal().is_none());
    }

    #[test]
    fn blocked_marker_routes_to_blocked_with_reason() {
        let m = ExitSignal::Blocked(reason("missing schema"));
        match decide(Some(&m), inputs(false, true, false)) {
            PhaseVerdict::Blocked { reason } => assert_eq!(reason, "missing schema"),
            other => panic!("expected Blocked, got {other:?}"),
        }
    }

    #[test]
    fn blocked_marker_without_reason_is_rejected_at_construction() {
        assert!(NonEmptyString::new("  ").is_err());
    }

    #[test]
    fn clarify_record_cannot_be_used_as_a_terminal_outcome() {
        assert!(matches!(
            decide(Some(&decision_record()), inputs(true, false, true)),
            PhaseVerdict::Recovery {
                cause: RecoveryCause::WrongPhaseMarker {
                    marker_name: "LOOM_CLARIFY",
                    ..
                }
            },
        ));
    }

    #[test]
    fn missing_marker_routes_to_swallowed_marker_recovery() {
        assert_eq!(
            decide(None, inputs(true, false, true)),
            PhaseVerdict::Recovery {
                cause: RecoveryCause::SwallowedMarker,
            },
        );
    }

    // --- LOOM_COMPLETE rows. ---

    #[test]
    fn complete_without_bd_closed_routes_to_incomplete_signaling() {
        assert_eq!(
            decide(Some(&ExitSignal::Complete), inputs(false, false, true)),
            PhaseVerdict::Recovery {
                cause: RecoveryCause::IncompleteSignaling,
            },
        );
    }

    #[test]
    fn phase_verdict_complete_with_empty_diff_routes_to_zero_progress() {
        assert_eq!(
            decide(Some(&ExitSignal::Complete), inputs(true, true, true)),
            PhaseVerdict::Recovery {
                cause: RecoveryCause::ZeroProgress,
            },
        );
    }

    #[test]
    fn complete_with_verify_fail_routes_to_verify_fail() {
        let result = decide(Some(&ExitSignal::Complete), inputs(true, false, false));
        match result {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::VerifyFail { failures },
            } => {
                assert_eq!(failures.len(), 1, "carries every failure block");
                assert_eq!(failures[0].exit_code, 1);
            }
            other => panic!("expected Recovery::VerifyFail, got {other:?}"),
        }
    }

    #[test]
    fn verify_fail_carries_every_failure_block_for_previous_failure() {
        // Spec gate: `previous_failure` carries every failure (not just the
        // first). The recovery-cause payload is the channel — downstream
        // formatter splits the 4000-char budget across them.
        let failures = vec![
            VerifyFailure {
                script_path: std::path::PathBuf::from("tests/a.sh"),
                exit_code: 1,
                stderr: "boom-a".into(),
            },
            VerifyFailure {
                script_path: std::path::PathBuf::from("tests/b.sh"),
                exit_code: 2,
                stderr: "boom-b".into(),
            },
        ];
        let g = GateInputs {
            bd_closed: true,
            diff_empty: false,
            verify_failures: failures.clone(),
            ..GateInputs::default()
        };
        match decide(Some(&ExitSignal::Complete), g) {
            PhaseVerdict::Recovery {
                cause:
                    RecoveryCause::VerifyFail {
                        failures: carried, ..
                    },
            } => {
                assert_eq!(carried, failures, "every failure threaded through");
            }
            other => panic!("expected Recovery::VerifyFail, got {other:?}"),
        }
    }

    /// Under the streaming-finding contract `LOOM_COMPLETE` plus
    /// `streamed_findings` ≥ 1 trips the pairing rule — the agent disagreed with itself
    /// (terminator says clean, stream says concern). The parsed
    /// findings ride through the `BadWalk::FindingsWithoutConcern`
    /// variant so the next iteration can name them.
    #[test]
    fn complete_with_streamed_findings_routes_to_badwalk_not_review_concern() {
        let result = decide(
            Some(&ExitSignal::Complete),
            GateInputs {
                review_walk: Some(review_walk(
                    &ExitSignal::Complete,
                    &[streamed_finding(ConcernToken::VerifierBypass)],
                )),
                ..inputs(true, false, true)
            },
        );
        match result {
            PhaseVerdict::Recovery {
                cause:
                    RecoveryCause::BadWalk(BadWalk::FindingsWithoutConcern {
                        finding_count,
                        findings,
                        ..
                    }),
            } => {
                assert_eq!(finding_count, 1);
                assert_eq!(findings[0].token(), ConcernToken::VerifierBypass);
            }
            other => panic!("expected Recovery::BadWalk(FindingsWithoutConcern), got {other:?}"),
        }
    }

    #[test]
    fn complete_clean_routes_to_done() {
        assert_eq!(
            decide(Some(&ExitSignal::Complete), inputs(true, false, true)),
            PhaseVerdict::Done,
        );
    }

    // --- LOOM_NOOP rows (the four scoped by this bead). ---

    #[test]
    fn noop_without_bd_closed_routes_to_incomplete_signaling() {
        assert_eq!(
            decide(Some(&ExitSignal::Noop), inputs(false, true, true)),
            PhaseVerdict::Recovery {
                cause: RecoveryCause::IncompleteSignaling,
            },
        );
    }

    #[test]
    fn noop_with_verify_fail_routes_to_verify_fail() {
        // Empty diff allowed under Noop; verify failure still recovers.
        for diff_empty in [true, false] {
            let result = decide(Some(&ExitSignal::Noop), inputs(true, diff_empty, false));
            match result {
                PhaseVerdict::Recovery {
                    cause: RecoveryCause::VerifyFail { failures, .. },
                } => {
                    assert_eq!(failures.len(), 1, "diff_empty={diff_empty}");
                }
                other => panic!("expected VerifyFail (diff_empty={diff_empty}), got {other:?}"),
            }
        }
    }

    /// A worker NOOP with no findings and successful verification is done.
    #[test]
    fn noop_without_findings_routes_to_done_under_streaming_contract() {
        assert_eq!(
            decide(Some(&ExitSignal::Noop), inputs(true, true, true)),
            PhaseVerdict::Done,
        );
    }

    #[test]
    fn noop_with_empty_diff_and_clean_review_is_done_not_zero_progress() {
        // The reason this gate exists: empty diff + Noop must NOT trip
        // zero-progress recovery — the work was already in tree.
        assert_eq!(
            decide(Some(&ExitSignal::Noop), inputs(true, true, true)),
            PhaseVerdict::Done,
        );
    }

    #[test]
    fn noop_with_non_empty_diff_and_clean_review_is_done() {
        assert_eq!(
            decide(Some(&ExitSignal::Noop), inputs(true, false, true)),
            PhaseVerdict::Done,
        );
    }

    // --- Tree-not-clean rows (precede verify-fail / review-concern). ---

    #[test]
    fn complete_with_dirty_tree_routes_to_tree_not_clean_before_verify() {
        // Spec gate (`specs/harness.md` §"Verdict Gate · Tree-clean check"):
        // when the worktree is dirty after the bead bd-closed, the gate
        // routes to `tree-not-clean` recovery BEFORE verify-fail /
        // review-concern. Verifiers do not run against a half-staged tree.
        // Also supply verify failures to pin the tree-clean precedence.
        let dirty = vec![" M src/foo.rs".to_string(), "?? scratch.tmp".to_string()];
        let g = GateInputs {
            bd_closed: true,
            diff_empty: false,
            tree_dirty_paths: dirty.clone(),
            verify_failures: vec![sample_failure()],
            ..GateInputs::default()
        };
        match decide(Some(&ExitSignal::Complete), g) {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::TreeNotClean { dirty_paths },
            } => {
                assert_eq!(
                    dirty_paths, dirty,
                    "tree-not-clean carries the (already-capped) dirty paths verbatim",
                );
            }
            other => panic!(
                "expected Recovery::TreeNotClean (precedes verify-fail & review-concern), \
                 got {other:?}",
            ),
        }
    }

    #[test]
    fn noop_with_dirty_tree_routes_to_tree_not_clean() {
        // Same gate fires for `LOOM_NOOP`: a NOOP claims "no work needed"
        // but a dirty tree disagrees; surfacing the discrepancy beats
        // letting the bead close on a false negative.
        let dirty = vec![" M crates/loom-driver/src/git/client.rs".to_string()];
        let g = GateInputs {
            bd_closed: true,
            diff_empty: true,
            tree_dirty_paths: dirty.clone(),
            verify_failures: vec![],
            ..GateInputs::default()
        };
        match decide(Some(&ExitSignal::Noop), g) {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::TreeNotClean { dirty_paths },
            } => {
                assert_eq!(dirty_paths, dirty);
            }
            other => panic!("expected Recovery::TreeNotClean for NOOP+dirty, got {other:?}"),
        }
    }

    #[test]
    fn tree_not_clean_detail_enumerates_and_caps_dirty_paths() {
        // Spec (`specs/harness.md` §"Verdict Gate · Tree-clean check"):
        // dirty paths capped at 30 entries with a "+N more" suffix when
        // truncated. The driver caps before construction; the variant
        // carries the already-capped list verbatim.
        use crate::r#loop::{TREE_NOT_CLEAN_CAP, dirty_paths_from_porcelain};

        // 42 lines of porcelain → 30 cap + "+12 more" suffix == 31 entries.
        let porcelain = (0..42)
            .map(|i| format!(" M src/file_{i}.rs"))
            .collect::<Vec<_>>()
            .join("\n");
        let capped = dirty_paths_from_porcelain(&porcelain);
        assert_eq!(
            capped.len(),
            TREE_NOT_CLEAN_CAP + 1,
            "cap of {TREE_NOT_CLEAN_CAP} + 1 overflow marker line",
        );
        assert_eq!(capped[0], " M src/file_0.rs");
        assert_eq!(capped[TREE_NOT_CLEAN_CAP - 1], " M src/file_29.rs");
        assert_eq!(
            capped[TREE_NOT_CLEAN_CAP], "+12 more",
            "final entry names the overflow count",
        );

        // Under the cap: every line passes through, no overflow marker.
        let porcelain_small = (0..5)
            .map(|i| format!("?? scratch_{i}.tmp"))
            .collect::<Vec<_>>()
            .join("\n");
        let capped_small = dirty_paths_from_porcelain(&porcelain_small);
        assert_eq!(capped_small.len(), 5);
        assert!(
            !capped_small.iter().any(|p| p.starts_with('+')),
            "no overflow marker under the cap (got: {capped_small:?})",
        );

        // The verdict gate accepts the already-capped Vec verbatim — the
        // capping discipline is enforced by the caller, not re-applied here.
        let g = GateInputs {
            bd_closed: true,
            diff_empty: false,
            tree_dirty_paths: capped.clone(),
            verify_failures: vec![],
            ..GateInputs::default()
        };
        match decide(Some(&ExitSignal::Complete), g) {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::TreeNotClean { dirty_paths },
            } => {
                assert_eq!(dirty_paths, capped);
                assert_eq!(dirty_paths.last().map(String::as_str), Some("+12 more"));
            }
            other => panic!("expected Recovery::TreeNotClean, got {other:?}"),
        }
    }

    // --- Cause label round-trip (bd notes / log surfaces). ---

    #[test]
    fn recovery_cause_labels_match_spec_strings() {
        assert_eq!(RecoveryCause::SwallowedMarker.as_str(), "swallowed-marker");
        assert_eq!(
            RecoveryCause::IncompleteSignaling.as_str(),
            "incomplete-signaling",
        );
        assert_eq!(RecoveryCause::ZeroProgress.as_str(), "zero-progress");
        assert_eq!(
            RecoveryCause::VerifyFail { failures: vec![] }.as_str(),
            "verify-fail",
        );
        assert_eq!(
            RecoveryCause::ReviewConcern {
                summary: "summary".into(),
                findings: vec![],
            }
            .as_str(),
            "review-concern",
        );
        assert_eq!(
            RecoveryCause::ObserverAbort {
                reason: "doom-loop: 3 identical tool calls".into(),
            }
            .as_str(),
            "observer-abort",
        );
        assert_eq!(
            RecoveryCause::TreeNotClean {
                dirty_paths: vec![" M src/foo.rs".into()],
            }
            .as_str(),
            "tree-not-clean",
        );
        assert_eq!(
            RecoveryCause::AgentRetry {
                reason: "tool exec broke".into(),
            }
            .as_str(),
            "agent-retry",
        );
        assert_eq!(
            RecoveryCause::WrongPhaseMarker {
                marker_name: "LOOM_RETRY",
                phase_kind: "interactive",
            }
            .as_str(),
            "wrong-phase-marker",
        );
    }

    /// `ExitSignal::Retry` routes the verdict gate to
    /// `PhaseVerdict::Recovery { cause: RecoveryCause::AgentRetry { reason } }`
    /// with the agent's verbatim reason carried through. The wire-format
    /// guarantee is that the `reason` field round-trips through `decide()`
    /// unchanged so the driver can populate
    /// `PreviousFailure::AgentRetry { reason }` for the next attempt.
    #[test]
    fn retry_marker_routes_to_agent_retry_recovery_cause() {
        let m = ExitSignal::Retry(reason("tools failing mid-session; cwd unlinked"));
        match decide(Some(&m), GateInputs::default()) {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::AgentRetry { reason },
            } => {
                assert_eq!(reason, "tools failing mid-session; cwd unlinked");
            }
            other => panic!("expected Recovery::AgentRetry, got {other:?}"),
        }
    }

    /// Defense-in-depth: `decide_for_phase` rejects `LOOM_RETRY` emitted
    /// from an interactive phase as `RecoveryCause::WrongPhaseMarker`
    /// per `specs/harness.md` § Marker definitions. The agent should
    /// never reach this branch (the worker-phase self-report partial is
    /// not pinned in interactive templates), but the gate enforces the
    /// rule mechanically.
    #[test]
    fn retry_marker_from_interactive_phase_is_wrong_phase_marker() {
        let m = ExitSignal::Retry(reason("should never get here"));
        match decide_for_phase(Some(&m), GateInputs::default(), PhaseKind::Interactive) {
            PhaseVerdict::Recovery {
                cause:
                    RecoveryCause::WrongPhaseMarker {
                        marker_name,
                        phase_kind,
                    },
            } => {
                assert_eq!(marker_name, "LOOM_RETRY");
                assert_eq!(phase_kind, "interactive");
            }
            other => panic!("expected Recovery::WrongPhaseMarker, got {other:?}"),
        }
    }

    /// Loop and todo both admit direct worker self-reports.
    #[test]
    fn retry_marker_admitted_under_loop_and_todo_phases() {
        let marker = ExitSignal::Retry(reason("transient io"));
        for phase in [PhaseKind::Loop, PhaseKind::Todo] {
            match decide_for_phase(Some(&marker), GateInputs::default(), phase) {
                PhaseVerdict::Recovery {
                    cause: RecoveryCause::AgentRetry { reason },
                } => assert_eq!(reason, "transient io"),
                other => panic!("expected Recovery::AgentRetry, got {other:?}"),
            }
        }
    }

    #[test]
    fn clarify_records_are_not_loop_or_todo_terminal_outcomes() {
        let marker = decision_record();
        for phase in [PhaseKind::Loop, PhaseKind::Todo] {
            assert!(matches!(
                decide_for_phase(Some(&marker), GateInputs::default(), phase),
                PhaseVerdict::Recovery {
                    cause: RecoveryCause::WrongPhaseMarker {
                        marker_name: "LOOM_CLARIFY",
                        ..
                    }
                },
            ));
        }
    }

    #[test]
    fn waiting_marker_admission_matches_canonical_worker_phases() {
        assert_eq!(
            decide_for_phase(
                Some(&ExitSignal::Waiting),
                GateInputs::default(),
                PhaseKind::Loop,
            ),
            PhaseVerdict::Waiting,
        );
        assert_eq!(
            decide_for_phase(
                Some(&ExitSignal::Waiting),
                GateInputs::default(),
                PhaseKind::Todo
            ),
            PhaseVerdict::Waiting
        );
        for phase in [PhaseKind::Review, PhaseKind::Interactive] {
            assert!(matches!(
                decide_for_phase(Some(&ExitSignal::Waiting), GateInputs::default(), phase),
                PhaseVerdict::Recovery {
                    cause: RecoveryCause::WrongPhaseMarker {
                        marker_name: "LOOM_WAITING",
                        ..
                    }
                }
            ));
        }
    }

    #[test]
    fn clarify_marker_from_review_phase_is_wrong_review_path() {
        let m = decision_record();
        match decide_for_phase(Some(&m), GateInputs::default(), PhaseKind::Review) {
            PhaseVerdict::Recovery {
                cause:
                    RecoveryCause::WrongPhaseMarker {
                        marker_name,
                        phase_kind,
                    },
            } => {
                assert_eq!(marker_name, "LOOM_CLARIFY");
                assert_eq!(phase_kind, "review");
            }
            other => panic!("expected Recovery::WrongPhaseMarker under review, got {other:?}"),
        }
    }

    #[test]
    fn retry_and_blocked_markers_are_admitted_under_review_phase() {
        let retry = ExitSignal::Retry(reason("logs disappeared"));
        match decide_for_phase(Some(&retry), GateInputs::default(), PhaseKind::Review) {
            PhaseVerdict::Recovery {
                cause: RecoveryCause::AgentRetry { reason },
            } => assert_eq!(reason, "logs disappeared"),
            other => panic!("expected AgentRetry under review, got {other:?}"),
        }

        let blocked = ExitSignal::Blocked(reason("workspace cannot be read"));
        match decide_for_phase(Some(&blocked), GateInputs::default(), PhaseKind::Review) {
            PhaseVerdict::Blocked { reason } => assert_eq!(reason, "workspace cannot be read"),
            other => panic!("expected Blocked under review, got {other:?}"),
        }
    }

    #[test]
    fn blocked_marker_without_reason_fails_shared_worker_admission() {
        for phase in [
            loom_protocol::output::Phase::Loop,
            loom_protocol::output::Phase::Review,
        ] {
            assert!(
                crate::todo::parse_exit_signal("LOOM_BLOCKED: {\"reason\":\"\"}", phase).is_err()
            );
        }
    }

    #[test]
    fn noop_marker_from_review_phase_is_wrong_phase_marker() {
        match decide_for_phase(
            Some(&ExitSignal::Noop),
            GateInputs::default(),
            PhaseKind::Review,
        ) {
            PhaseVerdict::Recovery {
                cause:
                    RecoveryCause::WrongPhaseMarker {
                        marker_name,
                        phase_kind,
                    },
            } => {
                assert_eq!(marker_name, "LOOM_NOOP");
                assert_eq!(phase_kind, "review");
            }
            other => panic!("expected Recovery::WrongPhaseMarker for review NOOP, got {other:?}"),
        }
    }

    /// `LOOM_COMPLETE` / `LOOM_NOOP` are admitted under interactive
    /// phases — the phase-aware wrapper only rejects the worker-only
    /// self-report set.
    #[test]
    fn complete_admitted_under_interactive_phase() {
        let inputs = inputs(true, false, true);
        match decide_for_phase(Some(&ExitSignal::Complete), inputs, PhaseKind::Interactive) {
            PhaseVerdict::Done => {}
            other => panic!("expected Done, got {other:?}"),
        }
    }

    #[test]
    fn review_concern_labels_match_spec_vocabulary() {
        assert_eq!(ReviewConcern::VerifierBypass.as_str(), "verifier-bypass");
        assert_eq!(
            ReviewConcern::FabricatedResult.as_str(),
            "fabricated-result",
        );
        assert_eq!(ReviewConcern::WeakAssertion.as_str(), "weak-assertion");
        assert_eq!(
            ReviewConcern::CoincidentalPass.as_str(),
            "coincidental-pass"
        );
        assert_eq!(ReviewConcern::Mock.as_str(), "mock");
        assert_eq!(ReviewConcern::Scope.as_str(), "scope");
        assert_eq!(ReviewConcern::Judge.as_str(), "judge");
        assert_eq!(ReviewConcern::StyleRule.as_str(), "style-rule");
        assert_eq!(ReviewConcern::SurfaceDrift.as_str(), "surface-drift");
        assert_eq!(ReviewConcern::CrossSpecClash.as_str(), "cross-spec-clash");
        assert_eq!(
            ReviewConcern::TemplateSpecDrift.as_str(),
            "template-spec-drift",
        );
        assert_eq!(
            ReviewConcern::SpecConventionsViolation.as_str(),
            "spec-conventions-violation",
        );
    }

    #[test]
    fn review_concern_parse_round_trips_each_variant() {
        for c in [
            ReviewConcern::VerifierBypass,
            ReviewConcern::FabricatedResult,
            ReviewConcern::WeakAssertion,
            ReviewConcern::CoincidentalPass,
            ReviewConcern::Mock,
            ReviewConcern::Scope,
            ReviewConcern::Judge,
            ReviewConcern::StyleRule,
            ReviewConcern::SurfaceDrift,
            ReviewConcern::CrossSpecClash,
            ReviewConcern::TemplateSpecDrift,
            ReviewConcern::SpecConventionsViolation,
        ] {
            assert_eq!(ReviewConcern::parse(c.as_str()), Some(c));
        }
    }

    #[test]
    fn streamed_findings_reach_recovery_without_legacy_flags() {
        use crate::review::{
            AcceptAllFindingValidator, DispatchScope, WalkOutputError, parse_walk_output,
        };
        let validator = AcceptAllFindingValidator;
        assert!(matches!(
            parse_walk_output(
                "LOOM_CONCERN: scope -- legacy flag",
                DispatchScope::Tree,
                &validator
            ),
            Err(WalkOutputError::BadWalk {
                bad_walk: BadWalk::Protocol { .. }
            })
        ));
        let output = concat!(
            "LOOM_FINDING: {\"token\":\"weak-assertion\",\"route\":\"deferred\",\"bonds\":[\"gate\"],\"target\":{\"kind\":\"Annotation\",\"target_string\":\"cargo test\"},\"evidence\":\"assertion never reaches the changed branch\"}\n",
            "LOOM_CONCERN: {\"summary\":\"Summary is not a concern token\"}\n",
        );
        let findings = parse_walk_output(output, DispatchScope::Tree, &validator).unwrap();
        let marker =
            crate::todo::parse_exit_signal(output, loom_protocol::output::Phase::Review).unwrap();
        let PhaseVerdict::Recovery { cause } = decide_for_phase(
            Some(&marker),
            GateInputs {
                review_walk: Some(review_walk(&marker, &findings)),
                ..GateInputs::default()
            },
            PhaseKind::Review,
        ) else {
            panic!("valid findings must reach recovery");
        };
        let body = crate::review::cause_to_previous_failure(&cause).to_string();
        assert!(
            body.contains("Review raised a concern (weak-assertion)"),
            "{body}"
        );
        assert!(body.contains("Summary is not a concern token"), "{body}");
        assert!(
            body.contains("assertion never reaches the changed branch"),
            "{body}"
        );
        assert!(!body.contains("Review notes:"), "{body}");
    }

    #[test]
    fn review_concern_parse_rejects_unknown_token() {
        // `live-path` is the pre-rubric-expansion umbrella token; it must
        // read as unknown rather than silently round-trip to a sub-check.
        assert_eq!(ReviewConcern::parse("live-path"), None);
        assert_eq!(ReviewConcern::parse("verifierbypass"), None);
        assert_eq!(ReviewConcern::parse("nit"), None);
        assert_eq!(ReviewConcern::parse(""), None);
    }
}
