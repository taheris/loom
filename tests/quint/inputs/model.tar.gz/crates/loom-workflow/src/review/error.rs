use displaydoc::Display;
use thiserror::Error;

use loom_driver::agent::ProtocolError;
use loom_driver::bd::BdError;
use loom_driver::git::GitError;
use loom_driver::identifier::ParseMoleculeIdError;
use loom_driver::logging::LogError;
use loom_driver::profile_manifest::ProfileError;
use loom_driver::state::CacheError;

use crate::spec::SpecError;

/// Errors raised by the `loom review` driver.
#[expect(
    clippy::doc_markdown,
    reason = "displaydoc fields are format placeholders; backticks would change the generated error text"
)]
#[derive(Debug, Display, Error)]
pub enum ReviewError {
    /// package context could not be captured or delivered
    Context(#[from] loom_driver::spec::context::Error),
    /// agent backend protocol failure during `loom review`
    Protocol(#[from] ProtocolError),

    /// integrity cap decision admission failed
    IntegrityDecision(#[from] crate::mint::integrity::Error),

    /// bd CLI failure during `loom review`
    Bd(#[from] BdError),

    /// review bead carried an invalid molecule id
    InvalidMoleculeId(#[from] ParseMoleculeIdError),

    /// rendering the review.md template failed
    Render(#[from] askama::Error),

    /// log sink failure during `loom review`
    Log(#[from] LogError),

    /// io operation failed during `loom review`
    Io(#[from] std::io::Error),

    /// reviewer agent did not emit LOOM_COMPLETE: {0}
    ReviewIncomplete(String),

    /// push-eligible review does not match verified scope: {0}
    VerifiedScopeMismatch(String),

    /// `git push` failed: {0}
    GitPushFailed(String),

    /// `wrix beads push` failed after `git push` succeeded: {0}
    BeadsPushFailed(String),

    /// detached HEAD — refuse to push
    DetachedHead,

    /// `loom loop` handoff for auto-iteration failed: {0}
    RunHandoff(String),

    /// cache-db read/write failure during `loom review`
    State(#[from] CacheError),

    /// profile-image manifest dispatch failed during `loom review`
    Profile(#[from] ProfileError),

    /// no active molecule for spec {0} — run `loom todo` before `loom review`
    NoActiveMolecule(String),

    /// failed to parse workspace review annotations
    Annotations(#[from] loom_gate::annotation::ParseError),

    /// no judge annotation matches target `{0}`
    UnknownJudgeTarget(String),

    /// failed to load `[test]`/`[judge]` sources for review prompt
    Spec(#[from] SpecError),

    /// spec → molecule resolution failed during `loom review`
    Resolve(#[from] crate::resolve::ResolveError),

    /// git step failed during `loom review`
    Git(#[from] GitError),

    /// skill resolution failed during `loom review`
    Skill(#[from] crate::skill::SkillError),
}
