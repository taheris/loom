//! Verdict-gate recovery resolution (`specs/harness.md` lines
//! 829-832 + 906-918 + 1960-1981).
//!
//! When the verdict gate's decision table produces
//! [`PhaseVerdict::Recovery`](super::phase_verdict::PhaseVerdict::Recovery)
//! the driver maps that onto one of two terminal shapes against the
//! bead's iteration counter and `[loop] max_iterations`:
//!
//! - **Retry** — iter `<` max. The original recovery cause is rendered
//!   into the next session's `previous_failure` payload (see
//!   [`super::verify_fail::format_previous_failure`]) and the bead is
//!   re-dispatched.
//! - **Blocked** — iter `>=` max. The driver applies `loom:blocked` with
//!   cause `retry-exhausted`; the original recovery cause is preserved
//!   in `bd update --notes` so the human can see *why* the loop gave up.
//!
//! The "spawns fix-up bead OR retries" disjunction in the spec criterion
//! `test_recovery_under_max` is satisfied by this module's Retry branch
//! plus the dedicated chokepoint in [`super::fixup`]: callers that want
//! to spawn a fix-up bead during a Retry pass invoke
//! [`super::fixup::spawn_fixup_bead`] explicitly.

use loom_templates::finding::Finding;
use loom_templates::run::{DriverNoticeCause, PreviousFailure, VerifierFailure};

use super::phase_verdict::RecoveryCause;
use super::verify_fail::{VerifyFailure, format_previous_failure};

/// Derive a human-readable concern label from the streamed-findings vec.
///
/// Returns the shared typed token's wire string for homogeneous findings,
/// `"multiple"` for heterogeneous tokens, or `"review-concern"` for no findings.
/// The human label comes from findings, never the terminal summary. Exported so the
/// review controller's `bd update --notes` writer and verdict-log
/// surfaces consume one canonical derivation.
pub fn concern_label_from_findings(findings: &[Finding]) -> String {
    let Some(first) = findings.first() else {
        return "review-concern".to_owned();
    };
    if findings.iter().any(|f| f.token() != first.token()) {
        return "multiple".to_owned();
    }
    first.token().as_wire().to_owned()
}

/// Render a [`RecoveryCause`] into a `previous_failure` body suitable for
/// threading into the next agent attempt's prompt — or into the blocked
/// notes when retries exhaust. Mirrors the per-cause detail table in
/// `specs/harness.md` §"Recovery context (`previous_failure`)".
fn render_previous_failure(cause: &RecoveryCause) -> String {
    match cause {
        RecoveryCause::SwallowedMarker => {
            "Last phase ended without a `LOOM_*` exit marker.".to_string()
        }
        RecoveryCause::IncompleteSignaling => {
            "Marker `LOOM_COMPLETE` emitted but the bead was not bd-closed.".to_string()
        }
        RecoveryCause::ZeroProgress => {
            "Marker `LOOM_COMPLETE` emitted with empty diff. Use `LOOM_NOOP` if no work was needed."
                .to_string()
        }
        RecoveryCause::VerifyFail { failures } => format_previous_failure(failures),
        RecoveryCause::ReviewConcern { summary, findings } => PreviousFailure::ReviewConcern {
            summary: summary.clone(),
            findings: findings.clone(),
        }
        .to_string(),
        RecoveryCause::ObserverAbort { reason } => {
            format!("Session aborted by observer: {reason}.")
        }
        RecoveryCause::TreeNotClean { dirty_paths } => PreviousFailure::TreeNotClean {
            dirty_paths: dirty_paths.clone(),
        }
        .to_string(),
        RecoveryCause::BadWalk(badwalk) => PreviousFailure::BadWalk(badwalk.clone()).to_string(),
        RecoveryCause::AgentRetry { reason } => PreviousFailure::AgentRetry {
            reason: reason.clone(),
        }
        .to_string(),
        RecoveryCause::WrongPhaseMarker {
            marker_name,
            phase_kind,
        } => {
            format!("wrong-phase-marker: `{marker_name}` is not admitted in {phase_kind} phases.")
        }
    }
}

/// Map a [`RecoveryCause`] to the typed
/// [`PreviousFailure`](loom_templates::run::PreviousFailure) variant the
/// `loop.md` template renders. Per `specs/harness.md` § Verdict Gate
/// (recovery-context table):
///
/// - `SwallowedMarker` / `IncompleteSignaling` / `ZeroProgress` →
///   `DriverNotice` with the corresponding `DriverNoticeCause` + detail.
/// - `ObserverAbort` → `DriverNotice { cause: ObserverAbort, detail }`.
/// - `VerifyFail` → `VerifyFailures(Vec<VerifierFailure>)`.
/// - `ReviewConcern` → `ReviewConcern { summary, findings }`. The structured
///   findings and summary pass through unchanged; rendering derives the
///   concern label from the typed finding tokens.
/// - `TreeNotClean` → `TreeNotClean { dirty_paths }`. The capped path list
///   passes through verbatim; the variant's `Display` impl emits the
///   spec-pinned framing + per-path enumeration + `"+N more"` suffix.
/// - `BadWalk` → `BadWalk(BadWalk)`. The typed `BadWalk` variant rides
///   through unchanged so the per-variant recovery framing in
///   `PreviousFailure::Display` fires.
pub fn cause_to_previous_failure(cause: &RecoveryCause) -> PreviousFailure {
    match cause {
        RecoveryCause::SwallowedMarker => PreviousFailure::DriverNotice {
            cause: DriverNoticeCause::SwallowedMarker,
            detail: "Last phase ended without a `LOOM_*` exit marker.".to_string(),
        },
        RecoveryCause::IncompleteSignaling => PreviousFailure::DriverNotice {
            cause: DriverNoticeCause::IncompleteSignaling,
            detail: "Marker `LOOM_COMPLETE` emitted but the bead was not bd-closed.".to_string(),
        },
        RecoveryCause::ZeroProgress => PreviousFailure::DriverNotice {
            cause: DriverNoticeCause::ZeroProgress,
            detail:
                "Marker `LOOM_COMPLETE` emitted with empty diff. Use `LOOM_NOOP` if no work was needed."
                    .to_string(),
        },
        RecoveryCause::ObserverAbort { reason } => PreviousFailure::DriverNotice {
            cause: DriverNoticeCause::ObserverAbort,
            detail: format!("Session aborted by observer: {reason}."),
        },
        RecoveryCause::VerifyFail { failures, .. } => {
            PreviousFailure::VerifyFailures(failures.iter().map(verify_failure_to_typed).collect())
        }
        RecoveryCause::ReviewConcern { summary, findings } => PreviousFailure::ReviewConcern {
            summary: summary.clone(),
            findings: findings.clone(),
        },
        RecoveryCause::TreeNotClean { dirty_paths } => PreviousFailure::TreeNotClean {
            dirty_paths: dirty_paths.clone(),
        },
        RecoveryCause::BadWalk(badwalk) => PreviousFailure::BadWalk(badwalk.clone()),
        RecoveryCause::AgentRetry { reason } => PreviousFailure::AgentRetry {
            reason: reason.clone(),
        },
        RecoveryCause::WrongPhaseMarker {
            marker_name,
            phase_kind,
        } => PreviousFailure::DriverNotice {
            cause: DriverNoticeCause::SwallowedMarker,
            detail: format!(
                "wrong-phase-marker: `{marker_name}` is not admitted in {phase_kind} phases.",
            ),
        },
    }
}

fn verify_failure_to_typed(failure: &VerifyFailure) -> VerifierFailure {
    VerifierFailure::new(
        failure.script_path.display().to_string(),
        failure.exit_code,
        failure.stderr.clone(),
    )
}

/// Cause string written to `bd update --notes` when the recovery loop
/// exhausts `[loop] max_iterations`. Mirrored from
/// `specs/harness.md` §"Verdict Gate · Labels".
pub const RETRY_EXHAUSTED_CAUSE: &str = "retry-exhausted";

/// Resolution of one [`RecoveryCause`] against the bead's iteration
/// counter + `[loop] max_iterations`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RecoveryResolution {
    /// Iter `<` max. Re-dispatch the bead with `previous_failure`
    /// threaded into the next session's prompt. The body is the spec's
    /// recovery-cause formatting (`super::verify_fail::format_previous_failure`).
    Retry { previous_failure: String },
    /// Iter `>=` max. Apply `loom:blocked` + `retry-exhausted` to the
    /// bead. `notes` is the `bd update --notes` body — it leads with the
    /// `retry-exhausted` label, names the original recovery cause for
    /// human review, and embeds the same `previous_failure` body the
    /// last retry would have seen (so the surface tells the human what
    /// the agent kept failing on).
    Blocked { cause: String, notes: String },
}

/// Pure-ish recovery resolver.
///
/// `max` is `[loop] max_iterations` (default
/// 3). `iter` is the bead's pre-decision iteration counter: 0 on the
/// first failure, so the function returns Retry until `iter` reaches
/// `max`.
pub fn resolve_recovery(cause: &RecoveryCause, iter: u32, max: u32) -> RecoveryResolution {
    let previous_failure = render_previous_failure(cause);
    if iter >= max {
        let notes = format!(
            "{RETRY_EXHAUSTED_CAUSE}: recovery loop hit [loop] max_iterations ({max}) on cause `{original}`.\n\n{previous_failure}",
            original = cause.as_str(),
        );
        RecoveryResolution::Blocked {
            cause: RETRY_EXHAUSTED_CAUSE.to_string(),
            notes,
        }
    } else {
        RecoveryResolution::Retry { previous_failure }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::review::verify_fail::VerifyFailure;
    use loom_events::identifier::SpecLabel;
    use loom_templates::finding::{ConcernToken, Finding, FindingRoute, FindingTarget};

    fn finding_with_token(token: ConcernToken) -> Finding {
        loom_test_support::finding::resolve(loom_protocol::gate::RawFinding {
            token,
            route: FindingRoute::Deferred,
            bonds: vec![SpecLabel::new("gate").unwrap()],
            target: if token == ConcernToken::SpecCoherenceFail {
                FindingTarget::Criterion {
                    spec: SpecLabel::new("gate").unwrap(),
                    anchor: "sample".into(),
                }
            } else {
                FindingTarget::Annotation {
                    target_string: "cargo test --lib sample".into(),
                }
            },
            evidence: "streamed via LOOM_FINDING".into(),
        })
        .expect("valid fixture finding")
    }

    #[test]
    fn cause_to_previous_failure_maps_driver_notices() {
        // The three driver-procedural causes all collapse onto
        // PreviousFailure::DriverNotice carrying the matching DriverNoticeCause
        // and the spec table's verbatim detail string.
        for (cause, expected_cause, expected_detail_fragment) in [
            (
                RecoveryCause::SwallowedMarker,
                DriverNoticeCause::SwallowedMarker,
                "without a `LOOM_*` exit marker",
            ),
            (
                RecoveryCause::IncompleteSignaling,
                DriverNoticeCause::IncompleteSignaling,
                "not bd-closed",
            ),
            (
                RecoveryCause::ZeroProgress,
                DriverNoticeCause::ZeroProgress,
                "empty diff",
            ),
        ] {
            match cause_to_previous_failure(&cause) {
                PreviousFailure::DriverNotice { cause: c, detail } => {
                    assert_eq!(c, expected_cause, "cause mismatch for {cause:?}");
                    assert!(
                        detail.contains(expected_detail_fragment),
                        "detail missing fragment for {cause:?}: {detail}",
                    );
                }
                other => panic!("expected DriverNotice for {cause:?}, got {other:?}"),
            }
        }
    }

    #[test]
    fn cause_to_previous_failure_maps_observer_abort_with_reason_in_detail() {
        let cause = RecoveryCause::ObserverAbort {
            reason: "doom-loop: 3 identical tool calls".into(),
        };
        match cause_to_previous_failure(&cause) {
            PreviousFailure::DriverNotice {
                cause: DriverNoticeCause::ObserverAbort,
                detail,
            } => {
                assert!(
                    detail.contains("doom-loop: 3 identical tool calls"),
                    "verbatim observer reason missing: {detail}",
                );
            }
            other => panic!("expected DriverNotice(ObserverAbort), got {other:?}"),
        }
    }

    #[test]
    fn cause_to_previous_failure_maps_verify_fail_into_typed_failures() {
        let cause = RecoveryCause::VerifyFail {
            failures: vec![
                VerifyFailure {
                    script_path: std::path::PathBuf::from("tests/a.sh"),
                    exit_code: 2,
                    stderr: "boom-a".into(),
                },
                VerifyFailure {
                    script_path: std::path::PathBuf::from("tests/b.sh"),
                    exit_code: 3,
                    stderr: "boom-b".into(),
                },
            ],
        };
        match cause_to_previous_failure(&cause) {
            PreviousFailure::VerifyFailures(failures) => {
                assert_eq!(failures.len(), 2);
                assert_eq!(failures[0].target, "tests/a.sh");
                assert_eq!(failures[0].exit_code, 2);
                assert!(failures[0].stderr_tail.contains("boom-a"));
                assert_eq!(failures[1].target, "tests/b.sh");
                assert_eq!(failures[1].exit_code, 3);
            }
            other => panic!("expected VerifyFailures, got {other:?}"),
        }
    }

    #[test]
    fn cause_to_previous_failure_maps_review_concern_to_typed_concern() {
        let streamed = vec![finding_with_token(ConcernToken::VerifierBypass)];
        let cause = RecoveryCause::ReviewConcern {
            summary: "test mocks the agent backend".into(),
            findings: streamed.clone(),
        };
        match cause_to_previous_failure(&cause) {
            PreviousFailure::ReviewConcern { summary, findings } => {
                assert_eq!(
                    summary, "test mocks the agent backend",
                    "summary is the verbatim LOOM_CONCERN summary, not concat",
                );
                assert_eq!(
                    findings, streamed,
                    "findings thread through verbatim into the typed prompt context",
                );
            }
            other => panic!("expected ReviewConcern, got {other:?}"),
        }
    }

    /// Per-criterion (`previous_failure_review_concern_renders_human_label_from_findings_not_summary`):
    /// the human-readable concern label rendered for `bd update --notes`
    /// and verdict-log surfaces is derived from `findings[0].token` (or
    /// `"multiple"` for heterogeneous), NOT from the terminal `summary`.
    #[test]
    fn previous_failure_review_concern_renders_human_label_from_findings_not_summary() {
        let homogeneous = vec![
            finding_with_token(ConcernToken::VerifierBypass),
            finding_with_token(ConcernToken::VerifierBypass),
        ];
        assert_eq!(
            concern_label_from_findings(&homogeneous),
            "verifier-bypass",
            "homogeneous → token's wire string",
        );

        let heterogeneous = vec![
            finding_with_token(ConcernToken::VerifierBypass),
            finding_with_token(ConcernToken::WeakAssertion),
        ];
        assert_eq!(
            concern_label_from_findings(&heterogeneous),
            "multiple",
            "heterogeneous → `multiple`",
        );

        // Finding-only token (not in ReviewConcern) returns the wire
        // string so the human still sees an accurate label.
        let finding_only = vec![finding_with_token(ConcernToken::SpecCoherenceFail)];
        assert_eq!(
            concern_label_from_findings(&finding_only),
            "spec-coherence-fail",
        );
    }

    #[test]
    fn cause_to_previous_failure_maps_bad_walk_passes_variant_through() {
        let badwalk = loom_protocol::gate::WalkOutput::from_stdout(
            "LOOM_CONCERN: {\"summary\":\"rubric concern with no enumerated findings\"}",
            loom_protocol::gate::DispatchScope::Tree,
            &loom_test_support::finding::FixtureSymbols,
        )
        .bad_walk()
        .unwrap();
        let cause = RecoveryCause::BadWalk(badwalk.clone());
        match cause_to_previous_failure(&cause) {
            PreviousFailure::BadWalk(carried) => {
                assert_eq!(carried, badwalk);
            }
            other => panic!("expected BadWalk, got {other:?}"),
        }
    }

    #[test]
    fn cause_to_previous_failure_maps_tree_not_clean_passes_paths_through() {
        // Spec (`specs/harness.md` §"Verdict Gate · Tree-clean check"):
        // dirty paths are capped by the driver before construction; the
        // mapping passes the capped list verbatim to the typed variant so
        // the template's render layer sees the same list (with `"+N more"`
        // suffix when truncated) that the driver constructed.
        let dirty = vec![
            " M src/foo.rs".to_string(),
            "?? scratch.tmp".to_string(),
            "+7 more".to_string(),
        ];
        let cause = RecoveryCause::TreeNotClean {
            dirty_paths: dirty.clone(),
        };
        match cause_to_previous_failure(&cause) {
            PreviousFailure::TreeNotClean { dirty_paths } => {
                assert_eq!(dirty_paths, dirty, "capped list passes through verbatim");
            }
            other => panic!("expected TreeNotClean, got {other:?}"),
        }
    }

    #[test]
    fn tree_not_clean_cause_renders_with_dirty_paths_in_notes() {
        // `retry-exhausted` notes preserve the original cause body so the
        // human reading `bd show --notes` sees the same framing the agent
        // would have seen in `previous_failure`. The body lines up with
        // the typed render path (`PreviousFailure::TreeNotClean`'s
        // `Display` impl) so framing stays identical across both
        // surfaces.
        let cause = RecoveryCause::TreeNotClean {
            dirty_paths: vec![" M src/foo.rs".into(), "?? scratch.tmp".into()],
        };
        match resolve_recovery(&cause, 5, 3) {
            RecoveryResolution::Blocked { cause: c, notes } => {
                assert_eq!(c, RETRY_EXHAUSTED_CAUSE);
                assert!(
                    notes.contains("tree-not-clean"),
                    "original cause label appears in notes: {notes}",
                );
                assert!(
                    notes.contains("Working tree was not clean"),
                    "spec-pinned framing appears in notes: {notes}",
                );
                assert!(
                    notes.contains(" M src/foo.rs"),
                    "dirty path appears in notes: {notes}",
                );
            }
            other @ RecoveryResolution::Retry { .. } => {
                panic!("expected Blocked, got {other:?}");
            }
        }
    }

    fn verify_fail_cause() -> RecoveryCause {
        RecoveryCause::VerifyFail {
            failures: vec![VerifyFailure {
                script_path: std::path::PathBuf::from("tests/sample.sh"),
                exit_code: 1,
                stderr: "boom\n".into(),
            }],
        }
    }

    #[test]
    fn under_max_recovers_with_previous_failure() {
        // iter < max → Retry, and the `previous_failure` body must be the
        // spec-formatted cause body so the next session's prompt sees
        // every failing-verify block (and any threaded review notes).
        let cause = verify_fail_cause();
        match resolve_recovery(&cause, 0, 3) {
            RecoveryResolution::Retry { previous_failure } => {
                assert!(
                    previous_failure.contains("tests/sample.sh"),
                    "previous_failure carries the spec-formatted cause body: {previous_failure}",
                );
                assert!(
                    previous_failure.contains("boom"),
                    "stderr tail is part of the previous_failure body: {previous_failure}",
                );
            }
            other @ RecoveryResolution::Blocked { .. } => {
                panic!("expected Retry, got {other:?}");
            }
        }
    }

    #[test]
    fn under_max_at_two_still_recovers_with_previous_failure() {
        // The boundary is strict-less-than: iter=2 with max=3 still
        // retries (one slot left). iter=3 is exhausted (see next test).
        let cause = RecoveryCause::SwallowedMarker;
        let res = resolve_recovery(&cause, 2, 3);
        assert!(matches!(res, RecoveryResolution::Retry { .. }));
    }

    #[test]
    fn at_or_above_max_applies_blocked_with_retry_exhausted_cause() {
        // iter >= max → Blocked. The cause is the literal spec string
        // `retry-exhausted`; the notes preserve the original recovery
        // cause so the human reading `bd show --notes` knows what kept
        // failing.
        let cause = verify_fail_cause();
        for iter in [3u32, 4, 99] {
            match resolve_recovery(&cause, iter, 3) {
                RecoveryResolution::Blocked {
                    cause: applied,
                    notes,
                } => {
                    assert_eq!(applied, RETRY_EXHAUSTED_CAUSE);
                    assert_eq!(applied, "retry-exhausted");
                    assert!(
                        notes.contains("retry-exhausted"),
                        "notes lead with the retry-exhausted label: {notes}",
                    );
                    assert!(
                        notes.contains("verify-fail"),
                        "notes preserve original cause for human review: {notes}",
                    );
                    assert!(
                        notes.contains("max_iterations (3)"),
                        "notes cite the cap that was hit: {notes}",
                    );
                    assert!(
                        notes.contains("tests/sample.sh"),
                        "previous_failure body is embedded in notes: {notes}",
                    );
                    assert!(
                        notes.contains("boom"),
                        "stderr tail is embedded in notes: {notes}",
                    );
                }
                other @ RecoveryResolution::Retry { .. } => {
                    panic!("expected Blocked at iter={iter}, got {other:?}");
                }
            }
        }
    }

    #[test]
    fn review_concern_cause_round_trips_through_notes() {
        // The `review-concern` cause carries the terminal summary +
        // streamed findings; both must survive into the blocked notes
        // when the recovery loop gives up.
        let cause = RecoveryCause::ReviewConcern {
            summary: "two findings in the diff".into(),
            findings: vec![finding_with_token(ConcernToken::VerifierBypass)],
        };
        match resolve_recovery(&cause, 3, 3) {
            RecoveryResolution::Blocked { cause, notes } => {
                assert_eq!(cause, "retry-exhausted");
                assert!(
                    notes.contains("review-concern"),
                    "notes name original cause",
                );
                assert!(
                    notes.contains("two findings in the diff"),
                    "terminal summary preserved verbatim: {notes}",
                );
                assert!(
                    notes.contains("verifier-bypass"),
                    "finding token preserved verbatim: {notes}",
                );
            }
            other @ RecoveryResolution::Retry { .. } => {
                panic!("expected Blocked, got {other:?}");
            }
        }
    }

    #[test]
    fn observer_abort_cause_renders_with_reason_in_notes() {
        let cause = RecoveryCause::ObserverAbort {
            reason: "doom-loop: 3 identical tool calls".into(),
        };
        match resolve_recovery(&cause, 3, 3) {
            RecoveryResolution::Blocked { cause: tag, notes } => {
                assert_eq!(tag, RETRY_EXHAUSTED_CAUSE);
                assert!(
                    notes.contains("observer-abort"),
                    "notes name original cause: {notes}",
                );
                assert!(
                    notes.contains("Session aborted by observer"),
                    "notes carry spec-format prefix: {notes}",
                );
                assert!(
                    notes.contains("doom-loop: 3 identical tool calls"),
                    "notes preserve verbatim observer reason: {notes}",
                );
            }
            other @ RecoveryResolution::Retry { .. } => {
                panic!("expected Blocked, got {other:?}");
            }
        }
    }

    #[test]
    fn zero_max_exhausts_immediately() {
        // Degenerate `max=0` (no retries allowed at all) immediately
        // exhausts — the first failure is also the terminal one.
        let cause = RecoveryCause::SwallowedMarker;
        assert!(matches!(
            resolve_recovery(&cause, 0, 0),
            RecoveryResolution::Blocked { .. }
        ));
    }
}
