use std::io;
use std::path::PathBuf;

use displaydoc::Display;
use thiserror::Error;

use loom_driver::git::GitError;
use loom_driver::lock::LockError;
use loom_driver::profile_manifest::ProfileError;
use loom_driver::state::CacheError;

/// Failures raised by [`super::run`] and the helpers it composes.
#[derive(Debug, Display, Error)]
pub enum PlanError {
    /// package context could not be captured or delivered
    Context(#[from] loom_driver::spec::context::Error),
    /// invalid plan anchor label `{label}`: expected lowercase ASCII kebab-case
    InvalidAnchorLabel { label: String },

    /// failed to read pinned-context file at {path}
    ReadPinnedContext {
        path: PathBuf,
        #[source]
        source: io::Error,
    },

    /// askama template render failed while running `loom plan`
    Render(#[from] askama::Error),

    /// lock acquisition failed while running `loom plan`
    Lock(#[from] LockError),

    /// cache-db operation failed while running `loom plan`
    State(#[from] CacheError),

    /// profile-image manifest lookup failed while resolving the plan phase
    Profile(#[from] ProfileError),

    /// failed to load plan configuration
    Config(#[from] loom_driver::config::LoomConfigError),

    /// direct backend cannot run interactive `loom plan`
    DirectInteractive,

    /// failed to spawn `wrix run`
    Spawn {
        #[source]
        source: io::Error,
    },

    /// `wrix run` exited with status {status}
    WrixExit { status: String },

    /// git step failed during `loom plan`
    Git(#[from] GitError),

    /// skill resolution failed during `loom plan`
    Skill(#[from] crate::skill::SkillError),
}
