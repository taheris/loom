use std::path::PathBuf;

use displaydoc::Display;
use loom_driver::agent::ProtocolError;
use loom_driver::bd::BdError;
use loom_driver::git::GitError;
use loom_driver::identifier::{ParseBeadIdError, ParseMoleculeIdError, ParseSpecLabelError};
use loom_driver::profile_manifest::ProfileError;
use loom_driver::state::CacheError;
use thiserror::Error;

/// Errors raised by the `loom todo` driver.
#[expect(
    clippy::doc_markdown,
    reason = "displaydoc fields are format placeholders; backticks would change the generated error text"
)]
#[derive(Debug, Display, Error)]
pub enum TodoError {
    /// package context could not be captured or delivered
    Context(#[from] loom_driver::spec::context::Error),
    /// native decision admission failed
    DecisionAdmission(#[source] Box<crate::r#loop::LoopError>),
    /// multiple open epics found for spec `{label}`: {ids}; close all but one before re-running
    InvariantViolation { label: String, ids: String },

    /// spec index is inconsistent: {detail}
    SpecIndex { detail: String },

    /// duplicate loom:spec epics found for spec `{label}`: {ids}; close or relabel all but one before re-running
    DuplicateSpecEpics { label: String, ids: String },

    /// existing spec epic `{epic_id}` for `{label}` lacks `loom.todo_cursor`; repair with `bd update {epic_id} --set-metadata loom.todo_cursor=<sha>`
    MissingSpecCursor { label: String, epic_id: String },

    /// spec epic `{epic_id}` for `{label}` has invalid `loom.todo_cursor` `{cursor}`: {reason}
    InvalidSpecCursor {
        label: String,
        epic_id: String,
        cursor: String,
        reason: String,
    },

    /// pending loom:todo epic conflict across {ids}; resolve before re-running:
    /// {diagnostic}
    PendingTodoEpicConflict { ids: String, diagnostic: String },

    /// failed to parse todo acceptance declarations
    Parse(#[from] loom_gate::annotation::ParseError),

    /// invalid todo acceptance criteria
    Criteria(#[from] loom_protocol::acceptance::SnapshotError),

    /// formatting todo evidence failed
    EvidenceFormat(#[from] std::fmt::Error),

    /// todo {surface} is {bytes} bytes, exceeding the {limit}-byte dispatch bound; no content was truncated; reduce oversized index/skill context or extend dossier paging before retrying the unchanged batch
    ContextTooLarge {
        surface: &'static str,
        bytes: usize,
        limit: usize,
    },

    /// no specs changed since their durable `loom.todo_cursor`; no todo agent was run
    NoChangedSpecs,

    /// todo success was observed before deterministic preflight completed
    TodoSuccessWithoutPreflight,

    /// `loom todo` success must be `LOOM_TODO: <json>`; generic LOOM_COMPLETE/LOOM_NOOP are wrong-phase markers
    GenericTodoMarker,

    /// LOOM_TODO validation failed: {detail}
    TodoValidation { detail: String },

    /// todo preflight acceptance snapshot is invalid
    AcceptanceSnapshot(#[source] Box<loom_gate::acceptance::Error>),

    /// todo criterion assignment does not resolve in the preflight snapshot
    AcceptanceResolution(#[from] loom_protocol::acceptance::ResolveError),

    /// todo task assignment is invalid
    AcceptanceReferences(#[from] loom_protocol::acceptance::ParseError),

    /// todo acceptance metadata could not be serialized
    AcceptanceSerde(#[from] serde_json::Error),

    /// todo finalization failed ({cause}) and compensation also failed: {failures}
    TodoCompensation { cause: String, failures: String },

    /// todo agent supplied no terminal signal — expected a final `LOOM_TODO: <json>` success payload or a worker self-report marker
    MissingExitSignal,

    /// agent reported LOOM_BLOCKED: {reason}
    AgentBlocked { reason: String },

    /// could not read spec file at {path}
    ReadSpec {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },

    /// rendering the prompt template failed
    Render(#[from] askama::Error),

    /// io operation failed during `loom todo`
    Io(#[from] std::io::Error),

    /// multi-spec fan-out collision; `loom:clarify` bead {clarify_id} created — resolve via `loom inbox`
    MultiSpecCollision { clarify_id: String },

    /// agent reported productive completion for spec `{label}` but minted no implementation beads despite {notes_remaining} note(s) remaining — either re-run after `loom note clear {label}` if the notes are obsolete, or investigate why the agent skipped fan-out (see logs/{label}/todo-*.jsonl)
    ProductiveCompletionWithoutFanout {
        label: String,
        notes_remaining: usize,
    },

    /// agent backend protocol failure during `loom todo`
    Protocol(#[from] ProtocolError),

    /// cache-db read/write failure during `loom todo`
    State(#[from] CacheError),

    /// profile-image manifest dispatch failed during `loom todo`
    Profile(#[from] ProfileError),

    /// bd client failure during `loom todo`
    Bd(#[from] BdError),

    /// git operation failed during `loom todo`
    Git(#[from] GitError),

    /// invalid molecule id returned during `loom todo`
    InvalidMoleculeId(#[from] ParseMoleculeIdError),

    /// invalid spec label discovered during `loom todo`
    InvalidSpecLabel(#[from] ParseSpecLabelError),

    /// invalid work epic id `{id}` returned during `loom todo`
    InvalidWorkEpic {
        id: String,
        #[source]
        source: ParseBeadIdError,
    },

    /// spec → molecule resolution failed during `loom todo`
    Resolve(#[from] crate::resolve::ResolveError),

    /// skill resolution failed during `loom todo`
    Skill(#[from] crate::skill::SkillError),
}
