//! Production [`TodoController`] used by the `loom todo` binary.

use std::collections::{BTreeSet, HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::time::SystemTime;

use askama::Template;
use loom_driver::agent::{AgentRuntime, SessionOutcome};
use loom_driver::bd::{
    BdClient, CommandRunner, CreateOpts, Label, ListOpts, TokioRunner, UpdateOpts,
};
use loom_driver::clock::{Clock, SystemClock};
use loom_driver::config::{LoomTopConfig, SkillsConfig};
use loom_driver::git::GitClient;
use loom_driver::identifier::{BeadId, ProfileName, SpecLabel};
use loom_driver::logging::{BeadOutcome, LogSink, phase_log_path};
use loom_driver::profile_manifest::ProfileImageManifest;
use loom_driver::state::{CacheDb, SpecEpicRow, WorkEpicRow};
use loom_events::{
    AgentEvent, AgentStartMetadata, DriverEventPayload, DriverKind, EnvelopeBuilder, Source,
};
use loom_protocol::acceptance::{Candidates, METADATA_KEY, Reference, References, Snapshot};
use loom_protocol::todo::{GitSha, TodoSpecOutcome, TodoSuccess};
use tracing::{debug, info};

use crate::skill::SkillPlan;
use crate::spawn::container_workspace_path;

use super::ExitSignal;
use super::context::{
    FingerprintSpecInput, TemplateBaseFields, build_template_context, changed_spec_context,
    implementation_notes_context, spec_epic_context, todo_fingerprint,
};
use super::criterion_status::build_criterion_status;
use super::cursor::{CURSOR_KEY as TODO_CURSOR_METADATA_KEY, Cursor};
use super::error::TodoError;
use super::runner::{TodoController, TodoRecord, TodoSession, TodoSpecSummary};

const TODO_HEAD_METADATA_KEY: &str = "loom.todo_head";
const TODO_FINGERPRINT_METADATA_KEY: &str = "loom.todo_fingerprint";
const TODO_SPECS_METADATA_KEY: &str = "loom.todo_specs";
const PENDING_WORK_EPIC_TITLE: &str = "Pending todo decomposition";

pub struct ProductionTodoController<R: CommandRunner = TokioRunner> {
    workspace: PathBuf,
    state: Arc<CacheDb>,
    manifest: Arc<ProfileImageManifest>,
    phase_default: ProfileName,
    runtime: AgentRuntime,
    git: Arc<GitClient>,
    bd: Arc<BdClient<R>>,
    preflight: Option<Preflight>,
    admitted_decisions: HashSet<BeadId>,
    reported_decisions: HashSet<BeadId>,
    loom_cfg: LoomTopConfig,
    skills_cfg: SkillsConfig,
    phase_log_root: Option<PathBuf>,
    phase_log_when: SystemTime,
    envelope_builder: Mutex<Option<EnvelopeBuilder>>,
}

#[derive(Debug, Clone)]
struct Preflight {
    head: GitSha,
    fingerprint: loom_protocol::todo::TodoFingerprint,
    changed_specs: Vec<ChangedSpec>,
    work_epic: BeadId,
    work_epic_title: String,
    work_epic_was_todo: bool,
    work_epic_was_active: bool,
    acceptance: Arc<Snapshot>,
}

#[derive(Debug, Clone)]
struct ChangedSpec {
    label: SpecLabel,
    spec_path: String,
    acceptance_path: String,
    input_scopes: Vec<String>,
    spec_epic: BeadId,
    cursor: Cursor,
}

#[derive(Debug, Clone)]
struct IndexedSpec {
    label: SpecLabel,
    spec_path: String,
    acceptance_path: String,
    input_scopes: Vec<String>,
}

struct PendingWorkEpic {
    id: BeadId,
    title: String,
    was_todo: bool,
    was_active: bool,
}

struct NoteMutation {
    bead_id: BeadId,
    previous: Option<String>,
    next: String,
}

struct BindingMutation {
    bead_id: BeadId,
    previous: Option<String>,
    next: String,
}

enum Compensation {
    Binding {
        bead_id: BeadId,
        previous: Option<String>,
    },
    Note {
        bead_id: BeadId,
        previous: Option<String>,
    },
    ActiveLabel {
        bead_id: BeadId,
    },
    Cursor {
        bead_id: BeadId,
        previous: Cursor,
    },
    WorkEpic {
        bead_id: BeadId,
        title: String,
        was_todo: bool,
        was_active: bool,
    },
}

struct BuiltTodoPrompt {
    prompt: String,
    skill_plan: SkillPlan,
    dossier: super::dossier::Dossier,
}

impl<R: CommandRunner> ProductionTodoController<R> {
    pub fn new(
        _label: SpecLabel,
        workspace: PathBuf,
        state: Arc<CacheDb>,
        manifest: Arc<ProfileImageManifest>,
        phase_default: ProfileName,
        git: Arc<GitClient>,
        bd: Arc<BdClient<R>>,
    ) -> Self {
        Self::for_workspace(workspace, state, manifest, phase_default, git, bd)
    }

    pub fn for_workspace(
        workspace: PathBuf,
        state: Arc<CacheDb>,
        manifest: Arc<ProfileImageManifest>,
        phase_default: ProfileName,
        git: Arc<GitClient>,
        bd: Arc<BdClient<R>>,
    ) -> Self {
        Self {
            workspace,
            state,
            manifest,
            phase_default,
            runtime: AgentRuntime::Pi,
            git,
            bd,
            preflight: None,
            admitted_decisions: HashSet::new(),
            reported_decisions: HashSet::new(),
            loom_cfg: LoomTopConfig::default(),
            skills_cfg: SkillsConfig::default(),
            phase_log_root: None,
            phase_log_when: SystemClock::new().wall_now(),
            envelope_builder: Mutex::new(None),
        }
    }

    /// Supply untrusted reported identities; outcome recording resolves their native graph.
    pub fn set_reported_decisions(&mut self, decisions: impl IntoIterator<Item = BeadId>) {
        self.reported_decisions = decisions.into_iter().collect();
    }

    #[must_use]
    pub fn with_loom_config(mut self, cfg: LoomTopConfig) -> Self {
        self.loom_cfg = cfg;
        self
    }

    #[must_use]
    pub const fn with_agent_runtime(mut self, runtime: AgentRuntime) -> Self {
        self.runtime = runtime;
        self
    }

    #[must_use]
    pub fn with_skills_config(mut self, cfg: SkillsConfig) -> Self {
        self.skills_cfg = cfg;
        self
    }

    #[must_use]
    pub fn with_phase_log(mut self, logs_root: PathBuf, when: SystemTime) -> Self {
        self.phase_log_root = Some(logs_root);
        self.phase_log_when = when;
        self
    }

    fn emit_driver_event(&self, event: DriverEventPayload) {
        let Some(logs_root) = self.phase_log_root.as_deref() else {
            return;
        };
        let path = phase_log_path(logs_root, "todo", self.phase_log_when);
        let mut guard = match self.envelope_builder.lock() {
            Ok(guard) => guard,
            Err(error) => {
                tracing::warn!(
                    error = ?error,
                    path = %path.display(),
                    "todo route envelope builder mutex poisoned",
                );
                return;
            }
        };
        if guard.is_none() {
            *guard = Some(crate::event_log::resume_phase_driver_envelope(
                &path,
                crate::event_log::RoutePhase::Todo,
                self.phase_log_when,
            ));
        }
        let Some(builder) = guard.as_mut() else {
            return;
        };
        let mut payload = event.payload;
        if matches!(event.driver_kind, DriverKind::ClarifyDowngraded)
            && let Some(object) = payload.as_object_mut()
        {
            object.insert(
                "event_sequence".to_string(),
                serde_json::json!(builder.current_seq()),
            );
            object.insert(
                "gate_log_path".to_string(),
                serde_json::json!(path.to_string_lossy()),
            );
        }
        let agent_event = AgentEvent::from_driver_event(
            DriverEventPayload::new(event.driver_kind, event.summary, payload),
            builder.build_with_source(Source::Driver),
        );
        drop(guard);
        match LogSink::open_at_path_append(&path) {
            Ok(mut sink) => {
                if let Err(error) = sink.emit(&agent_event) {
                    tracing::warn!(
                        error = ?error,
                        path = %path.display(),
                        "todo route event emit failed",
                    );
                }
                if let Err(error) = sink.finish(BeadOutcome::Done) {
                    tracing::warn!(
                        error = ?error,
                        path = %path.display(),
                        "todo route event finish failed",
                    );
                }
            }
            Err(error) => tracing::warn!(
                error = ?error,
                path = %path.display(),
                "todo route event sink open failed",
            ),
        }
    }

    fn emit_bd_update(
        &self,
        bead: &BeadId,
        identity: &str,
        status: Option<&str>,
        added_labels: &[&str],
        removed_labels: &[&str],
        notes_cause: Option<&str>,
    ) {
        self.emit_driver_event(DriverEventPayload::new(
            DriverKind::BdStateTransition,
            format!("Beads state updated for {bead}"),
            serde_json::json!({
                "source_route": "todo-marker",
                "identity": identity,
                "bead_id": bead,
                "mutation": "update",
                "status": status,
                "added_labels": added_labels,
                "removed_labels": removed_labels,
                "notes_cause": notes_cause,
            }),
        ));
    }

    async fn preflight(&self) -> Result<Option<Preflight>, TodoError> {
        crate::r#loop::DecisionWaitJournal::new(&self.workspace)
            .refresh_native_waits(&self.bd, None, None)
            .await
            .map_err(decision_admission_error)?;
        let indexed = parse_spec_index(&self.workspace)?;
        let mut changed = Vec::new();
        for spec in &indexed {
            self.state.upsert_spec(&spec.label, &spec.spec_path)?;
            let epic = self.ensure_spec_epic(spec).await?;
            if epic.cursor.is_uninitialized() {
                changed.push(epic);
                continue;
            }
            if self
                .spec_changed_since_cursor(spec, epic.cursor.as_str())
                .await?
            {
                changed.push(epic);
            }
        }
        if changed.is_empty() {
            return Ok(None);
        }
        changed.sort_by(|left, right| left.label.as_str().cmp(right.label.as_str()));
        let head = self.git.head_commit_sha().await?;
        let docs_blob = self.git.head_blob_sha(Path::new("docs/README.md")).await?;
        let mut fingerprint_specs = Vec::with_capacity(changed.len());
        for spec in &changed {
            let mut inputs = vec![(
                spec.spec_path.clone(),
                Some(self.git.head_blob_sha(Path::new(&spec.spec_path)).await?),
            )];
            if spec.acceptance_path != spec.spec_path {
                inputs.push((
                    spec.acceptance_path.clone(),
                    Some(
                        self.git
                            .head_blob_sha(Path::new(&spec.acceptance_path))
                            .await?,
                    ),
                ));
            }
            for scope in &spec.input_scopes {
                if inputs.iter().any(|(path, _)| path == scope) {
                    continue;
                }
                let oid = if spec.spec_path == spec.acceptance_path {
                    self.git
                        .blob_sha_at_revision("HEAD", Path::new(scope))
                        .await?
                } else {
                    Some(self.git.head_blob_sha(Path::new(scope)).await?)
                };
                inputs.push((scope.clone(), oid));
            }
            fingerprint_specs.push(FingerprintSpecInput {
                label: spec.label.clone(),
                spec_path: spec.spec_path.clone(),
                acceptance_path: spec.acceptance_path.clone(),
                inputs,
                spec_epic_id: spec.spec_epic.clone(),
                todo_cursor: spec.cursor.as_str().map(str::to_owned),
                initialized: spec.cursor.is_uninitialized(),
            });
        }
        let fingerprint = todo_fingerprint(&head, docs_blob.as_str(), &fingerprint_specs);
        let packages = loom_driver::spec::package::discover_indexed(&self.workspace)
            .map_err(|error| TodoError::SpecIndex {
                detail: format!("{error:#}"),
            })?
            .into_iter()
            .filter(|package| changed.iter().any(|spec| spec.label == *package.label()))
            .collect::<Vec<_>>();
        let acceptance = Arc::new(
            loom_gate::acceptance::load_packages(&packages)
                .map_err(|source| TodoError::AcceptanceSnapshot(Box::new(source)))?,
        );
        let work_epic = self.ensure_work_epic(&head, &fingerprint, &changed).await?;
        Ok(Some(Preflight {
            head,
            fingerprint,
            changed_specs: changed,
            work_epic: work_epic.id,
            work_epic_title: work_epic.title,
            work_epic_was_todo: work_epic.was_todo,
            work_epic_was_active: work_epic.was_active,
            acceptance,
        }))
    }

    async fn ensure_spec_epic(&self, spec: &IndexedSpec) -> Result<ChangedSpec, TodoError> {
        let epics = self.spec_epics_for(&spec.label).await?;
        if epics.len() > 1 {
            let ids = epics
                .iter()
                .map(|bead| bead.id.as_str())
                .collect::<Vec<_>>()
                .join(", ");
            return Err(TodoError::DuplicateSpecEpics {
                label: spec.label.to_string(),
                ids,
            });
        }
        let (spec_epic, cursor) = if let Some(bead) = epics.first() {
            let cursor = Cursor::parse(bead, spec.label.as_str())?;
            if let Cursor::Finalized(sha) = &cursor {
                self.validate_cursor(&spec.label, &bead.id, sha).await?;
            }
            self.close_spec_epic_if_needed(&bead.id, bead.status.as_str())
                .await?;
            (bead.id.clone(), cursor)
        } else {
            (self.create_spec_epic(spec).await?, Cursor::Uninitialized)
        };
        let molecule_id = spec_epic.as_str().parse()?;
        self.state.upsert_spec_epic(&SpecEpicRow {
            spec_label: spec.label.clone(),
            epic_id: molecule_id,
            todo_cursor: cursor.as_str().map(str::to_owned),
        })?;
        Ok(ChangedSpec {
            label: spec.label.clone(),
            spec_path: spec.spec_path.clone(),
            acceptance_path: spec.acceptance_path.clone(),
            input_scopes: spec.input_scopes.clone(),
            spec_epic,
            cursor,
        })
    }

    async fn create_spec_epic(&self, spec: &IndexedSpec) -> Result<BeadId, TodoError> {
        let id = self
            .bd
            .create(CreateOpts {
                title: format!("loom spec: {}", spec.label),
                description: format!("Spec metadata epic for `{}`.", spec.label),
                issue_type: Some(loom_driver::bd::IssueType::Epic),
                priority: Some(loom_driver::bd::Priority::P2),
                labels: vec!["loom:spec".to_string(), format!("spec:{}", spec.label)],
                metadata: Some(Cursor::creation_metadata()),
                ..CreateOpts::default()
            })
            .await?;
        self.close_spec_epic_if_needed(&id, "open").await?;
        Ok(id)
    }

    async fn close_spec_epic_if_needed(&self, id: &BeadId, status: &str) -> Result<(), TodoError> {
        if status == "closed" {
            return Ok(());
        }
        self.bd.close(id, Some("spec metadata carrier")).await?;
        Ok(())
    }

    async fn spec_epics_for(
        &self,
        label: &SpecLabel,
    ) -> Result<Vec<loom_driver::bd::Bead>, TodoError> {
        let mut out = Vec::new();
        for status in [
            loom_driver::bd::Status::Open,
            loom_driver::bd::Status::InProgress,
            loom_driver::bd::Status::Closed,
        ] {
            let beads = self
                .bd
                .list(ListOpts {
                    issue_type: Some(loom_driver::bd::IssueType::Epic),
                    label: Some(format!("spec:{label}")),
                    statuses: vec![status],
                    limit: Some(0),
                    ..Default::default()
                })
                .await?;
            out.extend(beads.into_iter().filter(has_label(Label::is_spec_epic)));
        }
        Ok(out)
    }

    async fn validate_cursor(
        &self,
        label: &SpecLabel,
        epic_id: &BeadId,
        cursor: &GitSha,
    ) -> Result<(), TodoError> {
        let cursor = cursor.as_str();
        if !self.git.rev_exists(cursor).await? {
            return Err(TodoError::InvalidSpecCursor {
                label: label.to_string(),
                epic_id: epic_id.to_string(),
                cursor: cursor.to_string(),
                reason: "commit does not exist".to_string(),
            });
        }
        if !self.git.is_ancestor_of_head(cursor).await? {
            return Err(TodoError::InvalidSpecCursor {
                label: label.to_string(),
                epic_id: epic_id.to_string(),
                cursor: cursor.to_string(),
                reason: "commit is not an ancestor of HEAD".to_string(),
            });
        }
        Ok(())
    }

    async fn spec_changed_since_cursor(
        &self,
        spec: &IndexedSpec,
        cursor: Option<&str>,
    ) -> Result<bool, TodoError> {
        let Some(cursor) = cursor else {
            return Ok(true);
        };
        for scope in &spec.input_scopes {
            if self
                .git
                .path_changed_since(cursor, Path::new(scope))
                .await?
            {
                return Ok(true);
            }
        }
        let old_index = self
            .git
            .file_at_revision(cursor, Path::new("docs/README.md"))
            .await?
            .unwrap_or_default();
        let old_rows = parse_spec_index_content(&old_index)?;
        let old_path = old_rows
            .iter()
            .find(|row| row.label == spec.label)
            .map(|row| row.contract.as_path());
        Ok(old_path != Some(Path::new(&spec.spec_path)))
    }

    async fn ensure_work_epic(
        &self,
        head: &GitSha,
        fingerprint: &loom_protocol::todo::TodoFingerprint,
        changed_specs: &[ChangedSpec],
    ) -> Result<PendingWorkEpic, TodoError> {
        let pending = self.pending_todo_epics().await?;
        let (matching, nonmatching): (Vec<_>, Vec<_>) = pending.into_iter().partition(|bead| {
            metadata_string(bead, TODO_HEAD_METADATA_KEY).as_deref() == Some(head.as_str())
                && metadata_string(bead, TODO_FINGERPRINT_METADATA_KEY).as_deref()
                    == Some(fingerprint.as_str())
        });
        if matching.len() == 1 && nonmatching.is_empty() {
            let bead = &matching[0];
            return Ok(PendingWorkEpic {
                id: bead.id.clone(),
                title: bead.title.clone(),
                was_todo: bead.labels.iter().any(Label::is_todo_stage),
                was_active: bead.labels.iter().any(Label::is_active),
            });
        }
        if matching.len() > 1 || !nonmatching.is_empty() {
            let ids = matching
                .iter()
                .chain(nonmatching.iter())
                .map(|bead| bead.id.as_str())
                .collect::<Vec<_>>()
                .join(", ");
            return Err(TodoError::PendingTodoEpicConflict {
                ids,
                diagnostic: pending_todo_options(head, fingerprint),
            });
        }
        let specs = changed_specs
            .iter()
            .map(|spec| spec.label.to_string())
            .collect::<Vec<_>>();
        let metadata = serde_json::json!({
            TODO_HEAD_METADATA_KEY: head.as_str(),
            TODO_FINGERPRINT_METADATA_KEY: fingerprint.as_str(),
            TODO_SPECS_METADATA_KEY: specs,
        })
        .to_string();
        let mut labels = vec!["loom:todo".to_string()];
        labels.extend(
            changed_specs
                .iter()
                .map(|spec| format!("spec:{}", spec.label)),
        );
        let work_epic = self
            .bd
            .create(CreateOpts {
                title: PENDING_WORK_EPIC_TITLE.to_string(),
                description: "Driver-created work epic for deterministic loom todo decomposition."
                    .to_string(),
                issue_type: Some(loom_driver::bd::IssueType::Epic),
                priority: Some(loom_driver::bd::Priority::P2),
                labels,
                metadata: Some(metadata),
                ..CreateOpts::default()
            })
            .await?;
        self.state.upsert_work_epic(&WorkEpicRow {
            epic_id: work_epic.as_str().parse()?,
            base_commit: Some(head.to_string()),
            todo_fingerprint: Some(fingerprint.to_string()),
            is_active: false,
            iteration_count: 0,
        })?;
        Ok(PendingWorkEpic {
            id: work_epic,
            title: PENDING_WORK_EPIC_TITLE.to_string(),
            was_todo: true,
            was_active: false,
        })
    }

    async fn pending_todo_epics(&self) -> Result<Vec<loom_driver::bd::Bead>, TodoError> {
        let beads = self
            .bd
            .list(ListOpts {
                issue_type: Some(loom_driver::bd::IssueType::Epic),
                label: Some("loom:todo".to_string()),
                statuses: vec![loom_driver::bd::Status::Open],
                limit: Some(0),
                ..Default::default()
            })
            .await?;
        Ok(beads
            .into_iter()
            .filter(has_label(Label::is_todo_stage))
            .collect())
    }

    async fn build_prompt(&mut self) -> Result<Option<BuiltTodoPrompt>, TodoError> {
        let Some(preflight) = self.preflight().await? else {
            self.preflight = None;
            return Ok(None);
        };
        let mut implementation_notes = Vec::new();
        let mut companion_paths = Vec::new();
        let mut spec_epics = Vec::new();
        let mut changed_specs = Vec::new();
        let mut criterion_status = Vec::new();
        for spec in &preflight.changed_specs {
            let notes = self
                .state
                .notes_list(Some(&spec.label), Some("implementation"))?
                .into_iter()
                .map(|row| row.text)
                .collect::<Vec<_>>();
            implementation_notes.push(implementation_notes_context(spec.label.clone(), notes));
            companion_paths.extend(self.state.companions(&spec.label)?);
            spec_epics.push(spec_epic_context(
                spec.label.clone(),
                Some(spec.spec_epic.as_str().parse()?),
                spec.cursor.as_str().map(str::to_owned),
            ));
            let diff = if let Some(cursor) = spec.cursor.as_str() {
                let mut diff = String::new();
                for scope in &spec.input_scopes {
                    diff.push_str(&self.git.diff_spec(cursor, Path::new(scope)).await?);
                }
                Some(diff)
            } else {
                None
            };
            changed_specs.push(changed_spec_context(
                spec.label.clone(),
                spec.spec_path.clone(),
                spec.acceptance_path.clone(),
                spec.input_scopes.join("`, `"),
                diff,
            ));
            let cache_path = self.workspace.join(".loom/cache.db");
            criterion_status.extend(
                build_criterion_status(
                    &self.workspace,
                    &cache_path,
                    &spec.label,
                    Path::new(&spec.acceptance_path),
                    self.git.as_ref(),
                )
                .await?,
            );
        }
        companion_paths.sort();
        companion_paths.dedup();
        let key = preflight.work_epic.as_str();
        let scratchpad_path =
            loom_driver::scratch::ScratchSession::scratchpad_path_for(&self.workspace, key);
        let scratch_dir = scratchpad_path.parent().ok_or_else(|| {
            TodoError::Protocol(loom_driver::agent::ProtocolError::Io(
                std::io::Error::other("scratchpad path has no parent"),
            ))
        })?;
        let tracked_files = self.git.tracked_files().await?;
        let skill_plan = SkillPlan::resolve(
            &self.workspace,
            &tracked_files,
            loom_driver::config::Phase::Todo.as_str(),
            &self.phase_default,
            self.runtime,
            &self.skills_cfg,
        )?;
        // The index needs materialized skill paths. Own this preview so render or
        // budget errors clean it up; build_session recreates the final layout.
        let preview = loom_driver::scratch::ScratchSession::open(
            &self.workspace,
            key,
            "",
            &format!("loom todo @ {}", preflight.work_epic),
        )?;
        let skill_session = skill_plan.materialize(preview.path(), &self.workspace)?;
        let spec_index = std::fs::read_to_string(self.workspace.join("docs/README.md"))?;
        let prompt_scratchpad_path = container_workspace_path(&self.workspace, &scratchpad_path);
        let labels = preflight
            .changed_specs
            .iter()
            .map(|spec| spec.label.clone())
            .collect::<Vec<_>>();
        let package_context = loom_driver::spec::context::load(
            &self.workspace,
            loom_protocol::context::Purpose::Decomposition,
            loom_driver::spec::context::Selection::Labels(&labels),
        )?;
        let base = TemplateBaseFields {
            package_context: Some(package_context),
            pinned_context: String::new(),
            spec_index,
            changed_specs,
            work_epic: preflight.work_epic.clone(),
            todo_head: preflight.head.clone(),
            todo_fingerprint: preflight.fingerprint.clone(),
            spec_epics,
            companion_paths,
            implementation_notes,
            scratchpad_path: prompt_scratchpad_path.to_string_lossy().into_owned(),
            skill_index: skill_session.skill_index,
        };
        let mut ctx = build_template_context(base, criterion_status);
        let dossier = super::dossier::Dossier::build(&ctx)?;
        ctx.evidence_delivery = loom_templates::todo::EvidenceDelivery::Dossier {
            manifest_path: container_workspace_path(
                &self.workspace,
                &scratch_dir.join("evidence/index.md"),
            )
            .to_string_lossy()
            .into_owned(),
        };
        let prompt = ctx.render()?;
        super::dossier::check_bound("entry prompt", prompt.len())?;
        self.preflight = Some(preflight);
        Ok(Some(BuiltTodoPrompt {
            prompt,
            skill_plan,
            dossier,
        }))
    }

    async fn validate_success(
        &self,
        success: &TodoSuccess,
    ) -> Result<Vec<BindingMutation>, TodoError> {
        let preflight = self
            .preflight
            .as_ref()
            .ok_or(TodoError::TodoSuccessWithoutPreflight)?;
        if success.head != preflight.head {
            return Err(TodoError::TodoValidation {
                detail: "LOOM_TODO head did not match preflight HEAD".to_string(),
            });
        }
        if success.fingerprint != preflight.fingerprint {
            return Err(TodoError::TodoValidation {
                detail: "LOOM_TODO fingerprint did not match preflight fingerprint".to_string(),
            });
        }
        if success.work_epic != preflight.work_epic {
            return Err(TodoError::TodoValidation {
                detail: "LOOM_TODO work_epic did not match driver-created work epic".to_string(),
            });
        }
        let expected = preflight
            .changed_specs
            .iter()
            .map(|spec| spec.label.to_string())
            .collect::<BTreeSet<_>>();
        let children = self
            .bd
            .list(ListOpts {
                all: true,
                limit: Some(0),
                parent: Some(preflight.work_epic.clone()),
                ..ListOpts::default()
            })
            .await?;
        if children
            .iter()
            .any(|bead| bead.parent.as_ref() != Some(&preflight.work_epic))
        {
            return Err(TodoError::TodoValidation {
                detail: "Beads child roster contains a task outside the work epic".into(),
            });
        }
        let implementation = children
            .iter()
            .filter(|bead| !self.admitted_decisions.contains(&bead.id))
            .map(|bead| bead.id.clone())
            .collect::<HashSet<_>>();
        let mut references: HashMap<BeadId, Vec<Reference>> = HashMap::new();
        let mut seen = BTreeSet::new();
        for spec in success.specs.as_slice() {
            let label = spec.label.to_string();
            if !seen.insert(label.clone()) {
                return Err(TodoError::TodoValidation {
                    detail: format!("LOOM_TODO reported duplicate spec `{}`", spec.label),
                });
            }
            if !expected.contains(&label) {
                return Err(TodoError::TodoValidation {
                    detail: format!("LOOM_TODO reported unexpected spec `{}`", spec.label),
                });
            }
            if let TodoSpecOutcome::Decomposed { beads, assignments } = &spec.outcome {
                let roster = beads.iter().cloned().collect::<HashSet<_>>();
                let mut assigned = HashSet::new();
                if roster.len() != beads.len() || !roster.is_subset(&implementation) {
                    return Err(TodoError::TodoValidation {
                        detail: format!(
                            "spec `{}` must name distinct implementation children of the work epic",
                            spec.label
                        ),
                    });
                }
                for assignment in assignments.as_slice() {
                    if !roster.contains(&assignment.task)
                        || !assigned.insert(assignment.task.clone())
                    {
                        return Err(TodoError::TodoValidation {
                            detail: format!(
                                "assignment for `{}` is duplicated or outside the decomposed roster",
                                assignment.task
                            ),
                        });
                    }
                    preflight.acceptance.resolve(&assignment.criteria)?;
                    references
                        .entry(assignment.task.clone())
                        .or_default()
                        .extend_from_slice(assignment.criteria.as_slice());
                }
                if assigned != roster {
                    return Err(TodoError::TodoValidation {
                        detail: format!("spec `{}` omitted task assignments", spec.label),
                    });
                }
            }
        }
        if seen != expected {
            let missing = expected
                .difference(&seen)
                .map(String::as_str)
                .collect::<Vec<_>>()
                .join(", ");
            return Err(TodoError::TodoValidation {
                detail: format!("LOOM_TODO omitted changed spec(s): {missing}"),
            });
        }
        if references.keys().cloned().collect::<HashSet<_>>() != implementation {
            return Err(TodoError::TodoValidation {
                detail: "LOOM_TODO must account for every implementation child, including existing drafts".into(),
            });
        }
        let mut references = references.into_iter().collect::<Vec<_>>();
        references.sort_by(|(left, _), (right, _)| left.as_str().cmp(right.as_str()));
        references.into_iter().map(|(bead_id, references)| {
            let criteria = References::new(references)?;
            let bead = children.iter().find(|bead| bead.id == bead_id)
                .ok_or_else(|| TodoError::TodoValidation { detail: format!("missing child `{bead_id}`") })?;
            Ok(BindingMutation {
                bead_id,
                previous: bead.metadata.get(METADATA_KEY).map(|value| {
                    value.as_str().map(ToOwned::to_owned).ok_or_else(|| TodoError::TodoValidation {
                        detail: format!("task `{}` has non-string acceptance metadata; repair it before finalization", bead.id),
                    })
                }).transpose()?,
                next: serde_json::to_string(&Candidates::Implementation { criteria })?,
            })
        }).collect()
    }

    async fn record_validation_failure(&self, detail: &str) -> Result<(), TodoError> {
        let Some(preflight) = self.preflight.clone() else {
            return Ok(());
        };
        self.bd
            .update(
                &preflight.work_epic,
                UpdateOpts {
                    append_notes: Some(format!("LOOM_TODO validation failed: {detail}")),
                    ..UpdateOpts::default()
                },
            )
            .await?;
        self.emit_bd_update(
            &preflight.work_epic,
            "LOOM_TODO",
            None,
            &[],
            &[],
            Some("todo-validation-failed"),
        );
        Ok(())
    }

    async fn record_missing_exit_signal(
        &self,
        outcome: &SessionOutcome,
        marker: Option<&ExitSignal>,
    ) -> Result<(), TodoError> {
        let Some(preflight) = self.preflight.clone() else {
            return Ok(());
        };
        self.bd
            .update(
                &preflight.work_epic,
                UpdateOpts {
                    notes: Some(format!(
                        "loom todo agent supplied no terminal signal: exit_code={}, marker={:?}; expected final LOOM_TODO success payload or worker self-report marker",
                        outcome.exit_code, marker
                    )),
                    ..UpdateOpts::default()
                },
            )
            .await?;
        self.emit_bd_update(
            &preflight.work_epic,
            marker.map_or("missing", ExitSignal::identity),
            None,
            &[],
            &[],
            Some("missing-exit-signal"),
        );
        Ok(())
    }

    async fn note_mutations(&self, success: &TodoSuccess) -> Result<Vec<NoteMutation>, TodoError> {
        let mut mutations: Vec<NoteMutation> = Vec::new();
        for spec in success.specs.as_slice() {
            let TodoSpecOutcome::Decomposed { beads, .. } = &spec.outcome else {
                continue;
            };
            let notes = self
                .state
                .notes_list(Some(&spec.label), Some("implementation"))?
                .into_iter()
                .map(|row| row.text)
                .collect::<Vec<_>>();
            if notes.is_empty() {
                continue;
            }
            let rendered = render_implementation_notes(&notes);
            for bead_id in beads.as_slice() {
                if let Some(mutation) = mutations
                    .iter_mut()
                    .find(|mutation| mutation.bead_id == *bead_id)
                {
                    mutation.next = append_note_block(Some(&mutation.next), &rendered);
                    continue;
                }
                let bead = self.bd.show(bead_id).await?;
                mutations.push(NoteMutation {
                    bead_id: bead_id.clone(),
                    previous: bead.notes.clone(),
                    next: append_note_block(bead.notes.as_deref(), &rendered),
                });
            }
        }
        Ok(mutations)
    }

    async fn update_or_rollback(
        &self,
        bead_id: &BeadId,
        update: UpdateOpts,
        compensation: Compensation,
        completed: &mut Vec<Compensation>,
    ) -> Result<(), TodoError> {
        completed.push(compensation);
        if let Err(source) = self.bd.update(bead_id, update).await {
            return Err(self.rollback_error(TodoError::Bd(source), completed).await);
        }
        Ok(())
    }

    async fn rollback_error(&self, source: TodoError, completed: &[Compensation]) -> TodoError {
        let failures = self.compensate(completed).await;
        if failures.is_empty() {
            source
        } else {
            TodoError::TodoCompensation {
                cause: format!("{source:#}"),
                failures: failures.join("; "),
            }
        }
    }

    async fn compensate(&self, completed: &[Compensation]) -> Vec<String> {
        let mut failures = Vec::new();
        for compensation in completed.iter().rev() {
            let (bead_id, update) = match compensation {
                Compensation::Binding { bead_id, previous } => {
                    let update = match previous {
                        Some(encoded) => UpdateOpts {
                            set_metadata: vec![(METADATA_KEY.into(), encoded.clone())],
                            ..UpdateOpts::default()
                        },
                        None => UpdateOpts {
                            unset_metadata: vec![METADATA_KEY.into()],
                            ..UpdateOpts::default()
                        },
                    };
                    (bead_id, update)
                }
                Compensation::Note { bead_id, previous } => (
                    bead_id,
                    UpdateOpts {
                        notes: Some(previous.clone().unwrap_or_default()),
                        ..UpdateOpts::default()
                    },
                ),
                Compensation::ActiveLabel { bead_id } => (
                    bead_id,
                    UpdateOpts {
                        add_labels: vec!["loom:active".to_string()],
                        ..UpdateOpts::default()
                    },
                ),
                Compensation::Cursor { bead_id, previous } => (bead_id, previous.update()),
                Compensation::WorkEpic {
                    bead_id,
                    title,
                    was_todo,
                    was_active,
                } => {
                    let mut update = UpdateOpts {
                        title: Some(title.clone()),
                        ..UpdateOpts::default()
                    };
                    restore_label(&mut update, "loom:todo", *was_todo);
                    restore_label(&mut update, "loom:active", *was_active);
                    (bead_id, update)
                }
            };
            if let Err(error) = self.bd.update(bead_id, update).await {
                failures.push(format!("{bead_id}: {error:#}"));
            }
        }
        failures
    }

    async fn finalize_success(
        &self,
        success: &TodoSuccess,
        binding_mutations: Vec<BindingMutation>,
    ) -> Result<TodoRecord, TodoError> {
        let preflight = self
            .preflight
            .clone()
            .ok_or(TodoError::TodoSuccessWithoutPreflight)?;
        let note_mutations = self.note_mutations(success).await?;
        let active_work_epics = self.active_work_epics().await?;
        let mut completed = Vec::new();

        for mutation in &binding_mutations {
            self.update_or_rollback(
                &mutation.bead_id,
                UpdateOpts {
                    set_metadata: vec![(METADATA_KEY.into(), mutation.next.clone())],
                    ..UpdateOpts::default()
                },
                Compensation::Binding {
                    bead_id: mutation.bead_id.clone(),
                    previous: mutation.previous.clone(),
                },
                &mut completed,
            )
            .await?;
        }
        for mutation in &note_mutations {
            self.update_or_rollback(
                &mutation.bead_id,
                UpdateOpts {
                    notes: Some(mutation.next.clone()),
                    ..UpdateOpts::default()
                },
                Compensation::Note {
                    bead_id: mutation.bead_id.clone(),
                    previous: mutation.previous.clone(),
                },
                &mut completed,
            )
            .await?;
        }
        for active in &active_work_epics {
            if active.id == preflight.work_epic {
                continue;
            }
            self.update_or_rollback(
                &active.id,
                UpdateOpts {
                    remove_labels: vec!["loom:active".to_string()],
                    ..UpdateOpts::default()
                },
                Compensation::ActiveLabel {
                    bead_id: active.id.clone(),
                },
                &mut completed,
            )
            .await?;
        }
        for spec in &preflight.changed_specs {
            self.update_or_rollback(
                &spec.spec_epic,
                Cursor::Finalized(preflight.head.clone()).update(),
                Compensation::Cursor {
                    bead_id: spec.spec_epic.clone(),
                    previous: spec.cursor.clone(),
                },
                &mut completed,
            )
            .await?;
        }
        self.update_or_rollback(
            &preflight.work_epic,
            UpdateOpts {
                title: Some(success.title.to_string()),
                add_labels: vec!["loom:active".to_string()],
                remove_labels: vec!["loom:todo".to_string()],
                ..UpdateOpts::default()
            },
            Compensation::WorkEpic {
                bead_id: preflight.work_epic.clone(),
                title: preflight.work_epic_title.clone(),
                was_todo: preflight.work_epic_was_todo,
                was_active: preflight.work_epic_was_active,
            },
            &mut completed,
        )
        .await?;

        let spec_epics = preflight
            .changed_specs
            .iter()
            .map(|spec| {
                Ok(SpecEpicRow {
                    spec_label: spec.label.clone(),
                    epic_id: spec.spec_epic.as_str().parse()?,
                    todo_cursor: Some(preflight.head.to_string()),
                })
            })
            .collect::<Result<Vec<_>, TodoError>>()?;
        let work_epic = WorkEpicRow {
            epic_id: preflight.work_epic.as_str().parse()?,
            base_commit: Some(preflight.head.to_string()),
            todo_fingerprint: Some(preflight.fingerprint.to_string()),
            is_active: true,
            iteration_count: 0,
        };
        if let Err(source) = self.state.finalize_todo(&spec_epics, &work_epic) {
            return Err(self
                .rollback_error(TodoError::State(source), &completed)
                .await);
        }

        for mutation in &note_mutations {
            self.emit_bd_update(
                &mutation.bead_id,
                "LOOM_TODO",
                None,
                &[],
                &[],
                Some("implementation-notes"),
            );
        }
        for active in &active_work_epics {
            if active.id != preflight.work_epic {
                self.emit_bd_update(&active.id, "LOOM_TODO", None, &[], &["loom:active"], None);
            }
        }
        for spec in &preflight.changed_specs {
            self.emit_bd_update(
                &spec.spec_epic,
                "LOOM_TODO",
                None,
                &[],
                &[],
                Some(TODO_CURSOR_METADATA_KEY),
            );
        }
        self.emit_bd_update(
            &preflight.work_epic,
            "LOOM_TODO",
            None,
            &["loom:active"],
            &["loom:todo"],
            None,
        );
        Ok(TodoRecord {
            spec_outcomes: summarize_success(success),
        })
    }

    async fn record_blocked(&self, reason: &str) -> Result<TodoRecord, TodoError> {
        let Some(preflight) = self.preflight.clone() else {
            return Ok(TodoRecord::default());
        };
        self.bd
            .update(
                &preflight.work_epic,
                UpdateOpts {
                    status: Some(loom_driver::bd::Status::Blocked),
                    add_labels: vec!["loom:blocked".to_string()],
                    notes: Some(reason.to_string()),
                    ..UpdateOpts::default()
                },
            )
            .await?;
        self.emit_bd_update(
            &preflight.work_epic,
            "LOOM_BLOCKED",
            Some("blocked"),
            &["loom:blocked"],
            &[],
            Some("agent-blocked"),
        );
        Ok(TodoRecord {
            spec_outcomes: preflight
                .changed_specs
                .iter()
                .map(|spec| TodoSpecSummary {
                    label: spec.label.clone(),
                    outcome: format!("blocked: {reason}"),
                })
                .collect(),
        })
    }

    async fn active_work_epics(&self) -> Result<Vec<loom_driver::bd::Bead>, TodoError> {
        let beads = self
            .bd
            .list(ListOpts {
                issue_type: Some(loom_driver::bd::IssueType::Epic),
                label: Some("loom:active".to_string()),
                statuses: vec![loom_driver::bd::Status::Open],
                ..Default::default()
            })
            .await?;
        Ok(beads
            .into_iter()
            .filter(has_label(Label::is_active))
            .collect())
    }
}

impl<R: CommandRunner> TodoController for ProductionTodoController<R> {
    fn report_decisions(&mut self, decisions: HashSet<BeadId>) {
        self.reported_decisions = decisions;
    }

    async fn build_session(&mut self) -> Result<TodoSession, TodoError> {
        let built_prompt = self
            .build_prompt()
            .await?
            .ok_or(TodoError::NoChangedSpecs)?;
        let prompt = built_prompt.prompt;
        let entry = self.manifest.lookup(&self.phase_default, self.runtime)?;
        let preflight = self
            .preflight
            .as_ref()
            .ok_or(TodoError::TodoSuccessWithoutPreflight)?;
        let banner = format!("loom todo @ {}", preflight.work_epic);
        let key = preflight.work_epic.as_str();
        let scratch =
            loom_driver::scratch::ScratchSession::open(&self.workspace, key, &prompt, &banner)
                .map_err(|source| {
                    TodoError::Protocol(loom_driver::agent::ProtocolError::Io(source))
                })?;
        info!(
            work_epic = %preflight.work_epic,
            workspace = %self.workspace.display(),
            image_ref = %entry.r#ref,
            scratch_dir = %scratch.path().display(),
            "loom todo: building spawn config",
        );
        built_prompt.dossier.write(scratch.path())?;
        let scratch_dir = scratch.path().to_path_buf();
        let mounts = crate::r#loop::sccache_mount(&self.loom_cfg)
            .map_err(|source| TodoError::Protocol(loom_driver::agent::ProtocolError::Io(source)))?
            .into_iter()
            .collect();
        let mut config = crate::spawn::build_spawn_config(
            entry,
            self.runtime,
            self.workspace.clone(),
            prompt,
            scratch_dir,
            self.loom_cfg.container_sccache_env(),
            vec![],
            mounts,
            vec![],
        );
        let skill_session = built_prompt
            .skill_plan
            .materialize(scratch.path(), &self.workspace)?;
        config.skills = Some(skill_session.registered);
        config.event_metadata = Some(AgentStartMetadata {
            title: banner,
            profile: self.phase_default.clone(),
            spec_label: SpecLabel::todo(),
            parent_tool_call_id: None,
        });
        Ok(TodoSession { config, scratch })
    }

    async fn record_outcome(
        &mut self,
        outcome: &SessionOutcome,
        marker: Option<&ExitSignal>,
        todo_success: Option<&TodoSuccess>,
    ) -> Result<TodoRecord, TodoError> {
        let identity = todo_success.map_or_else(
            || marker.map_or("missing", ExitSignal::identity),
            |_| "LOOM_TODO",
        );
        let route = todo_outcome_route(outcome, marker, todo_success);
        self.emit_driver_event(DriverEventPayload::new(
            DriverKind::MarkerRouted,
            format!("terminal marker {identity} routed to {route}"),
            serde_json::json!({
                "source_route": "todo-marker",
                "identity": identity,
                "route": route,
                "work_epic": self.preflight.as_ref().map(|preflight| &preflight.work_epic),
                "exit_code": outcome.exit_code,
            }),
        ));
        if let Some(message) = marker
            && (!loom_protocol::output::Phase::Todo.admits(message)
                || message.role() != loom_protocol::output::Role::Terminal)
        {
            return Err(TodoError::GenericTodoMarker);
        }
        if outcome.exit_code == 0 && (marker.is_some() || todo_success.is_some()) {
            let preflight = self
                .preflight
                .as_ref()
                .ok_or(TodoError::TodoSuccessWithoutPreflight)?;
            let epic = self.bd.show(&preflight.work_epic).await?;
            self.admitted_decisions = crate::r#loop::admit_todo(
                &self.bd,
                &crate::r#loop::DecisionWaitJournal::new(&self.workspace),
                &epic,
                &self.reported_decisions,
            )
            .await
            .map_err(decision_admission_error)?;
        }
        if let Some(ExitSignal::Blocked(payload)) = marker {
            return self.record_blocked(payload.reason.as_str()).await;
        }
        if outcome.exit_code != 0 {
            debug!(exit_code = outcome.exit_code, marker = ?marker, "loom todo: agent exited before finalizing success");
            self.record_missing_exit_signal(outcome, marker).await?;
            return Err(TodoError::MissingExitSignal);
        }
        if matches!(marker, Some(ExitSignal::Waiting)) {
            let epic = &self
                .preflight
                .as_ref()
                .ok_or(TodoError::TodoSuccessWithoutPreflight)?
                .work_epic;
            let source = self.bd.show(epic).await?;
            match crate::r#loop::DecisionWaitJournal::new(&self.workspace)
                .reconcile_native_wait(
                    &self.bd,
                    &source,
                    crate::r#loop::AgentOutcome::WaitingRequested,
                )
                .await
                .map_err(decision_admission_error)?
            {
                crate::r#loop::AgentOutcome::Waiting { .. } => return Ok(TodoRecord::default()),
                other => {
                    return Err(TodoError::TodoValidation {
                        detail: format!("unattributed Todo wait: {other:?}"),
                    });
                }
            }
        }
        let Some(success) = todo_success else {
            debug!(exit_code = outcome.exit_code, marker = ?marker, "loom todo: no success payload to finalize");
            self.record_missing_exit_signal(outcome, marker).await?;
            return Err(TodoError::MissingExitSignal);
        };
        let bindings = match self.validate_success(success).await {
            Ok(bindings) => bindings,
            Err(err) => {
                self.record_validation_failure(&format!("{err:#}")).await?;
                return Err(err);
            }
        };
        self.finalize_success(success, bindings).await
    }
}

fn decision_admission_error(error: crate::r#loop::LoopError) -> TodoError {
    match error {
        crate::r#loop::LoopError::DecisionWait(error) => TodoError::TodoValidation {
            detail: error.to_string(),
        },
        error => TodoError::DecisionAdmission(Box::new(error)),
    }
}

const fn todo_outcome_route(
    outcome: &SessionOutcome,
    marker: Option<&ExitSignal>,
    todo_success: Option<&TodoSuccess>,
) -> &'static str {
    match marker {
        Some(ExitSignal::Blocked(_)) => "blocked",
        Some(ExitSignal::Retry(_)) => "retry",
        Some(ExitSignal::Waiting) => "waiting",
        Some(ExitSignal::Todo(_)) if todo_success.is_some() => "success",
        Some(_) => "wrong-phase-marker",
        None if outcome.exit_code != 0 => "recovery",
        None if todo_success.is_some() => "success",
        None => "recovery",
    }
}

fn parse_spec_index(workspace: &Path) -> Result<Vec<IndexedSpec>, TodoError> {
    let packages = loom_driver::spec::package::discover_indexed(workspace).map_err(|error| {
        TodoError::SpecIndex {
            detail: format!("{error:#}"),
        }
    })?;
    packages
        .into_iter()
        .map(|package| {
            let relative = |path: &Path| {
                path.strip_prefix(workspace)
                    .map(|path| path.to_string_lossy().into_owned())
                    .map_err(|error| TodoError::SpecIndex {
                        detail: error.to_string(),
                    })
            };
            Ok(IndexedSpec {
                label: package.label().clone(),
                spec_path: relative(package.contract())?,
                acceptance_path: relative(package.acceptance())?,
                input_scopes: package
                    .input_scopes()
                    .iter()
                    .map(|path| relative(path))
                    .collect::<Result<_, _>>()?,
            })
        })
        .collect()
}

fn parse_spec_index_content(
    content: &str,
) -> Result<Vec<loom_driver::spec::package::IndexEntry>, TodoError> {
    loom_driver::spec::package::parse_index(content).map_err(|error| TodoError::SpecIndex {
        detail: format!("{error:#}"),
    })
}

fn metadata_string(bead: &loom_driver::bd::Bead, key: &str) -> Option<String> {
    bead.metadata
        .get(key)
        .and_then(serde_json::Value::as_str)
        .map(ToOwned::to_owned)
}

fn has_label(pred: fn(&Label) -> bool) -> impl Fn(&loom_driver::bd::Bead) -> bool {
    move |bead| bead.labels.iter().any(pred)
}

fn pending_todo_options(
    head: &GitSha,
    fingerprint: &loom_protocol::todo::TodoFingerprint,
) -> String {
    format!(
        "## Options — Resolve pending todo epic\n\n### Option 1 — Continue matching batch\nClose or relabel non-matching `loom:todo` epics, leaving exactly one open epic with `{TODO_HEAD_METADATA_KEY}={head}` and `{TODO_FINGERPRINT_METADATA_KEY}={fingerprint}`. Cost: manual bd cleanup.\n\n### Option 2 — Restart decomposition\nRemove `loom:todo` from all pending todo epics, then rerun `loom todo` so the driver creates a fresh batch. Cost: any useful draft decomposition must be copied manually."
    )
}

fn render_implementation_notes(notes: &[String]) -> String {
    let mut out = String::from("Implementation notes:\n");
    for note in notes {
        out.push_str("\n- ");
        out.push_str(note);
    }
    out
}

fn append_note_block(existing: Option<&str>, block: &str) -> String {
    let Some(existing) = existing.filter(|value| !value.trim().is_empty()) else {
        return block.to_string();
    };
    format!("{}\n\n{}", existing.trim_end(), block)
}

fn restore_label(update: &mut UpdateOpts, label: &str, was_present: bool) {
    if was_present {
        update.add_labels.push(label.to_string());
    } else {
        update.remove_labels.push(label.to_string());
    }
}

fn summarize_success(success: &TodoSuccess) -> Vec<TodoSpecSummary> {
    success
        .specs
        .as_slice()
        .iter()
        .map(|spec| {
            let outcome = match &spec.outcome {
                TodoSpecOutcome::Decomposed { beads, .. } => {
                    let bead_list = beads
                        .as_slice()
                        .iter()
                        .map(ToString::to_string)
                        .collect::<Vec<_>>()
                        .join(", ");
                    format!("decomposed: {bead_list}")
                }
                TodoSpecOutcome::NoWork { reason } => format!("no-work: {reason}"),
            };
            TodoSpecSummary {
                label: spec.label.clone(),
                outcome,
            }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_spec_index_reads_docs_rows() {
        let rows = parse_spec_index_content(
            "- [Harness](../specs/harness.md)\n- [Templates](../specs/templates.md)\n",
        )
        .expect("index parses");
        assert_eq!(rows[0].label, SpecLabel::new("harness").unwrap());
        assert_eq!(rows[1].contract, Path::new("specs/templates.md"));
    }

    #[test]
    fn parse_spec_index_rejects_duplicate_labels() {
        let err = parse_spec_index_content(
            "- [Harness](../specs/harness.md)\n- [Harness again](../specs/harness.md)\n",
        )
        .expect_err("duplicate rejected");
        assert!(matches!(err, TodoError::SpecIndex { .. }));
    }
}
