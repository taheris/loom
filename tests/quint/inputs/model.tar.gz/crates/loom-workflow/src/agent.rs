//! Backend-agnostic session driver.
//!
//! [`run_agent`] is the single function the workflow modules call to drive a
//! [`SpawnConfig`] through any [`AgentBackend`]. The binary crate
//! monomorphizes one copy per concrete backend (`run_agent::<PiBackend>` and
//! `run_agent::<ClaudeBackend>`) inside a `dispatch` match and hands the
//! resulting closure into the workflow modules — keeping
//! [`run_agent`]'s `<B: AgentBackend>` parameter the only place the workflow
//! is generic over the backend.
//!
//! Every [`AgentEvent`] consumed from the typestate session is tee'd into an
//! optional [`LogSink`] (when one is supplied) so the spec contract — "the
//! terminal renderer consumes the same `AgentEvent` stream that's written to
//! disk" — is enforced through a single emission point. Sink lifecycle
//! ownership lives here: passing `Some(sink)` consumes it, and `run_agent`
//! calls [`LogSink::finish`] before returning so callers can rely on the
//! file being closed and flushed regardless of the exit path.

use std::time::Duration;

use loom_driver::agent::{
    Active, AgentBackend, AgentEvent, AgentSession, DEFAULT_STALL_WARN_SECS, Idle, ProtocolError,
    SessionOutcome, SpawnConfig,
};
use loom_driver::clock::{Clock, SystemClock};
use loom_driver::logging::{BeadOutcome, LogSink};
use loom_events::identifier::SessionId;
use loom_events::{
    DriverEventPayload, DriverKind, EVENT_SCHEMA_VERSION, EnvelopeBuilder, EventSink, InputKind,
    ParsedAgentEvent, SessionCommand, SessionScope, Source,
};
use tracing::{error, info, trace, warn};

use crate::r#loop::{MISSING_AGENT_BINARY_CAUSE, SessionResult};
use crate::observer::DefaultObserverChain;
use crate::redaction::{Sink, redact_agent_input};

/// Admit captured agent-origin output without changing workflow state.
pub fn admit_session_output(
    result: SessionResult,
    text: &str,
    phase: loom_protocol::output::Phase,
) -> (SessionResult, Option<loom_protocol::output::Message>) {
    let SessionResult::Complete(outcome) = result else {
        return (result, None);
    };
    let output = loom_protocol::output::decode(text, phase);
    let terminal = match &output {
        Ok(session) => Some(session.terminal().message.clone()),
        Err(_) => None,
    };
    (
        SessionResult::Decoded {
            outcome,
            output: std::sync::Arc::new(output),
        },
        terminal,
    )
}

/// Drive `B` through one full session: spawn, prompt, then consume events
/// until `SessionComplete` arrives. Returns the resulting [`SessionOutcome`]
/// (exit code + cost, when surfaced by the backend).
///
/// When `sink` is `Some`, every observed event is emitted into the sink in
/// arrival order — including the terminal `SessionComplete` — and the sink
/// is finished with the appropriate [`BeadOutcome`] before this function
/// returns. Sink-write failures map to [`ProtocolError::Io`] so the caller
/// surfaces a single error type regardless of which subsystem failed.
///
/// `UnexpectedEof` is returned if the agent process closes its stdout
/// without emitting a terminal event — this signals the caller that the
/// session ended abnormally and the outcome is not trustworthy.
///
/// # Errors
///
/// Returns an error when workflow setup, execution, or state validation fails.
pub async fn run_agent<B: AgentBackend>(
    config: &SpawnConfig,
    sink: Option<LogSink>,
    text_capture: Option<&mut String>,
) -> Result<SessionOutcome, ProtocolError> {
    match run_agent_classified::<B>(config, sink, None, text_capture, None).await {
        SessionResult::Complete(outcome) => Ok(outcome),
        SessionResult::Decoded { outcome, output } => match output.as_ref() {
            Ok(_) => Ok(outcome),
            Err(failure) => Err(ProtocolError::Io(std::io::Error::other(format!(
                "{failure:?}"
            )))),
        },
        // Callers that only accept the legacy `Result` shape (todo, plan,
        // inbox, batch dispatch) treat both infra phases as a single failure
        // surface. The run-loop dispatch path in `main.rs` calls
        // `run_agent_classified` directly so it can preserve the
        // pre-stream/interrupted distinction the verdict gate relies on.
        SessionResult::PreflightFailed { error }
        | SessionResult::MidSessionFailed { error }
        | SessionResult::StaticInfra { error, .. } => {
            Err(ProtocolError::Io(std::io::Error::other(error)))
        }
        SessionResult::ObserverAbort { reason } => Err(ProtocolError::Io(std::io::Error::other(
            format!("Session aborted by observer: {reason}"),
        ))),
    }
}

/// Same as [`run_agent`] but preserves the pre-stream vs interrupted
/// infrastructure split in its return type.
///
/// Used by the `loom loop` driver so
/// failures before the first canonical agent-sourced event route as
/// `infra-preflight`, while failures after agent output but before
/// `session_complete` route as interrupted infra.
///
/// `observer` is an optional [`DefaultObserverChain`] the driver fans
/// every event into alongside `sink`. After every non-streaming event
/// the driver calls `observer.react()` (then `sink.react()`) and applies
/// the returned [`SessionCommand`]s to the live session: `Steer` injects
/// a system message into the next turn; `Abort` terminates the session
/// and the function returns [`SessionResult::ObserverAbort`]. `Abort`
/// is terminal — subsequent commands in the same batch are ignored. The
/// driver also drains the chain's pending observability payloads
/// (`take_pending_driver_events`) and writes each one through the same
/// `sink` + `envelope_builder` as the surrounding agent events, so
/// `DriverKind::DoomLoopTripped` / `DriverKind::DuplicateToolResult`
/// land in the log alongside the events that caused them.
///
/// `envelope_builder` joins each `ParsedAgentEvent` the session yields
/// with the next per-spawn envelope (monotonic `seq`, stable
/// `session_id`, real wall-clock `ts_ms`) via `AgentEvent::from_parsed`.
/// The session layer is the sole constructor of `AgentEvent`; parsers
/// cannot reach a stamped event by any other path. When `None`, the loop
/// falls back to `phase_envelope_builder` so phase spawns (todo / plan /
/// inbox) without a bead context still produce fully-valid envelopes
/// without a synthetic `bead_id`.
pub async fn run_agent_classified<B: AgentBackend>(
    config: &SpawnConfig,
    sink: Option<LogSink>,
    mut observer: Option<&mut DefaultObserverChain>,
    mut text_capture: Option<&mut String>,
    mut envelope_builder: Option<loom_events::EnvelopeBuilder>,
) -> SessionResult {
    let mut sink = sink.map(|sink| Sink::new(sink, config));
    let stall_window = config
        .stall_warn_interval
        .unwrap_or_else(|| Duration::from_secs(DEFAULT_STALL_WARN_SECS));
    let clock = SystemClock::new();
    let mut first_event_seen = false;
    if let Err(err) = emit_agent_start_event(&mut sink, &mut envelope_builder, config) {
        let error = err.to_string();
        finish_sink(sink, BeadOutcome::Failed);
        return SessionResult::PreflightFailed { error };
    }
    let session = match B::spawn(config).await {
        Ok(session) => {
            emit_driver_event(
                sink.as_mut(),
                envelope_builder.as_mut(),
                DriverKind::ContainerSpawn,
                &format!(
                    "container spawn ok: {image} for {workspace}",
                    image = config.image_ref,
                    workspace = config.workspace.display(),
                ),
                serde_json::json!({
                    "image_ref": config.image_ref,
                    "workspace": config.workspace.to_string_lossy(),
                }),
            );
            session
        }
        Err(err) => {
            let error_str = protocol_error_diagnostic(&err, config);
            warn!(error = %error_str, "agent spawn failed before session became live");
            emit_spawn_failure_event(sink.as_mut(), envelope_builder.as_mut(), &err, &error_str);
            finish_sink(sink, BeadOutcome::Failed);
            return spawn_error_session_result(&err, error_str);
        }
    };
    info!(
        prompt_chars = config.initial_prompt.chars().count(),
        stall_warn_secs = stall_window.as_secs(),
        "agent spawned; sending initial prompt",
    );
    if let Err(err) = emit_agent_input_event(
        &mut sink,
        &mut envelope_builder,
        InputKind::InitialPrompt,
        &config.initial_prompt,
    ) {
        let error_str = err.to_string();
        emit_protocol_failure_event(
            sink.as_mut(),
            envelope_builder.as_mut(),
            first_event_seen,
            &err,
            &error_str,
        );
        finish_sink(sink, BeadOutcome::Failed);
        return protocol_error_session_result(first_event_seen, &err, error_str);
    }
    let mut session = match prompt_with_stall_warn(
        session,
        &config.initial_prompt,
        stall_window,
        &clock,
        &mut sink,
        &mut envelope_builder,
    )
    .await
    {
        Ok(s) => s,
        Err(err) => {
            let error_str = err.to_string();
            emit_protocol_failure_event(
                sink.as_mut(),
                envelope_builder.as_mut(),
                first_event_seen,
                &err,
                &error_str,
            );
            finish_sink(sink, BeadOutcome::Failed);
            return protocol_error_session_result(first_event_seen, &err, error_str);
        }
    };
    info!("prompt sent; awaiting agent events");
    loop {
        let next = next_event_with_stall_warn(
            &mut session,
            stall_window,
            &clock,
            &mut sink,
            &mut envelope_builder,
        )
        .await;
        let parsed = match next {
            Ok(Some(event)) => event,
            Ok(None) => {
                let err = ProtocolError::UnexpectedEof;
                let error_str = err.to_string();
                emit_protocol_failure_event(
                    sink.as_mut(),
                    envelope_builder.as_mut(),
                    first_event_seen,
                    &err,
                    &error_str,
                );
                finish_sink(sink, BeadOutcome::Failed);
                return protocol_error_session_result(first_event_seen, &err, error_str);
            }
            Err(err) => {
                let error_str = err.to_string();
                emit_protocol_failure_event(
                    sink.as_mut(),
                    envelope_builder.as_mut(),
                    first_event_seen,
                    &err,
                    &error_str,
                );
                finish_sink(sink, BeadOutcome::Failed);
                return protocol_error_session_result(first_event_seen, &err, error_str);
            }
        };
        // RS-12: the session yields the parser's payload only; the
        // workflow layer joins it with the per-spawn envelope to
        // produce the consumer-visible `AgentEvent`.
        let envelope = match envelope_builder.as_mut() {
            Some(b) => b.build(),
            None => envelope_builder.insert(phase_envelope_builder()).build(),
        };
        let event = AgentEvent::from_parsed(parsed, envelope);
        if event.envelope().source == Source::Agent {
            first_event_seen = true;
        }
        log_agent_event(&event, config);
        if let Some(buf) = text_capture.as_deref_mut() {
            capture_text(&event, buf);
        }
        if let Some(s) = sink.as_mut()
            && let Err(e) = s.emit(&event)
        {
            warn!(error = ?e, "log sink emit failed");
            let error_str = format!("log sink emit failed: {e}");
            emit_infra_failure_event(
                sink.as_mut(),
                envelope_builder.as_mut(),
                stream_infra_phase(first_event_seen),
                InfraCause::SinkFailure,
                &error_str,
                None,
                None,
            );
            finish_sink(sink, BeadOutcome::Failed);
            return infra_session_result(first_event_seen, error_str);
        }
        if let Some(o) = observer.as_deref_mut() {
            o.emit(&event);
        }
        if is_non_streaming(&event) {
            if let Some(o) = observer.as_deref_mut() {
                let pending = o.take_pending_driver_events();
                for entry in pending {
                    emit_driver_event(
                        sink.as_mut(),
                        envelope_builder.as_mut(),
                        entry.kind,
                        &entry.summary,
                        entry.payload,
                    );
                }
            }
            let mut commands: Vec<SessionCommand> = Vec::new();
            if let Some(s) = sink.as_mut() {
                commands.extend(EventSink::react(s));
            }
            if let Some(o) = observer.as_deref_mut() {
                commands.extend(o.react());
            }
            match classify_react_commands(commands) {
                ReactAction::Continue { steers } => {
                    for msg in steers {
                        if let Err(e) = emit_agent_input_event(
                            &mut sink,
                            &mut envelope_builder,
                            InputKind::Steer,
                            &msg,
                        ) {
                            warn!(error = ?e, "agent input event emit failed before steer");
                            let error_str = format!("agent input event emit failed: {e}");
                            emit_protocol_failure_event(
                                sink.as_mut(),
                                envelope_builder.as_mut(),
                                first_event_seen,
                                &e,
                                &error_str,
                            );
                            finish_sink(sink, BeadOutcome::Failed);
                            return protocol_error_session_result(first_event_seen, &e, error_str);
                        }
                        if let Err(e) = session.steer(&msg).await {
                            warn!(error = ?e, "session steer failed");
                            let error_str = format!("session steer failed: {e}");
                            emit_protocol_failure_event(
                                sink.as_mut(),
                                envelope_builder.as_mut(),
                                first_event_seen,
                                &e,
                                &error_str,
                            );
                            finish_sink(sink, BeadOutcome::Failed);
                            return protocol_error_session_result(first_event_seen, &e, error_str);
                        }
                    }
                }
                ReactAction::Abort { reason } => {
                    info!(
                        reason = %reason,
                        "observer requested session abort via react()",
                    );
                    if let Err(e) = session.abort().await {
                        warn!(
                            error = ?e,
                            "session abort failed during observer-driven cancel; \
                             kill_on_drop will reap the child",
                        );
                    }
                    finish_sink(sink, BeadOutcome::Failed);
                    return SessionResult::ObserverAbort { reason };
                }
            }
        }
        if matches!(event, AgentEvent::CompactionStart { .. }) {
            match B::compaction_repin(config) {
                Ok(Some(payload)) => {
                    if let Err(e) = emit_agent_input_event(
                        &mut sink,
                        &mut envelope_builder,
                        InputKind::Repin,
                        &payload,
                    ) {
                        warn!(error = ?e, "agent input event emit failed before re-pin");
                        let error_str = format!("agent input event emit failed: {e}");
                        emit_protocol_failure_event(
                            sink.as_mut(),
                            envelope_builder.as_mut(),
                            first_event_seen,
                            &e,
                            &error_str,
                        );
                        finish_sink(sink, BeadOutcome::Failed);
                        return protocol_error_session_result(first_event_seen, &e, error_str);
                    }
                    if let Err(e) = session.steer(&payload).await {
                        warn!(error = ?e, "backend compaction re-pin failed");
                        let error_str = e.to_string();
                        emit_protocol_failure_event(
                            sink.as_mut(),
                            envelope_builder.as_mut(),
                            first_event_seen,
                            &e,
                            &error_str,
                        );
                        finish_sink(sink, BeadOutcome::Failed);
                        return protocol_error_session_result(first_event_seen, &e, error_str);
                    }
                }
                Ok(None) => {}
                Err(e) => {
                    warn!(error = ?e, "backend compaction handler failed");
                    let error_str = e.to_string();
                    emit_protocol_failure_event(
                        sink.as_mut(),
                        envelope_builder.as_mut(),
                        first_event_seen,
                        &e,
                        &error_str,
                    );
                    finish_sink(sink, BeadOutcome::Failed);
                    return protocol_error_session_result(first_event_seen, &e, error_str);
                }
            }
        }
        if matches!(event, AgentEvent::TurnEnd { .. })
            && let Err(e) = session.finish_turn().await
        {
            error!(error = ?e, "session turn completion failed");
            let error_str = format!("session turn completion failed: {e}");
            emit_protocol_failure_event(
                sink.as_mut(),
                envelope_builder.as_mut(),
                first_event_seen,
                &e,
                &error_str,
            );
            finish_sink(sink, BeadOutcome::Failed);
            return protocol_error_session_result(first_event_seen, &e, error_str);
        }
        if let AgentEvent::SessionComplete {
            exit_code,
            cost_usd,
            ..
        } = event
        {
            let outcome = if exit_code == 0 {
                BeadOutcome::Done
            } else {
                BeadOutcome::Failed
            };
            if let Err(e) = B::after_session_complete(session, config).await {
                warn!(error = ?e, "backend shutdown hook failed");
            }
            finish_sink(sink, outcome);
            return SessionResult::Complete(SessionOutcome {
                exit_code,
                cost_usd,
            });
        }
    }
}

/// Collect normalized assistant text only, with logical message boundaries.
pub(crate) fn capture_text(event: &AgentEvent, output: &mut String) {
    if event.envelope().source != Source::Agent {
        return;
    }
    match event {
        AgentEvent::TextDelta { text, .. } => output.push_str(text),
        AgentEvent::TextEnd { .. } | AgentEvent::TurnEnd { .. } | AgentEvent::AgentEnd { .. }
            if !output.is_empty() && !output.ends_with('\n') =>
        {
            output.push('\n');
        }
        _ => {}
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum DriverSeverity {
    Warning,
}

impl DriverSeverity {
    const fn as_wire(self) -> &'static str {
        match self {
            DriverSeverity::Warning => "warning",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum StallPhase {
    PromptWrite,
    AwaitEvent,
}

impl StallPhase {
    const fn as_wire(self) -> &'static str {
        match self {
            StallPhase::PromptWrite => "prompt_write",
            StallPhase::AwaitEvent => "await_event",
        }
    }

    const fn summary(self) -> &'static str {
        match self {
            StallPhase::PromptWrite => {
                "still writing initial prompt to agent — agent stdin not draining yet"
            }
            StallPhase::AwaitEvent => "no agent event for stall window — still waiting",
        }
    }
}

/// Drive [`AgentSession::prompt`] to completion while surfacing one
/// coalesced stall watchdog event when the write remains pending past
/// `stall_window`. Closes the visibility gap between `B::spawn` returning
/// and the first agent event: for the claude backend that window is the
/// container starting up and claude opening stdin, and a slow consumer can
/// leave the pipe write blocked with no log output. `stall_window ==
/// Duration::ZERO` disables the watchdog (used by tests).
async fn prompt_with_stall_warn(
    session: AgentSession<Idle>,
    msg: &str,
    stall_window: Duration,
    clock: &dyn Clock,
    sink: &mut Option<Sink>,
    envelope_builder: &mut Option<EnvelopeBuilder>,
) -> Result<AgentSession<Active>, ProtocolError> {
    let fut = session.prompt(msg);
    if stall_window.is_zero() {
        return fut.await;
    }
    tokio::pin!(fut);
    let mut stall_event_emitted = false;
    loop {
        let sleep = clock.sleep(stall_window);
        tokio::select! {
            biased;
            result = &mut fut => return result,
            () = sleep => record_stall_watchdog_tick(
                sink,
                envelope_builder,
                StallPhase::PromptWrite,
                stall_window,
                &mut stall_event_emitted,
            ),
        }
    }
}

/// Poll [`AgentSession::next_event`] while surfacing one coalesced stall
/// watchdog event for a silence window. The warning does not abort the
/// run — claude can legitimately think for minutes — but it ends the
/// silent stare at the terminal so the operator can decide whether to
/// intervene.
///
/// `stall_window == Duration::ZERO` disables the watchdog explicitly. A
/// fresh `clock.sleep(stall_window)` is created on every loop iteration so
/// the trace-only diagnostic still tracks repeated watchdog ticks without
/// emitting repeated renderer rows.
async fn next_event_with_stall_warn(
    session: &mut AgentSession<Active>,
    stall_window: Duration,
    clock: &dyn Clock,
    sink: &mut Option<Sink>,
    envelope_builder: &mut Option<EnvelopeBuilder>,
) -> Result<Option<ParsedAgentEvent>, ProtocolError> {
    let next = session.next_event();
    if stall_window.is_zero() {
        return next.await;
    }
    tokio::pin!(next);
    let mut stall_event_emitted = false;
    loop {
        let sleep = clock.sleep(stall_window);
        tokio::select! {
            biased;
            result = &mut next => return result,
            () = sleep => record_stall_watchdog_tick(
                sink,
                envelope_builder,
                StallPhase::AwaitEvent,
                stall_window,
                &mut stall_event_emitted,
            ),
        }
    }
}

fn record_stall_watchdog_tick(
    sink: &mut Option<Sink>,
    envelope_builder: &mut Option<EnvelopeBuilder>,
    phase: StallPhase,
    stall_window: Duration,
    stall_event_emitted: &mut bool,
) {
    let stall_secs = stall_window.as_secs();
    if *stall_event_emitted {
        trace!(
            phase = phase.as_wire(),
            stall_secs, "stall watchdog tick coalesced into prior driver event",
        );
        return;
    }
    *stall_event_emitted = true;
    match phase {
        StallPhase::PromptWrite => warn!(
            stall_secs,
            "still writing initial prompt to agent — agent stdin not draining yet",
        ),
        StallPhase::AwaitEvent => warn!(
            stall_secs,
            "no agent event for stall window — still waiting",
        ),
    }
    emit_stall_watchdog_event(sink, envelope_builder, phase, stall_window);
}

fn emit_stall_watchdog_event(
    sink: &mut Option<Sink>,
    envelope_builder: &mut Option<EnvelopeBuilder>,
    phase: StallPhase,
    stall_window: Duration,
) {
    emit_driver_event(
        sink.as_mut(),
        envelope_builder.as_mut(),
        DriverKind::StallWatchdog,
        phase.summary(),
        serde_json::json!({
            "severity": DriverSeverity::Warning.as_wire(),
            "phase": phase.as_wire(),
            "stall_secs": stall_window.as_secs(),
        }),
    );
}

/// Fallback `EnvelopeBuilder` for phase-level spawns (todo/check/inbox)
/// that do not own a per-bead context yet. Stamps events with a session
/// id and leaves work-routing fields absent. The `ts_ms` closure samples
/// the wall clock so events stay monotonic.
fn phase_envelope_builder() -> EnvelopeBuilder {
    let clock = SystemClock::new();
    let started_ms = clock
        .wall_now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis());
    EnvelopeBuilder::new(
        SessionScope::phase(
            SessionId::generated(format!("phase-{}-{started_ms}", std::process::id())),
            None,
        ),
        Source::Agent,
        move || {
            clock
                .wall_now()
                .duration_since(std::time::UNIX_EPOCH)
                .map_or(0, |duration| {
                    i64::try_from(duration.as_millis()).unwrap_or(i64::MAX)
                })
        },
    )
}

fn finish_sink(sink: Option<Sink>, outcome: BeadOutcome) {
    if let Some(mut s) = sink
        && let Err(e) = s.finish(outcome)
    {
        warn!(error = ?e, "log sink finish failed");
    }
}

fn emit_agent_start_event(
    sink: &mut Option<Sink>,
    builder: &mut Option<EnvelopeBuilder>,
    config: &SpawnConfig,
) -> Result<(), ProtocolError> {
    let Some(sink) = sink.as_mut() else {
        return Ok(());
    };
    if builder.is_none() {
        *builder = Some(phase_envelope_builder());
    }
    let metadata = config.event_metadata.as_ref().ok_or_else(|| {
        ProtocolError::Io(std::io::Error::other(
            "agent event metadata is required when a log sink is attached",
        ))
    })?;
    let builder = builder.as_mut().ok_or_else(|| {
        ProtocolError::Io(std::io::Error::other(
            "agent event envelope builder was not initialized",
        ))
    })?;
    let envelope = builder.build_with_source(Source::Driver);
    let started_at_ms = envelope.ts_ms;
    let event = AgentEvent::AgentStart {
        envelope,
        schema_version: EVENT_SCHEMA_VERSION,
        title: metadata.title.clone(),
        profile: metadata.profile.clone(),
        spec_label: metadata.spec_label.clone(),
        started_at_ms,
        parent_tool_call_id: metadata.parent_tool_call_id.clone(),
    };
    sink.emit(&event)
        .map_err(|error| ProtocolError::Io(std::io::Error::other(error.to_string())))
}

fn emit_agent_input_event(
    sink: &mut Option<Sink>,
    builder: &mut Option<EnvelopeBuilder>,
    input_kind: InputKind,
    text: &str,
) -> Result<(), ProtocolError> {
    let Some(sink) = sink.as_mut() else {
        return Ok(());
    };
    if builder.is_none() {
        *builder = Some(phase_envelope_builder());
    }
    let Some(builder) = builder.as_mut() else {
        return Ok(());
    };
    let envelope = builder.build_with_source(Source::Driver);
    let event = AgentEvent::AgentInput {
        envelope,
        input_kind,
        text: text.to_string(),
        redactions: None,
    };
    sink.emit(&event)
        .map_err(|e| ProtocolError::Io(std::io::Error::other(e.to_string())))
}

/// Emit a single `driver_event` into `sink` carrying `source: driver`.
///
/// Pulled out so driver-authored events in `run_agent_classified` share one
/// code path and write through the same envelope-builder seq counter as the agent
/// events that surround them. Silent no-op when either the sink or the
/// envelope builder is absent — tests and the legacy `run_agent` wrapper
/// pass `None` and must not be required to wire driver events.
fn emit_driver_event(
    sink: Option<&mut Sink>,
    builder: Option<&mut EnvelopeBuilder>,
    kind: DriverKind,
    summary: &str,
    payload: serde_json::Value,
) {
    let (Some(sink), Some(builder)) = (sink, builder) else {
        return;
    };
    let envelope = builder.build_with_source(Source::Driver);
    let wire = kind.as_wire().to_string();
    let event = AgentEvent::from_driver_event(
        DriverEventPayload::new(kind, summary.to_string(), payload),
        envelope,
    );
    if let Err(e) = sink.emit(&event) {
        warn!(error = ?e, kind = %wire, "driver event emit failed");
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum InfraClass {
    Preflight,
    Interrupted,
}

impl InfraClass {
    const fn as_wire(self) -> &'static str {
        match self {
            InfraClass::Preflight => "infra-preflight",
            InfraClass::Interrupted => "infra-interrupted",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum InfraPhase {
    Preflight,
    PreStream,
    Interrupted,
}

impl InfraPhase {
    const fn as_wire(self) -> &'static str {
        match self {
            InfraPhase::Preflight => "preflight",
            InfraPhase::PreStream => "pre-stream",
            InfraPhase::Interrupted => "interrupted",
        }
    }

    const fn first_event_seen(self) -> bool {
        matches!(self, InfraPhase::Interrupted)
    }

    const fn infra_class(self) -> InfraClass {
        match self {
            InfraPhase::Interrupted => InfraClass::Interrupted,
            InfraPhase::Preflight | InfraPhase::PreStream => InfraClass::Preflight,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum InfraCause {
    UnexpectedEof,
    MalformedFraming,
    UnknownMessageType,
    HandshakeTimeout,
    ProcessExit,
    ContainerOom,
    Io,
    SinkFailure,
    BackendHandler,
}

impl InfraCause {
    const fn as_wire(self) -> &'static str {
        match self {
            InfraCause::UnexpectedEof => "unexpected_eof",
            InfraCause::MalformedFraming => "malformed_framing",
            InfraCause::UnknownMessageType => "unknown_message_type",
            InfraCause::HandshakeTimeout => "handshake_timeout",
            InfraCause::ProcessExit => "process_exit",
            InfraCause::ContainerOom => "container_oom",
            InfraCause::Io => "io",
            InfraCause::SinkFailure => "sink_failure",
            InfraCause::BackendHandler => "backend_handler",
        }
    }
}

const fn stream_infra_phase(first_event_seen: bool) -> InfraPhase {
    if first_event_seen {
        InfraPhase::Interrupted
    } else {
        InfraPhase::PreStream
    }
}

fn spawn_error_session_result(err: &ProtocolError, error: String) -> SessionResult {
    protocol_error_session_result(false, err, error)
}

fn protocol_error_session_result(
    first_event_seen: bool,
    err: &ProtocolError,
    error: String,
) -> SessionResult {
    if !first_event_seen && matches!(err, ProtocolError::ProcessExit(78)) {
        return SessionResult::StaticInfra {
            cause: crate::r#loop::VERIFICATION_CAPABILITY_UNAVAILABLE_CAUSE.to_string(),
            error,
        };
    }
    if !first_event_seen && matches!(err, ProtocolError::ProcessExit(127)) {
        return SessionResult::StaticInfra {
            cause: MISSING_AGENT_BINARY_CAUSE.to_string(),
            error,
        };
    }
    infra_session_result(first_event_seen, error)
}

const fn infra_session_result(first_event_seen: bool, error: String) -> SessionResult {
    if first_event_seen {
        SessionResult::MidSessionFailed { error }
    } else {
        SessionResult::PreflightFailed { error }
    }
}

fn emit_spawn_failure_event(
    sink: Option<&mut Sink>,
    builder: Option<&mut EnvelopeBuilder>,
    err: &ProtocolError,
    error: &str,
) {
    emit_infra_failure_event(
        sink,
        builder,
        InfraPhase::Preflight,
        protocol_infra_cause(err),
        error,
        Some(error),
        protocol_exit_status(err),
    );
}

fn emit_protocol_failure_event(
    sink: Option<&mut Sink>,
    builder: Option<&mut EnvelopeBuilder>,
    first_event_seen: bool,
    err: &ProtocolError,
    error: &str,
) {
    emit_infra_failure_event(
        sink,
        builder,
        stream_infra_phase(first_event_seen),
        protocol_infra_cause(err),
        error,
        None,
        protocol_exit_status(err),
    );
}

fn emit_infra_failure_event(
    sink: Option<&mut Sink>,
    builder: Option<&mut EnvelopeBuilder>,
    phase: InfraPhase,
    cause: InfraCause,
    error: &str,
    spawn_error: Option<&str>,
    exit_status: Option<i32>,
) {
    let summary = infra_failure_summary(phase, cause, error);
    let mut payload = serde_json::Map::new();
    payload.insert("phase".to_string(), serde_json::json!(phase.as_wire()));
    payload.insert(
        "first_event_seen".to_string(),
        serde_json::json!(phase.first_event_seen()),
    );
    payload.insert(
        "infra_class".to_string(),
        serde_json::json!(phase.infra_class().as_wire()),
    );
    payload.insert("cause".to_string(), serde_json::json!(cause.as_wire()));
    payload.insert("error".to_string(), serde_json::json!(error));
    if let Some(status) = exit_status {
        payload.insert("exit_status".to_string(), serde_json::json!(status));
    }
    if let Some(spawn_error) = spawn_error {
        payload.insert("spawn_error".to_string(), serde_json::json!(spawn_error));
    }
    emit_driver_event(
        sink,
        builder,
        DriverKind::InfraFailure,
        &summary,
        serde_json::Value::Object(payload),
    );
}

fn protocol_error_diagnostic(error: &ProtocolError, config: &SpawnConfig) -> String {
    const MAX_BYTES: usize = 4096;
    const TRUNCATED: &str = " [truncated]";
    let mut chain = std::iter::successors(Some(error as &dyn std::error::Error), |cause| {
        cause.source()
    })
    .map(ToString::to_string)
    .collect::<Vec<_>>()
    .join(": ");
    if let Some(line) = error.protocol_line() {
        chain.push_str("; protocol line: ");
        chain.push_str(line);
    }
    let mut detail = redact_agent_input(&chain, config)
        .text
        .chars()
        .flat_map(char::escape_debug)
        .collect::<String>();
    if detail.len() > MAX_BYTES {
        detail.truncate(detail.floor_char_boundary(MAX_BYTES - TRUNCATED.len()));
        detail.push_str(TRUNCATED);
    }
    detail
}

fn infra_failure_summary(phase: InfraPhase, cause: InfraCause, error: &str) -> String {
    let class = phase.infra_class().as_wire();
    match (phase, cause) {
        (InfraPhase::Preflight, _) => format!("{class} spawn failure: {error}"),
        (InfraPhase::PreStream, InfraCause::UnexpectedEof) => {
            format!("{class} pre-stream EOF: {error}")
        }
        (InfraPhase::Interrupted, InfraCause::UnexpectedEof) => {
            format!("{class} interrupted EOF after agent output: {error}")
        }
        (InfraPhase::PreStream, InfraCause::ProcessExit) => {
            format!("{class} pre-stream process exit: {error}")
        }
        (InfraPhase::Interrupted, InfraCause::ProcessExit) => {
            format!("{class} process exit after agent output: {error}")
        }
        (_, InfraCause::ContainerOom) => format!("{class} container OOM: {error}"),
        _ => format!("{class} {}: {error}", cause.as_wire()),
    }
}

fn protocol_infra_cause(err: &ProtocolError) -> InfraCause {
    match err {
        ProtocolError::InvalidJson { .. } | ProtocolError::LineTooLong { .. } => {
            InfraCause::MalformedFraming
        }
        ProtocolError::UnknownMessageType(_) => InfraCause::UnknownMessageType,
        ProtocolError::Io(_) if is_oom_error(&err.to_string()) => InfraCause::ContainerOom,
        ProtocolError::Io(_) => InfraCause::Io,
        ProtocolError::ProcessExit(code) if *code == 137 => InfraCause::ContainerOom,
        ProtocolError::ProcessExit(_) => InfraCause::ProcessExit,
        ProtocolError::UnexpectedEof => InfraCause::UnexpectedEof,
        ProtocolError::HandshakeTimeout { .. } => InfraCause::HandshakeTimeout,
        ProtocolError::Unsupported | ProtocolError::LockPoisoned => InfraCause::BackendHandler,
    }
}

const fn protocol_exit_status(err: &ProtocolError) -> Option<i32> {
    match err {
        ProtocolError::ProcessExit(code) => Some(*code),
        _ => None,
    }
}

fn is_oom_error(error: &str) -> bool {
    let lower = error.to_ascii_lowercase();
    error.contains("code 137")
        || lower.contains("killed")
        || lower.contains("oom")
        || lower.contains("out of memory")
}

/// Action the event loop should take after collecting `react()` commands
/// from every sink in the chain. `Steer` commands are batched in
/// registration order; the first `Abort` short-circuits the batch and
/// becomes terminal — per `specs/harness.md` §"`EventSink` and
/// `SessionCommand` · `react()` priority".
#[derive(Debug, Clone, PartialEq, Eq)]
enum ReactAction {
    Continue { steers: Vec<String> },
    Abort { reason: String },
}

/// Pure classifier for the [`SessionCommand`] batch returned from
/// `react()`. Pulled out of the event loop so the priority rule (Abort is
/// terminal; subsequent commands in the same batch are dropped) can be
/// tested without driving a real session.
fn classify_react_commands(commands: Vec<SessionCommand>) -> ReactAction {
    let mut steers = Vec::new();
    for cmd in commands {
        match cmd {
            SessionCommand::Steer(msg) => steers.push(msg),
            SessionCommand::Abort(reason) => return ReactAction::Abort { reason },
        }
    }
    ReactAction::Continue { steers }
}

/// Streaming events (`text_delta`, `thinking_delta`, `toolcall_delta`) do
/// not trigger `react()`; observer state does not change on text bytes
/// and polling them every fragment would be pure overhead. Spec contract
/// (`specs/harness.md` §"`EventSink` and `SessionCommand`").
const fn is_non_streaming(event: &AgentEvent) -> bool {
    !matches!(
        event,
        AgentEvent::TextDelta { .. }
            | AgentEvent::ThinkingDelta { .. }
            | AgentEvent::ToolcallDelta { .. }
    )
}

fn log_agent_event(event: &AgentEvent, config: &SpawnConfig) {
    let summary = redact_agent_input(&summarize_event(event), config).text;
    trace!(event = %summary, "agent event");
}

fn summarize_event(event: &AgentEvent) -> String {
    match event {
        AgentEvent::AgentStart { title, profile, .. } => {
            format!("agent_start ({title}, profile={profile})")
        }
        AgentEvent::TextDelta { text, .. } => {
            format!("message_delta ({} chars)", text.chars().count())
        }
        AgentEvent::AgentInput {
            input_kind, text, ..
        } => format!(
            "agent_input {input_kind:?} ({} chars)",
            text.chars().count()
        ),
        AgentEvent::ToolCall { id, tool, .. } => format!("tool_call {tool} (id={id})"),
        AgentEvent::ToolResult {
            id,
            output,
            is_error,
            ..
        } => format!(
            "tool_result (id={id}, is_error={is_error}, {} chars)",
            output.chars().count(),
        ),
        AgentEvent::TurnEnd { .. } => "turn_end".to_string(),
        AgentEvent::SessionComplete {
            exit_code,
            cost_usd,
            ..
        } => format!("session_complete (exit_code={exit_code}, cost_usd={cost_usd:?})"),
        AgentEvent::CompactionStart { reason, .. } => format!("compaction_start ({reason:?})"),
        AgentEvent::CompactionEnd { aborted, .. } => {
            format!("compaction_end (aborted={aborted})")
        }
        AgentEvent::Error { message, .. } => format!("error: {message}"),
        AgentEvent::AgentEnd { .. } => "agent_end".to_string(),
        AgentEvent::TurnStart { .. } => "turn_start".to_string(),
        AgentEvent::TextEnd { .. } => "text_end".to_string(),
        AgentEvent::ThinkingDelta { text, .. } => {
            format!("thinking_delta ({} chars)", text.chars().count())
        }
        AgentEvent::ThinkingEnd { .. } => "thinking_end".to_string(),
        AgentEvent::ToolcallDelta { id, delta, .. } => {
            format!("toolcall_delta (id={id}, {} chars)", delta.chars().count())
        }
        AgentEvent::ToolProgress { id, text, .. } => {
            format!("tool_progress (id={id}, {} chars)", text.chars().count())
        }
        AgentEvent::AutoRetry {
            attempt,
            max_attempts,
            ..
        } => format!("auto_retry (attempt={attempt}/{max_attempts})"),
        AgentEvent::DriverEvent {
            driver_kind,
            summary,
            ..
        } => format!(
            "driver_event {kind}: {summary}",
            kind = driver_kind.as_wire()
        ),
    }
}

#[cfg(test)]
mod tests {
    mod review_output;

    use super::*;
    use loom_driver::agent::{JsonlReader, LineParse, ParsedLine, RePinContent};
    use loom_driver::logging::LogSink;
    use loom_events::identifier::{BeadId, SessionId, SpecLabel};
    use std::path::{Path, PathBuf};
    use std::process::Stdio;
    use std::time::SystemTime;
    use tokio::io::BufWriter;

    #[derive(Clone)]
    struct SharedBufferWriter {
        inner: std::sync::Arc<std::sync::Mutex<Vec<u8>>>,
    }

    #[derive(Debug, Default)]
    struct InputOrderState {
        seen: std::sync::Mutex<Vec<InputKind>>,
    }

    impl InputOrderState {
        fn record_render_chunk(&self, chunk: &str) {
            let mut seen = self.seen.lock().expect("input-order mutex");
            for (label, kind) in [
                ("initial_prompt", InputKind::InitialPrompt),
                ("follow_up", InputKind::FollowUp),
                ("steer", InputKind::Steer),
                ("repin", InputKind::Repin),
            ] {
                if chunk.contains(&format!("agent_input {label}")) && !seen.contains(&kind) {
                    seen.push(kind);
                }
            }
        }

        fn has_seen(&self, kind: InputKind) -> bool {
            self.seen.lock().expect("input-order mutex").contains(&kind)
        }
    }

    #[derive(Clone)]
    struct InputRecordingWriter {
        inner: std::sync::Arc<std::sync::Mutex<Vec<u8>>>,
        state: std::sync::Arc<InputOrderState>,
    }

    impl std::io::Write for InputRecordingWriter {
        fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
            self.state
                .record_render_chunk(&String::from_utf8_lossy(buf));
            self.inner
                .lock()
                .map_err(|_| std::io::Error::other("poisoned"))?
                .extend_from_slice(buf);
            Ok(buf.len())
        }

        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    impl std::io::Write for SharedBufferWriter {
        fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
            self.inner
                .lock()
                .map_err(|_| std::io::Error::other("poisoned"))?
                .extend_from_slice(buf);
            Ok(buf.len())
        }

        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    struct ControlledPi;
    struct ControlledClaude;
    struct ControlledDirect;

    impl AgentBackend for ControlledPi {
        async fn spawn(config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
            external_output_session(
                config,
                Box::new(loom_agent::pi::parser::PiParser::new()),
                false,
            )
        }
    }

    impl AgentBackend for ControlledClaude {
        async fn spawn(config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
            external_output_session(
                config,
                Box::new(loom_agent::claude::parser::ClaudeParser::new(Vec::new())),
                false,
            )
        }
    }

    impl AgentBackend for ControlledDirect {
        async fn spawn(config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
            external_output_session(
                config,
                Box::new(loom_agent::direct::backend::DirectParser),
                true,
            )
        }
    }

    fn external_output_session(
        config: &SpawnConfig,
        parser: Box<dyn LineParse + Send>,
        completion_handshake: bool,
    ) -> Result<AgentSession<Idle>, ProtocolError> {
        let (last, before) = config
            .agent_args
            .split_last()
            .ok_or(ProtocolError::UnexpectedEof)?;
        let mut script = String::from("set -euo pipefail\nIFS= read -r _\nprintf '%s\\n'");
        for line in before {
            append_shell_argument(&mut script, line);
        }
        if completion_handshake {
            script.push_str("\nIFS= read -r complete\n[[ \"$complete\" == *'\"type\":\"complete\"'* ]]\nprintf '%s\\n'");
        }
        append_shell_argument(&mut script, last);
        spawn_script_with_parser(&script, parser)
    }

    fn append_shell_argument(script: &mut String, line: &str) {
        script.push_str(" '");
        script.push_str(&line.replace('\'', "'\\''"));
        script.push('\'');
    }

    async fn drive_external<B: AgentBackend>(
        wire: Vec<serde_json::Value>,
    ) -> (SessionResult, String) {
        let dir = tempfile::tempdir().unwrap();
        let mut config = sample_spawn_config(dir.path());
        config.initial_prompt =
            "LOOM_COMPLETE\nLOOM_APPLY: {\"proposals\":[\"lm-prompt.1\"]}".into();
        config.agent_args = wire.into_iter().map(|value| value.to_string()).collect();
        let mut output = String::new();
        let result = run_agent_classified::<B>(&config, None, None, Some(&mut output), None).await;
        assert!(
            matches!(&result, SessionResult::Complete(outcome) if outcome.exit_code == 0),
            "{result:?}"
        );
        (result, output)
    }

    async fn capture_external<B: AgentBackend>(wire: Vec<serde_json::Value>) -> String {
        drive_external::<B>(wire).await.1
    }

    fn pi_output(record: &str, terminal: &str) -> Vec<serde_json::Value> {
        use serde_json::json;

        vec![
            json!({"type":"message_start","message":{"role":"user"}}),
            json!({"type":"message_end","message":{"role":"user","content":"LOOM_COMPLETE"}}),
            json!({"type":"message_start","message":{"role":"assistant"}}),
            json!({"type":"message_update","assistantMessageEvent":{"type":"text_delta","delta":&record[..12]}}),
            json!({"type":"message_update","assistantMessageEvent":{"type":"text_delta","delta":&record[12..]}}),
            json!({"type":"message_update","assistantMessageEvent":{"type":"text_end"}}),
            json!({"type":"message_end","message":{"role":"assistant","content":record}}),
            json!({"type":"tool_execution_start","toolCallId":"tc-1","toolName":"Bash","args":{"command":"echo LOOM_NOOP"}}),
            json!({"type":"tool_execution_end","toolCallId":"tc-1","toolName":"Bash","result":"LOOM_COMPLETE","isError":false}),
            json!({"type":"turn_end","message":{"role":"assistant","content":record},"toolResults":[]}),
            json!({"type":"message_start","message":{"role":"assistant"}}),
            json!({"type":"message_end","message":{"role":"assistant","content":terminal}}),
            json!({"type":"turn_end","message":{"role":"assistant","content":terminal},"toolResults":[]}),
            json!({"type":"agent_end","messages":[]}),
        ]
    }

    fn claude_output(record: &str, terminal: &str) -> Vec<serde_json::Value> {
        use serde_json::json;

        vec![
            json!({"type":"system","subtype":"init","session_id":"LOOM_COMPLETE"}),
            json!({"type":"user","message":{"role":"user","content":[{"type":"text","text":"LOOM_COMPLETE"}]}}),
            json!({"type":"assistant","message":{"role":"assistant","content":[{"type":"text","text":&record[..12]},{"type":"text","text":&record[12..]}]}}),
            json!({"type":"assistant","message":{"role":"assistant","content":[{"type":"tool_use","id":"tc-1","name":"Bash","input":{"command":"echo LOOM_NOOP"}}]}}),
            json!({"type":"user","message":{"role":"user","content":[{"type":"tool_result","tool_use_id":"tc-1","content":"LOOM_COMPLETE","is_error":false}]}}),
            json!({"type":"assistant","message":{"role":"assistant","content":[{"type":"text","text":terminal}]}}),
            json!({"type":"result","subtype":"success","result":terminal}),
        ]
    }

    fn direct_output(record: &str, terminal: &str) -> Vec<serde_json::Value> {
        use serde_json::json;

        vec![
            json!({"type":"text_delta","text":&record[..12]}),
            json!({"type":"text_delta","text":&record[12..]}),
            json!({"type":"text_end"}),
            json!({"type":"tool_call","id":"tc-1","tool":"Bash","params":{"command":"echo LOOM_NOOP"}}),
            json!({"type":"tool_result","id":"tc-1","output":"LOOM_COMPLETE","is_error":false}),
            json!({"type":"driver_event","driver_kind":"offload","summary":"LOOM_COMPLETE","payload":{}}),
            json!({"type":"text_delta","text":terminal}),
            json!({"type":"text_end"}),
            json!({"type":"turn_end"}),
            json!({"type":"session_complete","exit_code":0}),
        ]
    }

    #[tokio::test]
    async fn live_capture_preserves_records_without_counting_final_text_twice() {
        let record = "LOOM_CLARIFY: {\n\"decisions\": [\"lm-decision.1\"]\n}";
        let terminal = "LOOM_RETRY: {\n\"reason\": \"controlled output\"\n}";
        let captures = [
            capture_external::<ControlledPi>(pi_output(record, terminal)).await,
            capture_external::<ControlledClaude>(claude_output(record, terminal)).await,
            capture_external::<ControlledDirect>(direct_output(record, terminal)).await,
        ];
        for output in captures {
            assert_eq!(output, format!("{record}\n{terminal}\n"));
            let session =
                loom_protocol::output::decode(&output, loom_protocol::output::Phase::Loop).unwrap();
            assert_eq!(session.context().messages().len(), 2);
            assert_eq!(session.context().decisions().len(), 1);
            assert!(matches!(
                session.terminal().message,
                loom_protocol::output::Message::Retry(_)
            ));
        }
    }

    #[tokio::test]
    async fn loop_admission_retains_external_records_and_protocol_failures() {
        loop_admission_cases().await;
    }

    async fn loop_admission_cases() {
        use crate::r#loop::{AgentOutcome, classify_session};
        use loom_protocol::output::Phase;

        let record = "LOOM_CLARIFY: {\n\"decisions\":[\"lm-decision.1\"]\n}";
        for (terminal, succeeds) in [
            ("LOOM_COMPLETE", true),
            ("LOOM_RETRY: {\"reason\":\"raw\nnewline\"}", false),
            ("LOOM_APPLY: {\"proposals\":[\"lm-proposal.1\"]}", false),
        ] {
            let runs = [
                drive_external::<ControlledPi>(pi_output(record, terminal)).await,
                drive_external::<ControlledClaude>(claude_output(record, terminal)).await,
                drive_external::<ControlledDirect>(direct_output(record, terminal)).await,
            ];
            for (result, text) in runs {
                let (result, marker) = admit_session_output(result, &text, Phase::Loop);
                let SessionResult::Decoded { output, .. } = &result else {
                    panic!("expected located phase admission: {result:?}");
                };
                let context = match output.as_ref() {
                    Ok(session) => {
                        assert!(succeeds);
                        session.context()
                    }
                    Err(failure) => {
                        assert!(!succeeds);
                        assert_ne!(failure.diagnostics(), []);
                        assert!(marker.is_none());
                        failure.context()
                    }
                };
                assert_eq!(context.raw(), text);
                assert_eq!(context.decisions().len(), 1);
                let classified = classify_session(result, marker.as_ref());
                if succeeds {
                    assert!(matches!(classified, AgentOutcome::Success));
                } else {
                    let AgentOutcome::Failure { error } = classified else {
                        panic!("rejected output must not authorize success: {classified:?}");
                    };
                    assert!(error.contains("lm-decision.1"));
                    assert!(error.contains("canonical admission"));
                }
            }
        }
    }

    async fn controlled_outputs(record: &str, terminal: &str) -> Vec<String> {
        vec![
            capture_external::<ControlledPi>(pi_output(record, terminal)).await,
            capture_external::<ControlledClaude>(claude_output(record, terminal)).await,
            capture_external::<ControlledDirect>(direct_output(record, terminal)).await,
        ]
    }

    fn tune_review_score(text: &str, validator: &dyn loom_protocol::gate::FindingValidator) -> f64 {
        use loom_tune::{case, checker, config, evidence, executor, plan};

        let target: loom_tune::target::Target = "skill:loom-context-before-edit".parse().unwrap();
        let id = case::Id::new("protocol-boundary").unwrap();
        let cases = case::LoadedCases::new(
            vec![case::Case {
                id: id.clone(),
                checker: "behavior.review.finding-recall".parse().unwrap(),
                targets: vec![target.clone()],
                role: checker::CaseRole::Regression,
                input: case::Input::ReviewFindingRecall {
                    patch: case::RepoPath {
                        relative: "fixture.patch".into(),
                        kind: case::PathKind::File,
                    },
                },
                expected: case::Expected::ReviewFindingRecall(case::ReviewExpected {
                    findings: vec![],
                    max_extra_findings: Some(0),
                }),
                source: case::Source {
                    path: "cases.md".into(),
                    line: 1,
                },
            }],
            vec![],
        );
        let registry = checker::Registry::builtin().unwrap();
        let evidence = evidence::Snapshot::empty(evidence::SplitMetadata {
            algorithm: "sha256-salt-v1".into(),
            salt_id: "fixture".into(),
            selection_fraction: config::SelectionFraction::new(0.34).unwrap(),
        });
        let plan = plan::build(plan::Request {
            targets: vec![target],
            level: checker::Level::Run,
            cases: &cases,
            evidence: &evidence,
            config: &config::TuneConfig::default(),
            registry: &registry,
            seed: 1,
        })
        .unwrap();
        assert_eq!(plan.selected_cases.len(), 1);
        let replay = executor::Replay::new(
            plan::PlannedCaseId::Declared(id),
            executor::Evidence::text(text),
            executor::Evidence::text(text),
        );
        let results = executor::run(&plan, &cases, &[replay], &registry, validator).unwrap();
        results[0].candidate.hard.get()
    }

    #[tokio::test]
    async fn production_phase_consumers_enforce_shared_agent_output_contract() {
        use crate::review::{
            PhaseVerdict, RecoveryCause, WorkspaceFindingValidator, phase_verdict_from_walk,
        };
        use loom_protocol::gate::{BadWalk, DispatchScope, WalkOutput};
        use loom_protocol::output::{Message, Phase};
        use loom_protocol::todo::{ParseTodoSuccessError, parse_todo_success};

        let decisions = "LOOM_CLARIFY: {\n\"decisions\":[\"lm-decision.1\"]\n}";
        let todo = "LOOM_TODO: {\n\"head\":\"0123456789abcdef0123456789abcdef01234567\",\n\"fingerprint\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\",\n\"work_epic\":\"lm-work\",\"title\":\"Work\",\"specs\":[{\"label\":\"alpha\",\"outcome\":\"no-work\",\"reason\":\"already implemented\"}]\n}";
        for (terminal, succeeds) in [
            (todo, true),
            ("LOOM_RETRY: {\"reason\":\"raw\nnewline\"}", false),
            ("LOOM_COMPLETE", false),
        ] {
            for text in controlled_outputs(decisions, terminal).await {
                assert_eq!(text, format!("{decisions}\n{terminal}\n"));
                match parse_todo_success(&text) {
                    Ok(success) => {
                        assert!(succeeds);
                        assert_eq!(success.work_epic.as_str(), "lm-work");
                    }
                    Err(ParseTodoSuccessError::Contract(failure)) => {
                        assert!(!succeeds);
                        assert_eq!(failure.context().raw(), text);
                        assert_eq!(failure.context().decisions().len(), 1);
                        assert_ne!(failure.diagnostics(), []);
                    }
                    result => panic!("unexpected Todo admission: {result:?}"),
                }
            }
        }
        loop_admission_cases().await;

        for (terminal, succeeds) in [
            ("LOOM_APPLY: {\n\"proposals\":[\"lm-proposal.1\"]\n}", true),
            ("LOOM_APPLY: {\"proposals\":[\"bad id\"]}", false),
            ("LOOM_RETRY: {\"reason\":\"wrong phase\"}", false),
        ] {
            for text in controlled_outputs("ordinary assistant commentary", terminal).await {
                let result = loom_protocol::inbox::parse(&text);
                assert_eq!(result.is_ok(), succeeds, "{result:?}");
                if let Err(loom_protocol::inbox::TerminalMarkerError::Contract(failure)) = result {
                    assert_eq!(failure.context().raw(), text);
                    assert_ne!(failure.diagnostics(), []);
                }
            }
        }
        for text in controlled_outputs("ordinary assistant commentary", "LOOM_COMPLETE").await {
            assert_eq!(
                crate::todo::parse_exit_signal(&text, Phase::Plan).unwrap(),
                Message::Complete
            );
        }

        let directory = tempfile::tempdir().unwrap();
        std::fs::create_dir(directory.path().join("tests")).unwrap();
        std::fs::write(
            directory.path().join("tests/check.rs"),
            "#[test] fn check() {}\n",
        )
        .unwrap();
        std::fs::create_dir(directory.path().join("specs")).unwrap();
        std::fs::write(
            directory.path().join("specs/alpha.md"),
            "## Success Criteria\n\n- check assertion [test](check)\n",
        )
        .unwrap();
        let validator = WorkspaceFindingValidator::new(directory.path());
        let finding = "LOOM_FINDING: {\"token\":\"mock-discipline\",\"target\":{\"kind\":\"TestPath\",\"path\":\"tests/check.rs\"},\"evidence\":\"first\\nsecond\",\"route\":\"blocking\",\"bonds\":[\"alpha\"]}";
        for terminal in [
            "LOOM_CONCERN: {\"summary\":\"raw\nnewline\"}",
            "LOOM_NOOP",
            "LOOM_COMPLETE\nLOOM_COMPLETE",
        ] {
            for text in controlled_outputs(finding, terminal).await {
                let walk = WalkOutput::from_stdout(&text, DispatchScope::Tree, &validator);
                assert_eq!(walk.findings().len(), 1, "{walk:?}");
                let PhaseVerdict::Recovery {
                    cause:
                        RecoveryCause::BadWalk(BadWalk::Protocol {
                            context,
                            diagnostics,
                            parsed_findings,
                            ..
                        }),
                } = phase_verdict_from_walk(&walk)
                else {
                    panic!("rejected Review output must not certify clean scope: {walk:?}");
                };
                assert_eq!(context.raw(), text);
                assert_ne!(diagnostics, [] as [loom_protocol::output::Diagnostic; 0]);
                assert_eq!(parsed_findings.len(), 1);
                assert_eq!(
                    tune_review_score(&text, &validator).to_bits(),
                    0.0_f64.to_bits()
                );
            }
        }
        for text in controlled_outputs("ordinary assistant commentary", "LOOM_COMPLETE").await {
            let walk = WalkOutput::from_stdout(&text, DispatchScope::Tree, &validator);
            assert!(matches!(phase_verdict_from_walk(&walk), PhaseVerdict::Done));
            assert_eq!(
                tune_review_score(&text, &validator).to_bits(),
                1.0_f64.to_bits()
            );
        }
    }

    #[tokio::test]
    async fn live_capture_retains_decisions_on_malformed_or_wrong_phase_output() {
        let record = "LOOM_CLARIFY: {\"decisions\": [\"lm-decision.1\"]}";
        for terminal in [
            "LOOM_RETRY",
            "LOOM_RETRY: {\"reason\":\"raw\nnewline\"}",
            "LOOM_APPLY: {\"proposals\":[\"lm-proposal.1\"]}",
        ] {
            let captures = [
                capture_external::<ControlledPi>(pi_output(record, terminal)).await,
                capture_external::<ControlledClaude>(claude_output(record, terminal)).await,
                capture_external::<ControlledDirect>(direct_output(record, terminal)).await,
            ];
            for output in captures {
                let failure =
                    loom_protocol::output::decode(&output, loom_protocol::output::Phase::Loop)
                        .unwrap_err();
                assert_eq!(failure.context().raw(), output);
                assert_eq!(failure.context().decisions().len(), 1);
                assert_eq!(failure.diagnostics()[0].span.line, 2);
            }
        }
    }

    #[test]
    fn capture_rejects_driver_sourced_text_deltas() {
        let mut envelope = builder();
        let event = AgentEvent::TextDelta {
            envelope: envelope.build_with_source(Source::Driver),
            text: "LOOM_COMPLETE".into(),
        };
        let mut output = String::new();
        capture_text(&event, &mut output);
        assert_eq!(output, "");
    }

    #[test]
    fn phase_envelope_builder_omits_work_routing_fields() {
        let mut builder = phase_envelope_builder();
        let envelope = builder.build();
        assert!(envelope.session_id.as_str().starts_with("phase-"));
        assert!(envelope.bead_id.is_none());
        assert!(envelope.iteration.is_none());
    }

    #[tokio::test]
    async fn non_bead_event_logs_use_session_id_routing_key() {
        struct CompleteBackend;
        impl AgentBackend for CompleteBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script("IFS= read -r _; printf '%s\n' complete")
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let sink = LogSink::open_phase_at(dir.path(), "todo", None, SystemTime::UNIX_EPOCH)
            .expect("open phase sink");
        let path = sink.log_path().to_path_buf();
        let cfg = sample_spawn_config(dir.path());

        let outcome = run_agent::<CompleteBackend>(&cfg, Some(sink), None)
            .await
            .expect("phase run completes");
        assert_eq!(outcome.exit_code, 0);

        let events = read_jsonl(&path);
        assert!(!events.is_empty(), "phase log must contain events");
        assert_eq!(events[0]["kind"], "agent_start", "{events:?}");
        assert_eq!(events[0]["seq"], 0, "{events:?}");
        assert_eq!(events[0]["source"], "driver", "{events:?}");
        assert_eq!(events[0]["schema_version"], EVENT_SCHEMA_VERSION);
        assert_eq!(events[0]["title"], "test agent session");
        assert_eq!(events[1]["driver_kind"], "container_spawn", "{events:?}");
        assert_eq!(events[2]["kind"], "agent_input", "{events:?}");
        let session_id = events[0]["session_id"]
            .as_str()
            .expect("session_id string")
            .to_string();
        assert!(
            session_id.starts_with("phase-"),
            "fallback phase session id is the routing key: {session_id}",
        );
        for event in events {
            assert_eq!(event["session_id"].as_str(), Some(session_id.as_str()));
            assert!(
                event.get("bead_id").is_none_or(serde_json::Value::is_null),
                "phase events must not synthesize bead_id: {event:?}",
            );
            assert!(
                event
                    .get("iteration")
                    .is_none_or(serde_json::Value::is_null),
                "phase events must not synthesize iteration: {event:?}",
            );
        }
    }

    #[test]
    fn is_oom_error_matches_exit_137_and_killed_phrasings() {
        assert!(is_oom_error("agent process exited with code 137"));
        assert!(is_oom_error("io failure on agent stdio: process Killed"));
        assert!(is_oom_error("OOM killer claimed agent"));
        assert!(is_oom_error("out of memory"));
        assert!(!is_oom_error("agent process exited with code 1"));
        assert!(!is_oom_error("io timeout"));
        assert!(!is_oom_error("unexpected end of agent event stream"));
    }

    #[test]
    fn protocol_infra_cause_routes_oom_exit_and_eof() {
        assert_eq!(
            protocol_infra_cause(&ProtocolError::ProcessExit(137)),
            InfraCause::ContainerOom,
        );
        assert_eq!(
            protocol_infra_cause(&ProtocolError::UnexpectedEof),
            InfraCause::UnexpectedEof,
        );
        assert_eq!(
            protocol_infra_cause(&ProtocolError::ProcessExit(1)),
            InfraCause::ProcessExit,
        );
    }

    fn builder() -> EnvelopeBuilder {
        let bead = BeadId::new("lm-emit").expect("bead id");
        let mut clock = 0_i64;
        EnvelopeBuilder::new(
            SessionScope::bead(SessionId::new("sess-emit").unwrap(), bead, None, 0),
            Source::Agent,
            move || {
                clock += 1;
                clock
            },
        )
    }

    fn read_jsonl(path: &std::path::Path) -> Vec<serde_json::Value> {
        let body = std::fs::read_to_string(path).expect("read log");
        body.lines()
            .map(|l| serde_json::from_str(l).expect("json line"))
            .collect()
    }

    fn open_test_sink(dir: &std::path::Path) -> (LogSink, std::path::PathBuf) {
        let label = SpecLabel::new("emit-test").unwrap();
        let bead = BeadId::new("lm-emit").expect("bead id");
        let sink = LogSink::open_in_at(dir, &label, &bead, None, SystemTime::UNIX_EPOCH)
            .expect("open sink");
        let path = sink.log_path().to_path_buf();
        (sink, path)
    }

    fn open_test_sink_with_renderer(
        dir: &std::path::Path,
        renderer: Box<dyn loom_render::Renderer>,
    ) -> (LogSink, std::path::PathBuf) {
        let label = SpecLabel::new("emit-test").unwrap();
        let bead = BeadId::new("lm-emit").expect("bead id");
        let sink = LogSink::open_in_at(dir, &label, &bead, Some(renderer), SystemTime::UNIX_EPOCH)
            .expect("open sink");
        let path = sink.log_path().to_path_buf();
        (sink, path)
    }

    fn sample_spawn_config(scratch: &Path) -> SpawnConfig {
        SpawnConfig {
            image_ref: "localhost/img:tag".into(),
            image_source: PathBuf::from("/nix/store/none.tar"),
            image_source_kind: Some(loom_driver::agent::ImageSourceKind::NixDescriptor),
            wrix_launcher: None,
            profile_config: None,
            workspace: PathBuf::from("/workspace"),
            env: vec![],
            mounts: vec![],
            initial_prompt: "prompt".to_string(),
            agent_args: vec![],
            repin: RePinContent {
                orientation: String::new(),
                pinned_context: String::new(),
                partial_bodies: vec![],
            },
            skills: None,
            event_metadata: Some(loom_events::AgentStartMetadata {
                title: "test agent session".to_string(),
                profile: loom_events::identifier::ProfileName::new("test").unwrap(),
                spec_label: SpecLabel::new("agent").unwrap(),
                parent_tool_call_id: None,
            }),
            scratch_dir: scratch.join("scratch"),
            model_id: None,
            model: None,
            thinking_level: None,
            observers: loom_driver::config::AgentObserversConfig::default(),
            output_limits: None,
            shutdown_grace: None,
            denied_tools: Vec::new(),
            handshake_timeout: None,
            stall_warn_interval: Some(Duration::ZERO),
            launcher_env: Vec::new(),
        }
    }

    const ORDERING_REPIN_PAYLOAD: &str = "repin payload";

    struct TestParser;

    struct OrderingParser {
        state: std::sync::Arc<InputOrderState>,
    }

    impl OrderingParser {
        fn require_seen(&self, kind: InputKind, op: &str) -> Result<(), ProtocolError> {
            if self.state.has_seen(kind) {
                Ok(())
            } else {
                Err(ProtocolError::Io(std::io::Error::other(format!(
                    "agent_input {kind:?} was not emitted before {op}",
                ))))
            }
        }
    }

    impl LineParse for OrderingParser {
        fn parse_line(&self, line: &str) -> Result<ParsedLine, ProtocolError> {
            TestParser.parse_line(line)
        }

        fn encode_prompt(&self, _msg: &str) -> Result<String, ProtocolError> {
            self.require_seen(InputKind::InitialPrompt, "prompt encode")?;
            Ok("prompt\n".to_string())
        }

        fn encode_steer(&self, msg: &str) -> Result<String, ProtocolError> {
            let kind = if msg == ORDERING_REPIN_PAYLOAD {
                InputKind::Repin
            } else {
                InputKind::Steer
            };
            self.require_seen(kind, "steer encode")?;
            TestParser.encode_steer(msg)
        }

        fn encode_follow_up(&self, msg: &str) -> Result<String, ProtocolError> {
            self.require_seen(InputKind::FollowUp, "follow-up encode")?;
            TestParser.encode_follow_up(msg)
        }

        fn encode_abort(&self) -> Result<Option<String>, ProtocolError> {
            Ok(None)
        }
    }

    impl LineParse for TestParser {
        fn parse_line(&self, line: &str) -> Result<ParsedLine, ProtocolError> {
            match line {
                "text" => Ok(ParsedLine {
                    events: vec![ParsedAgentEvent::TextDelta {
                        text: "agent output".to_string(),
                    }],
                    response: None,
                }),
                "complete" => Ok(ParsedLine {
                    events: vec![ParsedAgentEvent::SessionComplete {
                        exit_code: 0,
                        cost_usd: None,
                    }],
                    response: None,
                }),
                "compaction" => Ok(ParsedLine {
                    events: vec![ParsedAgentEvent::CompactionStart {
                        reason: loom_events::event::CompactionReason::ContextLimit,
                    }],
                    response: None,
                }),
                "call1" => Ok(tool_call_line("tc-1")),
                "call2" => Ok(tool_call_line("tc-2")),
                "call3" => Ok(tool_call_line("tc-3")),
                "result1" => Ok(tool_result_line("tc-1")),
                "result2" => Ok(tool_result_line("tc-2")),
                "result3" => Ok(tool_result_line("tc-3")),
                "exit7" => Err(ProtocolError::ProcessExit(7)),
                "exit127" => Err(ProtocolError::ProcessExit(127)),
                other => Err(ProtocolError::invalid_protocol_line(
                    other,
                    serde_json::from_str::<serde_json::Value>(other).expect_err("invalid JSON"),
                )),
            }
        }

        fn encode_prompt(&self, _msg: &str) -> Result<String, ProtocolError> {
            Ok("prompt\n".to_string())
        }

        fn encode_steer(&self, msg: &str) -> Result<String, ProtocolError> {
            Ok(format!("{msg}\n"))
        }

        fn encode_abort(&self) -> Result<Option<String>, ProtocolError> {
            Ok(None)
        }
    }

    fn tool_call_line(id: &str) -> ParsedLine {
        ParsedLine {
            events: vec![ParsedAgentEvent::ToolCall {
                id: loom_events::identifier::ToolCallId::new(id).unwrap(),
                tool: "read_file".to_string(),
                params: serde_json::json!({"path": "/tmp/same"}),
                parent_tool_call_id: None,
            }],
            response: None,
        }
    }

    fn tool_result_line(id: &str) -> ParsedLine {
        ParsedLine {
            events: vec![ParsedAgentEvent::ToolResult {
                id: loom_events::identifier::ToolCallId::new(id).unwrap(),
                output: serde_json::json!({
                    "content": "x".repeat(512),
                })
                .to_string(),
                is_error: false,
            }],
            response: None,
        }
    }

    fn spawn_script(script: &str) -> Result<AgentSession<Idle>, ProtocolError> {
        spawn_script_with_parser(script, Box::new(TestParser))
    }

    fn spawn_script_with_parser(
        script: &str,
        parser: Box<dyn LineParse + Send>,
    ) -> Result<AgentSession<Idle>, ProtocolError> {
        let mut child = loom_driver::process::OwnedChild::spawn(
            tokio::process::Command::new("sh")
                .arg("-c")
                .arg(script)
                .stdin(Stdio::piped())
                .stdout(Stdio::piped())
                .stderr(Stdio::null()),
        )?;
        let stdin = child
            .stdin
            .take()
            .ok_or_else(|| ProtocolError::Io(std::io::Error::other("child stdin not piped")))?;
        let stdout = child
            .stdout
            .take()
            .ok_or_else(|| ProtocolError::Io(std::io::Error::other("child stdout not piped")))?;
        Ok(AgentSession::new(
            child,
            BufWriter::new(stdin),
            JsonlReader::new(stdout),
            parser,
        ))
    }

    fn infra_event(events: &[serde_json::Value]) -> &serde_json::Value {
        events
            .iter()
            .find(|event| event["driver_kind"] == "infra_failure")
            .expect("infra failure event")
    }

    #[test]
    fn emit_driver_event_writes_one_jsonl_line_with_source_driver() {
        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let mut sink = Sink::new(sink, &sample_spawn_config(dir.path()));
        let mut b = builder();
        emit_driver_event(
            Some(&mut sink),
            Some(&mut b),
            DriverKind::ContainerSpawn,
            "container spawn ok: img:tag",
            serde_json::json!({"image_ref": "img:tag"}),
        );
        sink.finish(BeadOutcome::Done).expect("finish");
        let events = read_jsonl(&path);
        assert_eq!(events.len(), 1, "exactly one driver event emitted");
        assert_eq!(events[0]["kind"], "driver_event");
        assert_eq!(events[0]["driver_kind"], "container_spawn");
        assert_eq!(events[0]["source"], "driver");
        assert_eq!(events[0]["payload"]["image_ref"], "img:tag");
    }

    #[tokio::test]
    async fn run_agent_lifts_observer_payloads_into_driver_events() {
        struct ObserverBackend;
        impl AgentBackend for ObserverBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script(
                    "IFS= read -r _; printf 'call1\\nresult1\\ncall2\\nresult2\\ncall3\\nresult3\\n'; IFS= read -r _; printf 'complete\\n'",
                )
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let scratch = dir.path().join("scratch-root");
        let cfg = sample_spawn_config(&scratch);
        let mut observer = DefaultObserverChain::from_config(
            &loom_driver::config::AgentObserversConfig::default(),
        )
        .expect("default observer chain is enabled");
        let result = run_agent_classified::<ObserverBackend>(
            &cfg,
            Some(sink),
            Some(&mut observer),
            None,
            Some(builder()),
        )
        .await;
        assert!(
            matches!(result, SessionResult::Complete { .. }),
            "expected complete session, got {result:?}",
        );

        let events = read_jsonl(&path);
        assert!(
            events.iter().any(|event| {
                event["kind"] == "driver_event" && event["driver_kind"] == "doom_loop_tripped"
            }),
            "doom-loop observer payload must be lifted into a DriverEvent: {events:?}",
        );
        assert!(
            events.iter().any(|event| {
                event["kind"] == "driver_event" && event["driver_kind"] == "duplicate_tool_result"
            }),
            "duplicate-result observer payload must be lifted into a DriverEvent: {events:?}",
        );
    }

    #[tokio::test]
    async fn observer_generated_direct_steer_finishes_before_controlled_completion() {
        struct ControlledDirectBackend;

        impl AgentBackend for ControlledDirectBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script_with_parser(
                    r#"set -euo pipefail
IFS= read -r prompt
case "$prompt" in
    *'"type":"prompt"'*) ;;
    *) exit 2 ;;
esac
printf '%s\n' '{"type":"tool_call","id":"tc-1","tool":"Read","params":{"path":"/tmp/same"}}'
printf '%s\n' '{"type":"tool_result","id":"tc-1","output":"same","is_error":false}'
printf '%s\n' '{"type":"turn_end"}'
IFS= read -r steer
case "$steer" in
    *'"type":"steer"'*) ;;
    *) exit 3 ;;
esac
printf '%s\n' '{"type":"turn_end"}'
IFS= read -r complete
case "$complete" in
    *'"type":"complete"'*) ;;
    *) exit 4 ;;
esac
printf '%s\n' '{"type":"session_complete","exit_code":0}'
"#,
                    Box::new(loom_agent::direct::backend::DirectParser),
                )
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let cfg = sample_spawn_config(dir.path());
        let observer_config = loom_driver::config::AgentObserversConfig {
            doom_loop: loom_driver::config::DoomLoopConfig {
                enabled: true,
                window: 1,
                threshold: 1,
                stage_2_after_stage_1: 3,
            },
            duplicate_result: loom_driver::config::DuplicateResultConfig {
                enabled: false,
                min_bytes: 256,
            },
        };
        let mut observer =
            DefaultObserverChain::from_config(&observer_config).expect("observer enabled");

        let result = run_agent_classified::<ControlledDirectBackend>(
            &cfg,
            Some(sink),
            Some(&mut observer),
            None,
            Some(builder()),
        )
        .await;
        assert!(
            matches!(result, SessionResult::Complete { .. }),
            "expected complete session, got {result:?}",
        );

        let events = read_jsonl(&path);
        assert_eq!(
            events
                .iter()
                .filter(|event| event["kind"] == "turn_end")
                .count(),
            2,
            "the observer steer must receive its own turn: {events:?}",
        );
        let steer = events
            .iter()
            .position(|event| event["kind"] == "agent_input" && event["input_kind"] == "steer")
            .expect("steer input event");
        let complete = events
            .iter()
            .position(|event| event["kind"] == "session_complete")
            .expect("session complete event");
        assert!(
            steer < complete,
            "steer must precede completion: {events:?}"
        );
    }

    #[test]
    fn emit_driver_event_is_silent_noop_when_sink_or_builder_missing() {
        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let mut sink = Sink::new(sink, &sample_spawn_config(dir.path()));
        let mut b = builder();
        emit_driver_event(
            None,
            Some(&mut b),
            DriverKind::ContainerSpawn,
            "no sink",
            serde_json::json!({}),
        );
        emit_driver_event(
            Some(&mut sink),
            None,
            DriverKind::ContainerSpawn,
            "no builder",
            serde_json::json!({}),
        );
        sink.finish(BeadOutcome::Done).expect("finish");
        assert!(
            read_jsonl(&path).is_empty(),
            "no events should land in the sink when either dep is missing",
        );
        // Builder seq must NOT advance when emission is suppressed.
        assert_eq!(
            b.current_seq(),
            0,
            "seq counter must not advance on suppressed emissions",
        );
    }

    #[tokio::test]
    async fn agent_input_events_precede_backend_send() {
        static ORDERING_STATE: std::sync::Mutex<Option<std::sync::Arc<InputOrderState>>> =
            std::sync::Mutex::new(None);

        fn ordering_state() -> std::sync::Arc<InputOrderState> {
            ORDERING_STATE
                .lock()
                .expect("ordering state mutex")
                .as_ref()
                .expect("ordering state set")
                .clone()
        }

        fn install_ordering_renderer(
            dir: &std::path::Path,
        ) -> (std::sync::Arc<InputOrderState>, LogSink, std::path::PathBuf) {
            let state = std::sync::Arc::new(InputOrderState::default());
            *ORDERING_STATE.lock().expect("ordering state mutex") = Some(state.clone());
            let render_buffer = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
            let renderer = Box::new(loom_driver::logging::TerminalRenderer::new(
                Box::new(InputRecordingWriter {
                    inner: render_buffer,
                    state: state.clone(),
                }),
                loom_driver::logging::RenderMode::Default,
                BeadId::new("lm-emit").expect("bead id"),
                false,
                false,
            ));
            let (sink, path) = open_test_sink_with_renderer(dir, renderer);
            (state, sink, path)
        }

        fn clear_ordering_state() {
            *ORDERING_STATE.lock().expect("ordering state mutex") = None;
        }

        fn assert_input_before(events: &[serde_json::Value], input_kind: &str, later_kind: &str) {
            let input_index = events
                .iter()
                .position(|event| {
                    event["kind"] == "agent_input" && event["input_kind"] == input_kind
                })
                .unwrap_or_else(|| panic!("missing agent_input {input_kind}: {events:?}"));
            let later_index = events
                .iter()
                .position(|event| event["kind"] == later_kind)
                .unwrap_or_else(|| panic!("missing {later_kind}: {events:?}"));
            assert!(
                input_index < later_index,
                "agent_input {input_kind} must precede {later_kind}: {events:?}",
            );
            assert_eq!(events[input_index]["source"], "driver");
        }

        struct InitialBackend;
        impl AgentBackend for InitialBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script_with_parser(
                    "IFS= read -r _; printf '%s\n' text complete",
                    Box::new(OrderingParser {
                        state: ordering_state(),
                    }),
                )
            }
        }

        struct ObserverSteerBackend;
        impl AgentBackend for ObserverSteerBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script_with_parser(
                    "IFS= read -r _; printf 'call1\nresult1\n'; IFS= read -r _; printf 'complete\n'",
                    Box::new(OrderingParser {
                        state: ordering_state(),
                    }),
                )
            }
        }

        struct RepinBackend;
        impl AgentBackend for RepinBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script_with_parser(
                    "IFS= read -r _; printf 'compaction\n'; IFS= read -r _; printf 'complete\n'",
                    Box::new(OrderingParser {
                        state: ordering_state(),
                    }),
                )
            }

            fn compaction_repin(_config: &SpawnConfig) -> Result<Option<String>, ProtocolError> {
                Ok(Some(ORDERING_REPIN_PAYLOAD.to_string()))
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let (_state, sink, path) = install_ordering_renderer(dir.path());
        let cfg = sample_spawn_config(dir.path());
        let result =
            run_agent_classified::<InitialBackend>(&cfg, Some(sink), None, None, Some(builder()))
                .await;
        clear_ordering_state();
        assert!(
            matches!(result, SessionResult::Complete { .. }),
            "expected complete session, got {result:?}",
        );
        let events = read_jsonl(&path);
        assert_input_before(&events, "initial_prompt", "text_delta");

        let dir = tempfile::tempdir().expect("tempdir");
        let (_state, sink, path) = install_ordering_renderer(dir.path());
        let cfg = sample_spawn_config(dir.path());
        let observer_config = loom_driver::config::AgentObserversConfig {
            doom_loop: loom_driver::config::DoomLoopConfig {
                enabled: true,
                window: 1,
                threshold: 1,
                stage_2_after_stage_1: 3,
            },
            duplicate_result: loom_driver::config::DuplicateResultConfig {
                enabled: false,
                min_bytes: 256,
            },
        };
        let mut observer =
            DefaultObserverChain::from_config(&observer_config).expect("observer enabled");
        let result = run_agent_classified::<ObserverSteerBackend>(
            &cfg,
            Some(sink),
            Some(&mut observer),
            None,
            Some(builder()),
        )
        .await;
        clear_ordering_state();
        assert!(
            matches!(result, SessionResult::Complete { .. }),
            "expected complete session, got {result:?}",
        );
        let events = read_jsonl(&path);
        assert_input_before(&events, "initial_prompt", "tool_call");
        assert_input_before(&events, "steer", "session_complete");

        let dir = tempfile::tempdir().expect("tempdir");
        let (_state, sink, path) = install_ordering_renderer(dir.path());
        let cfg = sample_spawn_config(dir.path());
        let result =
            run_agent_classified::<RepinBackend>(&cfg, Some(sink), None, None, Some(builder()))
                .await;
        clear_ordering_state();
        assert!(
            matches!(result, SessionResult::Complete { .. }),
            "expected complete session, got {result:?}",
        );
        let events = read_jsonl(&path);
        assert_input_before(&events, "initial_prompt", "compaction_start");
        assert_input_before(&events, "repin", "session_complete");
    }

    #[tokio::test]
    async fn agent_input_redaction_is_explicit() {
        struct CompleteBackend;
        impl AgentBackend for CompleteBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script("IFS= read -r _; printf '%s\n' complete")
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let render_buffer = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let renderer = Box::new(loom_driver::logging::TerminalRenderer::new(
            Box::new(SharedBufferWriter {
                inner: render_buffer.clone(),
            }),
            loom_driver::logging::RenderMode::Default,
            BeadId::new("lm-emit").expect("bead id"),
            false,
            false,
        ));
        let (sink, path) = open_test_sink_with_renderer(dir.path(), renderer);
        let mut cfg = sample_spawn_config(dir.path());
        cfg.initial_prompt = "send key sk-redact to backend".to_string();
        cfg.env
            .push(("ANTHROPIC_API_KEY".into(), "sk-redact".into()));

        let result =
            run_agent_classified::<CompleteBackend>(&cfg, Some(sink), None, None, Some(builder()))
                .await;
        assert!(
            matches!(result, SessionResult::Complete { .. }),
            "expected complete session, got {result:?}",
        );

        let events = read_jsonl(&path);
        let input = events
            .iter()
            .find(|event| event["kind"] == "agent_input")
            .expect("agent_input event");
        let marker = "[REDACTED:api_key:ANTHROPIC_API_KEY]";
        assert_eq!(input["text"], format!("send key {marker} to backend"));
        assert_eq!(input["redactions"][0]["marker"], marker);
        assert_eq!(input["redactions"][0]["class"], "api_key");
        assert!(
            !serde_json::to_string(input)
                .expect("json")
                .contains("sk-redact"),
            "persisted event must not contain the secret: {input:?}",
        );

        let render = String::from_utf8(render_buffer.lock().expect("not poisoned").clone())
            .expect("utf-8 render");
        assert!(
            render.contains(&format!("send key {marker} to backend")),
            "{render:?}",
        );
        assert!(render.contains("api_key"), "{render:?}");
        assert!(!render.contains("sk-redact"), "{render:?}");
    }

    #[tokio::test]
    async fn backend_events_are_redacted_before_log_and_render() {
        struct EchoBackend;
        impl AgentBackend for EchoBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script_with_parser(
                    r#"set -euo pipefail
IFS= read -r prompt
case "$prompt" in
    *fixture-key-value*) ;;
    *) exit 2 ;;
esac
printf '%s\n' \
    '{"type":"text_delta","text":"assistant fixture-key-"}' \
    '{"type":"text_delta","text":"value\nLOOM_COMPLETE\n"}' \
    '{"type":"text_end"}' \
    '{"type":"tool_call","id":"tc-1","tool":"Bash","params":{"command":"echo fixture-key-value","nested":[{"fixture-key-value":"fixture-launcher-value","count":3}]}}' \
    '{"type":"tool_result","id":"tc-1","output":"result fixture-key-value","is_error":false}' \
    '{"type":"driver_event","driver_kind":"offload","summary":"offload fixture-launcher-value","payload":{"detail":["fixture-key-value",true]}}' \
    '{"type":"error","message":"error fixture-launcher-value"}' \
    '{"type":"session_complete","exit_code":0,"cost_usd":0.25}'
"#,
                    Box::new(loom_agent::direct::backend::DirectParser),
                )
            }
        }

        for mode in [
            loom_render::RenderMode::Pretty,
            loom_render::RenderMode::Plain,
            loom_render::RenderMode::VerbosePlain,
            loom_render::RenderMode::Json,
            loom_render::RenderMode::Raw,
        ] {
            let dir = tempfile::tempdir().expect("tempdir");
            let render_buffer = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
            let renderer = loom_render::build_renderer(
                mode,
                Box::new(SharedBufferWriter {
                    inner: render_buffer.clone(),
                }),
                BeadId::new("lm-emit").unwrap(),
                false,
                true,
            );
            let (sink, path) = open_test_sink_with_renderer(dir.path(), renderer);
            let mut cfg = sample_spawn_config(dir.path());
            cfg.initial_prompt = "send fixture-key-value unchanged".into();
            cfg.env
                .push(("ANTHROPIC_API_KEY".into(), "fixture-key-value".into()));
            cfg.launcher_env
                .push(("HOST_TOKEN".into(), "fixture-launcher-value".into()));
            let mut captured = String::new();
            let result = run_agent_classified::<EchoBackend>(
                &cfg,
                Some(sink),
                None,
                Some(&mut captured),
                Some(builder()),
            )
            .await;
            assert!(matches!(result, SessionResult::Complete(_)), "{result:?}");
            assert_eq!(captured, "assistant fixture-key-value\nLOOM_COMPLETE\n");

            let persisted = std::fs::read_to_string(&path).unwrap();
            let transcript = String::from_utf8(render_buffer.lock().unwrap().clone()).unwrap();
            for surface in [&persisted, &transcript] {
                assert!(
                    !surface.contains("fixture-key-value"),
                    "{mode:?}: {surface}"
                );
                assert!(
                    !surface.contains("fixture-launcher-value"),
                    "{mode:?}: {surface}"
                );
                assert!(surface.contains("[REDACTED:api_key:ANTHROPIC_API_KEY]"));
                assert!(surface.contains("[REDACTED:token:HOST_TOKEN]"));
                assert!(surface.contains("LOOM_COMPLETE"), "{mode:?}: {surface:?}");
            }
            let events = read_jsonl(&path);
            assert_eq!(events.len(), 11);
            for (seq, event) in events.iter().enumerate() {
                assert_eq!(event["seq"], seq);
                assert_eq!(event["session_id"], "sess-emit");
            }
            let call = events
                .iter()
                .find(|event| event["kind"] == "tool_call")
                .unwrap();
            assert_eq!(call["params"]["nested"][0]["count"], 3);
            assert_eq!(call["id"], "tc-1");
            assert_eq!(events.last().unwrap()["cost_usd"], 0.25);
        }
    }

    fn sample_envelope() -> loom_events::EventEnvelope {
        loom_events::EventEnvelope {
            session_id: SessionId::new("sess-react").unwrap(),
            bead_id: Some(BeadId::new("lm-react").expect("bead id")),
            molecule_id: None,
            iteration: Some(1),
            source: Source::Agent,
            ts_ms: 0,
            seq: 0,
        }
    }

    fn tool_call_event() -> AgentEvent {
        AgentEvent::ToolCall {
            envelope: sample_envelope(),
            id: loom_events::identifier::ToolCallId::new("tc-1").unwrap(),
            tool: "bash".to_string(),
            params: serde_json::json!({}),
            parent_tool_call_id: None,
        }
    }

    fn text_delta_event() -> AgentEvent {
        AgentEvent::TextDelta {
            envelope: sample_envelope(),
            text: "hi".into(),
        }
    }

    #[test]
    fn classify_react_commands_collects_steers_in_registration_order() {
        let action = classify_react_commands(vec![
            SessionCommand::Steer("first".into()),
            SessionCommand::Steer("second".into()),
        ]);
        match action {
            ReactAction::Continue { steers } => {
                assert_eq!(steers, vec!["first".to_string(), "second".to_string()]);
            }
            other @ ReactAction::Abort { .. } => panic!("expected Continue, got {other:?}"),
        }
    }

    #[test]
    fn classify_react_commands_empty_batch_is_continue_no_steers() {
        match classify_react_commands(vec![]) {
            ReactAction::Continue { steers } => assert_eq!(steers, [] as [std::string::String; 0]),
            other @ ReactAction::Abort { .. } => panic!("expected Continue, got {other:?}"),
        }
    }

    /// Spec criterion: "Driver applies `react()` after every non-streaming
    /// event (not after `text_delta` / `thinking_delta` /
    /// `toolcall_delta`)" (`specs/harness.md` Success Criteria §
    /// "`EventSink` and `SessionCommand`"). The driver gates its
    /// `react()` poll on [`is_non_streaming`]; this verifies the delta
    /// trio is the only set excluded.
    #[test]
    fn react_invoked_after_non_streaming_events_only() {
        assert!(!is_non_streaming(&text_delta_event()));
        assert!(!is_non_streaming(&AgentEvent::ThinkingDelta {
            envelope: sample_envelope(),
            text: "x".into(),
        }));
        assert!(!is_non_streaming(&AgentEvent::ToolcallDelta {
            envelope: sample_envelope(),
            id: loom_events::identifier::ToolCallId::new("tc-1").unwrap(),
            delta: "x".into(),
        }));
        assert!(is_non_streaming(&tool_call_event()));
        assert!(is_non_streaming(&AgentEvent::ToolResult {
            envelope: sample_envelope(),
            id: loom_events::identifier::ToolCallId::new("tc-1").unwrap(),
            output: "ok".into(),
            is_error: false,
        }));
        assert!(is_non_streaming(&AgentEvent::DriverEvent {
            envelope: sample_envelope(),
            driver_kind: DriverKind::ContainerSpawn,
            summary: "spawned".into(),
            payload: serde_json::json!({}),
        }));
        assert!(is_non_streaming(&AgentEvent::TurnEnd {
            envelope: sample_envelope()
        }));
    }

    fn capture_agent_event_log(filter: &str, event: &AgentEvent) -> String {
        let buffer = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let writer = SharedBufferWriter {
            inner: buffer.clone(),
        };
        let subscriber = tracing_subscriber::fmt()
            .with_env_filter(tracing_subscriber::EnvFilter::new(filter))
            .with_writer(move || writer.clone())
            .without_time()
            .finish();
        let dispatch = tracing::Dispatch::new(subscriber);
        let scratch = tempfile::tempdir().unwrap();
        let config = sample_spawn_config(scratch.path());
        tracing::dispatcher::with_default(&dispatch, || log_agent_event(event, &config));
        let bytes = buffer.lock().expect("not poisoned").clone();
        String::from_utf8(bytes).expect("utf-8 log output")
    }

    #[test]
    fn agent_event_bookkeeping_uses_trace_level() {
        let event = text_delta_event();
        let debug_output = capture_agent_event_log("debug", &event);
        assert!(
            debug_output.is_empty(),
            "agent event bookkeeping must not be debug/info output: {debug_output:?}",
        );
        let trace_output = capture_agent_event_log("trace", &event);
        assert!(trace_output.contains("agent event"), "{trace_output:?}");
        assert!(trace_output.contains("message_delta"), "{trace_output:?}");
    }

    #[test]
    fn stall_watchdog_renders_coalesced_warning_row() {
        let dir = tempfile::tempdir().expect("tempdir");
        let label = SpecLabel::new("emit-test").unwrap();
        let bead = BeadId::new("lm-emit").expect("bead id");
        let render_buffer = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let renderer = Box::new(loom_driver::logging::TerminalRenderer::new(
            Box::new(SharedBufferWriter {
                inner: render_buffer.clone(),
            }),
            loom_driver::logging::RenderMode::Default,
            bead.clone(),
            false,
            false,
        ));
        let sink = LogSink::open_in_at(
            dir.path(),
            &label,
            &bead,
            Some(renderer),
            SystemTime::UNIX_EPOCH,
        )
        .expect("open sink");
        let path = sink.log_path().to_path_buf();
        let mut sink = Some(Sink::new(sink, &sample_spawn_config(dir.path())));
        let mut b = Some(builder());
        let mut emitted = false;
        record_stall_watchdog_tick(
            &mut sink,
            &mut b,
            StallPhase::AwaitEvent,
            Duration::from_secs(30),
            &mut emitted,
        );
        record_stall_watchdog_tick(
            &mut sink,
            &mut b,
            StallPhase::AwaitEvent,
            Duration::from_secs(30),
            &mut emitted,
        );
        finish_sink(sink, BeadOutcome::Failed);

        let events = read_jsonl(&path);
        assert_eq!(
            events.len(),
            1,
            "repeated stall ticks in one silence window coalesce into one row",
        );
        assert_eq!(events[0]["kind"], "driver_event");
        assert_eq!(events[0]["driver_kind"], "stall_watchdog");
        assert_eq!(events[0]["source"], "driver");
        assert_eq!(events[0]["payload"]["severity"], "warning");
        assert_eq!(events[0]["payload"]["phase"], "await_event");
        assert_eq!(events[0]["payload"]["stall_secs"], 30);

        let render = String::from_utf8(render_buffer.lock().expect("not poisoned").clone())
            .expect("utf-8 render");
        assert!(render.contains('⚠'), "{render:?}");
        assert!(render.contains("stall_watchdog"), "{render:?}");
        assert!(
            render.contains("no agent event for stall window"),
            "{render:?}",
        );
    }

    /// Spec criterion: "Driver treats any `SessionCommand::Abort`
    /// returned from `react()` as terminal: subsequent commands in the
    /// same batch are not applied, session is cancelled, recovery cause
    /// is `observer-abort`" (`specs/harness.md` Success Criteria §
    /// "`EventSink` and `SessionCommand`"). Drives a mock observer that
    /// returns `Abort` on the third `tool_call`; verifies (a) `Abort`
    /// short-circuits subsequent `Steer`s in the same batch, and (b)
    /// the cause classifier maps a session aborted by an observer to
    /// `RecoveryCause::ObserverAbort` (label `"observer-abort"`) rather
    /// than `swallowed-marker`.
    #[test]
    fn abort_command_short_circuits_remaining_commands_and_classifies_observer_abort() {
        struct CountingAbortObserver {
            tool_calls: u32,
            abort_at: u32,
            abort_reason: String,
        }
        impl EventSink for CountingAbortObserver {
            fn emit(&mut self, event: &AgentEvent) {
                if matches!(event, AgentEvent::ToolCall { .. }) {
                    self.tool_calls += 1;
                }
            }
            fn react(&mut self) -> Vec<SessionCommand> {
                if self.tool_calls >= self.abort_at {
                    vec![
                        SessionCommand::Abort(self.abort_reason.clone()),
                        // Subsequent commands in the same batch MUST be
                        // dropped per the spec's react() priority rule.
                        SessionCommand::Steer("post-abort-steer".into()),
                    ]
                } else {
                    Vec::new()
                }
            }
        }

        let mut observer = CountingAbortObserver {
            tool_calls: 0,
            abort_at: 3,
            abort_reason: "doom-loop: 3 identical tool calls".into(),
        };

        for _ in 0..2 {
            observer.emit(&tool_call_event());
            assert!(observer.react().is_empty(), "no abort before threshold");
        }
        observer.emit(&tool_call_event());
        let commands = observer.react();
        assert_eq!(
            commands.len(),
            2,
            "observer emits Abort + a trailing Steer in the same batch",
        );

        match classify_react_commands(commands) {
            ReactAction::Abort { reason } => {
                assert_eq!(
                    reason, "doom-loop: 3 identical tool calls",
                    "Abort's reason must round-trip verbatim",
                );
            }
            other @ ReactAction::Continue { .. } => panic!(
                "Abort must short-circuit the batch; got {other:?} — the trailing Steer leaked through",
            ),
        }

        // The recovery cause label is the spec's `observer-abort`
        // identifier, not `swallowed-marker`.
        assert_eq!(
            crate::review::RecoveryCause::ObserverAbort {
                reason: "doom-loop: 3 identical tool calls".into(),
            }
            .as_str(),
            "observer-abort",
        );
    }

    /// `B::spawn` returning `Err` is the preflight failure path. The
    /// driver must emit a `driver_event { kind: infra_failure }` into
    /// the sink after the required `agent_start` and before finishing it, so a
    /// replay can show the session metadata and failure cause.
    #[tokio::test]
    async fn preflight_failure_emits_infra_failure_driver_event() {
        struct FailingBackend;
        impl AgentBackend for FailingBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                Err(ProtocolError::Io(std::io::Error::other(
                    "podman load failed: image archive missing",
                )))
            }
        }
        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let b = builder();
        let cfg = sample_spawn_config(dir.path());
        let result =
            run_agent_classified::<FailingBackend>(&cfg, Some(sink), None, None, Some(b)).await;
        match result {
            crate::r#loop::SessionResult::PreflightFailed { error } => {
                assert!(
                    error.contains("io failure")
                        && error.contains("podman load failed: image archive missing"),
                    "preflight error must carry the source chain: {error}",
                );
            }
            other => panic!("expected PreflightFailed, got {other:?}"),
        }
        let events = read_jsonl(&path);
        assert_eq!(events.len(), 2, "{events:?}");
        assert_eq!(events[0]["kind"], "agent_start");
        let infra = infra_event(&events);
        assert_eq!(infra["source"], "driver");
        assert_eq!(infra["payload"]["phase"], "preflight");
        assert_eq!(infra["payload"]["first_event_seen"], false);
        assert_eq!(infra["payload"]["infra_class"], "infra-preflight");
        assert_eq!(infra["payload"]["cause"], "io");
        assert!(
            infra["payload"]["error"]
                .as_str()
                .is_some_and(|s| s.contains("podman load failed: image archive missing")),
            "payload error body must carry the source chain: {:?}",
            infra["payload"],
        );
        assert!(
            infra["payload"]["spawn_error"]
                .as_str()
                .is_some_and(|s| s.contains("podman load failed: image archive missing")),
            "spawn failures must carry the source chain in spawn_error: {:?}",
            infra["payload"],
        );
    }

    #[test]
    fn startup_error_diagnostic_is_bounded_after_redaction() {
        let dir = tempfile::tempdir().expect("tempdir");
        let mut cfg = sample_spawn_config(dir.path());
        let secret = "密".repeat(5000);
        cfg.launcher_env
            .push(("WRIX_SIGNING_KEY".into(), secret.clone()));
        let err = ProtocolError::Io(std::io::Error::other(format!(
            "{secret} {}",
            "界".repeat(5000),
        )));
        let detail = protocol_error_diagnostic(&err, &cfg);
        assert!(
            detail.contains("[REDACTED:secret:WRIX_SIGNING_KEY]"),
            "{detail}"
        );
        assert!(!detail.contains('密'), "{detail}");
        assert!(detail.len() <= 4096, "{}", detail.len());
        assert!(detail.ends_with(" [truncated]"), "{detail}");
    }

    #[test]
    fn rejected_line_is_redacted_before_preview_truncation() {
        let dir = tempfile::tempdir().expect("tempdir");
        let mut cfg = sample_spawn_config(dir.path());
        let secret = "private-fixture-value".repeat(500);
        cfg.launcher_env
            .push(("WRIX_SIGNING_KEY".into(), secret.clone()));
        let line = format!("WARN {secret} {}", "界".repeat(5000));
        let source = serde_json::from_str::<serde_json::Value>(&line).expect_err("not JSON");
        let error = ProtocolError::invalid_protocol_line(&line, source);
        let detail = protocol_error_diagnostic(&error, &cfg);
        assert!(
            detail.contains("protocol line: WARN [REDACTED:secret:WRIX_SIGNING_KEY]"),
            "{detail}"
        );
        assert!(!detail.contains("private-fixture-value"), "{detail}");
        assert!(detail.len() <= 4096, "{}", detail.len());
        assert!(detail.ends_with(" [truncated]"), "{detail}");
    }

    #[tokio::test]
    async fn startup_parse_error_retains_redacted_cause_in_durable_log() {
        struct MalformedBackend;
        impl AgentBackend for MalformedBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                let source = serde_json::from_str::<bool>(r#""sk-startup-secret""#)
                    .expect_err("string is not a boolean");
                Err(source.into())
            }
        }
        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let mut cfg = sample_spawn_config(dir.path());
        cfg.env
            .push(("OPENAI_API_KEY".into(), "sk-startup-secret".into()));
        let result =
            run_agent_classified::<MalformedBackend>(&cfg, Some(sink), None, None, Some(builder()))
                .await;
        let SessionResult::PreflightFailed { error } = result else {
            panic!("expected preflight failure");
        };
        assert!(error.contains("invalid JSON on protocol line"), "{error}");
        assert!(error.contains("expected a boolean"), "{error}");
        assert!(error.contains("line 1 column"), "{error}");
        assert!(
            error.contains("[REDACTED:api_key:OPENAI_API_KEY]"),
            "{error}"
        );
        let events = read_jsonl(&path);
        let infra = infra_event(&events);
        assert_eq!(infra["payload"]["error"], error);
        assert_eq!(infra["payload"]["spawn_error"], error);
        assert!(
            !std::fs::read_to_string(path)
                .expect("log")
                .contains("sk-startup-secret")
        );
    }

    #[tokio::test]
    async fn startup_rejected_line_is_escaped_and_redacted_in_durable_log() {
        struct WarningBackend;
        impl AgentBackend for WarningBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                let line = "\u{1b}[33m WARN focus target omitted the window identifier token=sk-startup-secret\r";
                let source = serde_json::from_str::<serde_json::Value>(line)
                    .expect_err("launcher warning is not JSON");
                Err(ProtocolError::invalid_protocol_line(line, source))
            }
        }
        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let mut cfg = sample_spawn_config(dir.path());
        cfg.env
            .push(("OPENAI_API_KEY".into(), "sk-startup-secret".into()));
        let result =
            run_agent_classified::<WarningBackend>(&cfg, Some(sink), None, None, Some(builder()))
                .await;
        let SessionResult::PreflightFailed { error } = result else {
            panic!("expected preflight failure");
        };
        assert!(
            error.contains("expected value at line 1 column 1"),
            "{error}"
        );
        assert!(
            error.contains("focus target omitted the window identifier"),
            "{error}"
        );
        assert!(
            error.contains("[REDACTED:api_key:OPENAI_API_KEY]"),
            "{error}"
        );
        assert!(error.contains(r"\u{1b}[33m"), "{error}");
        assert!(error.contains(r"\r"), "{error}");
        assert!(!error.chars().any(char::is_control), "{error:?}");
        let events = read_jsonl(&path);
        let infra = infra_event(&events);
        assert_eq!(infra["payload"]["cause"], "malformed_framing");
        assert_eq!(infra["payload"]["error"], error);
        assert_eq!(infra["payload"]["spawn_error"], error);
        assert!(
            !std::fs::read_to_string(path)
                .expect("log")
                .contains("sk-startup-secret")
        );
    }

    #[tokio::test]
    async fn pre_stream_eof_emits_infra_preflight_driver_event() {
        struct EofBackend;
        impl AgentBackend for EofBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script("IFS= read -r _; exit 0")
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let cfg = sample_spawn_config(dir.path());
        let result =
            run_agent_classified::<EofBackend>(&cfg, Some(sink), None, None, Some(builder())).await;

        match result {
            SessionResult::PreflightFailed { error } => assert!(
                error.contains("unexpected end"),
                "pre-stream EOF must return the EOF detail: {error}",
            ),
            other => panic!("expected PreflightFailed, got {other:?}"),
        }
        let events = read_jsonl(&path);
        assert_eq!(events[0]["kind"], "agent_start");
        assert_eq!(events[1]["driver_kind"], "container_spawn");
        let infra = infra_event(&events);
        assert_eq!(infra["payload"]["phase"], "pre-stream");
        assert_eq!(infra["payload"]["first_event_seen"], false);
        assert_eq!(infra["payload"]["infra_class"], "infra-preflight");
        assert_eq!(infra["payload"]["cause"], "unexpected_eof");
        assert!(
            infra["summary"]
                .as_str()
                .is_some_and(|summary| summary.contains("pre-stream EOF")),
            "summary must distinguish pre-stream EOF: {infra:?}",
        );
    }

    #[tokio::test]
    async fn partial_stream_eof_emits_infra_interrupted_driver_event() {
        struct PartialBackend;
        impl AgentBackend for PartialBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script("IFS= read -r _; printf '%s\\n' text; exit 0")
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let cfg = sample_spawn_config(dir.path());
        let result =
            run_agent_classified::<PartialBackend>(&cfg, Some(sink), None, None, Some(builder()))
                .await;

        match result {
            SessionResult::MidSessionFailed { error } => assert!(
                error.contains("unexpected end"),
                "interrupted EOF must return the EOF detail: {error}",
            ),
            other => panic!("expected MidSessionFailed, got {other:?}"),
        }
        let events = read_jsonl(&path);
        assert!(
            events.iter().any(|event| event["kind"] == "text_delta"),
            "partial stream must log the agent event before infra: {events:?}",
        );
        let infra = infra_event(&events);
        assert_eq!(infra["payload"]["phase"], "interrupted");
        assert_eq!(infra["payload"]["first_event_seen"], true);
        assert_eq!(infra["payload"]["infra_class"], "infra-interrupted");
        assert_eq!(infra["payload"]["cause"], "unexpected_eof");
        assert!(
            infra["summary"]
                .as_str()
                .is_some_and(|summary| summary.contains("interrupted EOF")),
            "summary must distinguish interrupted EOF: {infra:?}",
        );
    }

    #[tokio::test]
    async fn pre_stream_process_exit_payload_carries_exit_status() {
        struct ExitBackend;
        impl AgentBackend for ExitBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script("IFS= read -r _; printf '%s\\n' exit7; exit 0")
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let cfg = sample_spawn_config(dir.path());
        let result =
            run_agent_classified::<ExitBackend>(&cfg, Some(sink), None, None, Some(builder()))
                .await;

        match result {
            SessionResult::PreflightFailed { error } => assert!(
                error.contains("code 7"),
                "pre-stream process exit must return status detail: {error}",
            ),
            other => panic!("expected PreflightFailed, got {other:?}"),
        }
        let events = read_jsonl(&path);
        let infra = infra_event(&events);
        assert_eq!(infra["payload"]["phase"], "pre-stream");
        assert_eq!(infra["payload"]["first_event_seen"], false);
        assert_eq!(infra["payload"]["cause"], "process_exit");
        assert_eq!(infra["payload"]["exit_status"], 7);
    }

    #[tokio::test]
    async fn pre_stream_exit_127_routes_static_missing_agent_binary() {
        struct MissingBinaryBackend;
        impl AgentBackend for MissingBinaryBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script("IFS= read -r _; printf '%s\\n' exit127; exit 0")
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let cfg = sample_spawn_config(dir.path());
        let result =
            run_agent_classified::<MissingBinaryBackend>(&cfg, None, None, None, Some(builder()))
                .await;

        match result {
            SessionResult::StaticInfra { cause, error } => {
                assert_eq!(cause, MISSING_AGENT_BINARY_CAUSE);
                assert!(error.contains("code 127"), "missing detail: {error}");
            }
            other => panic!("expected StaticInfra, got {other:?}"),
        }
    }

    #[test]
    fn native_preflight_capability_exit_is_static_infrastructure() {
        let result = protocol_error_session_result(
            false,
            &ProtocolError::ProcessExit(78),
            "native profile cannot execute Nextest".to_owned(),
        );
        assert!(matches!(result, SessionResult::StaticInfra { cause, error }
            if cause == crate::r#loop::VERIFICATION_CAPABILITY_UNAVAILABLE_CAUSE
                && error.contains("Nextest")));
    }

    #[test]
    fn native_preflight_exit_after_agent_output_is_interruption() {
        let result = protocol_error_session_result(
            true,
            &ProtocolError::ProcessExit(78),
            "interrupted active agent".to_owned(),
        );
        assert!(matches!(result, SessionResult::MidSessionFailed { error }
            if error == "interrupted active agent"));
    }

    #[tokio::test]
    async fn session_complete_is_not_overwritten_by_later_stream_noise() {
        struct CompleteThenNoiseBackend;
        impl AgentBackend for CompleteThenNoiseBackend {
            async fn spawn(_config: &SpawnConfig) -> Result<AgentSession<Idle>, ProtocolError> {
                spawn_script("IFS= read -r _; printf '%s\\n' complete; printf '%s\\n' bad; exit 7")
            }
        }

        let dir = tempfile::tempdir().expect("tempdir");
        let (sink, path) = open_test_sink(dir.path());
        let cfg = sample_spawn_config(dir.path());
        let result = run_agent_classified::<CompleteThenNoiseBackend>(
            &cfg,
            Some(sink),
            None,
            None,
            Some(builder()),
        )
        .await;

        match result {
            SessionResult::Complete(outcome) => assert_eq!(outcome.exit_code, 0),
            other => panic!("expected Complete, got {other:?}"),
        }
        let events = read_jsonl(&path);
        assert!(
            events
                .iter()
                .any(|event| event["kind"] == "session_complete"),
            "session_complete must be logged: {events:?}",
        );
        assert!(
            events
                .iter()
                .all(|event| event["driver_kind"] != "infra_failure"),
            "later stream noise must not append infra diagnostics: {events:?}",
        );
    }
}
