//! Sequential [`AgentLoopController`] with host-owned integration and recovery.
//!
//! Worker preparation is shared with parallel scheduling through [`super::worker`].
//! The caller supplies transport; static profile faults never fall back silently.

use std::collections::{HashSet, VecDeque};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, UNIX_EPOCH};

use loom_driver::agent::{AgentRuntime, SpawnConfig};
use loom_driver::bd::{
    BdClient, Bead, CommandRunner, ListOpts, ReadyOpts, TokioRunner, UpdateOpts,
};
use loom_driver::clock::{Clock, SystemClock};
use loom_driver::config::{LoomConfig, LoomTopConfig, SkillsConfig};
use loom_driver::git::{CreatedWorktree, GitClient, GitOid, RebaseOutcome};
use loom_driver::identifier::{BeadId, MoleculeId, ProfileName, SpecLabel};
use loom_driver::lock::LockGuard;
use loom_driver::logging::phase_log_path;
use loom_driver::profile_manifest::ProfileImageManifest;
use loom_events::{
    AgentEvent, DriverEventPayload, DriverKind, EnvelopeBuilder, SessionScope, Source,
};
use tokio::process::Command;
use tracing::{info, warn};

use loom_gate::{
    GatePhase, GateRun, GateRunStatus, GateSuccess, HandoffEvidence, MarkerProof, MoleculeState,
    append_gate_run_lifecycle_events, parse_gate_runs_from_jsonl,
};

use super::decision_wait::{DecisionWaitJournal, held, reconcile_session};
use super::driver_emit::BeadEmit;
use super::error::LoopError;
use super::outcome::{AgentOutcome, InfraDiagnostic, SessionResult};
use super::runner::{
    AgentLoopController, PerBeadGateOutcome, StabilizationOutcome, WORKSPACE_RECOVERY_FAILED_CAUSE,
};
use super::tree_clean::dirty_paths_from_porcelain;
use super::verify::{VerifyPass, verify_pass};
use crate::review::{
    DispatchScope, GateInputs, PhaseVerdict, RecoveryCause, WalkOutput, WorkspaceFindingValidator,
    decide,
};
use crate::suppression::suppresses_rubric_finding;
use crate::todo::ExitSignal;
use loom_templates::previous_failure::{TerminalSurface, VerifierFailure};
use loom_templates::run::PreviousFailure;

/// Env var the molecule-completion handoff sets when spawning `loom gate
/// review` so the child re-uses the parent's pinned `phase_when`
/// timestamp.
///
/// With both sides computing the JSONL log path from the
/// same `(logs_root, "review", when)` tuple, the parent can
/// thread `review_log_path` into [`HandoffEvidence`] without scanning
/// directories.
pub const REVIEW_PHASE_WHEN_ENV: &str = "LOOM_REVIEW_PHASE_WHEN_MILLIS";

/// Requests review output from the molecule-completion handoff.
///
/// The child emits its agent-origin transcript for canonical Review decoding;
/// driver-authored finding-status records are not promoted into agent messages.
pub const REVIEW_EMIT_STDOUT_ENV: &str = "LOOM_REVIEW_EMIT_STDOUT";

/// Selects the review handoff's spec context and log namespace.
///
/// The molecule-completion handoff sets it when spawning `loom gate review`,
/// without adding a public `--spec` gate filter. The value is context only:
/// `--diff` remains the trust-bearing scope.
pub const REVIEW_SPEC_LABEL_ENV: &str = "LOOM_REVIEW_SPEC_LABEL";

/// Internal handoff path to the completed deterministic gate log whose
/// [`loom_gate::VerifiedScope`] the push-eligible review must consume.
pub const REVIEW_VERIFIED_LOG_ENV: &str = "LOOM_REVIEW_VERIFIED_LOG";

/// Wires the [`AgentLoopController`] trait against the real `BdClient`, a
/// caller-provided agent dispatch closure, and a child `loom review` exec for
/// handoff.
///
/// `manifest` / `cli_profile` / `phase_default` are the inputs the per-bead
/// profile resolver chain needs (see
/// [`super::resolve_profile_image`]). They are stored on the controller so
/// every `run_bead` call resolves the bead's `image_ref` + `image_source`
/// from the same parsed manifest, never re-reading it from disk.
///
/// `spawn` is the per-phase dispatch closure: the binary builds it from
/// `dispatch(kind, &spawn_config)` so the workflow stays backend-agnostic.
/// `run_bead` calls it on every retry attempt, so the closure must be `Fn`
/// (callable repeatedly). It receives `(SpawnConfig, BeadId)` — the bead id
/// is passed alongside the spawn config so the closure can open the per-bead
/// JSONL [`LogSink`](loom_driver::logging::LogSink) before dispatch.
pub struct ProductionAgentLoopController<S, F, R: CommandRunner = TokioRunner>
where
    S: Fn(SpawnConfig, BeadId) -> F + Send,
    F: std::future::Future<Output = (SessionResult, Option<ExitSignal>)> + Send,
{
    bd: BdClient<R>,
    label: SpecLabel,
    loom_bin: PathBuf,
    wrix_bin: PathBuf,
    workspace: PathBuf,
    git: GitClient,
    manifest: Arc<ProfileImageManifest>,
    cli_profile: Option<ProfileName>,
    phase_default: ProfileName,
    runtime: AgentRuntime,
    /// Global `--agent` override to propagate into the molecule-review child.
    /// `None` preserves the review phase's independent config selection.
    agent_override: Option<AgentRuntime>,
    spawn: S,
    /// Spec lock dropped before exec'ing child `loom gate` commands.
    lock: Option<LockGuard>,
    /// Workspace-relative path to the style-rules document pinned in the
    /// run prompt. Sourced from `LoomConfig.style_rules` at construction
    /// time via [`Self::with_style_rules`]; defaults to the built-in path
    /// so test fakes that skip the builder still render a valid prompt.
    style_rules: String,
    /// Typed `PreviousFailure` to thread on the next attempt, set by the
    /// verdict-gate tree-not-clean dispatcher so a dirty worktree on attempt
    /// N renders the rich `TreeNotClean { dirty_paths }` body on attempt
    /// N+1 instead of the opaque agent-error string returned through the
    /// runner. Cleared on a fresh bead dispatch (`previous_failure = None`).
    stashed_previous_failure: Option<PreviousFailure>,
    /// Typed [`PreviousFailure::ReviewConcern`] (or `BadWalk`) parsed
    /// from the molecule-completion review's stdout. Distinct from
    /// [`Self::stashed_previous_failure`] because its scope is the
    /// molecule, not a single bead's retry chain: the next `run_bead`
    /// call — typically a fresh fix-up bead, not a retry — consumes it
    /// so the parsed `Vec<Finding>` rides through into the recovery
    /// prompt per `specs/harness.md`
    /// § *`molecule_completion_review_threads_findings_into_previous_failure_review_concern`*.
    /// Consumed once (take); cleared on first read.
    stashed_review_concern: Option<PreviousFailure>,
    /// Per-bead JSONL log root. When set, the controller appends driver
    /// events (`bead_branch_pushed`, `merge_ok`, `tree_not_clean`,
    /// `retry_dispatch`, …) into the current bead's `.jsonl` so the
    /// dispatch-to-dispatch gap surfaces in the same file as the agent's
    /// own events. `None` is a silent no-op for tests that don't wire
    /// the phase log.
    logs_root: Option<PathBuf>,
    /// `[loom]` block snapshot. The sccache fields are consulted at every
    /// dispatch to decide whether the bead container picks up the shared
    /// cache mount + env. `LoomTopConfig::default()` is harmless — both
    /// sccache fields are `None`/`/sccache` so no mount is emitted.
    loom_cfg: LoomTopConfig,
    retry_policy: super::RetryPolicy,
    skills_cfg: SkillsConfig,
    /// State for the bead currently being processed by `run_bead`. The
    /// envelope builder is shared across every driver event emitted
    /// during one attempt so seq stays strictly increasing across the
    /// post-session merge/push/cleanup window. Reset at the start of
    /// each `run_bead` call.
    current_emit: Option<BeadEmit>,
    admissions: super::AdmissionTracker,
    /// Integration tip the current bead's ff-merge advanced past, captured
    /// in `run_bead` only when the merge actually moved the integration
    /// branch. `exec_per_bead_gate`'s audit-fail rollback consumes it: a
    /// bead that added no commit leaves this `None`, so the rollback is
    /// skipped rather than unwinding a prior bead's commit
    /// (`specs/harness.md` § Verdict Gate — `post-integrate-fail`).
    pre_integration_tip: Option<GitOid>,
    verification_attempted: HashSet<BeadId>,
    verification_resume: Option<loom_driver::workspace::VerificationContinuation>,
    verification_restore_status: Option<loom_driver::bd::Status>,
    /// Attempt number rendered into the current bead's prompt and copied
    /// into durable post-integrate gate logs.
    current_attempt: u32,
    /// Bead workspace awaiting lifecycle cleanup after its integrated diff
    /// clears the deterministic per-bead gate.
    current_worktree_path: Option<PathBuf>,
    fixed_queue: Option<VecDeque<Bead>>,
    infra_queue: VecDeque<Bead>,
    infra_queue_loaded: bool,
    /// Optional work-epic scope for active/explicit epic loops. When set,
    /// ready lookup is constrained to descendants of this work root rather
    /// than to a single `spec:<label>` so multi-spec todo batches can run.
    ready_parent: Option<BeadId>,
    /// Molecule selected by the CLI work root. Explicit epic roots use their
    /// own id; explicit task roots use their Beads parent.
    handoff_molecule: Option<MoleculeId>,
}

impl<S, F, R: CommandRunner> ProductionAgentLoopController<S, F, R>
where
    S: Fn(SpawnConfig, BeadId) -> F + Send,
    F: std::future::Future<Output = (SessionResult, Option<ExitSignal>)> + Send,
{
    #[expect(clippy::too_many_arguments, reason = "controller construction surface")]
    pub fn new(
        bd: BdClient<R>,
        label: SpecLabel,
        loom_bin: PathBuf,
        workspace: PathBuf,
        git: GitClient,
        manifest: Arc<ProfileImageManifest>,
        cli_profile: Option<ProfileName>,
        phase_default: ProfileName,
        spawn: S,
    ) -> Self {
        Self {
            bd,
            label,
            loom_bin,
            wrix_bin: PathBuf::from("wrix"),
            workspace,
            git,
            manifest,
            cli_profile,
            phase_default,
            runtime: AgentRuntime::Pi,
            agent_override: None,
            spawn,
            lock: None,
            style_rules: "docs/style-rules.md".to_string(),
            stashed_previous_failure: None,
            stashed_review_concern: None,
            logs_root: None,
            current_emit: None,
            admissions: super::AdmissionTracker::default(),
            loom_cfg: LoomTopConfig::default(),
            retry_policy: super::RetryPolicy::default(),
            skills_cfg: SkillsConfig::default(),
            pre_integration_tip: None,
            verification_attempted: HashSet::new(),
            verification_resume: None,
            verification_restore_status: None,
            current_attempt: 0,
            current_worktree_path: None,
            fixed_queue: None,
            infra_queue: VecDeque::new(),
            infra_queue_loaded: false,
            ready_parent: None,
            handoff_molecule: None,
        }
    }

    #[must_use]
    pub fn with_wrix_bin(mut self, path: PathBuf) -> Self {
        self.wrix_bin = path;
        self
    }

    #[must_use]
    pub fn with_fixed_queue(mut self, queue: VecDeque<Bead>) -> Self {
        self.fixed_queue = Some(queue);
        self
    }

    #[must_use]
    pub fn with_ready_parent(mut self, parent: BeadId) -> Self {
        self.ready_parent = Some(parent);
        self
    }

    #[must_use]
    pub fn with_handoff_molecule(mut self, molecule: MoleculeId) -> Self {
        self.handoff_molecule = Some(molecule);
        self
    }

    /// Snapshot the `[loom]` config block onto the controller so the
    /// per-bead dispatch picks up the shared sccache mount + env when
    /// [`LoomTopConfig::sccache_dir`] is set. Defaults to
    /// `LoomTopConfig::default()` when unset, which emits no mount.
    #[must_use]
    pub fn with_loom_config(mut self, cfg: LoomTopConfig) -> Self {
        self.loom_cfg = cfg;
        self
    }

    #[must_use]
    pub const fn with_retry_policy(mut self, policy: super::RetryPolicy) -> Self {
        self.retry_policy = policy;
        self
    }

    #[must_use]
    pub fn with_skills_config(mut self, cfg: SkillsConfig) -> Self {
        self.skills_cfg = cfg;
        self
    }

    /// Pin the per-bead JSONL log root the controller appends
    /// driver-side merge/push/cleanup events into. Production callers
    /// thread `<workspace>/.loom/logs`; tests that don't exercise
    /// the driver-event channel leave it unset and the emit path is a
    /// silent no-op.
    #[must_use]
    pub fn with_phase_log_root(mut self, logs_root: PathBuf) -> Self {
        self.logs_root = Some(logs_root);
        self
    }

    /// Hand the work-root lock to the controller so `exec_review` can drop it
    /// before spawning child `loom gate` commands that acquire the same lock.
    #[must_use]
    pub fn with_handoff_lock(mut self, guard: LockGuard) -> Self {
        self.lock = Some(guard);
        self
    }

    fn release_handoff_lock_for_child_gate(&mut self) {
        self.lock.take();
    }

    pub(super) async fn reopen_after_verification_failure(
        &mut self,
        bead: &BeadId,
        detail: String,
    ) -> Result<bool, LoopError> {
        let Some(source) = verification_source(&self.bd, &self.workspace, bead).await? else {
            return Ok(false);
        };
        if held(
            &self.bd,
            &DecisionWaitJournal::new(&self.workspace).with_admissions(self.admissions.clone()),
            &source,
        )
        .await?
        {
            return Ok(false);
        }
        let association = loom_driver::workspace::Association::resolve(&self.workspace)?;
        if let Some(record) = association
            .verification_continuations()?
            .into_iter()
            .find(|record| &record.bead == bead && record.needs_source_repair())
        {
            association.validate_verification_checkout(&record)?;
            if record.semantic_failures > self.retry_policy.max_retries {
                self.apply_blocked(bead, super::runner::RETRY_EXHAUSTED_CAUSE, &format!("{} semantic verification failures exhausted max_retries={}; rejected source and failure evidence remain retained: {detail}", record.semantic_failures, self.retry_policy.max_retries)).await?;
                return Ok(false);
            }
            let pin = format!(
                "refs/loom/verification/{}/{}",
                record.bead, record.candidate
            );
            if loom_driver::git::sync_rev_parse(&self.git.loom_workspace(), &pin)?
                != record.candidate
            {
                return Err(LoopError::Bug {
                    context: "rejected source candidate pin changed".into(),
                });
            }
            let integration = self.git.loom_workspace();
            if record.candidate == self.git.integration_commit_sha().await?
                && let Some(rollback) = &record.rollback
                && rollback != &record.candidate
            {
                if !GitClient::open(&integration)?
                    .is_ancestor_of_head(rollback.as_str())
                    .await?
                {
                    return Err(LoopError::Bug {
                        context: "rejected source rollback is unrelated to current integration"
                            .into(),
                    });
                }
                if !self
                    .git
                    .status_porcelain_at(&integration)
                    .await?
                    .trim()
                    .is_empty()
                {
                    return Err(LoopError::Bug {
                        context: "rejected source recovery has dirty integration; retained".into(),
                    });
                }
                let rollback = self.git.bounded_verification_rollback(rollback).await?;
                self.git.reset_integration_to(rollback.as_str()).await?;
            }
        }
        if source.status == loom_driver::bd::Status::Open
            && !source.labels.iter().any(loom_driver::bd::Label::is_infra)
        {
            return Ok(true);
        }
        self.bd.update(bead, UpdateOpts { if_status: Some(source.status), status: Some(loom_driver::bd::Status::Open), remove_labels: vec!["loom:infra".into()], append_notes: Some(format!("Required verifier rejected the preserved candidate; implementation repair resumes automatically: {detail}")), ..UpdateOpts::default() }).await?;
        self.emit_to_log(DriverKind::BdStateTransition, "semantic verifier rejection returned to implementation repair", serde_json::json!({"bead_id":bead, "status":"open", "source_route":"verification-source-repair"}));
        Ok(true)
    }

    pub(super) async fn resume_verification(
        &mut self,
        bead: &Bead,
        mut record: loom_driver::workspace::VerificationContinuation,
    ) -> Result<AgentOutcome, LoopError> {
        self.current_emit = None;
        self.pre_integration_tip = None;
        self.verification_resume = None;
        self.verification_restore_status = None;
        self.prepare_emit_state(&bead.id);
        let Some(current_bead) = verification_source(&self.bd, &self.workspace, &bead.id).await?
        else {
            return Ok(AgentOutcome::Blocked { reason: "current native prerequisites or independent holds preserve verification candidate".into() });
        };
        if held(
            &self.bd,
            &DecisionWaitJournal::new(&self.workspace).with_admissions(self.admissions.clone()),
            &current_bead,
        )
        .await?
        {
            return Ok(AgentOutcome::Blocked {
                reason: "independent hold preserves verification candidate".into(),
            });
        }
        let bead = &current_bead;
        let association = loom_driver::workspace::Association::resolve(&self.workspace)?;
        association.validate_verification(&record)?;
        let path = self.workspace.join(".loom/beads").join(bead.id.as_str());
        if !self.git.status_porcelain_at(&path).await?.trim().is_empty() {
            return Ok(AgentOutcome::StaticInfra { cause: WORKSPACE_RECOVERY_FAILED_CAUSE.into(), error: "completed source changed during verifier recovery; preserved without source redispatch".into() });
        }
        let gate_workspace = self.git.loom_workspace();
        if !self
            .git
            .status_porcelain_at(&gate_workspace)
            .await?
            .trim()
            .is_empty()
        {
            return Ok(AgentOutcome::StaticInfra {
                cause: WORKSPACE_RECOVERY_FAILED_CAUSE.into(),
                error: "integration has unfinished work; verifier continuation retained".into(),
            });
        }
        self.git.checkout_integration().await?;
        let current = self.git.integration_commit_sha().await?;
        if !GitClient::open(&gate_workspace)?
            .is_ancestor_of_head(record.base.as_str())
            .await?
        {
            return Ok(AgentOutcome::StaticInfra { cause: WORKSPACE_RECOVERY_FAILED_CAUSE.into(), error: "integration history no longer contains verification base; continuation retained".into() });
        }
        let pinned = format!("refs/loom/verification/{}/{}", bead.id, record.candidate);
        if loom_driver::git::sync_rev_parse(&gate_workspace, &pinned)? != record.candidate {
            return Err(LoopError::Bug {
                context: "verification candidate pin changed; no coverage admitted".into(),
            });
        }
        let branch = self
            .git
            .restore_verification_branch(&bead.id, &record.candidate)
            .await?;
        let worktree = CreatedWorktree {
            path: path.clone(),
            branch: branch.clone(),
        };
        if !matches!(
            self.git.rebase_onto_integration(&branch).await?,
            RebaseOutcome::Rebased
        ) {
            return Ok(AgentOutcome::StaticInfra { cause: WORKSPACE_RECOVERY_FAILED_CAUSE.into(), error: "verification continuation conflicts with independent integration work; both histories retained".into() });
        }
        let candidate = loom_driver::git::sync_rev_parse(&gate_workspace, &branch)?;
        let base = if candidate == current {
            record.base.clone()
        } else {
            current.clone()
        };
        let rollback = if candidate == current && record.candidate == current {
            record.rollback.clone().unwrap_or_else(|| current.clone())
        } else {
            current.clone()
        };
        let rollback = self.git.bounded_verification_rollback(&rollback).await?;
        if !GitClient::open(&gate_workspace)?
            .is_ancestor_of_head(rollback.as_str())
            .await?
        {
            return Ok(AgentOutcome::StaticInfra { cause: WORKSPACE_RECOVERY_FAILED_CAUSE.into(), error: "verification rollback no longer belongs to current integration; all work preserved".into() });
        }
        if let Some(outcome) = self
            .verify_or_block(
                &bead.id,
                &worktree,
                &format!("{base}..{branch}"),
                VerifyPass::Driver,
            )
            .await?
        {
            return Ok(outcome);
        }
        association.validate_verification(&record)?;
        self.git
            .preserve_verification_candidate(&bead.id, &candidate)
            .await?;
        record.rollback = Some(rollback.clone());
        record.base = base.clone();
        record.candidate = candidate.clone();
        association.append_verification(&record)?;
        self.git.ff_merge_integration(&branch).await?;
        self.pre_integration_tip = (candidate != rollback).then_some(rollback);
        self.current_worktree_path = Some(path);
        self.verification_restore_status = bead
            .labels
            .iter()
            .any(loom_driver::bd::Label::is_infra)
            .then_some(record.parked_status)
            .flatten();
        self.verification_resume = Some(record);
        self.prepare_emit_state(&bead.id);
        Ok(AgentOutcome::Success)
    }

    async fn load_infra_queue(&mut self) -> Result<(), LoopError> {
        if !self.infra_queue_loaded {
            let beads = self
                .bd
                .list(ListOpts {
                    statuses: vec![loom_driver::bd::Status::Blocked],
                    label: self
                        .ready_parent
                        .is_none()
                        .then(|| self.spec_label_filter()),
                    label_any: vec!["loom:infra".to_string()],
                    parent: self.ready_parent.clone(),
                    ..ListOpts::default()
                })
                .await?;
            self.infra_queue = beads
                .into_iter()
                .filter(|bead| !self.verification_attempted.contains(&bead.id))
                .collect();
            self.infra_queue_loaded = true;
        }
        let association = loom_driver::workspace::Association::resolve(&self.workspace)?;
        for record in association.verification_continuations()? {
            if record.label != self.label {
                continue;
            }
            if record.root != self.ready_parent {
                continue;
            }
            if !self.verification_attempted.contains(&record.bead)
                && !self.infra_queue.iter().any(|bead| bead.id == record.bead)
                && let Some(source) =
                    verification_source(&self.bd, &self.workspace, &record.bead).await?
            {
                self.infra_queue.push_back(source);
            }
        }
        Ok(())
    }

    /// Override the style-rules pin used in the rendered run prompt.
    /// Production callers thread this from `LoomConfig.style_rules`; tests
    /// rely on the built-in default.
    #[must_use]
    pub fn with_style_rules(mut self, path: String) -> Self {
        self.style_rules = path;
        self
    }

    #[must_use]
    pub const fn with_agent_runtime(mut self, runtime: AgentRuntime) -> Self {
        self.runtime = runtime;
        self
    }

    #[must_use]
    pub const fn with_agent_override(mut self, agent_override: Option<AgentRuntime>) -> Self {
        self.agent_override = agent_override;
        self
    }

    fn spec_label_filter(&self) -> String {
        format!("spec:{}", self.label.as_str())
    }

    /// Resolve the per-bead log file the spawn closure just finished
    /// writing to and seed the driver-event emit channel so subsequent
    /// merge/push/cleanup events land in the same JSONL. Silent no-op
    /// when no log root is configured or the file is not resolvable.
    fn prepare_emit_state(&mut self, bead: &BeadId) {
        self.current_emit = self
            .logs_root
            .as_deref()
            .and_then(|root| BeadEmit::for_bead(root, &self.label, bead));
    }

    /// Append a single driver event to the current bead's log file.
    /// Silent no-op when [`Self::current_emit`] is unset.
    fn emit_to_log(&mut self, kind: DriverKind, summary: &str, mut payload: serde_json::Value) {
        if let Some(state) = self.current_emit.as_mut() {
            if matches!(kind, DriverKind::ClarifyDowngraded)
                && let Some(object) = payload.as_object_mut()
            {
                object.insert(
                    "event_sequence".to_string(),
                    serde_json::json!(state.builder.current_seq()),
                );
                object.insert(
                    "gate_log_path".to_string(),
                    serde_json::json!(state.log_path.to_string_lossy()),
                );
            }
            state.emit(kind, summary, payload);
        }
    }

    fn emit_payload(&mut self, event: DriverEventPayload) {
        self.emit_to_log(event.driver_kind, &event.summary, event.payload);
    }

    /// Run one `git verify-commit` pass over `range` in the loom
    /// workspace via the shared [`verify_pass`] helper. `pass` is
    /// [`VerifyPass::Worker`] (pass 1, fetched commits) or
    /// [`VerifyPass::Driver`] (pass 2, rebased commits) — it rides into
    /// the `signature-verification-failed` detail so the operator knows
    /// whether to investigate the wrix container's signing setup or the
    /// loom-workspace gitconfig + key resolution.
    ///
    /// Returns `Ok(None)` when the pass verified (or was skipped because
    /// no signing key resolved). Returns `Ok(Some(SignatureVerificationFailed))`
    /// on a rejected signature — the transient `loom/<id>` ref is deleted
    /// unconditionally first so a later dispatch's fetch starts clean.
    async fn verify_or_block(
        &mut self,
        bead: &BeadId,
        worktree: &CreatedWorktree,
        range: &str,
        pass: VerifyPass,
    ) -> Result<Option<AgentOutcome>, LoopError> {
        // Disjoint field borrows: `&self.git` (shared) alongside
        // `self.current_emit.as_mut()` (exclusive) is sound because they
        // are distinct fields accessed directly rather than through a
        // method.
        let reason = verify_pass(
            &self.git,
            self.current_emit.as_mut(),
            bead,
            &worktree.branch,
            range,
            pass,
        )
        .await?;
        Ok(reason.map(|detail| AgentOutcome::SignatureVerificationFailed { detail }))
    }

    async fn rollback_if_bead_advanced_integration(&mut self) -> Result<bool, LoopError> {
        if let Some(tip) = self.pre_integration_tip.take() {
            let tip = self.git.bounded_verification_rollback(&tip).await?;
            if tip == self.git.integration_commit_sha().await? {
                return Ok(false);
            }
            self.git.reset_integration_to(tip.as_str()).await?;
            Ok(true)
        } else {
            Ok(false)
        }
    }

    async fn reap_closed_worktree(&mut self, bead: &BeadId) -> Result<(), LoopError> {
        let Some(path) = self.current_worktree_path.clone() else {
            return Ok(());
        };
        if self.bd.show(bead).await?.status != loom_driver::bd::Status::Closed {
            return Ok(());
        }
        self.git.remove_worktree(&path).await?;
        self.current_worktree_path = None;
        self.emit_to_log(
            DriverKind::WorktreeCleanupOk,
            &format!("closed bead workspace reaped for {bead}"),
            serde_json::json!({
                "bead_id": bead.to_string(),
                "worktree_path": path.to_string_lossy(),
            }),
        );
        Ok(())
    }
}

impl<S, F, R: CommandRunner> AgentLoopController for ProductionAgentLoopController<S, F, R>
where
    S: Fn(SpawnConfig, BeadId) -> F + Send,
    F: std::future::Future<Output = (SessionResult, Option<ExitSignal>)> + Send,
{
    async fn next_ready_bead(&mut self, deferred: &[BeadId]) -> Result<Option<Bead>, LoopError> {
        DecisionWaitJournal::new(&self.workspace)
            .with_admissions(self.admissions.clone())
            .recover_inventory(&self.bd, self.ready_parent.as_ref(), &self.label)
            .await?;
        if let Some(queue) = self.fixed_queue.as_mut() {
            while let Some(bead) = queue.pop_front() {
                if matches!(
                    bead.issue_type,
                    loom_driver::bd::IssueType::Epic | loom_driver::bd::IssueType::Decision
                ) {
                    continue;
                }
                if !held(
                    &self.bd,
                    &DecisionWaitJournal::new(&self.workspace)
                        .with_admissions(self.admissions.clone()),
                    &bead,
                )
                .await?
                {
                    return Ok(Some(bead));
                }
            }
            return Ok(None);
        }
        // Dedup of parked beads primarily relies on their paired blocked or
        // deferred status. The explicit label guard below catches stale or
        // partially-written `loom:*` parked state, so no exclude-label flag is
        // needed here.
        //
        // Epic-typed beads are skipped: workers dispatch leaf work, not
        // molecule containers. A stray ready epic surfaces as one info-log
        // line per skip so the operator sees the routing decision.
        let beads = self
            .bd
            .ready(ReadyOpts {
                limit: None,
                label: self
                    .ready_parent
                    .is_none()
                    .then(|| self.spec_label_filter()),
                parent: self.ready_parent.clone(),
                exclude_label: vec![],
            })
            .await?;
        for bead in beads {
            if deferred.iter().any(|id| id == &bead.id) {
                continue;
            }
            if matches!(
                bead.issue_type,
                loom_driver::bd::IssueType::Epic | loom_driver::bd::IssueType::Decision
            ) {
                info!(
                    bead = %bead.id,
                    spec = %self.label,
                    "loom loop: skipping container or human decision — workers dispatch implementation only",
                );
                continue;
            }
            if bead_has_parked_state(&bead) {
                info!(
                    bead = %bead.id,
                    spec = %self.label,
                    "loom loop: skipping parked ready bead",
                );
                continue;
            }
            let parent_is_parked = if let Some(parent_id) = bead.parent.clone() {
                let parent = self.bd.show(&parent_id).await?;
                bead_has_parked_state(&parent)
            } else {
                false
            };
            if parent_is_parked {
                info!(
                    bead = %bead.id,
                    spec = %self.label,
                    "loom loop: skipping parked ready bead",
                );
                continue;
            }
            if held(
                &self.bd,
                &DecisionWaitJournal::new(&self.workspace).with_admissions(self.admissions.clone()),
                &bead,
            )
            .await?
            {
                continue;
            }
            return Ok(Some(bead));
        }
        self.load_infra_queue().await?;
        while let Some(bead) = self.infra_queue.pop_front() {
            if bead
                .labels
                .iter()
                .any(|label| label.is_blocked() || label.is_clarify() || label.is_deferred())
                || bead.status == loom_driver::bd::Status::Deferred
            {
                continue;
            }
            if deferred.iter().any(|id| id == &bead.id) {
                continue;
            }
            if matches!(
                bead.issue_type,
                loom_driver::bd::IssueType::Epic | loom_driver::bd::IssueType::Decision
            ) {
                info!(
                    bead = %bead.id,
                    spec = %self.label,
                    "loom loop: skipping container or human decision in infrastructure retry",
                );
                continue;
            }
            if held(
                &self.bd,
                &DecisionWaitJournal::new(&self.workspace).with_admissions(self.admissions.clone()),
                &bead,
            )
            .await?
            {
                continue;
            }
            return Ok(Some(bead));
        }
        Ok(None)
    }

    fn start_invocation(&mut self) {
        self.admissions = super::AdmissionTracker::default();
    }

    fn admitted_decisions(&self) -> Result<std::collections::HashSet<BeadId>, LoopError> {
        self.admissions.ids()
    }

    async fn run_bead(
        &mut self,
        bead: &Bead,
        mut previous_failure: Option<String>,
    ) -> Result<AgentOutcome, LoopError> {
        self.current_emit = None;
        self.current_worktree_path = None;
        self.verification_resume = None;
        self.verification_restore_status = None;
        let mut repaired_source = None;
        let association = loom_driver::workspace::Association::resolve(&self.workspace)?;
        if let Some(record) = association
            .verification_continuations()?
            .into_iter()
            .find(|record| record.bead == bead.id)
        {
            self.verification_attempted.insert(bead.id.clone());
            if record.needs_source_repair() {
                let Some(mut source) =
                    verification_source(&self.bd, &self.workspace, &bead.id).await?
                else {
                    return Ok(AgentOutcome::Blocked {
                        reason:
                            "native prerequisites or independent holds retain rejected source work"
                                .into(),
                    });
                };
                let detail = record
                    .repair_detail
                    .clone()
                    .unwrap_or_else(|| "required verifier rejected this source candidate".into());
                if !self
                    .reopen_after_verification_failure(&bead.id, detail.clone())
                    .await?
                {
                    return Ok(AgentOutcome::Blocked {
                        reason: "source repair is held or its semantic retry budget is exhausted; rejected work remains retained".into(),
                    });
                }
                source.status = loom_driver::bd::Status::Open;
                source.labels.retain(|label| !label.is_infra());
                repaired_source = Some(source);
                self.stashed_previous_failure = super::worker::verification_failure(&record)
                    .or_else(|| self.stashed_previous_failure.take());
                self.current_attempt = self
                    .current_attempt
                    .max(record.semantic_failures.saturating_sub(1));
                previous_failure = previous_failure.or(Some(detail));
            } else {
                return self.resume_verification(bead, record).await;
            }
        }
        let bead = repaired_source.as_ref().unwrap_or(bead);
        if bead.labels.iter().any(loom_driver::bd::Label::is_infra) {
            self.bd
                .update(
                    &bead.id,
                    UpdateOpts {
                        status: Some(loom_driver::bd::Status::Open),
                        remove_labels: vec!["loom:infra".to_string()],
                        ..UpdateOpts::default()
                    },
                )
                .await?;
        }
        let is_retry = previous_failure.is_some();
        // The stash is per-retry-sequence: a fresh dispatch
        // (`previous_failure = None`) means any leftover variant from a
        // prior bead's retry chain is stale. Resolve typed `PreviousFailure`
        // by preferring the stashed variant (set by the tree-not-clean
        // dispatcher) over the opaque runner-supplied error string.
        // The molecule-scoped review-concern stash (set by `exec_review`
        // when the review walk emits ≥1 `LOOM_FINDING:` + a
        // `LOOM_CONCERN:` terminator per `specs/harness.md`
        // § *molecule_completion_review_threads_findings_into_previous_failure_review_concern*)
        // is consumed first regardless of `is_retry` — fix-up beads
        // typically arrive as fresh dispatches, not retries, and the
        // parsed `Vec<Finding>` must ride into the next prompt either way.
        let typed_previous_failure = if let Some(concern) = self.stashed_review_concern.take() {
            Some(concern)
        } else if is_retry {
            self.stashed_previous_failure
                .take()
                .or_else(|| previous_failure.map(PreviousFailure::from_agent_error))
        } else {
            self.stashed_previous_failure = None;
            None
        };
        // Dispatch each bead against its own clone-backed workspace under
        // `.loom/beads/<bead-id>/` (per `specs/harness.md`
        // § Bead dispatch — Path A). The clone's `.git/` is a regular
        // directory inside the bind-mounted path, so workers inside the
        // wrix container can commit and the driver can fold the work
        // back via push + merge_branch on clean exit.
        let worktree = self.git.create_worktree(&self.label, &bead.id).await?;
        self.current_worktree_path = Some(worktree.path.clone());
        info!(
            bead = %bead.id,
            path = %worktree.path.display(),
            branch = %worktree.branch,
            "dispatching agent against per-bead workspace",
        );
        let preparation = match super::worker::prepare_workspace(&self.git, bead, &worktree.path)
            .await
        {
            Ok(preparation) => preparation,
            Err(source) => {
                return Ok(AgentOutcome::StaticInfra {
                    cause: WORKSPACE_RECOVERY_FAILED_CAUSE.to_string(),
                    error: format!(
                        "workspace recovery pre-dispatch prepare failed before cleanup: {source}"
                    ),
                });
            }
        };
        let workspace_recovery_event = preparation
            .recovery
            .as_ref()
            .map(|recovery| super::worker::recovery_event(&bead.id, recovery));

        let attempt = if is_retry {
            self.current_attempt.saturating_add(1)
        } else {
            0
        };
        self.current_attempt = attempt;
        let worker = match super::worker::prepare_with_bd(
            &self.bd,
            super::worker::Request {
                bead,
                workspace: &worktree.path,
                loom_workspace: &self.workspace,
                manifest: &self.manifest,
                cli_profile: self.cli_profile.as_ref(),
                phase_default: &self.phase_default,
                runtime: self.runtime,
                label: &self.label,
                style_rules: &self.style_rules,
                loom: &self.loom_cfg,
                skills: &self.skills_cfg,
                launcher_env: self.git.launcher_key_env()?,
                previous_failure: typed_previous_failure,
                bead_base: preparation.bead_base,
                workspace_recovery: preparation.recovery,
                attempt,
            },
        )
        .await?
        {
            super::worker::Preparation::Ready(worker) => worker,
            super::worker::Preparation::Rejected(outcome) => return Ok(outcome),
        };
        let super::worker::Worker {
            spawn: spawn_config,
            scratch,
            ..
        } = *worker;
        info!(
            bead = %bead.id,
            image_ref = %spawn_config.image_ref,
            worktree = %worktree.path.display(),
            retry = is_retry,
            "loom loop: dispatching agent",
        );
        let (session, marker) = (self.spawn)(spawn_config, bead.id.clone()).await;
        let marker_is_noop = matches!(marker.as_ref(), Some(ExitSignal::Noop));
        let marker_for_event = marker.clone();
        let session_exit_code = session_exit_code(&session);
        drop(scratch);
        // Resolve the per-bead log file the closure just finished writing
        // to so subsequent driver events (tree-not-clean / merge / push /
        // cleanup) land in the same JSONL the agent's events live in.
        self.prepare_emit_state(&bead.id);
        if let Some(event) = workspace_recovery_event {
            self.emit_payload(event);
        }

        let outcome = reconcile_session(
            &self.bd,
            &DecisionWaitJournal::new(&self.workspace).with_admissions(self.admissions.clone()),
            bead,
            session,
            marker.as_ref(),
        )
        .await?;
        self.emit_to_log(
            DriverKind::MarkerRouted,
            &format!(
                "terminal marker {} routed to {} for bead {}",
                marker_name(marker_for_event.as_ref()),
                agent_outcome_route(&outcome),
                bead.id,
            ),
            serde_json::json!({
                "source_route": "loop-marker",
                "identity": marker_name(marker_for_event.as_ref()),
                "route": agent_outcome_route(&outcome),
                "bead_id": bead.id.to_string(),
                "exit_code": session_exit_code,
            }),
        );
        if outcome == AgentOutcome::Success {
            // Tree-clean precedes verify-fail / review-concern per
            // `specs/harness.md` § Verdict Gate. The pre-attempt
            // `prepare_bead_clone` path stashes preserved dirty work and
            // resets non-conflicted dispatches, so any dirty porcelain
            // entry is necessarily an agent leftover, unresolved recovery
            // conflict, or prepare-step bug — running verifiers against a
            // half-staged tree would conflate the agent's intended
            // diff with its leftover scratch.
            let porcelain = self.git.status_porcelain_at(&worktree.path).await?;
            let dirty = dirty_paths_from_porcelain(&porcelain);
            if !dirty.is_empty() {
                warn!(
                    bead = %bead.id,
                    dirty_count = dirty.len(),
                    "tree-not-clean: preserving worktree and stashing TreeNotClean for the next attempt",
                );
                self.emit_to_log(
                    DriverKind::TreeNotClean,
                    &format!(
                        "tree-not-clean: {} dirty path(s) for bead {}",
                        dirty.len(),
                        bead.id,
                    ),
                    serde_json::json!({
                        "bead_id": bead.id.to_string(),
                        "dirty_paths": dirty,
                    }),
                );
                // The bead workspace persists on every non-merged exit
                // (`specs/harness.md` § Verdict Gate — the per-bead-close
                // lifecycle preserves the clone until `bd close`). The next
                // attempt reuses it via the idempotent `create_worktree` +
                // `prepare_bead_clone`, which preserves these dirty leftovers
                // in recovery context before cleanup while keeping any
                // committed work on the bead branch.
                self.stashed_previous_failure =
                    Some(PreviousFailure::TreeNotClean { dirty_paths: dirty });
                return Ok(AgentOutcome::Failure {
                    error: "tree-not-clean".to_string(),
                });
            }
            // A3: the worker never pushes; the driver fetches the bead
            // branch from the bead workspace path into the loom workspace
            // so `merge_branch` can rebase + ff it onto the integration
            // branch.
            self.git.fetch_bead_branch(&worktree.path, &bead.id).await?;
            self.emit_to_log(
                DriverKind::BeadBranchPushed,
                &format!(
                    "bead branch fetched into loom workspace: {}",
                    worktree.branch
                ),
                serde_json::json!({
                    "bead_id": bead.id.to_string(),
                    "branch": worktree.branch,
                    "worktree_path": worktree.path.to_string_lossy(),
                }),
            );
            // Verify signatures (pass 1) on the fetched worker commits.
            // Conditional on a signing key resolving (allowed_signers file
            // present); skipped otherwise. A rejected signature routes the
            // bead to `loom:blocked` (worker-side) — the transient
            // `loom/<id>` ref is deleted unconditionally first so a retry's
            // fetch starts clean.
            let integration_branch = self.git.integration_branch().to_string();
            let pass1_range = format!("{integration_branch}..{}", worktree.branch);
            if let Some(outcome) = self
                .verify_or_block(&bead.id, &worktree, &pass1_range, VerifyPass::Worker)
                .await?
            {
                return Ok(outcome);
            }
            // Rebase the bead branch onto the integration tip (rerere
            // replays any recorded conflict resolution). Pass-2
            // verification runs on the rewritten commits BEFORE the
            // ff-merge, matching the spec recipe (specs/harness.md
            // § Bead dispatch — Bead branch flow; § Verdict Gate phases
            // 3-4): a driver-side signature failure leaves the integration
            // branch untouched because the ff-merge has not run yet.
            match self.git.rebase_onto_integration(&worktree.branch).await? {
                RebaseOutcome::Rebased => {
                    // Verify signatures (pass 2) on the rewritten commits
                    // the rebase produced, before the ff-merge. The range
                    // is `<integration-branch>..<branch>` evaluated in the
                    // loom workspace where the rebase ran — not the
                    // operator workdir's HEAD. Conditional on the same
                    // signing-key resolution as pass 1; a rejected
                    // signature here means loom's own (driver-side) signing
                    // setup is broken. `verify_or_block` deletes the
                    // transient ref, so a failure rolls nothing onto the
                    // integration line.
                    let pass2_range = format!("{integration_branch}..{}", worktree.branch);
                    if let Some(outcome) = self
                        .verify_or_block(&bead.id, &worktree, &pass2_range, VerifyPass::Driver)
                        .await?
                    {
                        return Ok(outcome);
                    }
                    let pre_tip = self.git.integration_commit_sha().await?;
                    let candidate = loom_driver::git::sync_rev_parse(
                        &self.git.loom_workspace(),
                        &worktree.branch,
                    )?;
                    if candidate != pre_tip {
                        self.git
                            .preserve_verification_candidate(&bead.id, &candidate)
                            .await?;
                        association.begin_verification(
                            bead.id.clone(),
                            self.label.clone(),
                            self.ready_parent.clone(),
                            pre_tip.clone(),
                            candidate,
                        )?;
                    }
                    self.git.ff_merge_integration(&worktree.branch).await?;
                    let main_sha = self.git.integration_commit_sha().await?;
                    if main_sha == pre_tip {
                        self.git.delete_branch(&worktree.branch).await?;
                        if marker_is_noop {
                            self.emit_to_log(
                                DriverKind::VerdictGate,
                                &format!("noop: bead {} did not advance integration", bead.id),
                                serde_json::json!({
                                    "bead_id": bead.id.to_string(),
                                    "branch": worktree.branch,
                                    "worktree_path": worktree.path.to_string_lossy(),
                                    "cause": "noop",
                                }),
                            );
                            return Ok(AgentOutcome::Noop);
                        }
                        let detail = format!(
                            "{bead_id} emitted success but branch {branch} did not advance {integration_branch}; preserved workspace {path}",
                            bead_id = bead.id,
                            branch = worktree.branch,
                            path = worktree.path.display(),
                        );
                        self.emit_to_log(
                            DriverKind::VerdictGate,
                            &format!(
                                "zero-progress: bead {} did not advance integration",
                                bead.id
                            ),
                            serde_json::json!({
                                "bead_id": bead.id.to_string(),
                                "branch": worktree.branch,
                                "worktree_path": worktree.path.to_string_lossy(),
                                "cause": "zero-progress",
                            }),
                        );
                        return Ok(AgentOutcome::ZeroProgress { detail });
                    }
                    self.pre_integration_tip = Some(pre_tip);
                    self.emit_to_log(
                        DriverKind::MergeOk,
                        &format!("merge ok: {} → main", worktree.branch),
                        serde_json::json!({
                            "bead_id": bead.id.to_string(),
                            "branch": worktree.branch,
                            "main_sha": main_sha.to_string(),
                        }),
                    );
                    self.git.delete_branch(&worktree.branch).await?;
                    self.emit_to_log(
                        DriverKind::Other("bead_workspace_preserved".to_string()),
                        &format!(
                            "bead workspace preserved through per-bead gate for {}",
                            bead.id
                        ),
                        serde_json::json!({
                            "bead_id": bead.id.to_string(),
                            "branch": worktree.branch,
                            "worktree_path": worktree.path.to_string_lossy(),
                        }),
                    );
                    Ok(AgentOutcome::Success)
                }
                RebaseOutcome::Conflict {
                    detail,
                    files,
                    new_base_sha,
                } => {
                    // Rebase conflict. The bead workspace is preserved
                    // (per the per-bead-close lifecycle); the transient
                    // loom-workspace `loom/<id>` ref is deleted
                    // unconditionally so the integration-conflict retry's
                    // fetch starts clean (a rebased bead branch would not
                    // fast-forward the stale ref). Routes to a single
                    // integration-conflict retry — `run_loop` threads the
                    // stashed typed `IntegrationConflict` into the next
                    // dispatch; a second conflict escalates to clarify.
                    warn!(
                        bead = %bead.id,
                        branch = %worktree.branch,
                        path = %worktree.path.display(),
                        detail = %detail,
                        files = files.len(),
                        new_base = %new_base_sha,
                        "rebase conflict — bead workspace preserved, routing to integration-conflict recovery",
                    );
                    self.emit_to_log(
                        DriverKind::IntegrationConflict,
                        &format!("rebase conflict: {}", worktree.branch),
                        serde_json::json!({
                            "bead_id": bead.id.to_string(),
                            "branch": worktree.branch,
                            "worktree_path": worktree.path.to_string_lossy(),
                            "detail": detail,
                            "new_base_sha": new_base_sha.as_str(),
                            "files": files.iter().map(|f| f.to_string_lossy()).collect::<Vec<_>>(),
                        }),
                    );
                    self.git.delete_branch(&worktree.branch).await?;
                    self.stashed_previous_failure = Some(PreviousFailure::IntegrationConflict {
                        files: files.clone(),
                        new_base_sha: new_base_sha.clone(),
                    });
                    Ok(AgentOutcome::IntegrationConflict {
                        files,
                        new_base_sha,
                    })
                }
            }
        } else {
            // Stash typed `PreviousFailure::AgentRetry { reason }` so the
            // next attempt's `run_bead` resolves the rich variant from
            // `stashed_previous_failure` (consumed via `.take()`) rather
            // than the opaque `PreviousFailure::from_agent_error`
            // fallback. Mirrors the tree-not-clean stash pattern.
            if let AgentOutcome::Retry { reason } = &outcome {
                self.stashed_previous_failure = Some(PreviousFailure::AgentRetry {
                    reason: reason.clone(),
                });
            }
            // Preserve the bead workspace (and any staged-but-uncommitted
            // diff) on every non-merged exit — agent failure, retry, block,
            // or clarify. The per-bead-close lifecycle reaps it at `bd close`
            // (`GitClient::sweep_orphan_bead_clones`); a retry reuses it via
            // the idempotent `create_worktree`. Removing it here would force a
            // full re-implementation of an agent that blocked mid-edit
            // (`specs/harness.md` § Verdict Gate — workspace persists on all
            // failure paths).
            Ok(outcome)
        }
    }

    async fn apply_clarify(&mut self, bead: &BeadId, question: &str) -> Result<(), LoopError> {
        // Driver-authored clarify (e.g. the integration-conflict
        // escalation): when `question` is itself a well-formed
        // `## Options — …` block, the driver — not the agent — is the
        // author, so persist it to bead state before the validation
        // pass. The agent-self-report path passes a plain question with
        // no options block; the guard skips persisting and the agent's
        // own prior write is what gets validated.
        if loom_protocol::gate::options::has_well_formed_block(question) {
            self.bd
                .update(
                    bead,
                    UpdateOpts {
                        notes: Some(question.to_string()),
                        ..UpdateOpts::default()
                    },
                )
                .await?;
            self.emit_to_log(
                DriverKind::BdStateTransition,
                &format!("Beads notes updated with clarify options for {bead}"),
                serde_json::json!({
                    "source_route": "loop-marker",
                    "identity": "LOOM_CLARIFY",
                    "bead_id": bead,
                    "mutation": "update",
                    "notes": "clarify-options",
                }),
            );
        }
        // Verdict-gate direct-emit LOOM_CLARIFY check (specs/gate.md §
        // Options Format Contract): inspect the bead under dispatch for a
        // well-formed `## Options — …` block. Well-formed → loom:clarify;
        // malformed / absent → loom:blocked with cause
        // `clarify-without-options` so `loom inbox`'s queue is not handed
        // an empty options block.
        let report = crate::gate_clarify::apply_clarify_or_blocked_report(&self.bd, bead).await?;
        let context = crate::gate_clarify::ClarifyRouteContext {
            source_route: crate::gate_clarify::ClarifySourceRoute::LoopMarker,
            identity: "LOOM_CLARIFY".to_string(),
            gate_log_path: self.current_emit.as_ref().map(|emit| emit.log_path.clone()),
        };
        for event in report.routing_events(bead, &context) {
            self.emit_payload(event);
        }
        Ok(())
    }

    async fn apply_blocked(
        &mut self,
        bead: &BeadId,
        cause: &str,
        error: &str,
    ) -> Result<(), LoopError> {
        let notes = diagnostic_notes(cause, error);
        let association = loom_driver::workspace::Association::resolve(&self.workspace)?;
        if association
            .verification_continuations()?
            .iter()
            .any(|record| &record.bead == bead)
            && verification_source(&self.bd, &self.workspace, bead)
                .await?
                .is_none()
        {
            return Ok(());
        }
        self.bd
            .update(
                bead,
                UpdateOpts {
                    status: Some(loom_driver::bd::Status::Blocked),
                    add_labels: vec!["loom:blocked".to_string()],
                    append_notes: Some(notes),
                    ..UpdateOpts::default()
                },
            )
            .await?;
        self.emit_to_log(
            DriverKind::BdStateTransition,
            &format!("Beads state updated for {bead}: loom:blocked"),
            serde_json::json!({
                "source_route": "loop-marker",
                "identity": "LOOM_BLOCKED",
                "bead_id": bead,
                "mutation": "update",
                "status": "blocked",
                "added_labels": ["loom:blocked"],
                "notes_cause": cause,
            }),
        );
        Ok(())
    }

    async fn apply_infra(
        &mut self,
        bead: &BeadId,
        diagnostic: &InfraDiagnostic,
    ) -> Result<(), LoopError> {
        let association = loom_driver::workspace::Association::resolve(&self.workspace)?;
        if let Some(mut record) = association
            .verification_continuations()?
            .into_iter()
            .find(|record| &record.bead == bead)
        {
            let Some(source) = verification_source(&self.bd, &self.workspace, bead).await? else {
                return Ok(());
            };
            if record.parked_status.is_none() || record.needs_source_repair() {
                record.parked_status = Some(source.status);
            }
            record.parked_cause = Some(diagnostic.cause.clone());
            association.append_verification(&record)?;
        }
        let mut metadata = vec![
            ("loom.infra.cause".to_string(), diagnostic.cause.clone()),
            ("loom.infra.phase".to_string(), "loop".to_string()),
            (
                "loom.infra.class".to_string(),
                diagnostic.infra_class.clone(),
            ),
        ];
        if let Some(first_event_seen) = diagnostic.first_event_seen {
            metadata.push((
                "loom.infra.first_event_seen".to_string(),
                first_event_seen.to_string(),
            ));
        }
        if let Some(attempt) = diagnostic.attempt {
            metadata.push(("loom.infra.attempt".to_string(), attempt.to_string()));
        }
        if let Some(max_attempts) = diagnostic.max_attempts {
            metadata.push((
                "loom.infra.max_attempts".to_string(),
                max_attempts.to_string(),
            ));
        }
        self.bd
            .update(
                bead,
                UpdateOpts {
                    status: Some(loom_driver::bd::Status::Blocked),
                    add_labels: vec!["loom:infra".to_string()],
                    append_notes: Some(diagnostic_notes(&diagnostic.cause, &diagnostic.error)),
                    set_metadata: metadata,
                    ..UpdateOpts::default()
                },
            )
            .await?;
        self.emit_to_log(
            DriverKind::BdStateTransition,
            &format!("Beads state updated for {bead}: loom:infra"),
            serde_json::json!({
                "source_route": "loop-infra",
                "identity": diagnostic.cause,
                "bead_id": bead,
                "mutation": "update",
                "status": "blocked",
                "added_labels": ["loom:infra"],
                "notes_cause": diagnostic.cause,
            }),
        );
        Ok(())
    }

    async fn exec_review(&mut self) -> Result<HandoffEvidence, LoopError> {
        let handoff = execute_molecule_push_gate(
            &self.bd,
            &self.label,
            self.handoff_molecule.as_ref(),
            MoleculePushGateCommands::new(self.agent_override, &self.loom_bin, &self.wrix_bin)
                .with_manifest(&self.manifest),
            &self.workspace,
            &self.git,
        )
        .await?;
        self.stashed_review_concern = handoff.review_concern;
        Ok(handoff.evidence)
    }

    async fn exec_per_bead_gate(&mut self, bead: &BeadId) -> Result<PerBeadGateOutcome, LoopError> {
        self.release_handoff_lock_for_child_gate();
        self.verification_attempted.insert(bead.clone());
        let association = loom_driver::workspace::Association::resolve(&self.workspace)?;
        let continuation = association
            .verification_continuations()?
            .into_iter()
            .find(|record| &record.bead == bead);
        let diff_range = self
            .verification_resume
            .as_ref()
            .map(|record| &record.base)
            .or(self.pre_integration_tip.as_ref())
            .map_or_else(|| "HEAD..HEAD".to_owned(), |tip| format!("{tip}..HEAD"));
        let verify_args = vec![
            "gate".to_string(),
            "verify".to_string(),
            "--diff".to_string(),
            diff_range.clone(),
        ];
        let gate_workspace = self.git.loom_workspace();
        let verify_output = super::verify::execute_gate(
            Command::new(&self.loom_bin)
                .current_dir(&gate_workspace)
                .args(&verify_args),
            &gate_workspace,
            &SystemClock::new(),
            self.loom_cfg.git_hook_timeout(),
            1,
        )
        .await?;
        let verify_code = verify_output.code;
        info!(
            bead = %bead,
            spec = %self.label.as_str(),
            exit_code = verify_code,
            "loom loop: per-bead gate — loom gate verify --diff finished",
        );
        if verify_code != 0 {
            let infrastructure = verify_output.infrastructure();
            let stderr_tail = verify_output.stderr;
            let stdout_tail = verify_output.stdout;
            let failure = VerifierFailure::new(
                format!("loom gate verify --diff {diff_range}"),
                verify_code,
                format!("{stdout_tail}\n{stderr_tail}"),
            );
            let integration_sha = self.git.integration_commit_sha().await?.to_string();
            let tree_oid = loom_driver::git::head_tree_oid_sync(&gate_workspace)?.to_string();
            let rollback_state = if self.pre_integration_tip.is_some() {
                "pending"
            } else {
                "skipped-no-integration-advance"
            };
            let gate_log_dir =
                gate_log_root(self.logs_root.as_deref(), &self.workspace).join(self.label.as_str());
            let gate_log_record = PostIntegrateGateLog {
                argv: verify_args,
                scope: diff_range.clone(),
                exit_code: verify_code,
                stdout: stdout_tail.clone(),
                stderr: stderr_tail.clone(),
                terminal_marker: None,
                integration_sha,
                tree_oid,
                config_digest: pre_commit_config_digest(&gate_workspace)?,
                bead_id: bead.clone(),
                retry_attempt: self.current_attempt,
                rollback_state,
                failures: vec![failure.clone()],
            };
            let gate_log_path = write_post_integrate_gate_log(&gate_log_dir, &gate_log_record)?;
            let gate_log = gate_log_path.to_string_lossy().to_string();
            let detail = format!(
                "loom gate verify --diff {diff_range} exited {verify_code}\n\
                 gate log: {gate_log}\nstdout:\n{stdout_tail}\nstderr:\n{stderr_tail}",
            );
            if !infrastructure && let Some(record) = &continuation {
                association.await_verification_repair(
                    record,
                    detail.clone(),
                    Some(loom_driver::workspace::VerificationFailure {
                        target: failure.target.clone(),
                        exit_code: failure.exit_code,
                        output: format!("{stdout_tail}\n{stderr_tail}"),
                        log_path: gate_log_path.clone(),
                    }),
                )?;
            }
            let rolled_back = self.rollback_if_bead_advanced_integration().await?;
            if !infrastructure {
                self.stashed_previous_failure = Some(PreviousFailure::PostIntegrateFail {
                    failures: vec![failure],
                    gate_log_path: gate_log_path.clone(),
                });
            }
            self.emit_to_log(
                DriverKind::VerdictGate,
                &format!(
                    "post-integrate-fail: integration audit failed for bead {bead}; gate log: {gate_log}"
                ),
                serde_json::json!({
                    "bead_id": bead.to_string(),
                    "cause": "post-integrate-fail",
                    "verify_code": verify_code,
                    "rolled_back": rolled_back,
                    "gate_log_path": gate_log,
                }),
            );
            return Ok(if infrastructure {
                PerBeadGateOutcome::Infrastructure { detail }
            } else {
                PerBeadGateOutcome::Recovery { detail }
            });
        }

        if continuation.is_some()
            && verification_source(&self.bd, &self.workspace, bead)
                .await?
                .is_none()
        {
            self.rollback_if_bead_advanced_integration().await?;
            return Ok(PerBeadGateOutcome::Infrastructure { detail: "Current native prerequisites or independent holds preserve verified candidate without publication or source-state changes".into() });
        }
        if let Some(status) = self.verification_restore_status.take() {
            if DecisionWaitJournal::new(&self.workspace).has_pending_for(bead)? {
                return Err(LoopError::ReviewHandoff {
                    detail:
                        "host decision hold prevents recovery-state restoration; candidate retained"
                            .into(),
                });
            }
            self.bd.update(bead, UpdateOpts { if_status: Some(loom_driver::bd::Status::Blocked), status: Some(status), remove_labels: vec!["loom:infra".into()], append_notes: Some("Trusted verification continuation completed; original source state restored without source redispatch. Publication still requires its normal gates.".into()), ..UpdateOpts::default() }).await?;
        }
        if let Some(record) = &continuation {
            association.await_verification_publication(record)?;
        } else {
            self.reap_closed_worktree(bead).await?;
        }
        Ok(PerBeadGateOutcome::Clean)
    }

    async fn promote_deferred(&mut self) -> Result<StabilizationOutcome, LoopError> {
        let molecule = if let Some(molecule) = self.handoff_molecule.as_ref() {
            Some(molecule.clone())
        } else if let Some(parent) = self.ready_parent.as_ref() {
            Some(parent.as_str().parse()?)
        } else {
            crate::resolve::resolve_open_epic(&self.bd, &self.label).await?
        };
        let Some(molecule) = molecule else {
            return Ok(StabilizationOutcome::NoDeferred);
        };
        let summary = crate::mint::promote_deferred(&self.bd, &molecule, false).await;
        for event in summary.routing_events() {
            self.emit_payload(event);
        }
        if summary.refused > 0 {
            let molecule = BeadId::new(molecule.as_str()).map_err(|_| LoopError::Bug {
                context: format!("molecule id `{molecule}` is not a bead id"),
            })?;
            return Ok(StabilizationOutcome::StructuralConflict {
                molecule,
                detail: summary.render(),
            });
        }
        if summary.errors > 0 {
            return Ok(StabilizationOutcome::TransientFailure {
                detail: summary.render(),
            });
        }
        if summary.promoted_deferred == 0 {
            Ok(StabilizationOutcome::NoDeferred)
        } else {
            Ok(StabilizationOutcome::Promoted {
                count: summary.promoted_deferred,
            })
        }
    }

    fn emit_driver_event(&mut self, kind: DriverKind, summary: &str, payload: serde_json::Value) {
        self.emit_to_log(kind, summary, payload);
    }
}

pub struct MoleculeGateHandoff {
    pub evidence: HandoffEvidence,
    pub review_concern: Option<PreviousFailure>,
    pub mint_summary: Option<crate::mint::MintSummary>,
}

/// Executables and global runtime selection used by molecule handoff children.
pub struct MoleculePushGateCommands<'a> {
    review_agent: Option<AgentRuntime>,
    loom_bin: &'a Path,
    wrix_bin: &'a Path,
    manifest: Option<&'a ProfileImageManifest>,
}

impl<'a> MoleculePushGateCommands<'a> {
    pub const fn new(
        review_agent: Option<AgentRuntime>,
        loom_bin: &'a Path,
        wrix_bin: &'a Path,
    ) -> Self {
        Self {
            review_agent,
            loom_bin,
            wrix_bin,
            manifest: None,
        }
    }

    #[must_use]
    pub const fn with_manifest(mut self, manifest: &'a ProfileImageManifest) -> Self {
        self.manifest = Some(manifest);
        self
    }
}

///
/// # Errors
///
/// Returns an error when loop state, agent execution, or gate handling fails.
pub async fn execute_molecule_push_gate<R: CommandRunner>(
    bd: &BdClient<R>,
    label: &SpecLabel,
    selected_molecule: Option<&MoleculeId>,
    commands: MoleculePushGateCommands<'_>,
    workspace: &Path,
    git: &GitClient,
) -> Result<MoleculeGateHandoff, LoopError> {
    let molecule = match selected_molecule {
        Some(molecule) => molecule.clone(),
        None => crate::resolve::resolve_open_epic(bd, label)
            .await?
            .ok_or_else(|| LoopError::NoActiveMolecule {
                label: label.to_string(),
            })?,
    };
    let root = BeadId::new(molecule.as_str())?;
    let initial_molecule_state = if DecisionWaitJournal::new(workspace)
        .blocks_scope(bd, &root)
        .await?
    {
        MoleculeState::Unresolved
    } else {
        molecule_state(bd, &molecule).await?
    };
    if initial_molecule_state != MoleculeState::Clean {
        return Ok(MoleculeGateHandoff {
            evidence: HandoffEvidence {
                molecule_state: initial_molecule_state,
                ..HandoffEvidence::default()
            },
            review_concern: None,
            mint_summary: None,
        });
    }

    git.recover_publication_rebase().await?;
    if !verification_publication_ready(bd, label, &molecule, workspace, git).await? {
        return Ok(MoleculeGateHandoff {
            evidence: HandoffEvidence {
                molecule_state: MoleculeState::Unresolved,
                ..HandoffEvidence::default()
            },
            review_concern: None,
            mint_summary: None,
        });
    }
    let actual = git.prepare_actual_push_range().await?;
    let gate_workspace = git.loom_workspace();
    let diff_range = actual.range.clone();
    let config_digest = pre_commit_config_digest(&gate_workspace)?;
    let hook_coverage = loom_gate::pre_push_hook_coverage_from_config(&gate_workspace)?;
    let verify_log_path = allocate_gate_log_path(&gate_workspace, "push-verify")?;
    let verify_result = git.run_pre_push_chain().await;
    let verify_run = match &verify_result {
        Ok(()) => GateRun::successful_verify(
            diff_range.clone(),
            actual.tree_oid.to_string(),
            config_digest.clone(),
            verify_log_path.clone(),
            hook_coverage,
        ),
        Err(_) => GateRun {
            phase: GatePhase::Verify,
            push_range: diff_range.clone(),
            tree_oid: actual.tree_oid.to_string(),
            config_digest: config_digest.clone(),
            log_path: verify_log_path.clone(),
            exit_code: Some(1),
            status: GateRunStatus::Failed,
            marker: None,
            covered_hooks: Vec::new(),
        },
    };
    append_gate_run_lifecycle_events(&verify_log_path, &verify_run)?;
    if let Err(error) = verify_result {
        let detail = error.to_string();
        append_push_gate_diagnostic(
            &verify_log_path,
            "verify",
            "pre-push verification failed",
            "",
            &detail,
        )?;
        warn!(
            spec = %label,
            error = ?error,
            gate_log_path = %verify_log_path.display(),
            "loom loop: molecule push gate refused by pre-push verification",
        );
        let mut evidence = HandoffEvidence::from_runs(vec![verify_run]);
        evidence.molecule_state = MoleculeState::Clean;
        return Ok(MoleculeGateHandoff {
            evidence,
            review_concern: None,
            mint_summary: None,
        });
    }

    let (review_log_path, phase_when) = allocate_review_log_path(&gate_workspace);
    let phase_when_millis = phase_when
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis());
    let mut review_command = Command::new(commands.loom_bin);
    if let Some(manifest) = commands.manifest {
        manifest.configure_driver(&mut review_command);
    }
    review_command
        .current_dir(&gate_workspace)
        .env(REVIEW_PHASE_WHEN_ENV, phase_when_millis.to_string())
        .env(REVIEW_EMIT_STDOUT_ENV, "1")
        .env(REVIEW_VERIFIED_LOG_ENV, &verify_log_path)
        .env(REVIEW_SPEC_LABEL_ENV, label.as_str());
    append_agent_override(&mut review_command, commands.review_agent);
    if git.uses_host_key() {
        review_command.arg("--host-key");
    }
    let review_output = review_command
        .arg("gate")
        .arg("review")
        .arg("--diff")
        .arg(&diff_range)
        .output()
        .await?;
    let review_status = review_output.status;
    let review_stdout = String::from_utf8_lossy(&review_output.stdout);
    let review_stderr = String::from_utf8_lossy(&review_output.stderr);
    let validator = WorkspaceFindingValidator::new(&gate_workspace);
    let walk = WalkOutput::from_stdout(&review_stdout, DispatchScope::PerBead, &validator);
    let config = LoomConfig::load(LoomConfig::resolve_path(&gate_workspace))?;
    let review_outcome = crate::review::classify_review_phase_with_suppressions(
        &walk,
        review_status.code().unwrap_or(-1),
        &config.suppress,
    );
    let review_admitted =
        review_status.success() && matches!(review_outcome, crate::review::ReviewOutcome::Complete);
    let unsuppressed_findings = walk
        .findings()
        .iter()
        .filter(|finding| !suppresses_rubric_finding(&config.suppress, finding))
        .cloned()
        .collect::<Vec<_>>();
    let bad_walk = walk.bad_walk();
    let suppressed_review_concern = bad_walk.is_none()
        && matches!(walk.terminal(), TerminalSurface::Concern { .. })
        && !walk.findings().is_empty()
        && unsuppressed_findings.is_empty();
    let review_marker = if suppressed_review_concern {
        Some(ExitSignal::Complete)
    } else {
        match walk.decoded() {
            Ok(session) => Some(session.terminal().message.clone()),
            Err(failure) => {
                warn!(error = ?failure, "molecule review output failed canonical admission");
                None
            }
        }
    };
    let review_concern = match (bad_walk, walk.terminal()) {
        (Some(bad_walk), _) => Some(PreviousFailure::BadWalk(bad_walk)),
        (None, TerminalSurface::Concern { summary }) if !unsuppressed_findings.is_empty() => {
            Some(PreviousFailure::ReviewConcern {
                summary: summary.clone(),
                findings: unsuppressed_findings.clone(),
            })
        }
        _ => None,
    };
    let mint_summary = if matches!(review_concern, Some(PreviousFailure::ReviewConcern { .. })) {
        let options = crate::mint::MintOptions {
            suppressions: config.suppress.clone(),
            suppress_closed_same_molecule: true,
            ..crate::mint::MintOptions::default()
        };
        let summary =
            crate::mint::route_molecule_findings(bd, &molecule, &unsuppressed_findings, &options)
                .await;
        if summary.errors > 0 {
            return Err(LoopError::ReviewHandoff {
                detail: summary.render(),
            });
        }
        Some(summary)
    } else {
        None
    };

    let review_runs = parse_gate_runs_from_jsonl(&review_log_path);
    let has_review_run = review_runs.iter().any(|run| run.phase == GatePhase::Review);
    let has_failed_review_run = review_runs
        .iter()
        .any(|run| run.phase == GatePhase::Review && matches!(run.status, GateRunStatus::Failed));
    let review_failure = if !review_status.success() {
        Some(format!(
            "review subprocess exited {}",
            review_status.code().unwrap_or(-1),
        ))
    } else if let crate::review::ReviewOutcome::Incomplete { detail } = &review_outcome {
        Some(detail.clone())
    } else if !has_review_run {
        Some("review subprocess produced no completed gate evidence".to_string())
    } else {
        None
    };
    if let Some(failure) = review_failure.as_deref() {
        if !has_review_run || (!review_admitted && !has_failed_review_run) {
            let failed_review = GateRun {
                phase: GatePhase::Review,
                push_range: diff_range.clone(),
                tree_oid: actual.tree_oid.to_string(),
                config_digest: config_digest.clone(),
                log_path: review_log_path.clone(),
                exit_code: review_status.code(),
                status: GateRunStatus::Failed,
                marker: review_marker.clone(),
                covered_hooks: Vec::new(),
            };
            append_gate_run_lifecycle_events(&review_log_path, &failed_review)?;
        }
        append_push_gate_diagnostic(
            &review_log_path,
            "review",
            failure,
            &review_stdout,
            &review_stderr,
        )?;
    }

    let mut runs = parse_gate_runs_from_jsonl(&verify_log_path);
    runs.extend(
        parse_gate_runs_from_jsonl(&review_log_path)
            .into_iter()
            .map(|mut run| {
                if !review_admitted && run.phase == GatePhase::Review {
                    run.status = GateRunStatus::Failed;
                }
                run
            }),
    );
    let mut evidence = HandoffEvidence::from_runs(runs);
    evidence.molecule_state = if mint_summary.is_some() {
        MoleculeState::Unresolved
    } else {
        MoleculeState::Clean
    };
    evidence.push_range = Some(diff_range.clone());
    evidence.tree_oid = Some(actual.tree_oid.to_string());
    evidence.review_marker = review_marker;
    evidence.review_exit = review_status.code();
    evidence.suppressed_review_concern = suppressed_review_concern;

    if !review_status.success() {
        warn!(
            spec = %label,
            diff = %diff_range,
            exit_code = review_status.code().unwrap_or(-1),
            gate_log_path = %review_log_path.display(),
            stdout_tail = %text_tail(&review_stdout, 4_000),
            stderr_tail = %text_tail(&review_stderr, 4_000),
            "loom loop: molecule push gate refused by review process",
        );
        return Ok(MoleculeGateHandoff {
            evidence,
            review_concern,
            mint_summary,
        });
    }

    let success = match GateSuccess::new(&evidence, 1) {
        Ok(success) => success,
        Err(fail) => {
            info!(
                spec = %label,
                reason = ?fail.reason,
                "loom loop: molecule push gate refused by typed evidence",
            );
            return Ok(MoleculeGateHandoff {
                evidence,
                review_concern,
                mint_summary,
            });
        }
    };
    if workspace
        .join(".git/loom-verification-continuations")
        .try_exists()?
        && (DecisionWaitJournal::new(workspace)
            .blocks_scope(bd, &root)
            .await?
            || molecule_state(bd, &molecule).await? != MoleculeState::Clean
            || !verification_publication_ready(bd, label, &molecule, workspace, git).await?)
    {
        evidence.molecule_state = MoleculeState::Unresolved;
        return Ok(MoleculeGateHandoff {
            evidence,
            review_concern,
            mint_summary,
        });
    }

    MarkerProof::mint(success, &gate_workspace, &SystemClock::new()).map_err(|error| {
        LoopError::ReviewHandoff {
            detail: format!("marker mint failed before push: {error}"),
        }
    })?;
    git.push().await?;
    let beads_output = wrix_beads_push_command(commands.wrix_bin, workspace)
        .output()
        .await?;
    if !beads_output.status.success() {
        return Err(LoopError::ReviewHandoff {
            detail: format!(
                "wrix beads push failed after git push: {}",
                String::from_utf8_lossy(&beads_output.stderr),
            ),
        });
    }
    let association = loom_driver::workspace::Association::resolve(workspace)?;
    let integrated = GitClient::open(&gate_workspace)?;
    for record in association.verification_continuations()? {
        if record.label != *label {
            continue;
        }
        if record
            .root
            .as_ref()
            .is_some_and(|root| root.as_str() != molecule.as_str())
        {
            continue;
        }
        if integrated
            .is_ancestor_of_head(record.candidate.as_str())
            .await?
        {
            association.finish_verification(&record)?;
        }
    }
    Ok(MoleculeGateHandoff {
        evidence,
        review_concern,
        mint_summary,
    })
}

fn wrix_beads_push_command(wrix_bin: &Path, workspace: &Path) -> Command {
    let mut command = Command::new(wrix_bin);
    command.current_dir(workspace).arg("beads").arg("push");
    command
}

fn append_agent_override(command: &mut Command, agent_override: Option<AgentRuntime>) {
    if let Some(agent) = agent_override {
        command.arg("--agent").arg(agent.as_str());
    }
}

async fn molecule_state<R: CommandRunner>(
    bd: &BdClient<R>,
    molecule: &MoleculeId,
) -> Result<MoleculeState, LoopError> {
    let parent = BeadId::new(molecule.as_str()).map_err(|_| LoopError::Bug {
        context: format!("molecule id `{molecule}` is not a bead id"),
    })?;
    let molecule_bead = bd.show(&parent).await?;
    let progress = bd.mol_progress(molecule).await?;
    let beads = bd
        .list(ListOpts {
            all: true,
            limit: Some(0),
            parent: Some(parent),
            ..ListOpts::default()
        })
        .await?;
    if bead_has_parked_state(&molecule_bead)
        || progress.completed < progress.total
        || beads.iter().any(|bead| {
            (bead.status != loom_driver::bd::Status::Closed && bead_has_parked_state(bead))
                || bead
                    .labels
                    .iter()
                    .any(|label| label.as_str() == "loom:decision-wait")
        })
    {
        Ok(MoleculeState::Unresolved)
    } else {
        Ok(MoleculeState::Clean)
    }
}

fn allocate_gate_log_path(workspace: &Path, stem: &str) -> Result<PathBuf, LoopError> {
    let dir = workspace.join(".loom/logs/gate");
    std::fs::create_dir_all(&dir)?;
    let nanos = SystemClock::new()
        .wall_now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos());
    for suffix in 0..1000_u16 {
        let name = if suffix == 0 {
            format!("{stem}-{nanos}.jsonl")
        } else {
            format!("{stem}-{nanos}-{suffix}.jsonl")
        };
        let path = dir.join(name);
        match std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)
        {
            Ok(file) => {
                drop(file);
                return Ok(path);
            }
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => {}
            Err(error) => return Err(error.into()),
        }
    }
    Err(std::io::Error::new(
        std::io::ErrorKind::AlreadyExists,
        "could not allocate a unique molecule gate log",
    )
    .into())
}

fn allocate_review_log_path(workspace: &Path) -> (PathBuf, std::time::SystemTime) {
    let logs_root = workspace.join(".loom/logs");
    let mut phase_when = SystemClock::new().wall_now();
    let mut path = phase_log_path(&logs_root, "review", phase_when);
    while path.exists() {
        phase_when += Duration::from_secs(1);
        path = phase_log_path(&logs_root, "review", phase_when);
    }
    (path, phase_when)
}

async fn verification_publication_ready<R: CommandRunner>(
    bd: &BdClient<R>,
    label: &SpecLabel,
    molecule: &MoleculeId,
    workspace: &Path,
    git: &GitClient,
) -> Result<bool, LoopError> {
    if !workspace
        .join(".git/loom-verification-continuations")
        .try_exists()?
    {
        return Ok(true);
    }
    let association = loom_driver::workspace::Association::resolve(workspace)?;
    for record in association.verification_continuations()? {
        let integrated = GitClient::open(git.loom_workspace())?
            .is_ancestor_of_head(record.candidate.as_str())
            .await?;
        let selected = record.label == *label
            && record
                .root
                .as_ref()
                .is_none_or(|root| root.as_str() == molecule.as_str());
        if integrated && !record.needs_source_repair() {
            association.validate_verification(&record)?;
            let pin = format!(
                "refs/loom/verification/{}/{}",
                record.bead, record.candidate
            );
            if loom_driver::git::sync_rev_parse(&git.loom_workspace(), &pin)? != record.candidate {
                return Err(LoopError::Bug {
                    context: "publication continuation candidate pin changed".into(),
                });
            }
        }
        if (selected && (!integrated || record.needs_source_repair()))
            || (integrated
                && (record.needs_source_repair()
                    || verification_source(bd, workspace, &record.bead)
                        .await?
                        .is_none_or(|source| source.status != loom_driver::bd::Status::Closed)))
        {
            return Ok(false);
        }
    }
    Ok(true)
}

pub(super) async fn verification_source<R: CommandRunner>(
    bd: &BdClient<R>,
    workspace: &Path,
    id: &BeadId,
) -> Result<Option<Bead>, LoopError> {
    let (source, dependencies) = bd.show_with_dependencies(id).await?;
    if source.id != *id {
        return Err(LoopError::Bug {
            context: "native verification response identifies a different bead".into(),
        });
    }
    let mut guard_source = source.clone();
    if source.status == loom_driver::bd::Status::Blocked
        && source.labels.iter().any(loom_driver::bd::Label::is_infra)
        && source
            .metadata
            .get("loom.infra.phase")
            .is_some_and(|phase| phase == "loop")
        && workspace
            .join(".git/loom-verification-continuations")
            .try_exists()?
    {
        let association = loom_driver::workspace::Association::resolve(workspace)?;
        if association
            .verification_continuations()?
            .iter()
            .any(|record| {
                record.bead == *id
                    && record.needs_source_repair()
                    && record.parked_cause.as_ref().is_some_and(|cause| {
                        source
                            .metadata
                            .get("loom.infra.cause")
                            .and_then(serde_json::Value::as_str)
                            == Some(cause.as_str())
                    })
            })
        {
            guard_source.status = loom_driver::bd::Status::Open;
            guard_source.labels.retain(|label| !label.is_infra());
        }
    }
    if verification_has_independent_hold(&guard_source)
        || !dependencies.active_blockers().is_empty()
        || held(bd, &DecisionWaitJournal::new(workspace), &source).await?
    {
        return Ok(None);
    }
    Ok(Some(source))
}

pub(super) fn verification_has_independent_hold(bead: &Bead) -> bool {
    use loom_driver::bd::Status;
    if bead
        .labels
        .iter()
        .any(|label| label.is_blocked() || label.is_clarify() || label.is_deferred())
        || matches!(
            bead.status,
            Status::Deferred | Status::Pinned | Status::Tombstone
        )
    {
        return true;
    }
    let infra = bead.labels.iter().any(loom_driver::bd::Label::is_infra);
    if !infra {
        return bead.status == Status::Blocked;
    }
    bead.status != Status::Blocked
        || bead
            .metadata
            .get("loom.infra.phase")
            .and_then(serde_json::Value::as_str)
            != Some("loop")
        || !matches!(
            bead.metadata
                .get("loom.infra.cause")
                .and_then(serde_json::Value::as_str),
            Some(
                super::runner::VERIFICATION_CAPABILITY_UNAVAILABLE_CAUSE
                    | "verification-continuation-unavailable"
            )
        )
}

fn bead_has_parked_state(bead: &Bead) -> bool {
    bead.status == loom_driver::bd::Status::Blocked
        || bead.labels.iter().any(|label| {
            label.is_blocked() || label.is_clarify() || label.is_deferred() || label.is_infra()
        })
}

fn append_push_gate_diagnostic(
    path: &Path,
    phase: &str,
    summary: &str,
    stdout: &str,
    stderr: &str,
) -> Result<(), LoopError> {
    use std::io::Write as _;

    let contents = std::fs::read_to_string(path)?;
    let last_event = contents
        .lines()
        .rev()
        .find_map(|line| serde_json::from_str::<AgentEvent>(line).ok())
        .ok_or_else(|| LoopError::Io(std::io::Error::other("gate log has no event envelope")))?;
    let envelope = last_event.envelope();
    let clock = SystemClock::new();
    let mut builder = EnvelopeBuilder::with_seq_start(
        SessionScope::phase(envelope.session_id.clone(), envelope.molecule_id.clone()),
        Source::Driver,
        envelope.seq + 1,
        move || {
            clock
                .wall_now()
                .duration_since(UNIX_EPOCH)
                .map_or(0, |duration| {
                    i64::try_from(duration.as_millis()).unwrap_or(i64::MAX)
                })
        },
    );
    let event = AgentEvent::DriverEvent {
        envelope: builder.build(),
        driver_kind: DriverKind::VerdictGate,
        summary: summary.to_string(),
        payload: serde_json::json!({
            "phase": phase,
            "summary": summary,
            "stdout_tail": text_tail(stdout, 4_000),
            "stderr_tail": text_tail(stderr, 4_000),
            "log_path": path.to_string_lossy(),
        }),
    };
    let mut file = std::fs::OpenOptions::new().append(true).open(path)?;
    serde_json::to_writer(&mut file, &event).map_err(std::io::Error::other)?;
    writeln!(&mut file)?;
    file.flush()?;
    Ok(())
}

fn text_tail(text: &str, max_chars: usize) -> String {
    let start = text
        .char_indices()
        .rev()
        .nth(max_chars.saturating_sub(1))
        .map_or(0, |(index, _)| index);
    text[start..].to_string()
}

fn diagnostic_notes(cause: &str, error: &str) -> String {
    if error.is_empty() {
        cause.to_string()
    } else {
        format!("{cause}: {error}")
    }
}

fn gate_log_root(logs_root: Option<&std::path::Path>, workspace: &std::path::Path) -> PathBuf {
    logs_root.map_or_else(
        || workspace.join(".loom/logs/gate"),
        |root| root.join("gate"),
    )
}

fn pre_commit_config_digest(workspace: &std::path::Path) -> Result<String, LoopError> {
    let path = workspace.join(".pre-commit-config.yaml");
    let bytes = match std::fs::read(path) {
        Ok(bytes) => bytes,
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Vec::new(),
        Err(error) => return Err(error.into()),
    };
    Ok(blake3::hash(&bytes).to_hex().to_string())
}

fn write_post_integrate_gate_log(
    dir: &Path,
    record: &PostIntegrateGateLog,
) -> Result<PathBuf, LoopError> {
    std::fs::create_dir_all(dir)?;
    let clock = SystemClock::new();
    let stamp = clock
        .wall_now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos());
    let stem = format!(
        "{}-attempt-{}-{stamp}",
        record.bead_id.as_str(),
        record.retry_attempt,
    );
    for suffix in 0..1000_u16 {
        let file_name = if suffix == 0 {
            format!("{stem}.jsonl")
        } else {
            format!("{stem}-{suffix}.jsonl")
        };
        let path = dir.join(file_name);
        let file = match std::fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)
        {
            Ok(file) => file,
            Err(err) if err.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(err) => return Err(LoopError::Io(err)),
        };
        drop(file);
        let run = GateRun {
            phase: GatePhase::Verify,
            push_range: record.scope.clone(),
            tree_oid: record.tree_oid.clone(),
            config_digest: record.config_digest.clone(),
            log_path: path.clone(),
            exit_code: Some(record.exit_code),
            status: GateRunStatus::Failed,
            marker: record.terminal_marker.clone(),
            covered_hooks: Vec::new(),
        };
        append_gate_run_lifecycle_events(&path, &run)?;
        append_post_integrate_diagnostics(&path, record)?;
        return Ok(path);
    }
    Err(LoopError::Io(std::io::Error::new(
        std::io::ErrorKind::AlreadyExists,
        "could not allocate unique post-integrate gate log path",
    )))
}

struct PostIntegrateGateLog {
    argv: Vec<String>,
    scope: String,
    exit_code: i32,
    stdout: String,
    stderr: String,
    terminal_marker: Option<ExitSignal>,
    integration_sha: String,
    tree_oid: String,
    config_digest: String,
    bead_id: BeadId,
    retry_attempt: u32,
    rollback_state: &'static str,
    failures: Vec<VerifierFailure>,
}

fn append_post_integrate_diagnostics(
    path: &std::path::Path,
    record: &PostIntegrateGateLog,
) -> Result<(), LoopError> {
    use std::io::Write as _;

    let contents = std::fs::read_to_string(path)?;
    let last_line = contents
        .lines()
        .next_back()
        .ok_or_else(|| std::io::Error::other("gate lifecycle log did not contain an event"))?;
    let last_event = serde_json::from_str::<AgentEvent>(last_line)
        .map_err(|error| std::io::Error::other(error.to_string()))?;
    let last_envelope = last_event.envelope();
    let clock = SystemClock::new();
    let mut builder = EnvelopeBuilder::with_seq_start(
        SessionScope::phase(
            last_envelope.session_id.clone(),
            last_envelope.molecule_id.clone(),
        ),
        Source::Driver,
        last_envelope.seq + 1,
        move || {
            clock
                .wall_now()
                .duration_since(UNIX_EPOCH)
                .map_or(0, |duration| {
                    i64::try_from(duration.as_millis()).unwrap_or(i64::MAX)
                })
        },
    );
    let failures = record
        .failures
        .iter()
        .map(|failure| {
            serde_json::json!({
                "target": failure.target,
                "exit_code": failure.exit_code,
                "stderr_tail": failure.stderr_tail,
            })
        })
        .collect::<Vec<_>>();
    let event = AgentEvent::DriverEvent {
        envelope: builder.build(),
        driver_kind: DriverKind::VerdictGate,
        summary: format!("post-integration verify failed for bead {}", record.bead_id),
        payload: serde_json::json!({
            "phase": "post_integrate_verify",
            "argv": record.argv,
            "scope_flag": "--diff",
            "scope": record.scope,
            "exit_code": record.exit_code,
            "stdout": record.stdout,
            "stderr": record.stderr,
            "terminal_marker": record.terminal_marker.as_ref().map(terminal_marker_json),
            "integration_sha": record.integration_sha,
            "bead_id": record.bead_id.to_string(),
            "retry_attempt": record.retry_attempt,
            "rollback_state": record.rollback_state,
            "failures": failures,
            "log_path": path.to_string_lossy(),
        }),
    };
    let mut file = std::fs::OpenOptions::new().append(true).open(path)?;
    serde_json::to_writer(&mut file, &event).map_err(std::io::Error::other)?;
    writeln!(&mut file)?;
    file.flush()?;
    file.sync_all()?;
    Ok(())
}

fn terminal_marker_json(marker: &ExitSignal) -> serde_json::Value {
    match marker {
        ExitSignal::Complete => serde_json::json!({ "kind": "complete" }),
        ExitSignal::Noop => serde_json::json!({ "kind": "noop" }),
        ExitSignal::Waiting => serde_json::json!({ "kind": "waiting" }),
        ExitSignal::Blocked(payload) => {
            serde_json::json!({ "kind": "blocked", "reason": payload.reason })
        }
        ExitSignal::Clarify(payload) => {
            serde_json::json!({ "kind": "clarify", "decisions": payload.decisions })
        }
        ExitSignal::Retry(payload) => {
            serde_json::json!({ "kind": "retry", "reason": payload.reason })
        }
        ExitSignal::Concern(payload) => {
            serde_json::json!({ "kind": "concern", "summary": payload.summary })
        }
        message => serde_json::json!({ "kind": "wrong-phase", "marker": message.marker() }),
    }
}

/// Render the operator-facing note body for the `unknown-profile`
/// blocked-cause path.
///
/// Names the requested label as it appears on the
/// bead (`profile:X`) and the manifest's declared set in the same form,
/// so the human can relabel the bead without re-reading the manifest.
pub fn format_unknown_profile_error(
    requested: &ProfileName,
    manifest: &ProfileImageManifest,
) -> String {
    let declared: Vec<String> = manifest
        .declared_profiles()
        .map(|p| format!("profile:{p}"))
        .collect();
    let declared_part = if declared.is_empty() {
        "manifest declares no profiles".to_string()
    } else {
        format!("manifest declares: {}", declared.join(", "))
    };
    format!("requested profile:{requested} not declared; {declared_part}")
}

pub fn format_unknown_runtime_for_profile_error(
    profile: &ProfileName,
    runtime: AgentRuntime,
    declared_runtimes: &[AgentRuntime],
) -> String {
    let declared: Vec<String> = declared_runtimes
        .iter()
        .map(|runtime| runtime.as_str().to_string())
        .collect();
    let declared_part = if declared.is_empty() {
        format!("profile:{profile} declares no runtimes")
    } else {
        format!(
            "profile:{profile} declares runtimes: {}",
            declared.join(", ")
        )
    };
    format!("requested profile:{profile} runtime:{runtime} not declared; {declared_part}")
}

const fn session_exit_code(session: &SessionResult) -> Option<i32> {
    match session {
        SessionResult::Complete(outcome) | SessionResult::Decoded { outcome, .. } => {
            Some(outcome.exit_code)
        }
        SessionResult::PreflightFailed { .. }
        | SessionResult::MidSessionFailed { .. }
        | SessionResult::StaticInfra { .. }
        | SessionResult::ObserverAbort { .. } => None,
    }
}

pub(super) fn marker_name(marker: Option<&ExitSignal>) -> &'static str {
    marker.map_or("missing", ExitSignal::identity)
}

pub(super) const fn agent_outcome_route(outcome: &AgentOutcome) -> &'static str {
    match outcome {
        AgentOutcome::Success => "success",
        AgentOutcome::Noop => "noop",
        AgentOutcome::WaitingRequested => "waiting-unvalidated",
        AgentOutcome::Waiting { .. } => "waiting",
        AgentOutcome::Failure { .. } | AgentOutcome::ZeroProgress { .. } => "recovery",
        AgentOutcome::Retry { .. } => "retry",
        AgentOutcome::Blocked { .. } | AgentOutcome::SignatureVerificationFailed { .. } => {
            "blocked"
        }
        AgentOutcome::Clarify { .. } => "clarify",
        AgentOutcome::IntegrationConflict { .. } => "integration-conflict-retry",
        AgentOutcome::InfraPreflight { .. } | AgentOutcome::InfraMidSession { .. } => "infra-retry",
        AgentOutcome::StaticInfra { .. }
        | AgentOutcome::UnknownProfile { .. }
        | AgentOutcome::UnknownRuntimeForProfile { .. } => "infra-blocked",
    }
}

/// Translate a `(SessionResult, Option<ExitSignal>)` pair into an
/// [`AgentOutcome`].
///
/// Marker → outcome routing goes through the canonical
/// [`crate::review::decide`] gate function (FR12 — single source of truth);
/// `bd_closed` / `diff_empty` / verify / review observables are not queried
/// at the per-bead exit (they belong to `loom gate verify`'s deterministic
/// pass), so neutral inputs are passed and the gate's output reduces to
/// marker-only routing. A defensive guard for `LOOM_COMPLETE`/`LOOM_NOOP`
/// paired with a non-zero exit code predates the gate call because the
/// spec's decision table does not consider exit code: a marker that
/// disagrees with the kernel's view is surfaced as a failure rather than
/// trusted blindly.
pub fn classify_session(session: SessionResult, marker: Option<&ExitSignal>) -> AgentOutcome {
    match session {
        SessionResult::Decoded { outcome, output } => match output.as_ref() {
            Ok(admitted) => classify_session(
                SessionResult::Complete(outcome),
                Some(&admitted.terminal().message),
            ),
            Err(failure) => AgentOutcome::Failure {
                error: format!(
                    "agent output failed canonical admission (exit {}): {failure:?}",
                    outcome.exit_code
                ),
            },
        },
        SessionResult::PreflightFailed { error } => AgentOutcome::InfraPreflight { error },
        SessionResult::MidSessionFailed { error } => AgentOutcome::InfraMidSession { error },
        SessionResult::StaticInfra { cause, error } => AgentOutcome::StaticInfra { cause, error },
        SessionResult::ObserverAbort { reason } => verdict_to_outcome(
            PhaseVerdict::Recovery {
                cause: RecoveryCause::ObserverAbort { reason },
            },
            0,
        ),
        SessionResult::Complete(outcome) => {
            if let Some(message) = marker
                && (!loom_protocol::output::Phase::Loop.admits(message)
                    || message.role() != loom_protocol::output::Role::Terminal)
            {
                return AgentOutcome::Failure {
                    error: format!(
                        "wrong-phase-marker: {} is not a loop terminal: {message:?}",
                        message.marker()
                    ),
                };
            }
            if let Some(marker @ (ExitSignal::Complete | ExitSignal::Noop | ExitSignal::Waiting)) =
                marker
                && outcome.exit_code != 0
            {
                return AgentOutcome::Failure {
                    error: format!(
                        "agent emitted {} but exited code {}",
                        marker.identity(),
                        outcome.exit_code,
                    ),
                };
            }
            verdict_to_outcome(decide(marker, neutral_gate_inputs()), outcome.exit_code)
        }
    }
}

/// Inputs threaded into [`decide`] when classifying the per-bead exit. The
/// run-phase classifier only knows the marker; bd-closed, diff, verify, and
/// review live in `loom gate verify`'s downstream pass. Passing neutral
/// defaults reduces the gate to marker-only routing — the spec table rows
/// for `COMPLETE`/`NOOP` collapse to `Done` and `None` to `SwallowedMarker`,
/// which is what the in-session classifier needs.
fn neutral_gate_inputs() -> GateInputs {
    GateInputs {
        bd_closed: true,
        diff_empty: false,
        verify_failures: vec![],
        ..GateInputs::default()
    }
}

fn verdict_to_outcome(verdict: PhaseVerdict, exit_code: i32) -> AgentOutcome {
    match verdict {
        PhaseVerdict::Done => AgentOutcome::Success,
        PhaseVerdict::Waiting => AgentOutcome::WaitingRequested,
        PhaseVerdict::Blocked { reason } => AgentOutcome::Blocked { reason },
        PhaseVerdict::Clarify { question } => AgentOutcome::Clarify { question },
        PhaseVerdict::Recovery {
            cause: RecoveryCause::SwallowedMarker,
        } => AgentOutcome::Failure {
            error: if exit_code == 0 {
                "agent exited 0 without LOOM_COMPLETE / LOOM_NOOP / LOOM_WAITING / \
                 LOOM_RETRY / LOOM_BLOCKED terminal (swallowed marker)"
                    .to_string()
            } else {
                format!("agent exited with code {exit_code}")
            },
        },
        PhaseVerdict::Recovery {
            cause: RecoveryCause::ObserverAbort { reason },
        } => AgentOutcome::Failure {
            error: format!("Session aborted by observer: {reason}."),
        },
        PhaseVerdict::Recovery {
            cause: RecoveryCause::AgentRetry { reason },
        } => AgentOutcome::Retry { reason },
        PhaseVerdict::Recovery {
            cause:
                RecoveryCause::WrongPhaseMarker {
                    marker_name,
                    phase_kind,
                },
        } => AgentOutcome::Failure {
            error: format!(
                "wrong-phase-marker: {marker_name} is not admitted in {phase_kind} phases",
            ),
        },
        PhaseVerdict::Recovery { cause } => AgentOutcome::Failure {
            error: format!("unexpected gate verdict: {}", cause.as_str()),
        },
    }
}

/// Helper used by `main.rs` to fetch the spec-filtered open list when the
/// caller needs the typed [`Bead`] slice (e.g. to print a status line).
///
/// Surfacing this here keeps the `BdClient` list-shape next to the controller.
///
/// # Errors
///
/// Returns an error when loop state, agent execution, or gate handling fails.
pub async fn list_open_for_spec(bd: &BdClient, label: &SpecLabel) -> Result<Vec<Bead>, LoopError> {
    let beads = bd
        .list(ListOpts {
            statuses: vec![loom_driver::bd::Status::Open],
            label: Some(format!("spec:{}", label.as_str())),
            ..ListOpts::default()
        })
        .await?;
    Ok(beads)
}

#[cfg(test)]
mod tests {
    mod decision_inventory;
    mod native_waits;
    use super::super::runner::MISSING_AGENT_BINARY_CAUSE;
    use super::*;
    use crate::r#loop::INVALID_SPAWN_CONFIG_CAUSE;
    use loom_driver::agent::SessionOutcome;
    use loom_driver::bd::{BdError, Label, RunOutput};
    use loom_driver::git::BeadCloneAlignment;
    use std::collections::VecDeque;
    use std::ffi::OsString;
    use std::sync::Mutex;
    use std::time::{Duration, SystemTime};

    /// Replays a scripted sequence of `bd` responses so the controller's
    /// `exec_review` can resolve the active molecule's `loom.base_commit`
    /// without spawning the real `bd` binary. Each entry feeds one
    /// `BdClient` call in order.
    struct ScriptedBd {
        responses: Mutex<VecDeque<RunOutput>>,
        /// Capture handle shared with the test, so an `Arc::clone` snapshot
        /// is held while the inner `ScriptedBd` is moved into `BdClient`.
        calls: Arc<Mutex<Vec<Vec<OsString>>>>,
    }

    impl ScriptedBd {
        fn new(responses: impl IntoIterator<Item = RunOutput>) -> Self {
            Self {
                responses: Mutex::new(responses.into_iter().collect()),
                calls: Arc::new(Mutex::new(Vec::new())),
            }
        }

        fn calls_handle(&self) -> Arc<Mutex<Vec<Vec<OsString>>>> {
            Arc::clone(&self.calls)
        }
    }

    impl CommandRunner for ScriptedBd {
        async fn run(&self, args: Vec<OsString>, _timeout: Duration) -> Result<RunOutput, BdError> {
            self.calls.lock().unwrap().push(args);
            Ok(self
                .responses
                .lock()
                .unwrap()
                .pop_front()
                .unwrap_or_else(|| RunOutput {
                    status: 0,
                    stdout: b"null\n".to_vec(),
                    stderr: Vec::new(),
                }))
        }
    }

    fn ok_stdout(stdout: &[u8]) -> RunOutput {
        RunOutput {
            status: 0,
            stdout: stdout.to_vec(),
            stderr: Vec::new(),
        }
    }

    fn seed_spec(workspace: &std::path::Path, label: &str) {
        loom_test_support::acceptance::write(workspace, label).unwrap();
    }

    /// Return a `ScriptedBd` that resolves one active molecule and has
    /// enough successful responses for a single deferred review finding to
    /// travel through the live molecule-routing seam.
    fn molecule_lookup_script(
        _workspace: &std::path::Path,
        spec_label: &str,
        mol_id: &str,
        base: &str,
    ) -> ScriptedBd {
        let body = format!(
            r#"[{{
                "id": "{mol_id}",
                "title": "{spec_label}: pending decomposition",
                "status": "open",
                "priority": 2,
                "issue_type": "epic",
                "labels": ["spec:{spec_label}"],
                "metadata": {{ "loom.base_commit": "{base}" }}
            }}]"#,
        );
        let progress =
            r#"{"molecule_id":"lm-3hhwq","completed":1,"in_progress":0,"total":1,"percent":100.0}"#;
        ScriptedBd::new([
            ok_stdout(body.as_bytes()),
            ok_stdout(body.as_bytes()),
            ok_stdout(progress.as_bytes()),
            ok_stdout(b"[]"),
            ok_stdout(body.as_bytes()),
            ok_stdout(b"[]"),
            ok_stdout(b"[]"),
            ok_stdout(b"[]"),
            ok_stdout(b"lm-routed.1\n"),
            ok_stdout(b""),
            ok_stdout(b""),
        ])
    }

    /// FR12 — `loom loop`'s per-bead exit MUST route the agent's marker
    /// through the canonical [`crate::review::decide`] gate function rather
    /// than its own ad-hoc `match`. This test pins the marker → outcome
    /// mapping that `decide()` produces under neutral run-phase inputs:
    /// `BLOCKED`/`CLARIFY` short-circuit, `COMPLETE`/`NOOP` reach Done, and
    /// a missing marker routes to `swallowed-marker` recovery (mapped to
    /// `Failure`). A regression that resurrects an inline classifier here
    /// would only fail this test if it diverged from `decide()`'s output —
    /// but combined with the source-level `decide()` import in
    /// `classify_session`, the two together fence the FR12 contract.
    #[test]
    fn classify_session_routes_marker_through_phase_verdict_decide() {
        let session_ok = || {
            SessionResult::Complete(SessionOutcome {
                exit_code: 0,
                cost_usd: None,
            })
        };
        // `BLOCKED` self-report → terminal `Blocked` (gate row 1).
        match classify_session(
            session_ok(),
            Some(&ExitSignal::Blocked(loom_protocol::output::Reason {
                reason: loom_protocol::todo::NonEmptyString::new("missing schema").unwrap(),
            })),
        ) {
            AgentOutcome::Blocked { reason } => assert_eq!(reason, "missing schema"),
            other => panic!("expected Blocked, got {other:?}"),
        }
        let record = ExitSignal::Clarify(loom_protocol::output::Decisions {
            decisions: loom_protocol::todo::NonEmptyVec::new(vec!["lm-decision".parse().unwrap()])
                .unwrap(),
        });
        assert!(matches!(
            classify_session(session_ok(), Some(&record)),
            AgentOutcome::Failure { .. }
        ));
        // `COMPLETE` + clean exit → `Success` (gate row "Done" with neutral inputs).
        assert_eq!(
            classify_session(session_ok(), Some(&ExitSignal::Complete)),
            AgentOutcome::Success,
        );
        // `NOOP` + clean exit → `Success` (gate row "Done" with neutral inputs).
        assert_eq!(
            classify_session(session_ok(), Some(&ExitSignal::Noop)),
            AgentOutcome::Success,
        );
        // None marker → `Recovery::SwallowedMarker` → `Failure` carrying
        // the spec's swallowed-marker phrasing.
        match classify_session(session_ok(), None) {
            AgentOutcome::Failure { error } => assert!(
                error.contains("swallowed marker"),
                "swallowed-marker text missing: {error}",
            ),
            other => panic!("expected Failure, got {other:?}"),
        }
    }

    #[test]
    fn agent_stream_failure_classifier_distinguishes_preflight_interrupted_and_blocked() {
        let outcomes = [
            classify_session(
                SessionResult::PreflightFailed {
                    error: "unexpected EOF before first agent event".to_string(),
                },
                None,
            ),
            classify_session(
                SessionResult::MidSessionFailed {
                    error: "unexpected EOF after text_delta".to_string(),
                },
                None,
            ),
            classify_session(
                SessionResult::Complete(SessionOutcome {
                    exit_code: 0,
                    cost_usd: None,
                }),
                Some(&ExitSignal::Blocked(loom_protocol::output::Reason {
                    reason: loom_protocol::todo::NonEmptyString::new(
                        "semantic dead end with no safe options",
                    )
                    .unwrap(),
                })),
            ),
        ];

        assert!(
            matches!(
                &outcomes[0],
                AgentOutcome::InfraPreflight { error }
                    if error == "unexpected EOF before first agent event"
            ),
            "preflight EOF must stay retryable infra: {:?}",
            outcomes[0]
        );
        assert!(
            matches!(
                &outcomes[1],
                AgentOutcome::InfraMidSession { error }
                    if error == "unexpected EOF after text_delta"
            ),
            "interrupted EOF must stay retryable infra: {:?}",
            outcomes[1]
        );
        assert!(
            matches!(
                &outcomes[2],
                AgentOutcome::Blocked { reason }
                    if reason == "semantic dead end with no safe options"
            ),
            "LOOM_BLOCKED must remain semantic: {:?}",
            outcomes[2]
        );
    }

    #[test]
    fn classify_session_preserves_static_infra_cause() {
        let outcome = classify_session(
            SessionResult::StaticInfra {
                cause: MISSING_AGENT_BINARY_CAUSE.to_string(),
                error: "agent process exited with code 127".into(),
            },
            None,
        );

        match outcome {
            AgentOutcome::StaticInfra { cause, error } => {
                assert_eq!(cause, MISSING_AGENT_BINARY_CAUSE);
                assert!(error.contains("code 127"));
            }
            other => panic!("expected StaticInfra, got {other:?}"),
        }
    }

    /// Spec gate (§"Marker definitions"): `LOOM_CONCERN` is
    /// review-phase-only. The run phase emitting it is a
    /// `wrong-phase-marker` error — neither `Success` nor a generic
    /// swallowed-marker; the detail names the concern token so triage can
    /// see which path the agent tried to flag.
    #[test]
    fn concern_marker_in_run_phase_is_wrong_phase_marker_failure() {
        let session = SessionResult::Complete(SessionOutcome {
            exit_code: 0,
            cost_usd: None,
        });
        match classify_session(
            session,
            Some(&ExitSignal::Concern(loom_protocol::output::Summary {
                summary: loom_protocol::todo::NonEmptyString::new(
                    "verifier-bypass on the agent backend mock",
                )
                .unwrap(),
            })),
        ) {
            AgentOutcome::Failure { error } => {
                assert!(
                    error.contains("wrong-phase-marker"),
                    "wrong-phase-marker prefix missing: {error}",
                );
                assert!(
                    error.contains("LOOM_CONCERN"),
                    "marker name must appear in error: {error}",
                );
                assert!(
                    error.contains("verifier-bypass"),
                    "concern token must appear in error: {error}",
                );
            }
            other => panic!("expected Failure, got {other:?}"),
        }
    }

    /// Spec gate (§"Disambiguating no marker"): a session aborted by an
    /// observer's `SessionCommand::Abort` must classify as `observer-abort`
    /// rather than `swallowed-marker`, even though no exit marker was
    /// emitted. The detail string must carry the observer's verbatim
    /// reason so human triage sees what tripped the kill. The two branches
    /// — observer-aborted vs. plain no-marker — share the same `marker=None`
    /// input, so distinctness is the load-bearing property: the choice of
    /// recovery cause must come from the `SessionResult` discriminator, not
    /// the marker shape.
    #[test]
    fn observer_abort_routes_to_observer_abort_distinct_from_swallowed_marker() {
        let observer_session = SessionResult::ObserverAbort {
            reason: "doom-loop: 3 identical tool calls".into(),
        };
        let observer_error = match classify_session(observer_session, None) {
            AgentOutcome::Failure { error } => error,
            other => panic!("expected Failure for ObserverAbort, got {other:?}"),
        };
        assert!(
            observer_error.contains("Session aborted by observer"),
            "observer-abort error must carry the spec format prefix: {observer_error}",
        );
        assert!(
            observer_error.contains("doom-loop: 3 identical tool calls"),
            "observer-abort error must preserve verbatim observer reason: {observer_error}",
        );
        assert!(
            !observer_error.contains("swallowed marker"),
            "observer-abort must NOT degrade to swallowed-marker: {observer_error}",
        );

        let plain_session = SessionResult::Complete(SessionOutcome {
            exit_code: 0,
            cost_usd: None,
        });
        let plain_error = match classify_session(plain_session, None) {
            AgentOutcome::Failure { error } => error,
            other => panic!("expected Failure for marker-less Complete, got {other:?}"),
        };
        assert!(
            plain_error.contains("swallowed marker"),
            "marker-less Complete must route to swallowed-marker: {plain_error}",
        );
        assert!(
            !plain_error.contains("Session aborted by observer"),
            "swallowed-marker must NOT borrow observer-abort phrasing: {plain_error}",
        );

        assert_ne!(
            observer_error, plain_error,
            "observer-abort and swallowed-marker must yield distinct error bodies under marker=None",
        );
    }

    fn write_manifest(dir: &std::path::Path) -> Arc<ProfileImageManifest> {
        let body = r#"{
          "base": { "pi": { "ref": "localhost/wrix-base-pi:abc", "source": "/nix/store/aaa-image-base-pi", "source_kind": "nix-descriptor" }, "claude": { "ref": "localhost/wrix-base-claude:abc", "source": "/nix/store/aaa-image-base-claude", "source_kind": "nix-descriptor" }, "direct": { "ref": "localhost/wrix-base-direct:abc", "source": "/nix/store/aaa-image-base-direct", "source_kind": "nix-descriptor" } }
        }"#;
        let path = dir.join("profile-images.json");
        loom_test_support::profile_manifest::write(
            &path,
            body,
            std::path::Path::new("/fixture/wrix"),
        )
        .expect("write manifest");
        Arc::new(ProfileImageManifest::from_path(&path).expect("parse manifest"))
    }

    /// Initialize a git repository at `workspace` (creating the directory if
    /// missing) and open a [`GitClient`] rooted there. Used by every
    /// controller-construction site so `run_bead`'s per-bead worktree
    /// dispatch has a real repo to bind against.
    fn git_workspace(workspace: &std::path::Path) -> loom_driver::git::GitClient {
        let git =
            loom_driver::git::init_test_repo_with_integration(workspace).expect("init test repo");
        loom_test_support::acceptance::seed_repository(workspace).unwrap();
        let policy = loom_driver::git::RepoGitPolicy::resolve(
            workspace,
            "unused-wrix".into(),
            loom_driver::git::KeyMode::Host,
        )
        .expect("explicit host-key policy");
        git.with_repo_git_policy(policy)
    }

    fn bead(id: &str) -> Bead {
        Bead {
            id: BeadId::new(id).expect("valid bead id"),
            title: format!("title-{id}"),
            description: "desc".into(),
            status: loom_driver::bd::Status::Open,
            priority: loom_driver::bd::Priority::P2,
            issue_type: loom_driver::bd::IssueType::Task,
            labels: vec![Label::new("profile:base").expect("valid Label")],
            parent: None,
            metadata: [(
                loom_protocol::acceptance::METADATA_KEY.to_owned(),
                loom_test_support::acceptance::metadata("harness").unwrap(),
            )]
            .into(),
            notes: None,
        }
    }

    #[test]
    fn review_subprocess_inherits_agent_override() {
        let mut command = Command::new("loom");
        append_agent_override(&mut command, Some(AgentRuntime::Pi));
        command.arg("gate").arg("review");

        let args = command
            .as_std()
            .get_args()
            .map(|arg| arg.to_string_lossy().into_owned())
            .collect::<Vec<_>>();
        assert_eq!(args, ["--agent", "pi", "gate", "review"]);

        let mut configured_command = Command::new("loom");
        append_agent_override(&mut configured_command, None);
        assert!(configured_command.as_std().get_args().next().is_none());
    }

    #[test]
    fn molecule_handoff_publishes_beads_through_wrix_cli() {
        let command = wrix_beads_push_command(Path::new("wrix"), Path::new("/workspace"));
        let std_command = command.as_std();
        assert_eq!(std_command.get_program(), "wrix");
        assert_eq!(
            std_command
                .get_args()
                .map(|arg| arg.to_string_lossy().into_owned())
                .collect::<Vec<_>>(),
            ["beads", "push"],
        );
        assert_eq!(std_command.get_current_dir(), Some(Path::new("/workspace")));
    }

    #[tokio::test]
    async fn clarify_or_infra_present_stops_without_pushing() {
        for label in ["loom:clarify", "loom:infra"] {
            let dir = tempfile::tempdir().expect("tempdir");
            let workspace = dir.path().to_path_buf();
            let git = git_workspace(&workspace);
            let epic = br#"[{
                "id": "lm-held",
                "title": "held molecule",
                "status": "open",
                "priority": 2,
                "issue_type": "epic",
                "labels": ["spec:alpha"]
            }]"#;
            let child = format!(
                r#"[{{
                    "id": "lm-held.1",
                    "title": "held molecule work",
                    "status": "blocked",
                    "priority": 2,
                    "issue_type": "task",
                    "parent": "lm-held",
                    "labels": ["spec:alpha", "{label}"]
                }}]"#,
            );
            let progress = br#"{"molecule_id":"lm-3hhwq","completed":0,"in_progress":0,"total":1,"percent":0.0}"#;
            let bd = BdClient::with_runner(ScriptedBd::new([
                ok_stdout(epic),
                ok_stdout(epic),
                ok_stdout(progress),
                ok_stdout(child.as_bytes()),
            ]));
            let before = loom_driver::git::sync_rev_parse(&git.loom_workspace(), "origin/main")
                .expect("origin tip before");
            let handoff = execute_molecule_push_gate(
                &bd,
                &SpecLabel::new("alpha").unwrap(),
                None,
                MoleculePushGateCommands::new(
                    None,
                    Path::new("must-not-run-review"),
                    Path::new("must-not-run-wrix"),
                ),
                &workspace,
                &git,
            )
            .await
            .expect("unresolved state is a typed refusal");
            assert_eq!(handoff.evidence.molecule_state, MoleculeState::Unresolved);
            assert_eq!(handoff.evidence.gate_runs, [] as [loom_gate::GateRun; 0]);
            assert!(!git.loom_workspace().join(".loom/marker.json").exists());
            let after = loom_driver::git::sync_rev_parse(&git.loom_workspace(), "origin/main")
                .expect("origin tip after");
            assert_eq!(before, after, "{label} must refuse the push");
        }
    }

    #[tokio::test]
    async fn molecule_state_refuses_a_parked_molecule_epic() {
        let epic = br#"[{
            "id": "lm-parked",
            "title": "parked molecule",
            "status": "blocked",
            "priority": 2,
            "issue_type": "epic",
            "labels": ["spec:agent", "loom:blocked"]
        }]"#;
        let progress = br#"{"molecule_id":"lm-parked","completed":1,"in_progress":0,"total":1,"percent":100.0}"#;
        let bd = BdClient::with_runner(ScriptedBd::new([
            ok_stdout(epic),
            ok_stdout(progress),
            ok_stdout(b"[]"),
        ]));

        let state = molecule_state(&bd, &MoleculeId::new("lm-parked").unwrap())
            .await
            .expect("read molecule state");

        assert_eq!(state, MoleculeState::Unresolved);
    }

    #[test]
    fn parked_state_includes_semantic_deferred_and_infra_labels() {
        let mut deferred = bead("lm-deferred");
        deferred
            .labels
            .push(Label::new("loom:deferred").expect("valid Label"));
        assert!(bead_has_parked_state(&deferred));

        let mut infra = bead("lm-infra");
        infra
            .labels
            .push(Label::new("loom:infra").expect("valid Label"));
        assert!(bead_has_parked_state(&infra));
    }

    #[tokio::test]
    async fn next_ready_bead_loads_blocked_infra_when_ready_queue_empty() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let infra = br#"[{
            "id":"lm-infra",
            "title":"infra",
            "status":"blocked",
            "priority":2,
            "issue_type":"task",
            "labels":["spec:gate","profile:base","loom:infra"]
        }]"#;
        let scripted = ScriptedBd::new([ok_stdout(b"[]\n"), ok_stdout(infra)]);
        let calls = scripted.calls_handle();
        let bd = BdClient::with_runner(scripted);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("gate").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );

        let picked = controller
            .next_ready_bead(&[])
            .await
            .expect("ready lookup ok")
            .expect("infra bead selected");

        assert_eq!(picked.id, BeadId::new("lm-infra").expect("valid"));
        let captured = calls.lock().unwrap();
        assert_eq!(captured.len(), 2);
        let infra_argv: Vec<String> = captured[1]
            .iter()
            .map(|s| s.to_string_lossy().into_owned())
            .collect();
        drop(captured);
        assert_eq!(infra_argv[0], "list");
        assert!(infra_argv.contains(&"--status=blocked".to_string()));
        assert!(infra_argv.contains(&"--label=spec:gate".to_string()));
        assert!(infra_argv.contains(&"--label-any=loom:infra".to_string()));
    }

    #[tokio::test]
    async fn run_bead_clears_stale_infra_state_before_dispatch() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let scripted = ScriptedBd::new([ok_stdout(b"")]);
        let calls = scripted.calls_handle();
        let bd = BdClient::with_runner(scripted);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("spec-x").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |cfg: SpawnConfig, _bead_id: BeadId| async move {
                std::fs::write(cfg.workspace.join("spawn.txt"), "spawned\n")
                    .expect("write spawn file");
                loom_driver::git::commit_all_in(&cfg.workspace, "spawn work")
                    .expect("commit spawn work");
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );
        let mut infra_bead = bead("lm-infra");
        infra_bead.status = loom_driver::bd::Status::Blocked;
        infra_bead
            .labels
            .push(Label::new("loom:infra").expect("valid Label"));

        let outcome = controller
            .run_bead(&infra_bead, None)
            .await
            .expect("run_bead ok");

        assert_eq!(outcome, AgentOutcome::Success);
        let captured = calls.lock().unwrap();
        let update: Vec<String> = captured[0]
            .iter()
            .map(|s| s.to_string_lossy().into_owned())
            .collect();
        drop(captured);
        assert_eq!(update[0], "update");
        assert_eq!(update[1], "lm-infra");
        assert!(
            update
                .windows(2)
                .any(|w| w[0] == "--status" && w[1] == "open"),
            "redispatch must reopen stale infra bead: {update:?}",
        );
        assert!(
            update
                .windows(2)
                .any(|w| w[0] == "--remove-label" && w[1] == "loom:infra"),
            "redispatch must clear stale infra label: {update:?}",
        );
    }

    #[tokio::test]
    async fn retry_attempt_counter_increments_per_bead_retry() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let captured_prompts = Arc::new(Mutex::new(Vec::new()));
        let captured_prompts_inner = Arc::clone(&captured_prompts);
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("templates").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            move |cfg: SpawnConfig, _bead_id: BeadId| {
                let captured_prompts = Arc::clone(&captured_prompts_inner);
                async move {
                    captured_prompts.lock().unwrap().push(cfg.initial_prompt);
                    (
                        SessionResult::Complete(SessionOutcome {
                            exit_code: 1,
                            cost_usd: None,
                        }),
                        None,
                    )
                }
            },
        );
        let bead = bead("lm-retry");

        for previous_failure in [
            None,
            Some("failed once".to_string()),
            Some("failed twice".to_string()),
        ] {
            let outcome = controller
                .run_bead(&bead, previous_failure)
                .await
                .expect("run_bead ok");
            assert!(matches!(outcome, AgentOutcome::Failure { .. }));
        }

        let prompts = captured_prompts.lock().unwrap();
        assert_eq!(prompts.len(), 3);
        assert!(!prompts[0].contains("Retry attempt"));
        assert!(
            prompts[1].contains("Retry attempt 1 — previous attempt failed with:"),
            "first retry prompt must render attempt 1: {}",
            prompts[1],
        );
        assert!(
            prompts[2].contains("Retry attempt 2 — previous attempt failed with:"),
            "second retry prompt must render attempt 2: {}",
            prompts[2],
        );
        drop(prompts);
    }

    #[tokio::test]
    async fn next_ready_skips_child_of_parked_parent() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let ready = br#"[{
            "id":"lm-child",
            "title":"child",
            "status":"open",
            "priority":2,
            "issue_type":"task",
            "labels":["spec:harness","profile:base"],
            "parent":"lm-parent"
        }]"#;
        let parent = br#"[{
            "id":"lm-parent",
            "title":"parent",
            "status":"open",
            "priority":2,
            "issue_type":"epic",
            "labels":["spec:harness","loom:blocked"]
        }]"#;
        let bd = BdClient::with_runner(ScriptedBd::new([ok_stdout(ready), ok_stdout(parent)]));
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("harness").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );

        let next = controller
            .next_ready_bead(&[])
            .await
            .expect("ready lookup ok");
        assert!(next.is_none(), "parked parent suppresses child dispatch");
    }

    #[tokio::test]
    async fn run_bead_invokes_dispatch_closure_with_resolved_spawn_config() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let captured: Arc<Mutex<Option<SpawnConfig>>> = Arc::new(Mutex::new(None));
        let captured_for_closure = Arc::clone(&captured);
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("spec-x").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            move |cfg: SpawnConfig, _bead_id: BeadId| {
                let captured = Arc::clone(&captured_for_closure);
                async move {
                    std::fs::write(cfg.workspace.join("spawn.txt"), "spawned\n")
                        .expect("write spawn file");
                    loom_driver::git::commit_all_in(&cfg.workspace, "spawn work")
                        .expect("commit spawn work");
                    *captured.lock().unwrap() = Some(cfg);
                    (
                        SessionResult::Complete(SessionOutcome {
                            exit_code: 0,
                            cost_usd: None,
                        }),
                        Some(ExitSignal::Complete),
                    )
                }
            },
        );
        let outcome = controller
            .run_bead(&bead("lm-1"), None)
            .await
            .expect("run_bead ok");
        assert_eq!(outcome, AgentOutcome::Success);
        let cfg = captured.lock().unwrap().take().expect("closure called");
        assert_eq!(cfg.image_ref, "localhost/wrix-base-pi:abc");
        assert!(cfg.initial_prompt.contains("lm-1"));
    }

    #[tokio::test]
    async fn run_bead_blocks_success_that_does_not_advance_branch() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("spec-x").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace.clone(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );

        let outcome = controller
            .run_bead(&bead("lm-zero"), None)
            .await
            .expect("run_bead ok");
        match outcome {
            AgentOutcome::ZeroProgress { detail } => {
                assert!(detail.contains("lm-zero"), "detail names bead: {detail}");
                assert!(
                    workspace.join(".loom/beads/lm-zero").exists(),
                    "workspace preserved for inspection",
                );
            }
            other => panic!("expected ZeroProgress, got {other:?}"),
        }
    }

    /// `loom loop` must dispatch with the rendered
    /// [`LoopContext`] template — bead title/description, scratchpad path,
    /// and `spec_path` all reach the agent prompt — and the same body must
    /// land in `<scratch_dir>/prompt.txt` so post-compaction `repin.sh`
    /// can re-emit the actual phase prompt.
    #[tokio::test]
    async fn run_bead_dispatches_rendered_run_template_and_writes_prompt_txt() {
        let dir = tempfile::tempdir().expect("tempdir");
        let manifest = write_manifest(dir.path());
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let bead_base = git.integration_commit_sha().await.unwrap();
        let captured: Arc<Mutex<Option<SpawnConfig>>> = Arc::new(Mutex::new(None));
        let captured_for_closure = Arc::clone(&captured);
        let prompt_seen: Arc<Mutex<Option<String>>> = Arc::new(Mutex::new(None));
        let prompt_seen_inner = Arc::clone(&prompt_seen);
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("harness").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace.clone(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            move |cfg: SpawnConfig, _bead_id: BeadId| {
                let captured = Arc::clone(&captured_for_closure);
                let prompt_seen = Arc::clone(&prompt_seen_inner);
                async move {
                    // Read prompt.txt mid-session, while the ScratchSession
                    // guard is still alive — Drop removes the dir on return.
                    let txt = std::fs::read_to_string(cfg.scratch_dir.join("prompt.txt"))
                        .expect("prompt.txt readable");
                    *prompt_seen.lock().unwrap() = Some(txt);
                    *captured.lock().unwrap() = Some(cfg);
                    (
                        SessionResult::Complete(SessionOutcome {
                            exit_code: 0,
                            cost_usd: None,
                        }),
                        Some(ExitSignal::Complete),
                    )
                }
            },
        );
        let bead = Bead {
            id: BeadId::new("lm-99").expect("bead id"),
            title: "Implement the harness".into(),
            description: "wire the per-bead loop".into(),
            status: loom_driver::bd::Status::Open,
            priority: loom_driver::bd::Priority::P2,
            issue_type: loom_driver::bd::IssueType::Task,
            labels: vec![Label::new("profile:base").expect("valid Label")],
            parent: None,
            metadata: [(
                loom_protocol::acceptance::METADATA_KEY.to_owned(),
                loom_test_support::acceptance::metadata("harness").unwrap(),
            )]
            .into(),
            notes: None,
        };
        controller.run_bead(&bead, None).await.expect("run_bead ok");
        let cfg = captured.lock().unwrap().take().expect("closure called");
        assert!(
            cfg.initial_prompt.contains("# Implementation Step"),
            "prompt missing template heading: {}",
            cfg.initial_prompt,
        );
        assert!(
            cfg.initial_prompt.contains("Implement the harness"),
            "prompt missing bead title: {}",
            cfg.initial_prompt,
        );
        assert!(
            cfg.initial_prompt.contains("wire the per-bead loop"),
            "prompt missing bead description: {}",
            cfg.initial_prompt,
        );
        assert!(
            cfg.initial_prompt.contains("specs/harness.md"),
            "prompt missing spec path: {}",
            cfg.initial_prompt,
        );
        // prompt.txt must hold the same rendered body so repin.sh
        // surfaces the phase prompt under compaction recovery.
        let written = prompt_seen.lock().unwrap().take().expect("prompt.txt seen");
        assert_eq!(written, cfg.initial_prompt);
        assert!(written.contains(&format!("loom gate verify --diff {bead_base}..HEAD")));
        assert!(!written.contains("## Workspace Recovery"));
    }

    #[tokio::test]
    async fn sequential_dispatch_pins_resolved_base_for_resumed_work() {
        for advance_integration in [false, true] {
            for dirty in [false, true] {
                let dir = tempfile::tempdir().unwrap();
                let workspace = dir.path().join("ws");
                let git = git_workspace(&workspace);
                let label = SpecLabel::new("harness").unwrap();
                let bead = bead("lm-resumed");
                let created = git.create_worktree(&label, &bead.id).await.unwrap();
                std::fs::write(created.path.join("worker.txt"), "previous attempt\n").unwrap();
                loom_driver::git::commit_all_in(&created.path, "Preserve worker commit").unwrap();
                if advance_integration {
                    let integration = git.loom_workspace();
                    std::fs::write(integration.join("other.txt"), "other bead\n").unwrap();
                    loom_driver::git::commit_all_in(&integration, "Advance integration").unwrap();
                }
                if dirty {
                    std::fs::write(created.path.join("dirty.txt"), "uncommitted work\n").unwrap();
                }
                let bead_base = git.integration_commit_sha().await.unwrap();
                let mut controller = ProductionAgentLoopController::new(
                    BdClient::new(),
                    label,
                    PathBuf::from("/loom/bin"),
                    workspace,
                    git,
                    write_manifest(dir.path()),
                    None,
                    ProfileName::base(),
                    move |cfg: SpawnConfig, _bead_id: BeadId| {
                        let bead_base = bead_base.clone();
                        async move {
                            let head =
                                loom_driver::git::sync_head_commit_sha(&cfg.workspace).unwrap();
                            assert_ne!(head, bead_base);
                            assert!(cfg.workspace.join("worker.txt").is_file());
                            let expected = format!("loom gate verify --diff {bead_base}..HEAD");
                            assert!(
                                cfg.initial_prompt.contains(&expected),
                                "{}",
                                cfg.initial_prompt
                            );
                            assert_eq!(cfg.initial_prompt.contains("## Workspace Recovery"), dirty);
                            let pin = std::fs::read_to_string(cfg.scratch_dir.join("prompt.txt"))
                                .unwrap();
                            assert_eq!(pin, cfg.initial_prompt);
                            (
                                SessionResult::Complete(SessionOutcome {
                                    exit_code: 1,
                                    cost_usd: None,
                                }),
                                None,
                            )
                        }
                    },
                );
                let outcome = controller
                    .run_bead(&bead, Some("resume worker".into()))
                    .await
                    .unwrap();
                assert!(matches!(outcome, AgentOutcome::Failure { .. }));
            }
        }
    }

    #[tokio::test]
    async fn loop_complete_does_not_require_recovery_stash_removed() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("harness").unwrap();
        let bead_id = BeadId::new("lm-stashok").expect("valid bead id");
        let created = git
            .create_worktree(&label, &bead_id)
            .await
            .expect("create worktree");
        std::fs::write(created.path.join("dirty.txt"), "preserved local work\n")
            .expect("write dirty file");
        let captured_prompt: Arc<Mutex<Option<String>>> = Arc::new(Mutex::new(None));
        let captured_prompt_inner = Arc::clone(&captured_prompt);
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            label,
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            move |cfg: SpawnConfig, _bead_id: BeadId| {
                let captured_prompt = Arc::clone(&captured_prompt_inner);
                async move {
                    *captured_prompt.lock().unwrap() = Some(cfg.initial_prompt.clone());
                    std::fs::write(cfg.workspace.join("spawn.txt"), "spawned\n")
                        .expect("write spawn file");
                    loom_driver::git::commit_all_in(&cfg.workspace, "spawn work")
                        .expect("commit spawn work");
                    (
                        SessionResult::Complete(SessionOutcome {
                            exit_code: 0,
                            cost_usd: None,
                        }),
                        Some(ExitSignal::Complete),
                    )
                }
            },
        );

        let outcome = controller
            .run_bead(&bead("lm-stashok"), None)
            .await
            .expect("run_bead ok");

        assert_eq!(outcome, AgentOutcome::Success);
        let prompt = captured_prompt
            .lock()
            .unwrap()
            .take()
            .expect("prompt captured");
        assert!(
            prompt.contains("## Workspace Recovery"),
            "workspace recovery context missing: {prompt}",
        );
        assert!(
            prompt.contains("git stash show --stat"),
            "stash inspection command missing: {prompt}",
        );
        assert!(
            !prompt.contains("Retry attempt 1"),
            "recovery stash context must not consume retry attempt: {prompt}",
        );
        let stash_reflog = std::fs::read_to_string(created.path.join(".git/logs/refs/stash"))
            .expect("stash reflog readable");
        assert!(
            stash_reflog.contains("loom workspace-recovery lm-stashok"),
            "successful completion must not require dropping the recovery stash: {stash_reflog}",
        );
    }

    #[tokio::test]
    async fn workspace_recovery_rebase_conflict_dispatches_agent_with_context() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("harness").unwrap();
        let bead_id = BeadId::new("lm-conflict").expect("valid bead id");
        let created = git
            .create_worktree(&label, &bead_id)
            .await
            .expect("create worktree");
        std::fs::write(created.path.join("README.md"), "bead edit\n").expect("write bead edit");
        loom_driver::git::commit_all_in(&created.path, "bead edit").expect("commit bead edit");
        let loom = git.loom_workspace();
        std::fs::write(loom.join("README.md"), "integration edit\n")
            .expect("write integration edit");
        loom_driver::git::commit_all_in(&loom, "integration edit")
            .expect("commit integration edit");
        std::fs::write(created.path.join("scratch.txt"), "dirty scratch\n")
            .expect("write dirty scratch");
        let captured_prompt: Arc<Mutex<Option<String>>> = Arc::new(Mutex::new(None));
        let bead_base = git.integration_commit_sha().await.unwrap();
        let conflict_body: Arc<Mutex<Option<String>>> = Arc::new(Mutex::new(None));
        let captured_prompt_inner = Arc::clone(&captured_prompt);
        let conflict_body_inner = Arc::clone(&conflict_body);
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            label,
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            move |cfg: SpawnConfig, _bead_id: BeadId| {
                let captured_prompt = Arc::clone(&captured_prompt_inner);
                let conflict_body = Arc::clone(&conflict_body_inner);
                async move {
                    *captured_prompt.lock().unwrap() = Some(cfg.initial_prompt.clone());
                    *conflict_body.lock().unwrap() = Some(
                        std::fs::read_to_string(cfg.workspace.join("README.md"))
                            .expect("conflict file readable"),
                    );
                    (
                        SessionResult::Complete(SessionOutcome {
                            exit_code: 1,
                            cost_usd: None,
                        }),
                        None,
                    )
                }
            },
        );

        let outcome = controller
            .run_bead(&bead("lm-conflict"), None)
            .await
            .expect("run_bead ok");

        assert!(matches!(outcome, AgentOutcome::Failure { .. }));
        let prompt = captured_prompt
            .lock()
            .unwrap()
            .take()
            .expect("prompt captured");
        assert!(
            prompt.contains("Alignment is in conflict"),
            "conflict guidance missing: {prompt}",
        );
        assert!(prompt.contains(&format!("loom gate verify --diff {bead_base}..HEAD")));
        assert!(
            prompt.contains("- `README.md`"),
            "conflict file missing from prompt: {prompt}",
        );
        assert!(
            prompt.contains("LOOM_CLARIFY"),
            "prompt must route human-needed conflicts through clarify: {prompt}",
        );
        assert!(
            !prompt.contains("Retry attempt 1"),
            "workspace recovery conflict dispatch must not consume retry attempt: {prompt}",
        );
        let readme = conflict_body
            .lock()
            .unwrap()
            .take()
            .expect("conflict file captured");
        assert!(
            readme.contains("<<<<<<<"),
            "worker saw no conflict markers: {readme}"
        );
    }

    #[tokio::test]
    async fn workspace_recovery_event_records_stash_and_alignment() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("harness").unwrap();
        let bead_id = BeadId::new("lm-event").expect("valid bead id");
        let created = git
            .create_worktree(&label, &bead_id)
            .await
            .expect("create worktree");
        std::fs::write(created.path.join("README.md"), "bead edit\n").expect("write bead edit");
        loom_driver::git::commit_all_in(&created.path, "bead edit").expect("commit bead edit");
        let loom = git.loom_workspace();
        std::fs::write(loom.join("README.md"), "integration edit\n")
            .expect("write integration edit");
        loom_driver::git::commit_all_in(&loom, "integration edit")
            .expect("commit integration edit");
        std::fs::write(created.path.join("scratch.txt"), "dirty scratch\n")
            .expect("write dirty scratch");
        let logs_root = dir.path().join("logs");
        let logs_root_for_closure = logs_root.clone();
        let label_for_closure = label.clone();
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            label.clone(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            move |_cfg: SpawnConfig, bead_id: BeadId| {
                let logs_root = logs_root_for_closure.clone();
                let label = label_for_closure.clone();
                async move {
                    let mut sink = loom_driver::logging::LogSink::open_in_at(
                        &logs_root,
                        &label,
                        &bead_id,
                        None,
                        SystemTime::UNIX_EPOCH,
                    )
                    .expect("open bead log");
                    sink.finish(loom_driver::logging::BeadOutcome::Failed)
                        .expect("finish bead log");
                    (
                        SessionResult::Complete(SessionOutcome {
                            exit_code: 1,
                            cost_usd: None,
                        }),
                        None,
                    )
                }
            },
        )
        .with_phase_log_root(logs_root.clone());

        let outcome = controller
            .run_bead(&bead("lm-event"), None)
            .await
            .expect("run_bead ok");

        assert!(matches!(outcome, AgentOutcome::Failure { .. }));
        let log_path = loom_driver::logging::bead_log_path(
            &logs_root,
            &label,
            &bead_id,
            SystemTime::UNIX_EPOCH,
        );
        let body = std::fs::read_to_string(&log_path).expect("driver event log readable");
        let event = body
            .lines()
            .map(|line| serde_json::from_str::<serde_json::Value>(line).expect("event json"))
            .find(|event| event["driver_kind"] == "workspace_recovery")
            .unwrap_or_else(|| panic!("workspace_recovery event missing from {body}"));
        assert_eq!(event["source"], "driver");
        assert_eq!(event["payload"]["bead_id"], "lm-event");
        assert!(
            event["payload"]["pre_stash_status"]
                .as_str()
                .unwrap_or_default()
                .contains("scratch.txt"),
            "pre-stash status missing dirty file: {event}",
        );
        assert_eq!(event["payload"]["stash_selector"], "stash@{0}");
        assert!(
            event["payload"]["stash_message"]
                .as_str()
                .unwrap_or_default()
                .contains("loom workspace-recovery lm-event"),
            "stash message missing bead id: {event}",
        );
        assert!(
            event["payload"]["stash_commit"]
                .as_str()
                .is_some_and(|s| s.len() == 40 || s.len() == 64),
            "stash commit must be a stable git oid: {event}",
        );
        assert!(
            event["payload"]["integration_tip"]
                .as_str()
                .is_some_and(|s| s.len() == 40 || s.len() == 64),
            "integration tip must be recorded: {event}",
        );
        assert_eq!(event["payload"]["alignment_outcome"], "conflict");
        assert_eq!(
            event["payload"]["conflict_files"],
            serde_json::json!(["README.md"]),
        );
    }

    #[tokio::test]
    async fn workspace_recovery_stash_failure_routes_static_infra_without_cleanup() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("harness").unwrap();
        let bead_id = BeadId::new("lm-stashfail").expect("valid bead id");
        let created = git
            .create_worktree(&label, &bead_id)
            .await
            .expect("create worktree");
        std::fs::write(created.path.join("README.md"), "bead edit\n").expect("write bead edit");
        loom_driver::git::commit_all_in(&created.path, "bead edit").expect("commit bead edit");
        let loom = git.loom_workspace();
        std::fs::write(loom.join("README.md"), "integration edit\n")
            .expect("write integration edit");
        loom_driver::git::commit_all_in(&loom, "integration edit")
            .expect("commit integration edit");
        let preexisting_conflict = GitClient::open(&created.path)
            .expect("open bead git")
            .prepare_bead_clone(&created.path, &bead_id)
            .await
            .expect("seed pre-existing conflict");
        assert!(
            matches!(
                preexisting_conflict.alignment,
                BeadCloneAlignment::Conflict { .. }
            ),
            "setup prepare should leave an unmerged index",
        );
        let before = std::fs::read_to_string(created.path.join("README.md"))
            .expect("conflict file readable");
        assert!(
            before.contains("<<<<<<<"),
            "conflict setup failed: {before}"
        );
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            label,
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("spawn closure must not run after recovery stash failure");
            },
        );

        let outcome = controller
            .run_bead(&bead("lm-stashfail"), None)
            .await
            .expect("run_bead ok");

        match outcome {
            AgentOutcome::StaticInfra { cause, error } => {
                assert_eq!(cause, WORKSPACE_RECOVERY_FAILED_CAUSE);
                assert!(
                    error.contains("workspace recovery pre-dispatch prepare failed"),
                    "diagnostic must name prepare failure: {error}",
                );
            }
            other => panic!("expected StaticInfra, got {other:?}"),
        }
        let after = std::fs::read_to_string(created.path.join("README.md"))
            .expect("conflict file readable after failure");
        assert!(
            after.contains("<<<<<<<"),
            "stash failure must abort before destructive cleanup: {after}",
        );
    }

    #[tokio::test]
    async fn run_bead_translates_nonzero_exit_code_into_failure_with_error_body() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("spec-x").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                // Nonzero exit + no marker = swallowed marker; we want to
                // verify the exit_code path. Pass None marker so the
                // classifier hits the `(None, code) => Failure` branch.
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 42,
                        cost_usd: None,
                    }),
                    None,
                )
            },
        );
        let outcome = controller
            .run_bead(&bead("lm-2"), None)
            .await
            .expect("run_bead ok");
        match outcome {
            AgentOutcome::Failure { error } => {
                assert!(
                    error.contains("42"),
                    "error body should mention exit code 42: {error}"
                );
            }
            other => panic!("non-zero exit must produce Failure, got {other:?}"),
        }
    }

    /// Spec gate: a [`SessionResult::PreflightFailed`] from the dispatch
    /// closure must surface as [`AgentOutcome::InfraPreflight`] so the
    /// run-loop infra budget can retry it before any `loom:infra` route.
    #[tokio::test]
    async fn run_bead_translates_preflight_failure_into_infra_preflight() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("spec-x").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::PreflightFailed {
                        error: "podman load failed: image archive missing".into(),
                    },
                    None,
                )
            },
        );
        let outcome = controller
            .run_bead(&bead("lm-3"), None)
            .await
            .expect("run_bead ok");
        match outcome {
            AgentOutcome::InfraPreflight { error } => {
                assert!(
                    error.contains("podman load"),
                    "preflight error must carry detail: {error}",
                );
            }
            other => panic!("expected InfraPreflight, got {other:?}"),
        }
    }

    /// Spec gate: a [`SessionResult::MidSessionFailed`] from the dispatch
    /// closure must surface as [`AgentOutcome::InfraMidSession`] so the
    /// per-bead infra budget can retry interrupted streams.
    #[tokio::test]
    async fn run_bead_translates_midsession_failure_into_infra_midsession() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("spec-x").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::MidSessionFailed {
                        error: "agent stdout closed: exit 137 (OOM)".into(),
                    },
                    None,
                )
            },
        );
        let outcome = controller
            .run_bead(&bead("lm-4"), None)
            .await
            .expect("run_bead ok");
        match outcome {
            AgentOutcome::InfraMidSession { error } => {
                assert!(
                    error.contains("OOM"),
                    "mid-session error must carry detail: {error}",
                );
            }
            other => panic!("expected InfraMidSession, got {other:?}"),
        }
    }

    /// Spec gate (Implementation Note 6): a bead whose `profile:X` label
    /// is missing from the manifest must surface as
    /// [`AgentOutcome::UnknownProfile`] (NOT [`AgentOutcome::Failure`])
    /// so [`process_one_bead`](crate::r#loop::run_loop) routes it straight to
    /// `loom:infra` cause `unknown-profile` without consuming a retry slot.
    /// The error string must name the requested profile and the manifest's
    /// declared set so the operator can relabel without re-reading the
    /// manifest.
    #[tokio::test]
    async fn run_bead_translates_unknown_profile_into_unknown_profile_outcome() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        // Manifest declares only `base` — the bead asks for `nonexistent`.
        let manifest = write_manifest(dir.path());
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("spec-x").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("spawn closure must not be invoked when profile resolution fails");
            },
        );
        let bad_bead = Bead {
            id: BeadId::new("lm-5").expect("valid bead id"),
            title: "needs a profile we do not have".into(),
            description: "desc".into(),
            status: loom_driver::bd::Status::Open,
            priority: loom_driver::bd::Priority::P2,
            issue_type: loom_driver::bd::IssueType::Task,
            labels: vec![Label::new("profile:nonexistent").expect("valid Label")],
            parent: None,
            metadata: [(
                loom_protocol::acceptance::METADATA_KEY.to_owned(),
                loom_test_support::acceptance::metadata("harness").unwrap(),
            )]
            .into(),
            notes: None,
        };
        let outcome = controller
            .run_bead(&bad_bead, None)
            .await
            .expect("run_bead must NOT bubble UnknownProfile up as LoopError");
        match outcome {
            AgentOutcome::UnknownProfile { error } => {
                assert!(
                    error.contains("profile:nonexistent"),
                    "error must name the requested profile (as it appears on the bead label): {error}",
                );
                assert!(
                    error.contains("profile:base"),
                    "error must name at least one declared profile so the operator can relabel: {error}",
                );
            }
            other => panic!("expected UnknownProfile, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn run_bead_translates_invalid_spawn_config_into_static_infra() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let path = dir.path().join("profile-images.json");
        std::fs::write(
            &path,
            r#"{
              "base": { "pi": { "ref": "", "source": "/nix/store/aaa-image-base-pi", "source_kind": "nix-descriptor", "launcher": "/fixture/wrix", "profile_config": "/fixture/profile.json" } }
            }"#,
        )
        .expect("write manifest");
        let manifest = Arc::new(ProfileImageManifest::from_path(&path).expect("parse manifest"));
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("spec-x").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("spawn closure must not run for invalid spawn config");
            },
        );

        let outcome = controller
            .run_bead(&bead("lm-invalid"), None)
            .await
            .expect("run_bead ok");

        match outcome {
            AgentOutcome::StaticInfra { cause, error } => {
                assert_eq!(cause, INVALID_SPAWN_CONFIG_CAUSE);
                assert!(error.contains("image ref"), "{error}");
            }
            other => panic!("expected StaticInfra, got {other:?}"),
        }
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn exec_review_holds_lock_through_marker_and_push() {
        use loom_driver::clock::SystemClock;
        use loom_driver::lock::LockManager;
        use std::os::unix::fs::PermissionsExt;

        let dir = tempfile::tempdir().expect("tempdir");
        let manifest = write_manifest(dir.path());
        let mgr = LockManager::new(dir.path()).expect("lock manager");
        let label = SpecLabel::new("alpha").unwrap();
        let root = BeadId::new("lm-lock").expect("valid bead id");
        let clock = SystemClock::new();
        let guard = mgr
            .acquire_work_root_async(&root, &clock)
            .await
            .expect("first acquire");

        // Stand-in for the `loom` binary: ignores all args and exits 0.
        // /bin/true does not exist on NixOS, so we ship a script.
        let stub = dir.path().join("loom-stub.sh");
        std::fs::write(&stub, "#!/bin/sh\nexit 0\n").unwrap();
        std::fs::set_permissions(&stub, std::fs::Permissions::from_mode(0o755)).unwrap();

        let bd = BdClient::with_runner(molecule_lookup_script(
            dir.path(),
            "alpha",
            "lm-mol1",
            "deadbeef",
        ));
        let git = git_workspace(dir.path());
        let mut controller = ProductionAgentLoopController::new(
            bd,
            label.clone(),
            stub,
            dir.path().to_path_buf(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        )
        .with_handoff_lock(guard);

        controller.exec_review().await.expect("exec_review ok");

        let held = mgr
            .acquire_work_root_with_timeout_async(&root, &clock, Duration::from_millis(100))
            .await;
        assert!(
            held.is_err(),
            "push critical section must retain the work-root lock"
        );
        drop(controller);
        let _reacquired = mgr
            .acquire_work_root_with_timeout_async(&root, &clock, Duration::from_millis(100))
            .await
            .expect("lock must be reacquirable after the controller drops");
    }

    /// Molecule-completion handoff computes the origin-synchronized push
    /// range and invokes review without scalar handoff flags.
    #[tokio::test(flavor = "multi_thread")]
    async fn molecule_push_gate_verifies_and_reviews_actual_push_range() {
        use std::os::unix::fs::PermissionsExt;

        let dir = tempfile::tempdir().expect("tempdir");
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("alpha").unwrap();

        // Recording stub: appends every invocation's argv (one per line,
        // tab-separated) to argv.log so the test can replay the call order.
        let argv_log = dir.path().join("argv.log");
        let stub = dir.path().join("loom-stub.sh");
        let stub_body = format!(
            "#!/bin/sh\nprintf '%s\\t%s\\t%s\\n' \"$PWD\" \"$LOOM_REVIEW_SPEC_LABEL\" \"$*\" >> {log}\nexit 0\n",
            log = argv_log.to_string_lossy(),
        );
        std::fs::write(&stub, stub_body).unwrap();
        std::fs::set_permissions(&stub, std::fs::Permissions::from_mode(0o755)).unwrap();

        let bd = BdClient::with_runner(molecule_lookup_script(
            dir.path(),
            "alpha",
            "lm-mol1",
            "deadbeef",
        ));
        let git = git_workspace(dir.path());
        let mut controller = ProductionAgentLoopController::new(
            bd,
            label.clone(),
            stub,
            dir.path().to_path_buf(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );

        let gate_workspace = controller.git.loom_workspace();
        let from_oid = loom_driver::git::sync_rev_parse(&gate_workspace, "origin/main")
            .expect("resolve origin tip");
        let to_oid =
            loom_driver::git::sync_rev_parse(&gate_workspace, "HEAD").expect("resolve HEAD");
        controller.exec_review().await.expect("exec_review ok");

        let recorded = std::fs::read_to_string(&argv_log).expect("argv log readable");
        let lines: Vec<String> = recorded.lines().map(ToOwned::to_owned).collect();
        assert_eq!(
            lines,
            vec![format!(
                "{}\talpha\t--host-key gate review --diff {from_oid}..{to_oid}",
                gate_workspace
                    .canonicalize()
                    .expect("integration checkout exists")
                    .display()
            )],
            "review must run from the integration checkout over the actual origin push range; the spec label travels as env context, not as a gate filter: {recorded:?}",
        );
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn parallel_handoff_propagates_provisioned_profiles_to_actual_review_child() {
        let dir = tempfile::tempdir().expect("fixture");
        let original = write_manifest(dir.path());
        let mut entries: serde_json::Value =
            serde_json::from_slice(&std::fs::read(original.manifest_path()).expect("manifest"))
                .expect("json");
        for entry in entries["base"]
            .as_object_mut()
            .expect("runtimes")
            .values_mut()
        {
            entry["native_preflight"] = "rust".into();
        }
        let installed_path = dir.path().join("installed.json");
        std::fs::write(&installed_path, serde_json::to_vec(&entries).expect("json"))
            .expect("installed");
        let manifest = (*original).clone().provision_native_from(
            &ProfileImageManifest::from_path(&installed_path).expect("installed manifest"),
        );
        let workspace = dir.path().join("workspace");
        let git = git_workspace(&workspace);
        let marker = dir.path().join("review-environment-observed");
        let stub = dir.path().join("review-child.sh");
        loom_test_support::write_executable_bash_script(&stub, &format!(
            "set -euo pipefail\n[[ \"$LOOM_PROFILES_MANIFEST\" == {original:?} ]]\n[[ \"$LOOM_PROVISIONED_PROFILES_MANIFEST\" == {installed_path:?} ]]\ntest -r \"$LOOM_PROFILES_MANIFEST\"\ntest -r \"$LOOM_PROVISIONED_PROFILES_MANIFEST\"\nprintf 'observed\\n' > {marker:?}\nexit 1\n",
            original = original.manifest_path(),
        )).expect("external child");
        let bd = BdClient::with_runner(molecule_lookup_script(
            dir.path(),
            "alpha",
            "lm-mol1",
            "deadbeef",
        ));
        let handoff = execute_molecule_push_gate(
            &bd,
            &SpecLabel::new("alpha").expect("label"),
            None,
            super::super::schedule::handoff_commands(
                None,
                &stub,
                Path::new("unused-wrix"),
                &manifest,
            ),
            &workspace,
            &git,
        )
        .await
        .expect("typed review failure");
        assert_eq!(
            std::fs::read_to_string(marker).expect("review child observed both inputs"),
            "observed\n"
        );
        assert!(
            handoff
                .evidence
                .gate_runs
                .iter()
                .any(|run| run.phase == GatePhase::Review && run.status != GateRunStatus::Success)
        );
        assert!(!git.loom_workspace().join(".loom/marker.json").exists());
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn exec_review_child_failure_returns_incomplete_typed_evidence() {
        use std::os::unix::fs::PermissionsExt;

        let dir = tempfile::tempdir().expect("tempdir");
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("alpha").unwrap();
        let stub = dir.path().join("loom-stub.sh");
        std::fs::write(
            &stub,
            "#!/bin/sh\nprintf 'child stdout\\n'\nprintf 'child stderr\\n' >&2\nexit 17\n",
        )
        .unwrap();
        std::fs::set_permissions(&stub, std::fs::Permissions::from_mode(0o755)).unwrap();

        let bd = BdClient::with_runner(molecule_lookup_script(
            dir.path(),
            "alpha",
            "lm-mol1",
            "deadbeef",
        ));
        let git = git_workspace(dir.path());
        let publish_marker = dir.path().join("unexpected-publish");
        let wrix = dir.path().join("wrix-stub.sh");
        loom_test_support::write_executable_bash_script(
            &wrix,
            &format!(
                "set -euo pipefail\nprintf published > {}\n",
                publish_marker.display()
            ),
        )
        .expect("write publication stub");
        let mut controller = ProductionAgentLoopController::new(
            bd,
            label,
            stub,
            dir.path().to_path_buf(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        )
        .with_wrix_bin(wrix);

        let evidence = controller
            .exec_review()
            .await
            .expect("review failure is a typed gate refusal");
        assert_eq!(evidence.review_exit, Some(17));
        assert!(evidence.verified.is_some());
        assert!(evidence.reviewed.is_none());
        let failed_review = evidence
            .gate_runs
            .iter()
            .find(|run| run.phase == GatePhase::Review)
            .expect("failed review run is retained");
        assert_eq!(failed_review.status, GateRunStatus::Failed);
        let diagnostic = std::fs::read_to_string(&failed_review.log_path)
            .expect("failed review log is readable");
        assert!(diagnostic.contains("review subprocess exited 17"));
        assert!(diagnostic.contains("child stdout"));
        assert!(diagnostic.contains("child stderr"));
        assert!(matches!(
            GateSuccess::new(&evidence, 1),
            Err(loom_gate::GateFail {
                reason: loom_gate::GateFailReason::ReviewEvidenceMissing,
                ..
            })
        ));
        assert!(
            !controller
                .git
                .loom_workspace()
                .join(".loom/marker.json")
                .exists()
        );
        assert!(
            !publish_marker.exists(),
            "failed review must stop before Beads publication"
        );
    }

    async fn clean_push_fixture(
        parent_git: Option<&std::path::Path>,
    ) -> (tempfile::TempDir, HandoffEvidence, PathBuf) {
        review_push_fixture(parent_git, "LOOM_COMPLETE\n").await
    }

    async fn review_push_fixture(
        parent_git: Option<&std::path::Path>,
        review_stdout: &str,
    ) -> (tempfile::TempDir, HandoffEvidence, PathBuf) {
        let dir = tempfile::tempdir().expect("tempdir");
        let stdout_path = dir.path().join("review-stdout");
        std::fs::write(&stdout_path, review_stdout).unwrap();
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("gamma").unwrap();
        let workspace = dir.path().to_path_buf();
        let git = git_workspace(&workspace);
        let gate_workspace = git.loom_workspace();
        let argv_log = dir.path().join("argv.log");
        let stub = dir.path().join("loom-stub.sh");
        let parent_git_env = parent_git
            .map(|parent| {
                format!(
                    "export GIT_DIR={:?}\nexport GIT_WORK_TREE={:?}\nexport GIT_INDEX_FILE={:?}\n",
                    parent.join(".git"),
                    parent,
                    parent.join(".git/index"),
                )
            })
            .unwrap_or_default();
        let stub_body = format!(
            "set -euo pipefail\n\
             {parent_git_env}\
             mapfile -t git_local_vars < <(git rev-parse --local-env-vars)\n\
             unset \"${{git_local_vars[@]}}\"\n\
             printf '%s\\n' \"$*\" >> {argv}\n\
             [[ \"$1\" == --host-key ]]\n\
             shift\n\
             range=\"$4\"\n\
             tree_oid=$(git rev-parse 'HEAD^{{tree}}')\n\
             verify_log=\"${{LOOM_REVIEW_VERIFIED_LOG:?}}\"\n\
             config_digest=$(grep '\"driver_kind\":\"gate_run_end\"' \"$verify_log\" | tail -n 1 | sed -E 's/.*\"config_digest\":\"([^\"]*)\".*/\\1/')\n\
             stamp=$(date -u -d @$(($LOOM_REVIEW_PHASE_WHEN_MILLIS / 1000)) +%Y%m%dT%H%M%SZ)\n\
             log=\"$PWD/.loom/logs/review/review-${{stamp}}.jsonl\"\n\
             mkdir -p \"$(dirname \"$log\")\"\n\
             payload=$(printf '{{\"phase\":\"review\",\"push_range\":\"%s\",\"tree_oid\":\"%s\",\"config_digest\":\"%s\",\"log_path\":\"%s\",\"exit_code\":0,\"status\":\"success\",\"marker\":\"complete\",\"covered_hooks\":[]}}' \"$range\" \"$tree_oid\" \"$config_digest\" \"$log\")\n\
             printf '{{\"kind\":\"driver_event\",\"driver_kind\":\"gate_run_start\",\"payload\":%s}}\\n' \"$payload\" >> \"$log\"\n\
             printf '{{\"kind\":\"driver_event\",\"driver_kind\":\"gate_run_end\",\"payload\":%s}}\\n' \"$payload\" >> \"$log\"\n\
             cat {stdout_path:?}\n",
            argv = argv_log.to_string_lossy(),
        );
        loom_test_support::write_executable_bash_script(&stub, &stub_body)
            .expect("write loom review stub");

        let bd = BdClient::with_runner(molecule_lookup_script(
            dir.path(),
            "gamma",
            "lm-mol9",
            "abc12345",
        ));
        let wrix = dir.path().join("wrix.sh");
        loom_test_support::write_executable_bash_script(&wrix, "set -euo pipefail\nexit 0\n")
            .expect("write wrix stub");
        let mut controller = ProductionAgentLoopController::new(
            bd,
            label.clone(),
            stub,
            workspace.clone(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        )
        .with_wrix_bin(wrix);

        let handoff = controller
            .exec_review()
            .await
            .expect("exec_review must succeed with populated evidence");
        (dir, handoff, gate_workspace)
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn molecule_review_handoff_rejects_invalid_stdout_even_with_success_logs() {
        for stdout in [
            "LOOM_FINDING: {broken}\nLOOM_COMPLETE\n",
            "LOOM_CLARIFY: {\"decisions\":[\"lm-mol9\"]}\nLOOM_COMPLETE\n",
            "LOOM_CONCERN: {\"summary\":\"missing findings\"}\n",
            "LOOM_FINDING: {\"token\":\"spec-coherence-fail\",\"route\":\"deferred\",\"bonds\":[\"gamma\"],\"target\":{\"kind\":\"Criterion\",\"spec\":\"gamma\",\"anchor\":\"unresolved\"},\"evidence\":\"no current target\"}\nLOOM_COMPLETE\n",
            "LOOM_FINDING_STATUS: {}\nLOOM_COMPLETE\n",
        ] {
            let (_dir, handoff, gate_workspace) = review_push_fixture(None, stdout).await;
            assert!(handoff.verified.is_some(), "verification completed");
            assert!(
                handoff.reviewed.is_none(),
                "stdout must precede scope admission: {handoff:?}"
            );
            assert!(
                GateSuccess::new(&handoff, 1).is_err(),
                "success logs cannot override stdout: {handoff:?}"
            );
            assert!(!gate_workspace.join(".loom/marker.json").exists());
        }
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn handoff_evidence_populates_typed_gate_scope_values() {
        let (_dir, handoff, gate_workspace) = clean_push_fixture(None).await;
        assert_eq!(handoff.molecule_state, MoleculeState::Clean);
        assert_eq!(handoff.gate_runs.len(), 2, "{:#?}", handoff.gate_runs);
        assert_eq!(handoff.gate_log_paths.len(), 2);
        for log_path in &handoff.gate_log_paths {
            assert!(
                log_path
                    .canonicalize()
                    .expect("gate log exists")
                    .starts_with(
                        gate_workspace
                            .join(".loom/logs")
                            .canonicalize()
                            .expect("gate log directory exists")
                    ),
                "gate evidence must live with the integration checkout: {log_path:?}",
            );
            let body = std::fs::read_to_string(log_path).expect("log readable");
            assert!(body.contains("gate_run_start"), "{body}");
            assert!(body.contains("gate_run_end"), "{body}");
        }
        let verified = handoff.verified.as_ref().expect("verified scope");
        let reviewed = handoff.reviewed.as_ref().expect("reviewed scope");
        assert_eq!(verified.push_range(), reviewed.push_range());
        assert_eq!(verified.tree_oid(), reviewed.tree_oid());
        assert_eq!(verified.config_digest(), reviewed.config_digest());
        assert_eq!(handoff.review_marker, Some(ExitSignal::Complete));
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn clean_push_mints_marker_after_covered_verify_and_review() {
        let (_dir, handoff, gate_workspace) = clean_push_fixture(None).await;
        assert!(handoff.verified.is_some());
        assert!(handoff.reviewed.is_some());
        let marker = loom_gate::verify_marker(&gate_workspace).expect("current marker");
        assert_eq!(
            marker.push_range(),
            handoff.push_range.as_deref().expect("range")
        );
        let local = loom_driver::git::sync_rev_parse(&gate_workspace, "HEAD").expect("local head");
        let remote =
            loom_driver::git::sync_rev_parse(&gate_workspace, "origin/main").expect("remote head");
        assert_eq!(
            local, remote,
            "clean gate must push after minting the marker"
        );
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn clean_push_fixture_isolated_from_parent_hook_git_environment() {
        let parent = tempfile::tempdir().expect("parent repository");
        let _parent_workspace = git_workspace(parent.path());
        std::fs::write(parent.path().join("foreign-file"), "foreign tree").unwrap();
        loom_driver::git::GitClient::open(parent.path())
            .unwrap()
            .commit_all_allow_empty("foreign tree")
            .await
            .unwrap();
        let (_dir, handoff, gate_workspace) = clean_push_fixture(Some(parent.path())).await;
        let verified = handoff.verified.as_ref().expect("verified scope");
        let reviewed = handoff.reviewed.as_ref().expect("reviewed scope");
        assert_eq!(verified.tree_oid(), reviewed.tree_oid());
        loom_gate::verify_marker(&gate_workspace).expect("fixture marker for its own tree");
    }

    #[tokio::test(flavor = "multi_thread")]
    async fn malformed_review_handoff_preserves_diagnosis_without_minting() {
        for terminal in [
            "LOOM_CONCERN: {\"summary\":\"mixed\"}",
            "LOOM_CONCERN: {\"summary\":\"\"}",
            "",
        ] {
            let dir = tempfile::tempdir().unwrap();
            let manifest = write_manifest(dir.path());
            let workspace = dir.path().to_path_buf();
            seed_spec(&workspace, "alpha");
            let record = r#"LOOM_FINDING: {"token":"mock-discipline","route":"deferred","bonds":["alpha"],"target":{"kind":"TestPath","path":"tests/check.rs"},"evidence":"valid sibling"}"#;
            let bad_record = record.replace("tests/check.rs", "tests/missing.rs");
            let text = format!("{record}\n{bad_record}\n{record}\n{terminal}\n");
            let stub = workspace.join("loom-stub.sh");
            loom_test_support::write_executable_bash_script(
                &stub,
                &format!("set -euo pipefail\nprintf '%s' '{text}'\n"),
            )
            .unwrap();
            let bd = BdClient::with_runner(molecule_lookup_script(
                dir.path(),
                "alpha",
                "lm-mol1",
                "deadbeef",
            ));
            let git = git_workspace(&workspace);
            let gate_workspace = git.loom_workspace();
            std::fs::create_dir_all(gate_workspace.join("specs")).unwrap();
            std::fs::write(gate_workspace.join("specs/alpha.md"), "# Alpha\n").unwrap();
            std::fs::create_dir_all(gate_workspace.join("tests")).unwrap();
            std::fs::write(
                gate_workspace.join("tests/check.rs"),
                "#[test] fn check() {}\n",
            )
            .unwrap();
            let walk = WalkOutput::from_stdout(
                &text,
                DispatchScope::PerBead,
                &WorkspaceFindingValidator::new(&gate_workspace),
            );
            assert_eq!(walk.findings().len(), 2);
            std::fs::write(
                gate_workspace.join("loom.toml"),
                format!(
                    "[[suppress]]\nid = {:?}\nreason = \"fixture\"\n",
                    walk.findings()[0].id()
                ),
            )
            .unwrap();
            loom_driver::git::commit_all_in(&gate_workspace, "Prepare malformed handoff fixture")
                .unwrap();
            let mut controller = ProductionAgentLoopController::new(
                bd,
                SpecLabel::new("alpha").unwrap(),
                stub,
                workspace,
                git,
                manifest,
                None,
                ProfileName::new("base").unwrap(),
                |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                    (
                        SessionResult::Complete(SessionOutcome {
                            exit_code: 0,
                            cost_usd: None,
                        }),
                        Some(ExitSignal::Complete),
                    )
                },
            );
            let handoff = controller.exec_review().await.unwrap();
            assert!(!handoff.suppressed_review_concern);
            assert!(handoff.reviewed.is_none());
            let Some(PreviousFailure::BadWalk(bad_walk)) =
                controller.stashed_review_concern.as_ref()
            else {
                panic!("malformed review lost diagnosis: {handoff:?}");
            };
            assert_eq!(bad_walk.context().raw(), text);
            assert_eq!(bad_walk.parsed_findings(), walk.findings());
            assert_eq!(bad_walk.finding_errors(), walk.finding_errors());
            assert_eq!(&bad_walk.terminal(), walk.terminal());
            assert_eq!(bad_walk, &walk.bad_walk().unwrap());
        }
    }

    /// `specs/gate.md` § Rubric suppression registry: molecule handoff
    /// re-parses review findings after shape validation and removes
    /// suppressed rubric findings from recovery context while keeping
    /// unsuppressed siblings live.
    #[tokio::test(flavor = "multi_thread")]
    async fn molecule_completion_review_stashes_only_unsuppressed_findings() {
        let dir = tempfile::tempdir().expect("tempdir");
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("alpha").unwrap();
        let workspace = dir.path().to_path_buf();
        seed_spec(&workspace, "alpha");
        let suppressed = loom_test_support::finding::resolve(loom_protocol::gate::RawFinding {
            token: crate::review::ConcernToken::VerifierBypass,
            route: crate::review::FindingRoute::Deferred,
            bonds: vec![label.clone()],
            target: crate::review::FindingTarget::Annotation {
                target_string: "cargo test --lib suppressed".to_owned(),
            },
            evidence: "suppressed finding".to_owned(),
        })
        .expect("valid fixture finding");
        let unsuppressed = loom_test_support::finding::resolve(loom_protocol::gate::RawFinding {
            token: crate::review::ConcernToken::VerifierBypass,
            route: crate::review::FindingRoute::Deferred,
            bonds: vec![label.clone()],
            target: crate::review::FindingTarget::Annotation {
                target_string: "cargo test --lib live".to_owned(),
            },
            evidence: "live finding".to_owned(),
        })
        .expect("valid fixture finding");
        std::fs::write(
            workspace.join("loom.toml"),
            format!(
                "[[suppress]]\nid = {:?}\nreason = \"false positive\"\n",
                suppressed.id()
            ),
        )
        .unwrap();
        std::fs::write(
            workspace.join("specs/alpha.md"),
            "# alpha\n\n- suppressed [check](cargo test --lib suppressed)\n- live [check](cargo test --lib live)\n",
        )
        .unwrap();
        let stub = dir.path().join("loom-stub.sh");
        let suppressed_payload = serde_json::to_string(&suppressed).unwrap();
        let unsuppressed_payload = serde_json::to_string(&unsuppressed).unwrap();
        let concern_payload = r#"{"summary":"reviewer flagged mixed findings"}"#;
        let stub_body = format!(
            "set -euo pipefail\n\
             [[ \"$1\" == --host-key ]]\n\
             shift\n\
             [[ \"$1\" == gate && \"$2\" == review ]]\n\
             printf 'LOOM_FINDING: {suppressed_payload}\nLOOM_FINDING: {unsuppressed_payload}\nLOOM_CONCERN: {concern_payload}\n'\n",
        );
        loom_test_support::write_executable_bash_script(&stub, &stub_body)
            .expect("write host-key review stub");

        let bd = BdClient::with_runner(molecule_lookup_script(
            dir.path(),
            "alpha",
            "lm-mol1",
            "deadbeef",
        ));
        let git = git_workspace(&workspace);
        std::fs::create_dir_all(git.loom_workspace().join("specs")).unwrap();
        std::fs::copy(
            workspace.join("specs/alpha.md"),
            git.loom_workspace().join("specs/alpha.md"),
        )
        .unwrap();
        std::fs::copy(
            workspace.join("loom.toml"),
            git.loom_workspace().join("loom.toml"),
        )
        .unwrap();
        let expected_stdout = format!(
            "LOOM_FINDING: {suppressed_payload}\nLOOM_FINDING: {unsuppressed_payload}\nLOOM_CONCERN: {concern_payload}\n"
        );
        let gate_workspace = git.loom_workspace();
        let validator = WorkspaceFindingValidator::new(&gate_workspace);
        let expected_walk =
            WalkOutput::from_stdout(&expected_stdout, DispatchScope::PerBead, &validator);
        assert_eq!(
            expected_walk.findings().len(),
            2,
            "fixture findings must validate: {:?}",
            expected_walk.finding_errors(),
        );
        let mut controller = ProductionAgentLoopController::new(
            bd,
            label,
            stub,
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );

        let handoff = controller.exec_review().await.expect("exec_review ok");
        assert!(
            matches!(handoff.review_marker, Some(ExitSignal::Concern { .. })),
            "review output must preserve concern marker: {handoff:?}",
        );

        let stashed = controller
            .stashed_review_concern
            .as_ref()
            .expect("unsuppressed finding keeps review concern live");
        match stashed {
            PreviousFailure::ReviewConcern { findings, .. } => {
                assert_eq!(findings.len(), 1);
                assert_eq!(findings[0].id(), unsuppressed.id());
            }
            other => panic!("expected ReviewConcern, got {other:?}"),
        }
    }

    /// A molecule-completion concern travels through the production review
    /// subprocess, typed walk parser, molecule mint route, and stabilization
    /// prompt context in one controller invocation.
    #[tokio::test(flavor = "multi_thread")]
    async fn molecule_completion_review_routes_findings_to_stabilization_or_clarify() {
        let dir = tempfile::tempdir().expect("tempdir");
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("alpha").unwrap();
        let workspace = dir.path().to_path_buf();
        seed_spec(&workspace, "alpha");

        // The stub emits one review finding so the production parser must preserve it.
        let argv_log = dir.path().join("argv.log");
        let stub = dir.path().join("loom-stub.sh");
        let finding_payload = r#"{"token":"verifier-bypass","route":"deferred","bonds":["alpha"],"target":{"kind":"Annotation","target_string":"cargo test --lib sample"},"evidence":"test mocks the agent backend"}"#;
        std::fs::write(
            workspace.join("specs/alpha.md"),
            "# alpha\n\n- sample [check](cargo test --lib sample)\n",
        )
        .unwrap();
        let concern_payload = r#"{"summary":"reviewer flagged a verifier-bypass"}"#;
        let stub_body = format!(
            "set -euo pipefail\n\
             printf '%s\\n' \"$*\" >> {argv}\n\
             [[ \"$1\" == --host-key ]]\n\
             shift\n\
             [[ \"$1\" == gate && \"$2\" == review ]]\n\
             printf 'LOOM_FINDING: {finding}\\nLOOM_CONCERN: {concern}\\n'\n",
            argv = argv_log.to_string_lossy(),
            finding = finding_payload,
            concern = concern_payload,
        );
        loom_test_support::write_executable_bash_script(&stub, &stub_body)
            .expect("write host-key review stub");

        let bd_runner = molecule_lookup_script(dir.path(), "alpha", "lm-mol1", "deadbeef");
        let bd_calls = bd_runner.calls_handle();
        let bd = BdClient::with_runner(bd_runner);
        let git = git_workspace(&workspace);
        std::fs::create_dir_all(git.loom_workspace().join("specs")).unwrap();
        std::fs::copy(
            workspace.join("specs/alpha.md"),
            git.loom_workspace().join("specs/alpha.md"),
        )
        .unwrap();
        // Capture the SpawnConfig the next `run_bead` synthesizes so we
        // can assert the rendered prompt carried the ReviewConcern body.
        let captured: Arc<Mutex<Option<SpawnConfig>>> = Arc::new(Mutex::new(None));
        let captured_inner = Arc::clone(&captured);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            label.clone(),
            stub,
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            move |cfg: SpawnConfig, _bead_id: BeadId| {
                let captured = Arc::clone(&captured_inner);
                async move {
                    *captured.lock().unwrap() = Some(cfg);
                    (
                        SessionResult::Complete(SessionOutcome {
                            exit_code: 0,
                            cost_usd: None,
                        }),
                        Some(ExitSignal::Complete),
                    )
                }
            },
        );

        // Pre-condition: nothing stashed yet.
        assert!(controller.stashed_review_concern.is_none());

        controller.exec_review().await.expect("exec_review ok");

        {
            let calls = {
                let guard = bd_calls.lock().expect("bd calls lock");
                guard
                    .iter()
                    .map(|args| {
                        args.iter()
                            .map(|arg| arg.to_string_lossy().into_owned())
                            .collect::<Vec<_>>()
                    })
                    .collect::<Vec<_>>()
            };
            let create = calls
                .iter()
                .find(|call| call.first().is_some_and(|arg| arg == "create"))
                .expect("review concern creates remediation");
            assert!(
                create
                    .windows(2)
                    .any(|pair| pair[0] == "--parent" && pair[1] == "lm-mol1")
            );
            assert!(create.iter().any(|arg| arg.contains("loom:deferred")));
            assert!(
                !calls
                    .iter()
                    .any(|call| call.starts_with(&["mol".to_owned(), "bond".to_owned()]))
            );
            assert!(calls.iter().any(|call| {
                call.windows(2)
                    .any(|pair| pair[0] == "--status" && pair[1] == "deferred")
            }));
        }

        // The streamed findings + the terminal concern summary land on
        // the molecule-scoped stash as a typed
        // `PreviousFailure::ReviewConcern { summary, findings }`.
        let stashed = controller
            .stashed_review_concern
            .as_ref()
            .expect("stashed_review_concern populated after concern terminator");
        match stashed {
            PreviousFailure::ReviewConcern { summary, findings } => {
                assert_eq!(
                    summary, "reviewer flagged a verifier-bypass",
                    "terminal summary threaded verbatim",
                );
                assert_eq!(findings.len(), 1, "one streamed finding parsed");
                assert_eq!(
                    findings[0].token(),
                    crate::review::ConcernToken::VerifierBypass,
                );
                assert_eq!(findings[0].evidence(), "test mocks the agent backend");
            }
            other => panic!("expected ReviewConcern, got {other:?}"),
        }

        // The next `run_bead` call (fresh dispatch — `previous_failure =
        // None`) consumes the molecule-scoped stash; the typed
        // `PreviousFailure::ReviewConcern` rides into the rendered
        // prompt verbatim. The dispatch closure captures the
        // `SpawnConfig.initial_prompt` so the assertions can scan the
        // exact prompt body the agent would receive.
        let fixup_bead = bead("lm-fixup");
        let _ = controller
            .run_bead(&fixup_bead, None)
            .await
            .expect("run_bead ok");
        assert!(
            controller.stashed_review_concern.is_none(),
            "stash consumed by the next run_bead call",
        );
        let cfg = captured
            .lock()
            .unwrap()
            .take()
            .expect("dispatch closure invoked");
        let prompt = &cfg.initial_prompt;
        assert!(
            prompt.contains("Review raised a concern"),
            "rendered prompt must carry the ReviewConcern framing: {prompt}",
        );
        assert!(
            prompt.contains("verifier-bypass"),
            "rendered prompt must name the finding's token: {prompt}",
        );
        assert!(
            prompt.contains("test mocks the agent backend"),
            "rendered prompt must include the finding's evidence: {prompt}",
        );
    }

    /// FR1 negative: when no `current_molecule` pointer exists for the
    /// spec, `exec_review` MUST surface `NoActiveMolecule` rather than
    /// silently falling back to `--tree` — the push-gate scope is
    /// load-bearing and a missing molecule means the run is
    /// specs/gate.md § "Persistence boundary: agent narrates, agent persists":
    /// when the bead under dispatch carries a well-formed `## Options — …`
    /// block, the runner's `apply_clarify` only stamps the `loom:clarify`
    /// label — the canonical block belongs to the agent, written to bead
    /// state *before* `LOOM_CLARIFY` is emitted. If the runner also wrote
    /// the agent's stdout reason-line via `bd update --notes`, every
    /// re-emit would clobber the canonical block and leave `loom inbox`'s
    /// queue empty.
    #[tokio::test(flavor = "multi_thread")]
    async fn apply_clarify_does_not_write_notes() {
        let dir = tempfile::tempdir().expect("tempdir");
        let manifest = write_manifest(dir.path());
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let well_formed = "## Options — pick a path\\n\\n### Option 1 — first\\nbody";
        let show_row = format!(
            r#"[{{"id":"lm-clarify.1","title":"t","status":"open","priority":2,"issue_type":"task","description":"{well_formed}"}}]"#,
        );
        let scripted = ScriptedBd::new([ok_stdout(show_row.as_bytes()), ok_stdout(b"")]);
        let calls = scripted.calls_handle();
        let bd = BdClient::with_runner(scripted);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("gate").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );
        let bead_id = BeadId::new("lm-clarify.1").expect("bead id");
        controller
            .apply_clarify(
                &bead_id,
                "agent's one-line reason that must not clobber notes",
            )
            .await
            .expect("apply_clarify ok");
        let captured = calls.lock().unwrap();
        assert_eq!(
            captured.len(),
            2,
            "expected one bd show + one bd update invocation",
        );
        let update_argv: Vec<String> = captured[1]
            .iter()
            .map(|s| s.to_string_lossy().into_owned())
            .collect();
        drop(captured);
        assert_eq!(update_argv[0], "update");
        assert_eq!(update_argv[1], "lm-clarify.1");
        assert!(
            update_argv.iter().any(|a| a == "--add-label"),
            "missing --add-label in argv: {update_argv:?}",
        );
        assert!(
            update_argv.iter().any(|a| a == "loom:clarify"),
            "missing loom:clarify label in argv: {update_argv:?}",
        );
        assert!(
            !update_argv.iter().any(|a| a == "--notes"),
            "apply_clarify must not forward --notes when options block is \
             well-formed (persistence boundary): {update_argv:?}",
        );
        assert!(
            update_argv
                .windows(2)
                .any(|w| w[0] == "--status" && w[1] == "blocked"),
            "apply_clarify must pair --status blocked with --add-label so \
             `bd ready` excludes via its native status filter: {update_argv:?}",
        );
    }

    /// Dedup contract: `apply_blocked` must set `--status blocked` in the
    /// same `bd update` invocation as `--add-label loom:blocked`. Without
    /// this, the run loop would re-dispatch the blocked bead every pass —
    /// the regression that motivated lm-uzrc.
    #[tokio::test]
    async fn apply_blocked_pairs_status_blocked_with_add_label() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let scripted = ScriptedBd::new([RunOutput {
            status: 0,
            stdout: Vec::new(),
            stderr: Vec::new(),
        }]);
        let calls = scripted.calls_handle();
        let bd = BdClient::with_runner(scripted);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("gate").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );
        let bead_id = BeadId::new("lm-blocked.1").expect("bead id");
        controller
            .apply_blocked(&bead_id, "agent-blocked", "operator decision needed")
            .await
            .expect("apply_blocked ok");
        let captured = calls.lock().unwrap();
        assert_eq!(captured.len(), 1, "exactly one bd invocation expected");
        let argv: Vec<String> = captured[0]
            .iter()
            .map(|s| s.to_string_lossy().into_owned())
            .collect();
        drop(captured);
        assert_eq!(argv[0], "update");
        assert_eq!(argv[1], "lm-blocked.1");
        assert!(
            argv.iter().any(|a| a == "loom:blocked"),
            "missing loom:blocked label in argv: {argv:?}",
        );
        assert!(
            argv.windows(2)
                .any(|w| w[0] == "--status" && w[1] == "blocked"),
            "apply_blocked must pair --status blocked with --add-label so \
             `bd ready` excludes via its native status filter: {argv:?}",
        );
    }

    #[tokio::test]
    async fn apply_infra_pairs_status_blocked_with_infra_label_and_metadata() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let scripted = ScriptedBd::new([RunOutput {
            status: 0,
            stdout: Vec::new(),
            stderr: Vec::new(),
        }]);
        let calls = scripted.calls_handle();
        let bd = BdClient::with_runner(scripted);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("gate").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );
        let bead_id = BeadId::new("lm-infra.1").expect("bead id");
        let diagnostic = InfraDiagnostic::retryable(
            "infra-preflight",
            "infra-preflight",
            "podman load failed".to_string(),
            2,
            3,
            false,
        );

        controller
            .apply_infra(&bead_id, &diagnostic)
            .await
            .expect("apply_infra ok");

        let captured = calls.lock().unwrap();
        let argv: Vec<String> = captured[0]
            .iter()
            .map(|s| s.to_string_lossy().into_owned())
            .collect();
        drop(captured);
        assert!(argv.iter().any(|a| a == "loom:infra"), "{argv:?}");
        assert!(!argv.iter().any(|a| a == "loom:blocked"), "{argv:?}");
        assert!(
            argv.windows(2)
                .any(|w| w[0] == "--status" && w[1] == "blocked"),
            "{argv:?}",
        );
        assert!(
            argv.windows(2)
                .any(|w| w[0] == "--set-metadata" && w[1] == "loom.infra.attempt=2"),
            "{argv:?}",
        );
        assert!(
            argv.windows(2)
                .any(|w| w[0] == "--set-metadata" && w[1] == "loom.infra.class=infra-preflight"),
            "{argv:?}",
        );
        assert!(
            argv.windows(2).any(|w| w[0] == "--append-notes"
                && w[1].starts_with("infra-preflight: podman load failed")),
            "{argv:?}",
        );
    }

    /// Dedup contract: `next_ready_bead` must NOT forward `--exclude-label`
    /// any more. The argv to `bd ready` carries `--label` for the spec
    /// filter and no exclude flags — clarify/blocked dedup is now anchored
    /// in the paired `status=blocked` transition.
    #[tokio::test]
    async fn next_ready_bead_does_not_forward_exclude_label() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let scripted = ScriptedBd::new([ok_stdout(b"[]\n")]);
        let calls = scripted.calls_handle();
        let bd = BdClient::with_runner(scripted);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("gate").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );
        let _ = controller.next_ready_bead(&[]).await.expect("ready ok");
        let captured = calls.lock().unwrap();
        assert_eq!(
            captured.len(),
            2,
            "ready lookup then infra fallback expected"
        );
        let argv: Vec<String> = captured[0]
            .iter()
            .map(|s| s.to_string_lossy().into_owned())
            .collect();
        drop(captured);
        assert_eq!(argv[0], "ready");
        assert!(
            !argv.iter().any(|a| a.starts_with("--exclude-label")),
            "next_ready_bead must NOT forward --exclude-label; argv={argv:?}",
        );
    }

    #[tokio::test]
    async fn next_ready_bead_with_ready_parent_omits_spec_filter() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let scripted = ScriptedBd::new([ok_stdout(b"[]\n")]);
        let calls = scripted.calls_handle();
        let bd = BdClient::with_runner(scripted);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("agent").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        )
        .with_ready_parent(BeadId::new("lm-root").expect("valid bead id"));
        let _ = controller.next_ready_bead(&[]).await.expect("ready ok");
        let captured = calls.lock().unwrap();
        assert_eq!(
            captured.len(),
            2,
            "ready lookup then infra fallback expected"
        );
        let argv: Vec<String> = captured[0]
            .iter()
            .map(|s| s.to_string_lossy().into_owned())
            .collect();
        drop(captured);
        assert!(
            argv.iter().any(|arg| arg == "--parent=lm-root"),
            "ready lookup must be scoped to the active work epic: {argv:?}",
        );
        assert!(
            !argv.iter().any(|arg| arg.starts_with("--label=")),
            "multi-spec work epic lookup must not narrow by spec: {argv:?}",
        );
    }

    /// Spec gate (`specs/harness.md` § Worker-queue resolution): the
    /// per-bead loop dispatches LEAVES, not molecule containers. A `bd
    /// ready` response carrying a `type=epic` bead must be skipped over
    /// and the next non-epic bead surfaced; the epic-skip emits an
    /// info-level log line so operators see the routing decision.
    #[tokio::test]
    async fn worker_queue_skips_epic_type_beads_with_info_log() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let body = br#"[
            {"id":"lm-epic.1","title":"epic","description":"","status":"open","priority":2,"issue_type":"epic","labels":["spec:gate","profile:base"]},
            {"id":"lm-leaf.2","title":"leaf","description":"","status":"open","priority":2,"issue_type":"task","labels":["spec:gate","profile:base"]}
        ]"#;
        let scripted = ScriptedBd::new([ok_stdout(body)]);
        let bd = BdClient::with_runner(scripted);
        let mut controller = ProductionAgentLoopController::new(
            bd,
            SpecLabel::new("gate").unwrap(),
            PathBuf::from("/loom/bin"),
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                (
                    SessionResult::Complete(SessionOutcome {
                        exit_code: 0,
                        cost_usd: None,
                    }),
                    Some(ExitSignal::Complete),
                )
            },
        );
        let picked = controller
            .next_ready_bead(&[])
            .await
            .expect("ready ok")
            .expect("a non-epic bead must surface");
        assert_eq!(
            picked.id.as_str(),
            "lm-leaf.2",
            "worker queue must skip the epic and return the leaf bead",
        );
    }

    /// Spec criterion (`specs/gate.md` § *Production walker wiring*):
    /// the production per-bead gate invokes deterministic verify as the
    /// only real subprocess against `loom_bin`.
    #[tokio::test]
    async fn exec_per_bead_gate_invokes_post_integration_verify_only() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let stub = dir.path().join("loom-stub.sh");
        loom_test_support::write_executable_bash_script(
            &stub,
            "set -euo pipefail\n\
             echo \"$*\" >> \"$PWD/argv.log\"\n\
             case \"$2\" in\n\
                 review|mint) echo \"$2 must not run in the per-bead hot path\" >&2; exit 99 ;;\n\
             esac\n\
             exit 0\n",
        )
        .expect("write stub");

        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("gate").unwrap(),
            stub.clone(),
            workspace.clone(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("spawn closure must not fire during exec_per_bead_gate");
            },
        );

        let bead_id = BeadId::new("lm-1").expect("valid bead id");
        let pre_tip = loom_driver::git::sync_head_commit_sha(&controller.git.loom_workspace())
            .expect("pre-integration sha");
        controller.pre_integration_tip = Some(pre_tip.clone());
        let outcome = controller
            .exec_per_bead_gate(&bead_id)
            .await
            .expect("exec_per_bead_gate ok");
        assert_eq!(outcome, PerBeadGateOutcome::Clean);

        let operator_log = workspace.join("argv.log");
        assert!(
            !operator_log.exists(),
            "post-integration gate must not run in stale operator checkout",
        );
        let log_path = controller.git.loom_workspace().join("argv.log");
        let log = std::fs::read_to_string(log_path).expect("argv.log readable");
        let calls: Vec<&str> = log.lines().collect();
        assert_eq!(
            calls.len(),
            1,
            "exec_per_bead_gate must spawn exactly one subprocess: {calls:?}",
        );
        assert_eq!(
            calls[0],
            format!("gate verify --diff {pre_tip}..HEAD"),
            "subprocess argv must be exactly `loom gate verify --diff <pre-integration-head>..HEAD`",
        );
    }

    #[tokio::test]
    async fn exec_per_bead_gate_releases_lock_before_spawning_children() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("gate").unwrap();
        let root = BeadId::new("lm-gate").expect("valid bead id");
        let mgr = loom_driver::lock::LockManager::with_state_home(&workspace, dir.path())
            .expect("lock manager");
        let clock = loom_driver::clock::SystemClock::new();
        let guard = mgr
            .acquire_work_root_async(&root, &clock)
            .await
            .expect("first acquire");
        let lock_path = mgr.locks_dir().join("lm-gate.lock");
        let stub = dir.path().join("loom-stub.sh");
        loom_test_support::write_executable_bash_script(
            &stub,
            &format!(
                "set -euo pipefail\n\
                 exec 9>\"{}\"\n\
                 flock -n 9\n\
                 if [[ \"$2\" == \"review\" ]]; then\n\
                     exit 99\n\
                 fi\n\
                 exit 0\n",
                lock_path.display(),
            ),
        )
        .expect("write stub");

        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            label,
            stub,
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("spawn closure must not fire during exec_per_bead_gate");
            },
        )
        .with_handoff_lock(guard);

        let bead_id = BeadId::new("lm-1").expect("valid bead id");
        let outcome = controller
            .exec_per_bead_gate(&bead_id)
            .await
            .expect("exec_per_bead_gate ok");
        assert_eq!(outcome, PerBeadGateOutcome::Clean);
    }

    #[tokio::test]
    async fn production_gate_preserves_candidate_after_verifier_infrastructure_exhaustion() {
        let dir = tempfile::tempdir().expect("fixture");
        let workspace = dir.path().join("workspace");
        let git = git_workspace(&workspace);
        let integration = git.loom_workspace();
        let base = loom_driver::git::sync_head_commit_sha(&integration).expect("base");
        std::fs::write(integration.join("candidate.txt"), "retained candidate\n").expect("source");
        loom_driver::git::commit_all_in(&integration, "candidate").expect("candidate commit");
        let bead = BeadId::new("lm-vinfra").expect("id");
        let candidate = git
            .create_worktree(&SpecLabel::new("gate").expect("label"), &bead)
            .await
            .expect("independent source clone");
        let manifest = write_manifest(dir.path());
        let stub = dir.path().join("unavailable-verifier.sh");
        loom_test_support::write_executable_bash_script(
            &stub,
            "set -euo pipefail\nprintf 'required isolated executor unavailable\\n' >&2\nexit 78\n",
        )
        .expect("external verifier");
        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("gate").expect("label"),
            stub,
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").expect("profile"),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("verification recovery cannot dispatch source work");
            },
        );
        controller.pre_integration_tip = Some(base.clone());
        controller.current_worktree_path = Some(candidate.path.clone());
        let head = loom_driver::git::sync_head_commit_sha(&integration).expect("candidate");
        let result = controller
            .exec_per_bead_gate(&bead)
            .await
            .expect("bounded gate");
        assert!(matches!(result, PerBeadGateOutcome::Infrastructure { .. }));
        assert!(controller.stashed_previous_failure.is_none());
        assert_eq!(
            loom_driver::git::sync_head_commit_sha(&candidate.path)
                .expect("preserved source candidate"),
            head
        );
        assert_eq!(
            loom_driver::git::sync_head_commit_sha(&integration).expect("integration rollback"),
            base
        );
        assert!(candidate.path.join("candidate.txt").exists());
        let attempts = std::fs::read_to_string(
            integration.join(".loom/diagnostics/verification-attempts.jsonl"),
        )
        .expect("durable attempts");
        assert_eq!(attempts.lines().count(), 1);
        for row in attempts.lines() {
            let row: serde_json::Value = serde_json::from_str(row).expect("observation");
            assert_eq!(row["head"], head.as_str());
            assert_eq!(row["coverage_admitted"], false);
        }
    }

    #[tokio::test]
    async fn production_scheduler_resumes_exhausted_verification_after_restart_without_source_dispatch()
     {
        let dir = tempfile::tempdir().expect("fixture");
        let workspace = dir.path().join("workspace");
        let git = git_workspace(&workspace);
        let integration = git.loom_workspace();
        let base = loom_driver::git::sync_head_commit_sha(&integration).expect("base");
        for n in 0..3 {
            std::fs::write(
                integration.join("candidate.txt"),
                format!("candidate {n}\n"),
            )
            .expect("source");
            loom_driver::git::commit_all_in(&integration, "candidate").expect("commit");
        }
        let candidate = loom_driver::git::sync_head_commit_sha(&integration).expect("candidate");
        let id = BeadId::new("lm-vresume").expect("id");
        let label = SpecLabel::new("gate").expect("label");
        let source = git
            .create_worktree(&label, &id)
            .await
            .expect("independent source");
        git.preserve_verification_candidate(&id, &candidate)
            .await
            .expect("pin");
        let association =
            loom_driver::workspace::Association::resolve(&workspace).expect("authority");
        assert!(
            !git.has_pending_verification_tip()
                .await
                .expect("unregistered ahead work stays rejected")
        );
        association
            .begin_verification(
                id.clone(),
                label.clone(),
                None,
                base.clone(),
                candidate.clone(),
            )
            .expect("driver continuation");
        assert!(
            git.has_pending_verification_tip()
                .await
                .expect("registered candidate reaches restart recovery")
        );
        let unavailable = dir.path().join("unavailable");
        std::fs::write(&unavailable, "outage\n").expect("fault");
        let stub = dir.path().join("verifier.sh");
        loom_test_support::write_executable_bash_script(
            &stub,
            &format!("set -euo pipefail\nif [[ -f {unavailable:?} ]]; then exit 78; fi\nexit 0\n"),
        )
        .expect("verifier");
        let closed = br#"[{"id":"lm-vresume","title":"completed source","description":"","status":"closed","priority":2,"issue_type":"task","labels":["spec:gate"]}]"#;
        let parked = br#"[{"id":"lm-vresume","title":"completed source","description":"","status":"blocked","priority":2,"issue_type":"task","labels":["spec:gate","loom:infra"],"metadata":{"loom.infra.phase":"loop","loom.infra.cause":"verification-capability-unavailable"}}]"#;
        let manifest = write_manifest(dir.path());
        let mut first = ProductionAgentLoopController::new(
            BdClient::with_runner(ScriptedBd::new([
                ok_stdout(closed),
                ok_stdout(b""),
                ok_stdout(b"[]"),
                ok_stdout(parked),
            ])),
            label.clone(),
            stub.clone(),
            workspace.clone(),
            git,
            Arc::clone(&manifest),
            None,
            ProfileName::new("base").expect("profile"),
            |_cfg: SpawnConfig, _id: BeadId| async move {
                panic!("source dispatch forbidden during verifier continuation")
            },
        );
        first.pre_integration_tip = Some(base.clone());
        first.current_worktree_path = Some(source.path.clone());
        assert!(matches!(
            first.exec_per_bead_gate(&id).await.expect("bounded outage"),
            PerBeadGateOutcome::Infrastructure { .. }
        ));
        assert_eq!(
            loom_driver::git::sync_head_commit_sha(&integration).expect("exact rollback"),
            base
        );
        first
            .apply_infra(
                &id,
                &InfraDiagnostic::static_diagnostic(
                    super::super::VERIFICATION_CAPABILITY_UNAVAILABLE_CAUSE,
                    "outage".into(),
                ),
            )
            .await
            .expect("park verification only");
        assert!(
            first
                .next_ready_bead(&[])
                .await
                .expect("no same-invocation retry")
                .is_none()
        );
        drop(first);
        assert_eq!(
            association
                .verification_continuations()
                .expect("retained")
                .len(),
            1
        );
        std::fs::write(
            integration.join("independent.txt"),
            "independent accepted work\n",
        )
        .expect("independent source");
        loom_driver::git::commit_all_in(&integration, "independent work")
            .expect("independent commit");
        std::fs::remove_file(&unavailable).expect("bounded fixture outage ends automatically");
        let policy = loom_driver::git::RepoGitPolicy::resolve(
            &workspace,
            "unused-wrix".into(),
            loom_driver::git::KeyMode::Host,
        )
        .expect("fixture policy");
        let git = GitClient::open(&workspace)
            .expect("existing repository")
            .with_repo_git_policy(policy);
        let sweep_script = ScriptedBd::new([]);
        let sweep_calls = sweep_script.calls_handle();
        let sweep_bd = BdClient::with_runner(sweep_script);
        assert_eq!(
            git.sweep_orphan_bead_clones(
                &sweep_bd,
                &MoleculeId::new("lm-vmolecule").expect("molecule")
            )
            .await
            .expect("startup recovery retention"),
            Vec::<PathBuf>::new()
        );
        assert!(sweep_calls.lock().expect("sweep calls").is_empty());
        assert!(source.path.exists());
        let scripted = ScriptedBd::new([
            ok_stdout(b"[]"),
            ok_stdout(b"[]"),
            ok_stdout(parked),
            ok_stdout(parked),
            ok_stdout(parked),
            ok_stdout(b""),
        ]);
        let calls = scripted.calls_handle();
        let bd = BdClient::with_runner(scripted);
        let mut resumed = ProductionAgentLoopController::new(
            bd,
            label,
            stub,
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").expect("profile"),
            |_cfg: SpawnConfig, _id: BeadId| async move {
                panic!("restart must resume verifier, never implementation")
            },
        );
        let bead = resumed
            .next_ready_bead(&[])
            .await
            .expect("production scheduler")
            .expect("pending candidate");
        assert_eq!(bead.id, id);
        let pending = association
            .verification_continuations()
            .expect("pending")
            .remove(0);
        let (interrupted, concurrent) = tokio::join!(
            resumed
                .git
                .restore_verification_branch(&id, &pending.candidate),
            resumed
                .git
                .restore_verification_branch(&id, &pending.candidate),
        );
        let interrupted_branch = interrupted.expect("transient branch");
        let concurrent_branch = concurrent.expect("distinct concurrent branch");
        assert_ne!(interrupted_branch, concurrent_branch);
        assert_eq!(
            resumed
                .git
                .rebase_onto_integration(&interrupted_branch)
                .await
                .expect("interrupted transition"),
            RebaseOutcome::Rebased
        );
        let interrupted_tip = loom_driver::git::sync_rev_parse(&integration, &interrupted_branch)
            .expect("rebased branch");
        assert_ne!(interrupted_tip, pending.candidate);
        assert_eq!(
            association
                .verification_continuations()
                .expect("unadvanced journal")[0]
                .candidate,
            pending.candidate
        );
        assert_eq!(
            resumed
                .run_bead(&bead, None)
                .await
                .expect("restore candidate"),
            AgentOutcome::Success
        );
        assert_eq!(
            resumed
                .exec_per_bead_gate(&id)
                .await
                .expect("verify resumed snapshot"),
            PerBeadGateOutcome::Clean
        );
        let publication = association
            .verification_continuations()
            .expect("publication continuation remains");
        assert_eq!(publication.len(), 1);
        assert!(publication[0].awaiting_publication());
        assert_eq!(
            loom_driver::git::sync_head_commit_sha(&source.path).expect("source preserved"),
            candidate
        );
        assert_eq!(
            loom_driver::git::sync_rev_parse(&integration, &interrupted_branch)
                .expect("interrupted branch retained"),
            interrupted_tip
        );
        assert_eq!(
            loom_driver::git::sync_rev_parse(&integration, &concurrent_branch)
                .expect("concurrent branch retained"),
            pending.candidate
        );
        assert!(integration.join("independent.txt").exists());
        assert!(integration.join("candidate.txt").exists());
        assert!(source.path.exists());
        let calls = calls.lock().expect("calls").clone();
        assert!(
            calls
                .iter()
                .any(|args| args.iter().any(|arg| arg == "--status=closed")
                    || args
                        .windows(2)
                        .any(|args| args[0] == "--status" && args[1] == "closed")),
            "original worker closure restored only after verification: {calls:?}"
        );
        let request = super::super::schedule::Request {
            workspace: resumed.workspace.clone(),
            label: resumed.label.clone(),
            ready_parent: None,
            parallelism: "2".parse().expect("parallelism"),
            agent_override: None,
            wrix_bin: resumed.wrix_bin.clone(),
            loom_bin: resumed.loom_bin.clone(),
            loom: resumed.loom_cfg.clone(),
            retry_policy: super::super::RetryPolicy::default(),
            infra_policy: super::super::InfraRetryPolicy { max_attempts: 3 },
            max_iterations: 2,
            repo_git_policy: loom_driver::git::RepoGitPolicy::resolve(
                &resumed.workspace,
                "unused-wrix".into(),
                loom_driver::git::KeyMode::Host,
            )
            .expect("fixture policy"),
            manifest: Arc::clone(&resumed.manifest),
        };
        drop(resumed);
        for label in ["loom:blocked", "loom:clarify", "loom:deferred"] {
            let mut source: Vec<Bead> = serde_json::from_slice(closed).expect("source");
            source[0]
                .labels
                .push(loom_driver::bd::Label::new(label).expect("hold label"));
            let held_source = serde_json::to_vec(&source).expect("held source");
            let (ids, work) = super::super::schedule::resume_verification_candidates(
                &request,
                BdClient::with_runner(ScriptedBd::new([ok_stdout(&held_source)])),
                &mut super::super::schedule::VerificationRecovery::default(),
            )
            .await
            .expect("independent hold remains untouched");
            assert!(ids.is_empty());
            assert!(!work);
        }
        let (ids, work) = super::super::schedule::resume_verification_candidates(
            &request,
            BdClient::with_runner(ScriptedBd::new([
                ok_stdout(closed),
                ok_stdout(closed),
                ok_stdout(closed),
            ])),
            &mut super::super::schedule::VerificationRecovery::default(),
        )
        .await
        .expect("parallel verifier-only restart");
        assert_eq!(ids, HashSet::from([id]));
        assert!(work);
        assert_eq!(
            loom_driver::git::sync_head_commit_sha(&source.path)
                .expect("source retained across both scheduler modes"),
            candidate
        );
        assert!(!integration.join(".loom/marker.json").exists());
    }

    #[tokio::test]
    async fn parallel_repaired_candidates_repeat_required_verification_before_publication() {
        parallel_repair_campaign(true, 2).await;
    }

    #[tokio::test]
    async fn parallel_semantic_repair_budget_survives_restart_and_retains_rejected_history() {
        for budget in [0, 2] {
            parallel_repair_campaign(false, budget).await;
        }
    }

    async fn parallel_repair_campaign(accept_final: bool, max_retries: u32) {
        let dir = tempfile::tempdir().expect("fixture");
        let workspace = dir.path().join("workspace");
        let git = git_workspace(&workspace);
        let integration = git.loom_workspace();
        let label = SpecLabel::new("gate").expect("label");
        let mut source = bead("lm-reverified");
        source.status = loom_driver::bd::Status::Closed;
        let observed = serde_json::to_vec(&vec![source.clone()]).expect("native closed source");
        let verifier = dir.path().join("verifier");
        loom_test_support::write_executable_bash_script(&verifier, "set -euo pipefail\nprintf 'executed\\n' >> .loom/verifier-executions\nif [[ ! -f accepted.txt ]]; then printf 'required system assertion failed\\n' >&2; exit 1; fi\n").expect("verifier");
        let request = super::super::schedule::Request {
            workspace: workspace.clone(),
            label: label.clone(),
            ready_parent: None,
            parallelism: "2".parse().expect("parallelism"),
            agent_override: None,
            wrix_bin: "unused-wrix".into(),
            loom_bin: verifier,
            loom: loom_driver::config::LoomTopConfig::default(),
            retry_policy: super::super::RetryPolicy { max_retries },
            infra_policy: super::super::InfraRetryPolicy { max_attempts: 2 },
            max_iterations: 5,
            repo_git_policy: loom_driver::git::RepoGitPolicy::resolve(
                &workspace,
                "unused-wrix".into(),
                loom_driver::git::KeyMode::Host,
            )
            .expect("policy"),
            manifest: write_manifest(dir.path()),
        };
        let association =
            loom_driver::workspace::Association::resolve(&workspace).expect("authority");
        let mut recovery = super::super::schedule::VerificationRecovery::default();
        let mut rejected = Vec::new();
        for round in 0..=max_retries {
            let manifest = Arc::clone(&request.manifest);
            let operator = workspace.clone();
            let worker_label = label.clone();
            let batch = super::super::parallel::run_parallel_batch_for_root(
                &git,
                &label,
                vec![source.clone()],
                None,
                None,
                move |slot| {
                    let manifest = Arc::clone(&manifest);
                    let operator = operator.clone();
                    let worker_label = worker_label.clone();
                    async move {
                        assert_eq!(slot.attempt, round);
                        if round == 0 {
                            assert!(slot.previous_failure.is_none());
                        } else {
                            let Some(PreviousFailure::PostIntegrateFail {
                                failures,
                                gate_log_path,
                            }) = &slot.previous_failure
                            else {
                                panic!("typed integration failure missing");
                            };
                            assert!(failures[0].target.starts_with("loom gate verify --diff "));
                            assert_eq!(failures[0].exit_code, 1);
                            assert!(
                                failures[0]
                                    .stderr_tail
                                    .contains("required system assertion failed")
                            );
                            assert!(gate_log_path.exists());
                            let prepared =
                                super::super::worker::prepare(super::super::worker::Request {
                                    bead: &slot.bead,
                                    workspace: &slot.worktree.path,
                                    loom_workspace: &operator,
                                    manifest: &manifest,
                                    cli_profile: None,
                                    phase_default: &ProfileName::base(),
                                    runtime: AgentRuntime::Pi,
                                    label: &worker_label,
                                    style_rules: "docs/style-rules.md",
                                    loom: &LoomTopConfig::default(),
                                    skills: &SkillsConfig::default(),
                                    launcher_env: vec![],
                                    previous_failure: slot.previous_failure.clone(),
                                    bead_base: slot.bead_base.clone(),
                                    workspace_recovery: slot.workspace_recovery.clone(),
                                    attempt: slot.attempt,
                                })
                                .await
                                .expect("real repair prompt preparation");
                            let super::super::worker::Preparation::Ready(worker) = prepared else {
                                panic!("repair prompt rejected");
                            };
                            assert!(
                                worker
                                    .spawn
                                    .initial_prompt
                                    .contains("required system assertion failed")
                            );
                            assert!(
                                worker
                                    .spawn
                                    .initial_prompt
                                    .contains(&gate_log_path.display().to_string())
                            );
                        }

                        if round == 1 {
                            return AgentOutcome::Noop;
                        }
                        std::fs::write(
                            slot.worktree.path.join("implementation.txt"),
                            format!("repair {round}\n"),
                        )
                        .expect("source");
                        if accept_final && round == max_retries {
                            std::fs::write(slot.worktree.path.join("accepted.txt"), "corrected\n")
                                .expect("fixed source");
                        }
                        loom_driver::git::commit_all_in(
                            &slot.worktree.path,
                            "repair source candidate",
                        )
                        .expect("commit");
                        AgentOutcome::Success
                    }
                },
            )
            .await
            .expect("real source merge");
            assert_eq!(batch.merged_ids(), vec![source.id.clone()]);
            let candidate =
                loom_driver::git::sync_head_commit_sha(&integration).expect("candidate");
            let responses = if !accept_final && round == max_retries {
                vec![
                    ok_stdout(&observed),
                    ok_stdout(&observed),
                    ok_stdout(&observed),
                    ok_stdout(&observed),
                    ok_stdout(b""),
                ]
            } else if round < max_retries {
                vec![
                    ok_stdout(&observed),
                    ok_stdout(&observed),
                    ok_stdout(&observed),
                    ok_stdout(b""),
                ]
            } else {
                vec![
                    ok_stdout(&observed),
                    ok_stdout(&observed),
                    ok_stdout(&observed),
                ]
            };
            let runner = ScriptedBd::new(responses);
            let calls = runner.calls_handle();
            let (completed, worked) = super::super::schedule::resume_verification_candidates(
                &request,
                BdClient::with_runner(runner),
                &mut recovery,
            )
            .await
            .expect("required verifier after each source merge");
            assert!(
                worked,
                "replacement source must never inherit an old candidate's exclusion"
            );
            let records = association.verification_continuations().expect("pending");
            if round < max_retries || !accept_final {
                if round < max_retries {
                    assert!(completed.is_empty());
                } else {
                    assert_eq!(completed, HashSet::from([source.id.clone()]));
                    assert!(calls.lock().expect("native calls").iter().any(|args| {
                        args.windows(2).any(|pair| {
                            pair[0] == "--append-notes"
                                && pair[1].to_string_lossy().contains("retry-exhausted")
                        })
                    }));
                }
                assert_eq!(records[0].semantic_failures, round + 1);

                assert!(records[0].needs_source_repair());
                assert!(
                    records[0]
                        .repair_detail
                        .as_ref()
                        .expect("feedback")
                        .contains("exited 1")
                );
                rejected.push(candidate);
            } else {
                assert_eq!(completed, HashSet::from([source.id.clone()]));
                assert!(records[0].awaiting_publication());
            }
        }
        assert_eq!(
            std::fs::read_to_string(integration.join(".loom/verifier-executions"))
                .expect("executions")
                .lines()
                .count(),
            usize::try_from(max_retries + 1).expect("small fixture budget")
        );
        if !accept_final {
            let mut blocked = source.clone();
            blocked.status = loom_driver::bd::Status::Blocked;
            blocked
                .labels
                .push(loom_driver::bd::Label::new("loom:blocked").expect("label"));
            let blocked = serde_json::to_vec(&vec![blocked]).expect("native blocked source");
            let (completed, work) = super::super::schedule::resume_verification_candidates(
                &request,
                BdClient::with_runner(ScriptedBd::new([ok_stdout(&blocked)])),
                &mut super::super::schedule::VerificationRecovery::default(),
            )
            .await
            .expect("restart preserves exhausted source");
            assert!(completed.is_empty());
            assert!(!work);
            assert!(
                association.verification_continuations().expect("retained")[0]
                    .needs_source_repair()
            );
            // A crash before the native blocked update cannot reset the durable semantic budget.
            let mut open = source.clone();
            open.status = loom_driver::bd::Status::Open;
            let open = serde_json::to_vec(&vec![open]).expect("native open source");
            let runner = ScriptedBd::new([
                ok_stdout(&open),
                ok_stdout(&open),
                ok_stdout(&open),
                ok_stdout(b""),
            ]);
            let calls = runner.calls_handle();
            let (completed, work) = super::super::schedule::resume_verification_candidates(
                &request,
                BdClient::with_runner(runner),
                &mut super::super::schedule::VerificationRecovery::default(),
            )
            .await
            .expect("restart before native parking update");
            assert_eq!(completed, HashSet::from([source.id.clone()]));
            assert!(!work);
            assert!(calls.lock().expect("calls").iter().any(|args| {
                args.windows(2).any(|pair| {
                    pair[0] == "--append-notes"
                        && pair[1].to_string_lossy().contains("retry-exhausted")
                })
            }));
        }
        for candidate in rejected {
            assert_eq!(
                loom_driver::git::sync_rev_parse(
                    &integration,
                    &format!("refs/loom/verification/{}/{candidate}", source.id)
                )
                .expect("rejected history retained"),
                candidate
            );
        }
    }

    #[tokio::test]
    async fn parallel_nested_descendant_retains_dispatch_root_for_verifier_restart() {
        let dir = tempfile::tempdir().expect("fixture");
        let workspace = dir.path().join("workspace");
        let git = git_workspace(&workspace);
        let root = BeadId::new("lm-ancestor").expect("root");
        let label = SpecLabel::new("gate").expect("label");
        let source: Bead = serde_json::from_value(serde_json::json!({"id":"lm-descendant","title":"nested source","status":"closed","parent":"lm-nested","labels":["spec:gate"]})).expect("bead");
        let outcome = super::super::parallel::run_parallel_batch_for_root(
            &git,
            &label,
            vec![source.clone()],
            None,
            Some(&root),
            |slot| async move {
                std::fs::write(
                    slot.worktree.path.join("nested.txt"),
                    "nested implementation\n",
                )
                .expect("source");
                loom_driver::git::commit_all_in(&slot.worktree.path, "implement nested source")
                    .expect("commit");
                AgentOutcome::Success
            },
        )
        .await
        .expect("parallel production merge");
        assert_eq!(outcome.merged_ids(), vec![source.id.clone()]);
        let association =
            loom_driver::workspace::Association::resolve(&workspace).expect("authority");
        let records = association
            .verification_continuations()
            .expect("continuation");
        assert_eq!(records[0].root, Some(root.clone()));
        let candidate =
            loom_driver::git::sync_head_commit_sha(&workspace.join(".loom/beads/lm-descendant"))
                .expect("source identity");
        let verifier = dir.path().join("verifier");
        loom_test_support::write_executable_bash_script(&verifier, "exit 0\n").expect("verifier");
        let request = super::super::schedule::Request {
            workspace: workspace.clone(),
            label,
            ready_parent: Some(root),
            parallelism: "2".parse().expect("parallelism"),
            agent_override: None,
            wrix_bin: "unused-wrix".into(),
            loom_bin: verifier,
            loom: loom_driver::config::LoomTopConfig::default(),
            retry_policy: super::super::RetryPolicy::default(),
            infra_policy: super::super::InfraRetryPolicy { max_attempts: 2 },
            max_iterations: 5,
            repo_git_policy: loom_driver::git::RepoGitPolicy::resolve(
                &workspace,
                "unused-wrix".into(),
                loom_driver::git::KeyMode::Host,
            )
            .expect("policy"),
            manifest: write_manifest(dir.path()),
        };
        let observed = serde_json::to_vec(&vec![source.clone()]).expect("native observation");
        let (ids, work) = super::super::schedule::resume_verification_candidates(
            &request,
            BdClient::with_runner(ScriptedBd::new([
                ok_stdout(&observed),
                ok_stdout(&observed),
                ok_stdout(&observed),
            ])),
            &mut super::super::schedule::VerificationRecovery::default(),
        )
        .await
        .expect("ancestor invocation resumes nested source");
        assert!(work);
        assert_eq!(ids, HashSet::from([source.id]));
        assert_eq!(
            loom_driver::git::sync_head_commit_sha(&workspace.join(".loom/beads/lm-descendant"))
                .expect("retained source"),
            candidate
        );
        assert!(
            association
                .verification_continuations()
                .expect("publication remains pending")[0]
                .awaiting_publication()
        );
    }

    #[tokio::test]
    async fn publication_continuation_rechecks_native_holds_after_prior_admission() {
        let dir = tempfile::tempdir().expect("fixture");
        let workspace = dir.path().join("workspace");
        let git = git_workspace(&workspace);
        let integration = git.loom_workspace();
        let base = loom_driver::git::sync_head_commit_sha(&integration).expect("base");
        std::fs::write(integration.join("candidate.txt"), "candidate\n").expect("source");
        loom_driver::git::commit_all_in(&integration, "candidate").expect("commit");
        let candidate = loom_driver::git::sync_head_commit_sha(&integration).expect("candidate");
        let id = BeadId::new("lm-current").expect("id");
        let label = SpecLabel::new("gate").expect("label");
        let root = BeadId::new("lm-root").expect("root");
        let molecule = MoleculeId::new(root.as_str()).expect("molecule");
        git.create_worktree(&label, &id)
            .await
            .expect("source clone");
        git.preserve_verification_candidate(&id, &candidate)
            .await
            .expect("pin");
        let association =
            loom_driver::workspace::Association::resolve(&workspace).expect("authority");
        let record = association
            .begin_verification(id, label.clone(), Some(root), base, candidate)
            .expect("continuation");
        association
            .await_verification_publication(&record)
            .expect("positive verifier");
        for held in [false, true] {
            let source = serde_json::to_vec(&serde_json::json!([{"id":"lm-current","title":"completed source","status":"closed","dependencies":[{"id":"lm-prerequisite","status":if held { "open" } else { "closed" },"dependency_type":"blocks"}]}])).expect("fresh native view");
            let bd = BdClient::with_runner(ScriptedBd::new([ok_stdout(&source)]));
            assert_eq!(
                verification_publication_ready(&bd, &label, &molecule, &workspace, &git)
                    .await
                    .expect("fresh publication admission"),
                !held
            );
        }
    }

    #[tokio::test]
    async fn pending_verification_reenters_after_independent_prerequisite_completion() {
        let dir = tempfile::tempdir().expect("fixture");
        let workspace = dir.path().join("workspace");
        let git = git_workspace(&workspace);
        let integration = git.loom_workspace();
        let base = loom_driver::git::sync_head_commit_sha(&integration).expect("base");
        std::fs::write(integration.join("pending.txt"), "pending source\n").expect("source");
        loom_driver::git::commit_all_in(&integration, "pending source").expect("commit");
        let candidate = loom_driver::git::sync_head_commit_sha(&integration).expect("candidate");
        let id = BeadId::new("lm-pending").expect("id");
        let label = SpecLabel::new("gate").expect("label");
        git.create_worktree(&label, &id)
            .await
            .expect("source clone");
        git.preserve_verification_candidate(&id, &candidate)
            .await
            .expect("pin");
        let association =
            loom_driver::workspace::Association::resolve(&workspace).expect("authority");
        association
            .begin_verification(id.clone(), label.clone(), None, base.clone(), candidate)
            .expect("continuation");
        git.reset_integration_to(base.as_str())
            .await
            .expect("rollback");
        let observed = |status: &str| {
            serde_json::to_vec(&serde_json::json!([{"id":"lm-pending","title":"completed source","status":"closed","dependencies":[{"id":"lm-prerequisite","status":status,"dependency_type":"blocks"}]}])).expect("native observation")
        };
        let held = observed("open");
        let released = observed("closed");
        let mut controller = ProductionAgentLoopController::new(
            BdClient::with_runner(ScriptedBd::new([
                ok_stdout(b"[]"),
                ok_stdout(b"[]"),
                ok_stdout(&held),
                ok_stdout(b"[]"),
                ok_stdout(&released),
            ])),
            label,
            "unused-loom".into(),
            workspace,
            git,
            write_manifest(dir.path()),
            None,
            ProfileName::new("base").expect("profile"),
            |_cfg: SpawnConfig, _id: BeadId| async move {
                panic!("queue discovery cannot dispatch source")
            },
        );
        assert!(
            controller
                .next_ready_bead(&[])
                .await
                .expect("native prerequisite is active")
                .is_none()
        );
        assert_eq!(
            controller
                .next_ready_bead(&[])
                .await
                .expect("same driver observes completed prerequisite")
                .expect("verification is queued")
                .id,
            id
        );
    }

    #[tokio::test]
    async fn semantic_rejection_remains_pending_across_restart_and_source_redispatch() {
        for before_rollback in [false, true] {
            let dir = tempfile::tempdir().expect("fixture");
            let workspace = dir.path().join("workspace");
            let git = git_workspace(&workspace);
            let integration = git.loom_workspace();
            let base = loom_driver::git::sync_head_commit_sha(&integration).expect("base");
            std::fs::write(
                integration.join("rejected.txt"),
                "preserve rejected implementation\n",
            )
            .expect("source");
            loom_driver::git::commit_all_in(&integration, "rejected candidate").expect("commit");
            let candidate =
                loom_driver::git::sync_head_commit_sha(&integration).expect("candidate");
            let label = SpecLabel::new("gate").expect("label");
            let mut source = bead("lm-repair");
            source.status = loom_driver::bd::Status::Closed;
            let clone = git
                .create_worktree(&label, &source.id)
                .await
                .expect("source clone");
            git.preserve_verification_candidate(&source.id, &candidate)
                .await
                .expect("pin");
            let association =
                loom_driver::workspace::Association::resolve(&workspace).expect("authority");
            association
                .begin_verification(
                    source.id.clone(),
                    label.clone(),
                    None,
                    base.clone(),
                    candidate.clone(),
                )
                .expect("continuation");
            let verifier = dir.path().join("reject-verifier");
            loom_test_support::write_executable_bash_script(&verifier, "exit 1\n")
                .expect("verifier");
            let manifest = write_manifest(dir.path());
            let mut first = ProductionAgentLoopController::new(
                BdClient::with_runner(ScriptedBd::new([])),
                label.clone(),
                verifier.clone(),
                workspace.clone(),
                git,
                Arc::clone(&manifest),
                None,
                ProfileName::new("base").expect("profile"),
                |_cfg: SpawnConfig, _id: BeadId| async move {
                    panic!("verifier never redispatches source")
                },
            );
            first.pre_integration_tip = Some(base.clone());
            assert!(matches!(
                first
                    .exec_per_bead_gate(&source.id)
                    .await
                    .expect("real rejection"),
                PerBeadGateOutcome::Recovery { .. }
            ));
            drop(first);
            let retained = association
                .verification_continuations()
                .expect("durable rejected work");
            assert!(retained[0].needs_source_repair());
            assert!(
                retained[0]
                    .repair_detail
                    .as_ref()
                    .expect("failure feedback")
                    .contains("exited 1")
            );
            assert_eq!(
                loom_driver::git::sync_head_commit_sha(&integration).expect("rollback"),
                base
            );
            if before_rollback {
                git_workspace_reopen(&workspace)
                    .reset_integration_to(candidate.as_str())
                    .await
                    .expect("interruption before owned rollback");
            }
            let observed = serde_json::to_vec(&vec![source.clone()]).expect("closed native source");
            let runner =
                ScriptedBd::new([ok_stdout(&observed), ok_stdout(&observed), ok_stdout(b"")]);
            let calls = runner.calls_handle();
            let dispatched = Arc::new(std::sync::atomic::AtomicBool::new(false));
            let captured = Arc::clone(&dispatched);
            let mut resumed = ProductionAgentLoopController::new(
                BdClient::with_runner(runner),
                label,
                verifier,
                workspace.clone(),
                git_workspace_reopen(&workspace),
                manifest,
                None,
                ProfileName::new("base").expect("profile"),
                move |cfg: SpawnConfig, _id: BeadId| {
                    let captured = Arc::clone(&captured);
                    async move {
                        assert!(
                            cfg.initial_prompt
                                .contains("post-integration verify failed")
                        );
                        assert!(cfg.initial_prompt.contains("loom gate verify --diff"));
                        captured.store(true, std::sync::atomic::Ordering::SeqCst);
                        (
                            SessionResult::PreflightFailed {
                                error: "source executor temporarily unavailable".into(),
                            },
                            None,
                        )
                    }
                },
            );
            let result = resumed
                .run_bead(&source, None)
                .await
                .expect("restart enters source repair");
            assert!(matches!(result, AgentOutcome::InfraPreflight { .. }));
            assert!(dispatched.load(std::sync::atomic::Ordering::SeqCst));
            assert!(
                association
                    .verification_continuations()
                    .expect("repair remains pending")[0]
                    .needs_source_repair()
            );
            assert_eq!(
                loom_driver::git::sync_rev_parse(
                    &integration,
                    &format!("refs/loom/verification/{}/{candidate}", source.id)
                )
                .expect("old candidate retained"),
                candidate
            );
            assert!(clone.path.exists());
            assert!(calls.lock().expect("calls").iter().any(|args| {
                args.first().is_some_and(|arg| arg == "update")
                    && (args.iter().any(|arg| arg == "--status=open")
                        || args
                            .windows(2)
                            .any(|args| args[0] == "--status" && args[1] == "open"))
            }));
            let mut open = source.clone();
            open.status = loom_driver::bd::Status::Open;
            let observed_open = serde_json::to_vec(&vec![open.clone()]).expect("open source");
            resumed.bd =
                BdClient::with_runner(ScriptedBd::new([ok_stdout(&observed_open), ok_stdout(b"")]));
            resumed
                .apply_infra(
                    &source.id,
                    &InfraDiagnostic::static_diagnostic(
                        MISSING_AGENT_BINARY_CAUSE,
                        "source runtime unavailable".into(),
                    ),
                )
                .await
                .expect("protected repair infrastructure parking");
            let mut parked = open;
            parked.status = loom_driver::bd::Status::Blocked;
            parked.labels.push(Label::new("loom:infra").expect("infra"));
            parked
                .metadata
                .insert("loom.infra.phase".into(), "loop".into());
            parked
                .metadata
                .insert("loom.infra.cause".into(), MISSING_AGENT_BINARY_CAUSE.into());
            let own = serde_json::to_vec(&vec![parked.clone()]).expect("owned infra");
            assert!(
                verification_source(
                    &BdClient::with_runner(ScriptedBd::new([ok_stdout(&own)])),
                    &workspace,
                    &source.id
                )
                .await
                .expect("owned repair recovery")
                .is_some()
            );
            parked.metadata.insert(
                "loom.infra.cause".into(),
                "independent-infrastructure-hold".into(),
            );
            let independent = serde_json::to_vec(&vec![parked]).expect("independent infra");
            assert!(
                verification_source(
                    &BdClient::with_runner(ScriptedBd::new([ok_stdout(&independent)])),
                    &workspace,
                    &source.id
                )
                .await
                .expect("independent hold")
                .is_none()
            );
            assert_eq!(
                loom_driver::git::sync_head_commit_sha(&integration)
                    .expect("owned rollback survives restart"),
                base
            );
        }
    }

    fn git_workspace_reopen(workspace: &Path) -> GitClient {
        GitClient::open(workspace)
            .expect("repository")
            .with_repo_git_policy(
                loom_driver::git::RepoGitPolicy::resolve(
                    workspace,
                    "unused-wrix".into(),
                    loom_driver::git::KeyMode::Host,
                )
                .expect("policy"),
            )
    }

    #[tokio::test]
    async fn rolled_back_unfinished_source_blocks_only_its_selected_publication_root() {
        for repair in [false, true] {
            let dir = tempfile::tempdir().expect("fixture");
            let workspace = dir.path().join("workspace");
            let git = git_workspace(&workspace);
            let integration = git.loom_workspace();
            let base = loom_driver::git::sync_head_commit_sha(&integration).expect("base");
            std::fs::write(integration.join("pending.txt"), "pending source\n").expect("source");
            loom_driver::git::commit_all_in(&integration, "pending candidate").expect("commit");
            let candidate =
                loom_driver::git::sync_head_commit_sha(&integration).expect("candidate");
            let id = BeadId::new("lm-unfinished").expect("id");
            let root = BeadId::new("lm-selected").expect("root");
            let label = SpecLabel::new("gate").expect("label");
            git.create_worktree(&label, &id)
                .await
                .expect("source clone");
            git.preserve_verification_candidate(&id, &candidate)
                .await
                .expect("pin");
            let association =
                loom_driver::workspace::Association::resolve(&workspace).expect("authority");
            let record = association
                .begin_verification(
                    id,
                    label.clone(),
                    Some(root),
                    base.clone(),
                    candidate.clone(),
                )
                .expect("continuation");
            if repair {
                association
                    .await_verification_repair(&record, "executed semantic rejection".into(), None)
                    .expect("durable repair");
            }
            git.reset_integration_to(base.as_str())
                .await
                .expect("owned rollback");
            std::fs::write(
                integration.join("independent.txt"),
                "independent implementation\n",
            )
            .expect("independent source");
            loom_driver::git::commit_all_in(&integration, "independent implementation")
                .expect("commit");
            let remaining =
                loom_driver::git::sync_head_commit_sha(&integration).expect("remaining tip");
            for selected in [true, false] {
                let molecule = if selected {
                    "lm-selected"
                } else {
                    "lm-independent"
                };
                let epic = serde_json::to_vec(&serde_json::json!([{"id":molecule,"title":"work root","status":"open","issue_type":"epic"}])).expect("epic");
                let progress = serde_json::to_vec(&serde_json::json!({"molecule_id":molecule,"completed":1,"total":1,"in_progress":0,"percent":100.0})).expect("progress");
                let bd = BdClient::with_runner(ScriptedBd::new([
                    ok_stdout(&epic),
                    ok_stdout(&progress),
                    ok_stdout(b"[]"),
                ]));
                let marker = dir.path().join("review-entered");
                let stub = dir.path().join("review-stub");
                loom_test_support::write_executable_bash_script(
                    &stub,
                    &format!("printf 'entered\n' > {marker:?}\nexit 1\n"),
                )
                .expect("external review stub");
                let handoff = execute_molecule_push_gate(
                    &bd,
                    &label,
                    Some(&MoleculeId::new(molecule).expect("molecule")),
                    MoleculePushGateCommands::new(None, &stub, Path::new("unused-wrix")),
                    &workspace,
                    &git,
                )
                .await
                .expect("typed admission");
                if selected {
                    assert_eq!(handoff.evidence.molecule_state, MoleculeState::Unresolved);
                    assert_eq!(handoff.evidence.gate_runs, Vec::new());
                    assert!(!marker.exists());
                } else {
                    assert!(
                        marker.exists(),
                        "unrelated work reaches its own required gates"
                    );
                }
                assert_eq!(
                    loom_driver::git::sync_head_commit_sha(&integration)
                        .expect("remaining source retained"),
                    remaining
                );
            }
        }
    }

    #[tokio::test]
    async fn restarted_integrated_candidate_rolls_back_on_rejection_and_exhaustion() {
        for code in [1, 78, 0] {
            for independent in [false, true] {
                let dir = tempfile::tempdir().expect("fixture");
                let workspace = dir.path().join("workspace");
                let git = git_workspace(&workspace);
                let integration = git.loom_workspace();
                let base = loom_driver::git::sync_head_commit_sha(&integration).expect("base");
                for index in 0..3 {
                    std::fs::write(
                        integration.join("candidate.txt"),
                        format!("candidate {index}\n"),
                    )
                    .expect("source");
                    loom_driver::git::commit_all_in(&integration, "candidate").expect("commit");
                }
                let candidate =
                    loom_driver::git::sync_head_commit_sha(&integration).expect("candidate");
                let id = BeadId::new("lm-vreject").expect("id");
                let label = SpecLabel::new("gate").expect("label");
                let source = git
                    .create_worktree(&label, &id)
                    .await
                    .expect("source clone");
                git.preserve_verification_candidate(&id, &candidate)
                    .await
                    .expect("pin");
                let association =
                    loom_driver::workspace::Association::resolve(&workspace).expect("authority");
                let mut record = association
                    .begin_verification(id, label.clone(), None, base.clone(), candidate.clone())
                    .expect("continuation");
                let expected_rollback = if independent {
                    std::fs::write(
                        integration.join("independent.txt"),
                        "independent descendant\n",
                    )
                    .expect("independent source");
                    loom_driver::git::commit_all_in(&integration, "independent descendant")
                        .expect("commit");
                    let descendant =
                        loom_driver::git::sync_head_commit_sha(&integration).expect("descendant");
                    let independent_id = BeadId::new("lm-vindependent").expect("id");
                    git.create_worktree(&label, &independent_id)
                        .await
                        .expect("independent source clone");
                    git.preserve_verification_candidate(&independent_id, &descendant)
                        .await
                        .expect("independent pin");
                    association
                        .begin_verification(
                            independent_id,
                            label.clone(),
                            None,
                            candidate.clone(),
                            descendant.clone(),
                        )
                        .expect("independent continuation");
                    descendant
                } else {
                    base.clone()
                };
                let mut bead: Bead = serde_json::from_value(
                serde_json::json!({"id":"lm-vreject","title":"completed source","status":"closed"}),
            )
            .expect("bead");
                if code == 0 {
                    record.parked_status = Some(loom_driver::bd::Status::Closed);
                    association
                        .append_verification(&record)
                        .expect("owned parking");
                    bead.status = loom_driver::bd::Status::Blocked;
                    bead.labels
                        .push(loom_driver::bd::Label::new("loom:infra").expect("infra"));
                    bead.metadata
                        .insert("loom.infra.phase".into(), "loop".into());
                    bead.metadata.insert(
                        "loom.infra.cause".into(),
                        "verification-capability-unavailable".into(),
                    );
                }
                let observed = serde_json::to_vec(&vec![&bead]).expect("observation");
                let mut held_source = bead.clone();
                held_source
                    .labels
                    .push(loom_driver::bd::Label::new("loom:clarify").expect("human hold"));
                let held_observation = serde_json::to_vec(&vec![held_source]).expect("later hold");
                let scripted =
                    ScriptedBd::new([ok_stdout(&observed), ok_stdout(&held_observation)]);
                let calls = scripted.calls_handle();
                let policy = loom_driver::git::RepoGitPolicy::resolve(
                    &workspace,
                    "unused-wrix".into(),
                    loom_driver::git::KeyMode::Host,
                )
                .expect("fixture policy");
                let git = GitClient::open(&workspace)
                    .expect("repository")
                    .with_repo_git_policy(policy);
                let verifier = dir.path().join("verifier.sh");
                loom_test_support::write_executable_bash_script(
                    &verifier,
                    &format!("exit {code}\n"),
                )
                .expect("verifier");
                let mut resumed = ProductionAgentLoopController::new(
                    BdClient::with_runner(scripted),
                    label,
                    verifier,
                    workspace,
                    git,
                    write_manifest(dir.path()),
                    None,
                    ProfileName::new("base").expect("profile"),
                    |_cfg: SpawnConfig, _id: BeadId| async move {
                        panic!("source must never redispatch")
                    },
                );
                assert_eq!(
                    resumed
                        .resume_verification(&bead, record)
                        .await
                        .expect("restart"),
                    AgentOutcome::Success
                );
                assert_eq!(
                    loom_driver::git::sync_head_commit_sha(&integration).expect("still integrated"),
                    if independent {
                        expected_rollback.clone()
                    } else {
                        candidate.clone()
                    }
                );
                let outcome = resumed
                    .exec_per_bead_gate(&bead.id)
                    .await
                    .expect("required rejection");
                assert!(if code == 1 {
                    matches!(outcome, PerBeadGateOutcome::Recovery { .. })
                } else {
                    matches!(outcome, PerBeadGateOutcome::Infrastructure { .. })
                });
                assert_eq!(
                    loom_driver::git::sync_head_commit_sha(&integration)
                        .expect("exact recorded rollback"),
                    expected_rollback
                );
                if independent {
                    assert!(integration.join("independent.txt").exists());
                }
                if code == 78 {
                    for _ in 0..2 {
                        let next = association
                            .verification_continuations()
                            .expect("continuation")
                            .into_iter()
                            .find(|record| record.bead == bead.id)
                            .expect("owned continuation");
                        resumed.bd = BdClient::with_runner(ScriptedBd::new([ok_stdout(&observed)]));
                        assert_eq!(
                            resumed
                                .resume_verification(&bead, next)
                                .await
                                .expect("repeat restart"),
                            AgentOutcome::Success
                        );
                        assert!(matches!(
                            resumed
                                .exec_per_bead_gate(&bead.id)
                                .await
                                .expect("repeat outage"),
                            PerBeadGateOutcome::Infrastructure { .. }
                        ));
                        assert_eq!(
                            loom_driver::git::sync_head_commit_sha(&integration)
                                .expect("repeat rollback"),
                            expected_rollback
                        );
                    }
                }
                assert_eq!(
                    loom_driver::git::sync_head_commit_sha(&source.path).expect("source retained"),
                    candidate
                );
                assert_eq!(
                    association
                        .verification_continuations()
                        .expect("retained attribution")
                        .len(),
                    1 + usize::from(independent)
                );
                assert!(
                    !calls
                        .lock()
                        .expect("calls")
                        .iter()
                        .any(|args| args.iter().any(|arg| arg == "update")),
                    "human source state is never rewritten"
                );
            }
        }
    }

    /// A non-zero `loom gate verify --diff` against the integrated tree is
    /// the `post-integrate-fail` audit failure: the integration is rolled
    /// back (`git reset --hard HEAD~1`), `PreviousFailure::PostIntegrateFail`
    /// is stashed for the next dispatch, the review step never runs, and the
    /// bead routes to recovery (specs/harness.md § Verdict Gate).
    #[tokio::test]
    async fn post_integrate_verify_failure_writes_durable_gate_log() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let loom_ws = git.loom_workspace();
        let base_tip = loom_driver::git::sync_head_commit_sha(&loom_ws).expect("base sha");

        // Stand in for the just-ff'd bead commit so `reset --hard HEAD~1`
        // has a commit to unwind back to the pre-merge tip.
        std::fs::write(loom_ws.join("integrated.txt"), "merged\n").expect("write");
        loom_driver::git::commit_all_in(&loom_ws, "integrated bead").expect("commit");
        let merged_tip = loom_driver::git::sync_head_commit_sha(&loom_ws).expect("ff'd sha");
        let merged_tree = loom_driver::git::head_tree_oid_sync(&loom_ws).expect("merged tree");
        assert_ne!(
            merged_tip.to_string(),
            base_tip.to_string(),
            "the ff-merge stand-in must advance the integration branch",
        );

        let stub = dir.path().join("loom-stub.sh");
        loom_test_support::write_executable_bash_script(
            &stub,
            "set -euo pipefail\n\
             case \"$2\" in\n\
                 verify) echo 'verifier failed: cargo test' >&2; exit 1 ;;\n\
                 review|mint) echo \"$2 must not run after verify-fail\" ; exit 99 ;;\n\
             esac\n\
             exit 0\n",
        )
        .expect("write stub");

        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("gate").unwrap(),
            stub.clone(),
            workspace.clone(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("spawn closure must not fire during exec_per_bead_gate");
            },
        );

        // `run_bead` would set this before the ff-merge; the test drives
        // `exec_per_bead_gate` directly, so seed the pre-merge tip the
        // advancing commit moved past.
        controller.pre_integration_tip = Some(base_tip.clone());

        let bead_id = BeadId::new("lm-1").expect("valid bead id");
        let outcome = controller
            .exec_per_bead_gate(&bead_id)
            .await
            .expect("exec_per_bead_gate ok");

        assert!(
            matches!(outcome, PerBeadGateOutcome::Recovery { .. }),
            "verify-fail must route to Recovery, got {outcome:?}",
        );
        let rolled_back = loom_driver::git::sync_head_commit_sha(&loom_ws)
            .expect("rolled-back sha")
            .to_string();
        assert_eq!(
            rolled_back,
            base_tip.to_string(),
            "audit-fail must reset the integration branch back to its pre-merge tip",
        );
        assert!(
            !loom_ws.join("integrated.txt").exists(),
            "reset --hard must drop the rolled-back commit's content",
        );
        match controller.stashed_previous_failure {
            Some(PreviousFailure::PostIntegrateFail {
                ref failures,
                ref gate_log_path,
            }) => {
                assert_eq!(failures.len(), 1, "one verifier-failure block expected");
                assert_eq!(failures[0].exit_code, 1);
                assert!(
                    failures[0].target.contains("loom gate verify --diff"),
                    "failure block names the failing verifier: {:?}",
                    failures[0].target,
                );
                assert!(
                    gate_log_path.exists(),
                    "durable gate log must exist before rollback: {gate_log_path:?}",
                );
                assert_eq!(
                    gate_log_path.extension().and_then(|ext| ext.to_str()),
                    Some("jsonl"),
                    "durable post-integrate log must be JSONL: {gate_log_path:?}",
                );
                let gate_log = std::fs::read_to_string(gate_log_path).expect("gate log readable");
                let events = gate_log
                    .lines()
                    .map(|line| {
                        serde_json::from_str::<loom_events::AgentEvent>(line)
                            .expect("every gate JSONL line is a canonical AgentEvent")
                    })
                    .collect::<Vec<_>>();
                assert_eq!(events.len(), 5, "{events:?}");
                let lifecycle_kinds = events[..4]
                    .iter()
                    .map(|event| match event {
                        loom_events::AgentEvent::DriverEvent { driver_kind, .. } => {
                            driver_kind.as_wire()
                        }
                        other => panic!("gate lifecycle must use driver events, got {other:?}"),
                    })
                    .collect::<Vec<_>>();
                assert_eq!(
                    lifecycle_kinds,
                    [
                        "gate_run_start",
                        "gate_run_scope",
                        "gate_run_lane",
                        "gate_run_end",
                    ]
                );
                let loom_events::AgentEvent::DriverEvent {
                    driver_kind,
                    payload,
                    ..
                } = &events[4]
                else {
                    panic!("post-integrate diagnostics must be a driver event");
                };
                assert_eq!(*driver_kind, DriverKind::VerdictGate);
                assert_eq!(
                    payload["argv"],
                    serde_json::json!(["gate", "verify", "--diff", format!("{base_tip}..HEAD")])
                );
                assert_eq!(payload["scope_flag"], "--diff");
                assert_eq!(payload["exit_code"], 1);
                assert_eq!(payload["integration_sha"], merged_tip.to_string());
                assert_eq!(payload["bead_id"], "lm-1");
                assert_eq!(payload["retry_attempt"], 0);
                assert_eq!(payload["rollback_state"], "pending");
                assert_eq!(
                    payload["log_path"].as_str(),
                    Some(gate_log_path.to_string_lossy().as_ref())
                );
                assert_eq!(payload["stdout"], "");
                assert!(
                    payload["stderr"]
                        .as_str()
                        .is_some_and(|output| output.contains("cargo test")),
                    "{payload:?}",
                );
                assert_eq!(payload["failures"][0]["exit_code"], 1);
                assert!(
                    payload["failures"][0]["target"]
                        .as_str()
                        .is_some_and(|target| target.contains("loom gate verify --diff"))
                );
                let runs = parse_gate_runs_from_jsonl(gate_log_path);
                assert_eq!(runs.len(), 1, "{runs:?}");
                assert_eq!(runs[0].status, GateRunStatus::Failed);
                assert_eq!(runs[0].exit_code, Some(1));
                assert_eq!(runs[0].push_range, format!("{base_tip}..HEAD"));
                assert_eq!(runs[0].tree_oid, merged_tree.to_string());
                assert_eq!(runs[0].log_path, *gate_log_path);
            }
            other => panic!("expected stashed PostIntegrateFail, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn gate_invocations_write_separate_jsonl_logs_with_parent_breadcrumb() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let label = SpecLabel::new("gate").unwrap();
        let bead_id = BeadId::new("lm-1").expect("valid bead id");
        let logs_root = dir.path().join("logs");
        let mut sink = loom_driver::logging::LogSink::open_in_at(
            &logs_root,
            &label,
            &bead_id,
            None,
            SystemTime::UNIX_EPOCH,
        )
        .expect("open bead log");
        let bead_log_path = sink.log_path().to_path_buf();
        sink.finish(loom_driver::logging::BeadOutcome::Done)
            .expect("finish bead log");

        let stub = dir.path().join("loom-stub.sh");
        loom_test_support::write_executable_bash_script(
            &stub,
            "set -euo pipefail\n\
             case \"$2\" in\n\
                 verify) echo 'verify stdout'; echo 'verify stderr' >&2; exit 2 ;;\n\
             esac\n\
             exit 0\n",
        )
        .expect("write stub");

        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            label,
            stub,
            workspace,
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("spawn closure must not fire during exec_per_bead_gate");
            },
        )
        .with_phase_log_root(logs_root);
        controller.prepare_emit_state(&bead_id);

        let outcome = controller
            .exec_per_bead_gate(&bead_id)
            .await
            .expect("exec_per_bead_gate ok");
        assert!(
            matches!(outcome, PerBeadGateOutcome::Recovery { .. }),
            "verify-fail must route to Recovery, got {outcome:?}",
        );
        let Some(PreviousFailure::PostIntegrateFail { gate_log_path, .. }) =
            &controller.stashed_previous_failure
        else {
            panic!("expected PostIntegrateFail with gate_log_path");
        };
        let first_gate_log_path = gate_log_path.clone();
        controller.current_attempt = 1;
        let second_outcome = controller
            .exec_per_bead_gate(&bead_id)
            .await
            .expect("second exec_per_bead_gate ok");
        assert!(
            matches!(second_outcome, PerBeadGateOutcome::Recovery { .. }),
            "second verify-fail must route to Recovery, got {second_outcome:?}",
        );
        let Some(PreviousFailure::PostIntegrateFail {
            gate_log_path: second_gate_log_path,
            ..
        }) = &controller.stashed_previous_failure
        else {
            panic!("expected second PostIntegrateFail with gate_log_path");
        };
        assert_ne!(
            &first_gate_log_path, second_gate_log_path,
            "retry attempts must write distinct durable gate logs",
        );
        for path in [&first_gate_log_path, second_gate_log_path] {
            let child_log = std::fs::read_to_string(path).expect("gate child log readable");
            for line in child_log.lines() {
                serde_json::from_str::<loom_events::AgentEvent>(line)
                    .expect("gate child log line is a canonical AgentEvent");
            }
            let runs = parse_gate_runs_from_jsonl(path);
            assert_eq!(runs.len(), 1, "{runs:?}");
            assert_eq!(runs[0].status, GateRunStatus::Failed);
        }
        let first_gate_log = first_gate_log_path.to_string_lossy().to_string();
        let second_gate_log = second_gate_log_path.to_string_lossy().to_string();
        let body = std::fs::read_to_string(bead_log_path).expect("driver event log readable");
        let events: Vec<serde_json::Value> = body
            .lines()
            .map(|line| serde_json::from_str(line).expect("driver event json"))
            .collect();
        let gate_events = events
            .iter()
            .filter(|event| event["payload"].get("gate_log_path").is_some())
            .collect::<Vec<_>>();
        assert_eq!(
            gate_events.len(),
            2,
            "each verify-fail retry must emit a driver_event carrying gate_log_path: {body}",
        );
        for gate_log in [first_gate_log, second_gate_log] {
            let expected = serde_json::json!(&gate_log);
            let event = gate_events
                .iter()
                .find(|event| event["payload"]["gate_log_path"] == expected)
                .unwrap_or_else(|| {
                    panic!("driver_event payload must name gate_log_path {gate_log}: {body}")
                });
            assert!(
                event["summary"]
                    .as_str()
                    .unwrap_or_default()
                    .contains(&format!("gate log: {gate_log}")),
                "driver_event summary must render gate log path {gate_log}: {body}",
            );
        }
    }

    /// A verify-fail on a bead whose ff advanced nothing
    /// (`pre_integration_tip == None`) must NOT roll back — there is no
    /// bead commit to unwind, and `reset --hard HEAD~1` against a tip with
    /// no parent would abort the loop. The bead still stashes
    /// `PostIntegrateFail` and routes to recovery.
    #[tokio::test]
    async fn exec_per_bead_gate_verify_fail_skips_rollback_when_integration_did_not_advance() {
        let dir = tempfile::tempdir().expect("tempdir");
        let workspace = dir.path().join("ws");
        let git = git_workspace(&workspace);
        let manifest = write_manifest(dir.path());
        let loom_ws = git.loom_workspace();
        let root_tip = loom_driver::git::sync_head_commit_sha(&loom_ws)
            .expect("root sha")
            .to_string();

        let stub = dir.path().join("loom-stub.sh");
        loom_test_support::write_executable_bash_script(
            &stub,
            "set -euo pipefail\n\
             case \"$2\" in\n\
                 verify) echo 'verifier failed' >&2; exit 1 ;;\n\
             esac\n\
             exit 0\n",
        )
        .expect("write stub");

        let mut controller = ProductionAgentLoopController::new(
            BdClient::new(),
            SpecLabel::new("gate").unwrap(),
            stub.clone(),
            workspace.clone(),
            git,
            manifest,
            None,
            ProfileName::new("base").unwrap(),
            |_cfg: SpawnConfig, _bead_id: BeadId| async move {
                panic!("spawn closure must not fire during exec_per_bead_gate");
            },
        );
        // `pre_integration_tip` stays None: the bead committed nothing.

        let bead_id = BeadId::new("lm-1").expect("valid bead id");
        let outcome = controller
            .exec_per_bead_gate(&bead_id)
            .await
            .expect("exec_per_bead_gate must not abort when there is nothing to roll back");

        assert!(
            matches!(outcome, PerBeadGateOutcome::Recovery { .. }),
            "verify-fail still routes to Recovery, got {outcome:?}",
        );
        assert_eq!(
            loom_driver::git::sync_head_commit_sha(&loom_ws)
                .expect("post sha")
                .to_string(),
            root_tip,
            "no-advance verify-fail must leave the integration tip untouched",
        );
        assert!(
            matches!(
                controller.stashed_previous_failure,
                Some(PreviousFailure::PostIntegrateFail { .. })
            ),
            "PostIntegrateFail is stashed even when nothing was rolled back",
        );
    }
}
