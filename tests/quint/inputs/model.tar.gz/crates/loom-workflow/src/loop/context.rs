use askama::Template;
use loom_driver::identifier::{BeadId, MoleculeId, SpecLabel};
use loom_protocol::oid::GitOid;
use loom_templates::SkillIndexMarkdown;
use loom_templates::run::{LoopContext, PreviousFailure, WorkspaceRecovery};

/// Inputs for [`build_loop_context`]. Constructed once per bead spawn — for
/// retries the driver rebuilds with `previous_failure` set + `attempt`
/// incremented.
pub struct LoopContextInputs {
    /// Immutable driver-selected package snapshot; None supports partial composition only.
    pub package_context: Option<loom_protocol::context::Context>,
    pub acceptance: loom_protocol::acceptance::dispatch::Acceptance,
    pub acceptance_workspace: std::path::PathBuf,
    pub label: SpecLabel,
    pub spec_path: String,
    pub pinned_context: String,
    pub companion_paths: Vec<String>,
    pub molecule_id: Option<MoleculeId>,
    pub issue_id: BeadId,
    /// Exact integration tip resolved during this bead's workspace preparation.
    pub bead_base: GitOid,
    pub title: String,
    pub description: String,
    /// Typed retry context from the prior attempt (the driver maps the
    /// verdict-gate's `RecoveryCause` onto the right variant). The template
    /// renders this via `Display` so framing prefixes ride along.
    pub previous_failure: Option<PreviousFailure>,
    /// Unapplied dirty-workspace stash context from pre-dispatch recovery.
    pub workspace_recovery: Option<WorkspaceRecovery>,
    /// In-session per-bead retry counter. `0` on fresh dispatch; `loop.md`
    /// omits the retry line when zero (see `specs/templates.md` §
    /// Attempt Counter).
    pub attempt: u32,
    /// Absolute path to `.loom/scratch/<bead-id>/scratch.md` for this
    /// session. Embedded in the rendered prompt so the agent can write to
    /// the correct file under compaction recovery.
    pub scratchpad_path: String,
    /// Workspace-relative path to the project's style-rules document. Pinned
    /// in the rendered prompt so the implementer reads applicable rules
    /// before writing code.
    pub style_rules: String,
    pub skill_index: SkillIndexMarkdown,
}

/// Build the typed [`LoopContext`] for a single bead spawn from the driver's
/// per-iteration inputs.
pub fn build_loop_context(inputs: LoopContextInputs) -> LoopContext {
    LoopContext {
        package_context: inputs.package_context,
        acceptance: Some(inputs.acceptance.context(&inputs.acceptance_workspace)),
        pinned_context: inputs.pinned_context,
        label: inputs.label,
        spec_path: inputs.spec_path,
        companion_paths: inputs.companion_paths,
        molecule_id: inputs.molecule_id,
        issue_id: Some(inputs.issue_id),
        bead_base: inputs.bead_base,
        title: Some(inputs.title),
        description: Some(inputs.description),
        previous_failure: inputs.previous_failure,
        workspace_recovery: inputs.workspace_recovery,
        review_notes: None,
        attempt: inputs.attempt,
        scratchpad_path: inputs.scratchpad_path,
        style_rules: inputs.style_rules,
        skill_index: inputs.skill_index,
    }
}

/// Render the loop prompt for `inputs` so binaries that lack a direct askama
/// dependency can build the same prompt as the workflow's own controllers.
///
/// # Errors
///
/// Returns an error when loop state, agent execution, or gate handling fails.
pub fn render_loop_prompt(inputs: LoopContextInputs) -> Result<String, askama::Error> {
    build_loop_context(inputs).render()
}

#[cfg(test)]
mod tests {
    use super::*;
    use askama::Template;

    fn inputs() -> LoopContextInputs {
        let dir = tempfile::tempdir().unwrap();
        let label = SpecLabel::new("harness").unwrap();
        crate::test_support::acceptance::write_contract(
            dir.path(),
            &label,
            "Worker context preserves its dispatched instructions through retries.",
        );
        LoopContextInputs {
            package_context: None,
            acceptance: crate::test_support::acceptance::resolved(dir.path(), &label),
            acceptance_workspace: dir.path().to_path_buf(),
            label: SpecLabel::new("harness").unwrap(),
            spec_path: "specs/harness.md".into(),
            pinned_context: "PIN".into(),
            companion_paths: vec![],
            molecule_id: Some(MoleculeId::new("lm-3hhwq").unwrap()),
            issue_id: BeadId::new("lm-3hhwq.15").expect("valid bead id"),
            bead_base: GitOid::new("0123456789abcdef0123456789abcdef01234567").unwrap(),
            title: "Implement loom loop".into(),
            description: "Per-bead loop".into(),
            previous_failure: None,
            workspace_recovery: None,
            attempt: 0,
            scratchpad_path: "/workspace/.loom/scratch/lm-3hhwq.15/scratch.md".into(),
            style_rules: "docs/style-rules.md".into(),
            skill_index: SkillIndexMarkdown::empty(),
        }
    }

    #[test]
    fn retry_input_carries_typed_previous_failure() {
        let mut i = inputs();
        i.previous_failure = Some(PreviousFailure::from_agent_error("cargo test failed"));
        i.attempt = 1;
        let ctx = build_loop_context(i);
        let pf = ctx.previous_failure.expect("set on retry");
        let rendered = pf.to_string();
        assert!(
            rendered.contains("cargo test failed"),
            "rendered body must carry agent error: {rendered}",
        );
        assert_eq!(ctx.attempt, 1);
    }

    #[test]
    fn fresh_dispatch_omits_previous_failure_and_attempt_is_zero() {
        let ctx = build_loop_context(inputs());
        assert!(ctx.previous_failure.is_none());
        assert!(
            ctx.review_notes.is_none(),
            "driver uses typed finding recovery, not caller-supplied legacy notes"
        );
        assert_eq!(ctx.attempt, 0);
    }

    #[test]
    fn attempt_zero_on_fresh_bead_dispatch() {
        let ctx = build_loop_context(inputs());
        assert_eq!(ctx.attempt, 0);
    }

    #[test]
    fn rendered_prompt_includes_issue_and_title() {
        let ctx = build_loop_context(inputs());
        let body = ctx.render().expect("render");
        assert!(body.contains("lm-3hhwq.15"), "{body}");
        assert!(body.contains("Implement loom loop"), "{body}");
    }

    #[test]
    fn rendered_prompt_uses_exact_dispatch_base_on_fresh_and_retry_attempts() {
        for attempt in [0, 1] {
            let mut input = inputs();
            input.attempt = attempt;
            if attempt > 0 {
                input.previous_failure = Some(PreviousFailure::AgentRetry {
                    reason: "retry requested".into(),
                });
            }
            let expected = format!("loom gate verify --diff {}..HEAD", input.bead_base);
            let body = render_loop_prompt(input).unwrap();
            assert!(body.contains(&expected), "{body}");
            assert!(!body.contains("<bead-base>"), "{body}");
        }
    }

    #[test]
    fn rendered_retry_prompt_includes_previous_failure_body() {
        let mut i = inputs();
        i.previous_failure = Some(PreviousFailure::from_agent_error(
            "STDERR: cargo test failure",
        ));
        i.attempt = 1;
        let ctx = build_loop_context(i);
        let body = ctx.render().expect("render");
        assert!(body.contains("STDERR: cargo test failure"), "{body}");
    }
}
