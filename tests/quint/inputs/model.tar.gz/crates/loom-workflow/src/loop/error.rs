use displaydoc::Display;
use thiserror::Error;

use loom_driver::agent::ProtocolError;
use loom_driver::bd::BdError;
use loom_driver::config::LoomConfigError;
use loom_driver::git::GitError;
use loom_driver::identifier::ParseMoleculeIdError;
use loom_driver::logging::LogError;
use loom_driver::profile_manifest::ProfileError;
use loom_driver::state::CacheError;

/// Errors raised by the `loom loop` driver.
#[derive(Debug, Display, Error)]
pub enum LoopError {
    /// package context could not be captured or delivered
    Context(#[from] loom_driver::spec::context::Error),
    /// agent backend protocol failure during `loom loop`
    Protocol(#[from] ProtocolError),

    /// decision admission or recovery failed: {0}
    DecisionWait(#[from] super::decision_wait::DecisionWaitError),

    /// bd CLI failure during `loom loop`
    Bd(#[from] BdError),

    /// loop state carried an invalid bead id
    InvalidBeadId(#[from] loom_driver::identifier::ParseBeadIdError),

    /// parallel molecule stabilization failed: {detail}
    Stabilization { detail: String },

    /// loop bead carried an invalid molecule id
    InvalidMoleculeId(#[from] ParseMoleculeIdError),

    /// rendering the loop.md template failed
    Render(#[from] askama::Error),

    /// log sink failure during `loom loop`
    Log(#[from] LogError),

    /// git step failed during `loom loop`
    Git(#[from] GitError),

    /// worker isolation or host safety-history association failed
    Workspace(#[from] loom_driver::workspace::Error),

    /// io operation failed during `loom loop`
    Io(#[from] std::io::Error),

    /// pre-commit config parsing failed during `loom loop`
    PreCommitConfig(#[from] loom_gate::PreCommitConfigError),

    /// profile-image manifest dispatch failed during `loom loop`
    Profile(#[from] ProfileError),

    /// config load failed during `loom loop`
    Config(#[from] LoomConfigError),

    /// cache.db access failure during `loom loop`
    State(#[from] CacheError),

    /// decision-wait journal locking failed
    DecisionWaitLock(#[from] loom_driver::lock::LockError),

    /// spec → molecule resolution failed during `loom loop`
    Resolve(#[from] crate::resolve::ResolveError),

    /// skill resolution failed during `loom loop`
    Skill(#[from] crate::skill::SkillError),

    /// no active molecule for spec `{label}`
    NoActiveMolecule { label: String },

    /// molecule-completion review failed: {detail}
    ReviewHandoff { detail: String },

    /// active molecule {id} has no `loom.base_commit` metadata and no parent to inherit from — set it with: `bd update {id} --set-metadata loom.base_commit=<sha>`
    MoleculeMissingBaseCommit { id: String },

    /// active molecule {id} has no `loom.base_commit` metadata and its parent {parent} also lacks it — set it with: `bd update {id} --set-metadata loom.base_commit=<sha>`
    MoleculeMissingBaseCommitNoParentMetadata { id: String, parent: String },

    /// internal invariant violated: {context}
    Bug { context: String },
}
