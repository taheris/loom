use std::path::{Path, PathBuf};

use loom_driver::agent::{AgentRuntime, MountSpec, RePinContent, SpawnConfig, set_loom_inside};
use loom_driver::profile_manifest::ImageEntry;
use tracing::info;

const WRIX_AGENT_ENV: &str = "WRIX_AGENT";
const LOOM_BIN_ENV: &str = "LOOM_BIN";
const CONTAINER_LOOM_BIN: &str = "loom";
const CONTAINER_WORKSPACE: &str = "/workspace";

/// Structured spawn diagnostics emitted for every non-interactive Wrix spawn.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct SpawnDiagnostics {
    pub agent_backend: AgentRuntime,
    pub wrix_agent_env: String,
    pub image_ref: String,
}

#[expect(
    clippy::too_many_arguments,
    reason = "explicit spawn construction boundary"
)]
pub fn build_spawn_config(
    entry: &ImageEntry,
    runtime: AgentRuntime,
    workspace: PathBuf,
    initial_prompt: String,
    scratch_dir: PathBuf,
    extra_env: Vec<(String, String)>,
    agent_args: Vec<String>,
    mounts: Vec<MountSpec>,
    launcher_env: Vec<(String, String)>,
) -> SpawnConfig {
    let runtime_name = runtime.as_str().to_string();
    let env = spawn_env(extra_env, &runtime_name);
    let launcher_env = spawn_launcher_env(launcher_env, &runtime_name);
    let diagnostics = log_spawn_diagnostics(runtime, &runtime_name, &entry.r#ref);
    let image_source_kind = (!entry.source.as_os_str().is_empty()).then_some(entry.source_kind);
    SpawnConfig {
        image_ref: diagnostics.image_ref,
        image_source: entry.source.clone(),
        image_source_kind,
        wrix_launcher: Some(entry.launcher.clone()),
        profile_config: Some(entry.profile_config.clone()),
        workspace,
        env,
        mounts,
        initial_prompt,
        agent_args,
        repin: RePinContent {
            orientation: String::new(),
            pinned_context: String::new(),
            partial_bodies: vec![],
        },
        skills: None,
        event_metadata: None,
        scratch_dir,
        model_id: None,
        model: None,
        thinking_level: None,
        observers: loom_driver::config::AgentObserversConfig::default(),
        output_limits: None,
        shutdown_grace: None,
        denied_tools: Vec::new(),
        handshake_timeout: None,
        stall_warn_interval: None,
        launcher_env,
    }
}

fn spawn_env(mut extra_env: Vec<(String, String)>, runtime_name: &str) -> Vec<(String, String)> {
    set_runtime_env(&mut extra_env, runtime_name);
    set_default_loom_bin(&mut extra_env);
    set_loom_inside(&mut extra_env);
    extra_env
}

fn spawn_launcher_env(
    mut launcher_env: Vec<(String, String)>,
    runtime_name: &str,
) -> Vec<(String, String)> {
    set_runtime_env(&mut launcher_env, runtime_name);
    launcher_env
}

fn set_runtime_env(env: &mut Vec<(String, String)>, runtime_name: &str) {
    env.retain(|(key, _)| key != WRIX_AGENT_ENV);
    env.push((WRIX_AGENT_ENV.to_string(), runtime_name.to_string()));
}

fn set_default_loom_bin(env: &mut Vec<(String, String)>) {
    if env.iter().any(|(key, _)| key == LOOM_BIN_ENV) {
        return;
    }
    env.push((LOOM_BIN_ENV.to_string(), CONTAINER_LOOM_BIN.to_string()));
}

pub fn container_workspace_path(host_workspace: &Path, host_path: &Path) -> PathBuf {
    match host_path.strip_prefix(host_workspace) {
        Ok(rel) => Path::new(CONTAINER_WORKSPACE).join(rel),
        Err(_) => host_path.to_path_buf(),
    }
}

pub fn log_spawn_diagnostics(
    runtime: AgentRuntime,
    runtime_name: &str,
    image_ref: &str,
) -> SpawnDiagnostics {
    info!(
        agent_backend = %runtime,
        wrix_agent_env = %runtime_name,
        image_ref = %image_ref,
        "wrix spawn: resolved backend runtime and image",
    );
    SpawnDiagnostics {
        agent_backend: runtime,
        wrix_agent_env: runtime_name.to_string(),
        image_ref: image_ref.to_string(),
    }
}

#[cfg(test)]
mod tests {
    use std::io::Write;
    use std::sync::{Arc, Mutex};

    use super::*;
    use loom_driver::agent::ImageSourceKind;

    struct CaptureWriter(Arc<Mutex<Vec<u8>>>);

    impl Write for CaptureWriter {
        fn write(&mut self, buf: &[u8]) -> std::io::Result<usize> {
            self.0.lock().expect("capture not poisoned").extend(buf);
            Ok(buf.len())
        }

        fn flush(&mut self) -> std::io::Result<()> {
            Ok(())
        }
    }

    fn entry() -> ImageEntry {
        ImageEntry {
            r#ref: "localhost/wrix-rust-pi:test".into(),
            source: PathBuf::from("/nix/store/image-rust-pi"),
            source_kind: ImageSourceKind::NixDescriptor,
            launcher: PathBuf::from("/nix/store/raw-wrix/bin/wrix"),
            profile_config: PathBuf::from("/nix/store/wrix-rust-pi-profile-config.json"),
            digest: Some(PathBuf::from("/nix/store/image-rust-pi-digest")),
            runtime: Some(AgentRuntime::Pi),
            native_preflight: None,
        }
    }

    #[test]
    fn container_workspace_path_rewrites_host_workspace_prefix() {
        let host_workspace = Path::new("/home/user/repo");
        let host_path = Path::new("/home/user/repo/.loom/scratch/lm-1/scratch.md");
        assert_eq!(
            container_workspace_path(host_workspace, host_path),
            PathBuf::from("/workspace/.loom/scratch/lm-1/scratch.md"),
        );
    }

    #[test]
    fn container_workspace_path_leaves_external_paths_unchanged() {
        let host_workspace = Path::new("/home/user/repo");
        let host_path = Path::new("/home/user/other");
        assert_eq!(
            container_workspace_path(host_workspace, host_path),
            PathBuf::from("/home/user/other"),
        );
    }

    #[tokio::test]
    async fn wrix_spawn_child_env_sets_backend_derived_wrix_agent() {
        for runtime in [AgentRuntime::Pi, AgentRuntime::Claude, AgentRuntime::Direct] {
            for parent_value in [None, Some("conflicting-parent")] {
                let cfg = build_spawn_config(
                    &entry(),
                    runtime,
                    PathBuf::from("/workspace"),
                    "prompt".into(),
                    PathBuf::from("/workspace/.loom/scratch/key"),
                    parent_value
                        .map(|value| vec![("WRIX_AGENT".into(), value.into())])
                        .unwrap_or_default(),
                    vec![],
                    vec![],
                    parent_value
                        .map(|value| vec![("WRIX_AGENT".into(), value.into())])
                        .unwrap_or_default(),
                );
                let expected = runtime.as_str();

                assert_eq!(
                    cfg.env
                        .iter()
                        .filter(|(key, _)| key == "WRIX_AGENT")
                        .map(|(_, value)| value.as_str())
                        .collect::<Vec<_>>(),
                    vec![expected],
                );
                assert_eq!(
                    cfg.launcher_env
                        .iter()
                        .filter(|(key, _)| key == "WRIX_AGENT")
                        .map(|(_, value)| value.as_str())
                        .collect::<Vec<_>>(),
                    vec![expected],
                );

                let mut child = tokio::process::Command::new("printenv");
                child.arg("WRIX_AGENT");
                if let Some(value) = parent_value {
                    child.env("WRIX_AGENT", value);
                } else {
                    child.env_remove("WRIX_AGENT");
                }
                loom_agent::apply_launcher_env(&mut child, &cfg.launcher_env);
                let output = child.output().await.expect("spawn child env recorder");
                assert!(output.status.success(), "printenv must observe WRIX_AGENT");
                assert_eq!(String::from_utf8_lossy(&output.stdout).trim(), expected);
            }
        }
    }

    #[test]
    fn build_spawn_config_copies_docker_archive_source_kind_from_manifest() {
        let mut image = entry();
        image.source = PathBuf::from("/nix/store/no-filename-inference");
        image.source_kind = ImageSourceKind::DockerArchive;

        let cfg = build_spawn_config(
            &image,
            AgentRuntime::Pi,
            PathBuf::from("/workspace"),
            "prompt".into(),
            PathBuf::from("/workspace/.loom/scratch/key"),
            vec![],
            vec![],
            vec![],
            vec![],
        );

        assert_eq!(
            cfg.image_source,
            PathBuf::from("/nix/store/no-filename-inference")
        );
        assert_eq!(cfg.image_source_kind, Some(ImageSourceKind::DockerArchive));
        let json = serde_json::to_string(&cfg).expect("serialize spawn config");
        let raw: serde_json::Value = serde_json::from_str(&json).expect("spawn config json");
        assert_eq!(raw["image_source_kind"], "docker-archive");
    }

    #[test]
    fn build_spawn_config_omits_image_source_kind_without_source_override() {
        let mut image = entry();
        image.source = PathBuf::new();

        let cfg = build_spawn_config(
            &image,
            AgentRuntime::Pi,
            PathBuf::from("/workspace"),
            "prompt".into(),
            PathBuf::from("/workspace/.loom/scratch/key"),
            vec![],
            vec![],
            vec![],
            vec![],
        );

        let json = serde_json::to_string(&cfg).expect("serialize spawn config");
        let raw: serde_json::Value = serde_json::from_str(&json).expect("spawn config json");
        assert!(
            raw.get("image_source").is_none(),
            "no source override: {json}"
        );
        assert!(
            raw.get("image_source_kind").is_none(),
            "no source kind without source override: {json}",
        );
    }

    #[test]
    fn spawn_config_omits_profile_manifest_host_only_fields_from_wrix_json() {
        let cfg = build_spawn_config(
            &entry(),
            AgentRuntime::Pi,
            PathBuf::from("/workspace"),
            "prompt".into(),
            PathBuf::from("/workspace/.loom/scratch/key"),
            vec![],
            vec![],
            vec![],
            vec![],
        );

        let json = serde_json::to_string(&cfg).expect("serialize spawn config");
        let raw: serde_json::Value = serde_json::from_str(&json).expect("spawn config json");
        assert_eq!(
            raw["image_source_kind"], "nix-descriptor",
            "SpawnConfig must carry the manifest source_kind when image_source is emitted: {json}",
        );
        assert!(
            !json.contains("wrix_launcher") && !json.contains("launcher"),
            "wrix launcher selection is host-only and must stay out of SpawnConfig JSON: {json}",
        );
        assert!(
            !json.contains("profile_config"),
            "wrix rejects profile_config as a per-launch override: {json}",
        );
        assert!(
            !json.contains("image_digest_path"),
            "wrix rejects image_digest_path as a per-launch override: {json}",
        );
        assert!(
            !json.contains("image_digest"),
            "wrix digest selection must stay in ProfileConfig, not SpawnConfig: {json}",
        );
    }

    #[test]
    fn wrix_spawn_logs_backend_runtime_and_image_ref() {
        let buf = Arc::new(Mutex::new(Vec::new()));
        let writer_buf = Arc::clone(&buf);
        let subscriber = tracing_subscriber::fmt()
            .with_ansi(false)
            .without_time()
            .with_writer(move || CaptureWriter(Arc::clone(&writer_buf)))
            .finish();

        let diagnostics = tracing::subscriber::with_default(subscriber, || {
            log_spawn_diagnostics(
                AgentRuntime::Direct,
                AgentRuntime::Direct.as_str(),
                "localhost/wrix-base-direct:abc",
            )
        });
        let captured = String::from_utf8(buf.lock().expect("capture not poisoned").clone())
            .expect("captured tracing output is UTF-8");

        assert_eq!(diagnostics.agent_backend, AgentRuntime::Direct);
        assert_eq!(diagnostics.wrix_agent_env, "direct");
        assert_eq!(diagnostics.image_ref, "localhost/wrix-base-direct:abc");
        assert!(captured.contains("agent_backend=direct"), "{captured}");
        assert!(captured.contains("wrix_agent_env=direct"), "{captured}");
        assert!(
            captured.contains("image_ref=localhost/wrix-base-direct:abc")
                || captured.contains("image_ref=\"localhost/wrix-base-direct:abc\""),
            "{captured}",
        );
    }
}
