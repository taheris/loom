//! Integration tests for `loom_driver::state::CacheDb`.

#![allow(
    clippy::unwrap_used,
    reason = "validated identifier literals are fixed integration-test fixtures"
)]

use std::path::Path;

use anyhow::{Context, Result, anyhow};
use loom_driver::identifier::{MoleculeId, SpecLabel};
use loom_driver::state::{CacheDb, CacheError, RebuildEpic, SpecEpicRow};
use loom_driver::testing::epic_fixture;

fn write_spec(workspace: &Path, label: &str, body: &str) -> Result<()> {
    let specs = workspace.join("specs");
    std::fs::create_dir_all(&specs)?;
    std::fs::write(specs.join(format!("{label}.md")), body)?;
    Ok(())
}

fn list_table(db_path: &Path, sql: &str) -> Result<Vec<Vec<String>>> {
    let conn = rusqlite::Connection::open(db_path)?;
    let mut stmt = conn.prepare(sql)?;
    let cols = stmt.column_count();
    let rows: Vec<Vec<String>> = stmt
        .query_map([], |row| {
            (0..cols)
                .map(|i| {
                    let v: rusqlite::types::Value = row.get(i)?;
                    Ok(match v {
                        rusqlite::types::Value::Null => String::from("NULL"),
                        rusqlite::types::Value::Integer(i) => i.to_string(),
                        rusqlite::types::Value::Real(r) => r.to_string(),
                        rusqlite::types::Value::Text(t) => t,
                        rusqlite::types::Value::Blob(_) => String::from("<blob>"),
                    })
                })
                .collect::<rusqlite::Result<Vec<String>>>()
        })?
        .collect::<rusqlite::Result<Vec<Vec<String>>>>()?;
    Ok(rows)
}

#[test]
fn cache_db_init_creates_tables() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");
    let _db = CacheDb::open(&db_path)?;
    assert!(db_path.exists(), "cache.db should be created");

    let tables = list_table(
        &db_path,
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name",
    )?;
    let names: Vec<&str> = tables.iter().map(|r| r[0].as_str()).collect();
    for expected in [
        "companions",
        "criterion_status",
        "meta",
        "spec_epics",
        "specs",
        "sqlite_sequence",
        "work_epics",
    ] {
        assert!(
            names.contains(&expected),
            "expected table {expected}: {names:?}"
        );
    }
    assert!(
        !names.contains(&"current_molecule"),
        "current_molecule must not exist on a fresh v8 schema: {names:?}",
    );

    let meta = list_table(
        &db_path,
        "SELECT key, value FROM meta WHERE key='schema_version'",
    )?;
    assert_eq!(
        meta,
        vec![vec!["schema_version".to_string(), "9".to_string()]]
    );
    Ok(())
}

#[test]
fn cache_db_rebuild_populates_specs_and_molecules() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n\nbody\n")?;
    write_spec(workspace, "beta", "# beta\n\nbody\n")?;

    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let molecules = epic_fixture(
        MoleculeId::new("lm-alpha").unwrap(),
        SpecLabel::new("alpha").unwrap(),
        Some("abc123".to_string()),
    )?;

    let report = db.rebuild(workspace, &molecules)?;
    assert_eq!(report.specs, 2);
    assert_eq!(report.work_epics, 1);

    let alpha = db.spec(&SpecLabel::new("alpha").unwrap())?;
    assert_eq!(alpha.label.as_str(), "alpha");

    let mol = db
        .work_epic(&MoleculeId::new("lm-alpha").unwrap())?
        .context("work epic should be present after rebuild")?;
    assert_eq!(mol.epic_id.as_str(), "lm-alpha");
    assert_eq!(mol.base_commit.as_deref(), Some("abc123"));
    assert_eq!(mol.iteration_count, 0);

    assert!(db.spec_epic(&SpecLabel::new("beta").unwrap())?.is_none());
    Ok(())
}

#[test]
fn cache_db_rebuild_companions() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(
        workspace,
        "with-companions",
        "# spec\n\n## Companions\n\n- `lib/a/`\n- `lib/b/`\n\n## Other\n\n- `lib/skip/`\n",
    )?;
    write_spec(
        workspace,
        "no-companions",
        "# bare spec\n\nno section here\n",
    )?;

    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let report = db.rebuild(workspace, &[])?;
    assert_eq!(report.specs, 2);
    assert_eq!(report.companions, 2);

    let rows = list_table(
        &workspace.join(".loom/cache.db"),
        "SELECT spec_label, companion_path FROM companions ORDER BY spec_label, companion_path",
    )?;
    assert_eq!(
        rows,
        vec![
            vec!["with-companions".to_string(), "lib/a/".to_string()],
            vec!["with-companions".to_string(), "lib/b/".to_string()],
        ]
    );
    Ok(())
}

#[test]
fn cache_db_rebuild_resets_counters() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n")?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let molecules = epic_fixture(
        MoleculeId::new("lm-alpha").unwrap(),
        SpecLabel::new("alpha").unwrap(),
        None,
    )?;
    db.rebuild(workspace, &molecules)?;

    let mol_id = MoleculeId::new("lm-alpha").unwrap();
    assert_eq!(db.increment_iteration(&mol_id)?, 1);
    assert_eq!(db.increment_iteration(&mol_id)?, 2);

    db.rebuild(workspace, &molecules)?;
    let mol = db
        .work_epic(&MoleculeId::new("lm-alpha").unwrap())?
        .context("work epic still present after rebuild")?;
    assert_eq!(mol.iteration_count, 0);
    Ok(())
}

/// `CacheDb::open` on a fresh DB must NOT carry the obsolete
/// `current_molecule` table. The at-most-one-open-epic-per-spec
/// invariant collapses resolution into a single `bd find` query, so
/// the pointer table is dead code; this test pins that the schema
/// reflects the new model.
#[test]
fn current_molecule_table_does_not_exist() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");
    let _db = CacheDb::open(&db_path)?;
    let rows = list_table(
        &db_path,
        "SELECT name FROM sqlite_master WHERE type='table' AND name='current_molecule'",
    )?;
    assert!(
        rows.is_empty(),
        "current_molecule table must not exist on a v8 schema: {rows:?}",
    );
    Ok(())
}

/// Opening an existing v6 DB that still carries the `current_molecule`
/// table must transparently drop the table and advance the schema
/// version to `7` without losing data in the other tables.
#[test]
fn cache_db_open_migrates_v6_drops_current_molecule() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");

    // Hand-build a v6 DB whose `current_molecule` table carries one
    // pointer, plus rows in the unrelated tables that must survive the
    // v6→v8 migration.
    {
        let conn = rusqlite::Connection::open(&db_path)?;
        conn.execute_batch(
            "CREATE TABLE specs (label TEXT PRIMARY KEY);
            CREATE TABLE molecules (
                id              TEXT PRIMARY KEY,
                spec_label      TEXT NOT NULL REFERENCES specs(label),
                base_commit     TEXT,
                iteration_count INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE companions (
                spec_label     TEXT NOT NULL REFERENCES specs(label),
                companion_path TEXT NOT NULL,
                PRIMARY KEY (spec_label, companion_path)
            );
            CREATE TABLE notes (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                spec_label TEXT NOT NULL REFERENCES specs(label) ON DELETE CASCADE,
                kind       TEXT NOT NULL,
                text       TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE INDEX idx_notes_spec_kind ON notes(spec_label, kind);
            CREATE TABLE current_molecule (
                spec_label TEXT PRIMARY KEY REFERENCES specs(label) ON DELETE CASCADE,
                epic_id    TEXT NOT NULL
            );
            CREATE TABLE meta (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            INSERT INTO meta(key, value) VALUES ('schema_version', '6');
            INSERT INTO meta(key, value) VALUES ('current_spec', 'alpha');
            INSERT INTO specs(label) VALUES ('alpha');
            INSERT INTO molecules(id, spec_label, base_commit, iteration_count)
              VALUES ('lm-alpha', 'alpha', 'deadbeef', 3);
            INSERT INTO companions(spec_label, companion_path)
              VALUES ('alpha', 'lib/a/');
            INSERT INTO current_molecule(spec_label, epic_id)
              VALUES ('alpha', 'lm-mol.1');",
        )?;
    }

    let db = CacheDb::open(&db_path)?;

    let version = list_table(
        &db_path,
        "SELECT value FROM meta WHERE key='schema_version'",
    )?;
    assert_eq!(
        version,
        vec![vec!["9".to_string()]],
        "schema_version must advance to 9",
    );

    let surviving = list_table(
        &db_path,
        "SELECT name FROM sqlite_master WHERE type='table' AND name='current_molecule'",
    )?;
    assert!(
        surviving.is_empty(),
        "current_molecule table must be dropped after v6→v8 migration: {surviving:?}",
    );

    assert!(matches!(
        db.spec(&SpecLabel::new("alpha").unwrap()),
        Err(CacheError::SpecNotFound { .. })
    ));
    Ok(())
}

#[test]
fn cache_increment_iteration_returns_updated_count() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n")?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let molecules = epic_fixture(
        MoleculeId::new("lm-alpha").unwrap(),
        SpecLabel::new("alpha").unwrap(),
        None,
    )?;
    db.rebuild(workspace, &molecules)?;

    let mol_id = MoleculeId::new("lm-alpha").unwrap();
    assert_eq!(db.increment_iteration(&mol_id)?, 1);
    assert_eq!(db.increment_iteration(&mol_id)?, 2);
    assert_eq!(db.increment_iteration(&mol_id)?, 3);
    Ok(())
}

#[test]
fn cache_set_and_reset_iteration_round_trip() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n")?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let molecules = epic_fixture(
        MoleculeId::new("lm-alpha").unwrap(),
        SpecLabel::new("alpha").unwrap(),
        None,
    )?;
    db.rebuild(workspace, &molecules)?;

    let mol_id = MoleculeId::new("lm-alpha").unwrap();
    db.set_iteration(&mol_id, 3)?;
    assert_eq!(
        db.work_epic(&mol_id)?
            .context("work epic present")?
            .iteration_count,
        3
    );

    db.reset_iteration(&mol_id)?;
    assert_eq!(
        db.work_epic(&mol_id)?
            .context("work epic present")?
            .iteration_count,
        0
    );

    let unknown = MoleculeId::new("lm-missing").unwrap();
    assert!(db.set_iteration(&unknown, 1).is_err());
    assert!(db.reset_iteration(&unknown).is_err());
    Ok(())
}

#[test]
fn cache_db_open_migrates_v1_to_v2() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");

    // Hand-build a v1 DB matching the pre-migration shape (specs has spec_path
    // NOT NULL, schema_version='1'). The new open() must drop spec_path and
    // bump schema_version to '2' without losing any rows.
    {
        let conn = rusqlite::Connection::open(&db_path)?;
        conn.execute_batch(
            "CREATE TABLE specs (
                label                TEXT PRIMARY KEY,
                spec_path            TEXT NOT NULL,
                implementation_notes TEXT
            );
            CREATE TABLE molecules (
                id              TEXT PRIMARY KEY,
                spec_label      TEXT NOT NULL REFERENCES specs(label),
                base_commit     TEXT,
                iteration_count INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE companions (
                spec_label     TEXT NOT NULL REFERENCES specs(label),
                companion_path TEXT NOT NULL,
                PRIMARY KEY (spec_label, companion_path)
            );
            CREATE TABLE meta (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            INSERT INTO meta(key, value) VALUES ('schema_version', '1');
            INSERT INTO specs(label, spec_path, implementation_notes)
              VALUES ('alpha', 'specs/alpha.md', NULL);
            INSERT INTO companions(spec_label, companion_path)
              VALUES ('alpha', 'lib/a/');",
        )?;
    }

    let db = CacheDb::open(&db_path)?;

    let meta = list_table(
        &db_path,
        "SELECT value FROM meta WHERE key='schema_version'",
    )?;
    assert_eq!(meta, vec![vec!["9".to_string()]]);

    let cols = list_table(&db_path, "PRAGMA table_info(specs)")?;
    let names: Vec<&str> = cols.iter().map(|r| r[1].as_str()).collect();
    assert!(names.contains(&"spec_path"));
    assert!(names.contains(&"label"));
    assert!(
        !names.contains(&"implementation_notes"),
        "implementation_notes column should be dropped: {names:?}",
    );

    assert!(matches!(
        db.spec(&SpecLabel::new("alpha").unwrap()),
        Err(CacheError::SpecNotFound { .. })
    ));
    Ok(())
}

#[test]
fn cache_db_open_is_idempotent_after_migration() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");

    // Fresh open lands at the current schema; a second open must be a
    // no-op rather than re-running any ALTER (which would fail because
    // the columns are already in their final shape).
    {
        let _ = CacheDb::open(&db_path)?;
    }
    let _db = CacheDb::open(&db_path)?;
    let meta = list_table(
        &db_path,
        "SELECT value FROM meta WHERE key='schema_version'",
    )?;
    assert_eq!(meta, vec![vec!["9".to_string()]]);
    Ok(())
}

#[test]
fn routine_commands_never_delete_spec_row() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n")?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let molecules = epic_fixture(
        MoleculeId::new("lm-alpha").unwrap(),
        SpecLabel::new("alpha").unwrap(),
        None,
    )?;
    db.rebuild(workspace, &molecules)?;
    let label = SpecLabel::new("alpha").unwrap();
    let mol_id = MoleculeId::new("lm-alpha").unwrap();

    db.set_iteration(&mol_id, 2)?;
    db.increment_iteration(&mol_id)?;
    db.reset_iteration(&mol_id)?;
    db.replace_companions(&label, &["lib/foo/".into(), "lib/bar/".into()])?;
    db.notes_set(
        &label,
        "implementation",
        &["touch lib/foo".to_string()],
        100,
    )?;
    db.notes_clear(&label, Some("implementation"))?;

    let row_count = list_table(
        &workspace.join(".loom/cache.db"),
        "SELECT COUNT(*) FROM specs WHERE label='alpha'",
    )?;
    assert_eq!(
        row_count,
        vec![vec!["1".to_string()]],
        "routine commands must never DELETE a specs row — only `loom init --rebuild` may",
    );
    assert_eq!(db.spec(&label)?.label.as_str(), "alpha");
    Ok(())
}

#[test]
fn cache_corruption_recovery() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");
    std::fs::write(&db_path, b"this is not a sqlite database\x00\x01\x02")?;

    if CacheDb::open(&db_path).is_ok() {
        return Err(anyhow!("opening a corrupt db should fail"));
    }

    let db = CacheDb::recreate(&db_path)?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n")?;
    let report = db.rebuild(workspace, &[])?;
    assert_eq!(report.specs, 1);
    Ok(())
}

// -- notes table CRUD -------------------------------------------------------

#[test]
fn notes_add_then_list_chronological() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db = CacheDb::open(dir.path().join("cache.db"))?;
    let label = SpecLabel::new("alpha").unwrap();
    let id1 = db.notes_add(&label, "implementation", "first", 100)?;
    let id2 = db.notes_add(&label, "implementation", "second", 200)?;
    let rows = db.notes_list(Some(&label), Some("implementation"))?;
    assert_eq!(rows.len(), 2);
    assert_eq!(rows[0].id, id1);
    assert_eq!(rows[0].text, "first");
    assert_eq!(rows[1].id, id2);
    assert_eq!(rows[1].text, "second");
    assert!(rows[0].id < rows[1].id, "list must be chronological by id");
    Ok(())
}

#[test]
fn notes_set_replaces_atomically() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db = CacheDb::open(dir.path().join("cache.db"))?;
    let label = SpecLabel::new("alpha").unwrap();
    db.notes_add(&label, "implementation", "old A", 100)?;
    db.notes_add(&label, "implementation", "old B", 200)?;
    db.notes_set(
        &label,
        "implementation",
        &[
            "new A".to_string(),
            "new B".to_string(),
            "new C".to_string(),
        ],
        300,
    )?;
    let rows = db.notes_list(Some(&label), Some("implementation"))?;
    let texts: Vec<&str> = rows.iter().map(|r| r.text.as_str()).collect();
    assert_eq!(texts, vec!["new A", "new B", "new C"]);
    Ok(())
}

#[test]
fn notes_clear_kind_only_or_all_kinds() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db = CacheDb::open(dir.path().join("cache.db"))?;
    let label = SpecLabel::new("alpha").unwrap();
    db.notes_add(&label, "implementation", "impl note", 100)?;
    db.notes_add(&label, "design", "design note", 100)?;

    db.notes_clear(&label, Some("implementation"))?;
    let rows = db.notes_list(Some(&label), None)?;
    assert_eq!(rows.len(), 1);
    assert_eq!(rows[0].kind, "design");

    db.notes_clear(&label, None)?;
    let rows = db.notes_list(Some(&label), None)?;
    assert_eq!(rows, [] as [loom_driver::state::NoteRow; 0]);
    Ok(())
}

#[test]
fn notes_rm_removes_one_row_by_id() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db = CacheDb::open(dir.path().join("cache.db"))?;
    let label = SpecLabel::new("alpha").unwrap();
    let id1 = db.notes_add(&label, "implementation", "first", 100)?;
    let id2 = db.notes_add(&label, "implementation", "second", 200)?;
    db.notes_rm(id1)?;
    let rows = db.notes_list(Some(&label), Some("implementation"))?;
    assert_eq!(rows.len(), 1);
    assert_eq!(rows[0].id, id2);
    Ok(())
}

#[test]
fn notes_kind_defaults_implementation() -> Result<()> {
    // The CLI binary's `Note` subcommand defaults `--kind` to
    // `implementation`. The DB layer takes `kind` explicitly; the
    // contract this pins is that the CLI's `default_value =
    // "implementation"` matches what `list` reads when called with
    // `--kind implementation` (the same default).
    let dir = tempfile::tempdir()?;
    let db = CacheDb::open(dir.path().join("cache.db"))?;
    let label = SpecLabel::new("alpha").unwrap();
    db.notes_add(&label, "implementation", "a", 100)?;
    db.notes_add(&label, "implementation", "b", 200)?;
    let rows = db.notes_list(Some(&label), Some("implementation"))?;
    assert_eq!(rows.len(), 2);
    Ok(())
}

#[test]
fn rebuild_drops_all_notes() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n")?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let label = SpecLabel::new("alpha").unwrap();
    db.notes_add(&label, "implementation", "impl 1", 100)?;
    db.notes_add(&label, "implementation", "impl 2", 200)?;
    db.notes_add(&label, "design", "design 1", 300)?;
    db.notes_add(&label, "review", "review 1", 400)?;
    assert_eq!(db.notes_list(Some(&label), None)?.len(), 4);

    db.rebuild(workspace, &[])?;
    let rows = db.notes_list(Some(&label), None)?;
    assert!(
        rows.is_empty(),
        "rebuild must drop and recreate the notes table — no notes survive regardless of kind",
    );

    let table_rows = list_table(
        &workspace.join(".loom/cache.db"),
        "SELECT name FROM sqlite_master WHERE type='table' AND name='notes'",
    )?;
    assert_eq!(
        table_rows,
        vec![vec!["notes".to_string()]],
        "notes table must be recreated after rebuild so subsequent inserts succeed",
    );
    Ok(())
}

#[test]
fn notes_cascade_on_spec_delete() -> Result<()> {
    // Verifies the `ON DELETE CASCADE` clause on `notes.spec_label` actually
    // fires when foreign keys are enabled — the spec acknowledges this is a
    // dormant guarantee (no routine command DELETEs from `specs`) but the
    // clause must work if a future code path ever takes that route.
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");
    let db = CacheDb::open(&db_path)?;
    let label = SpecLabel::new("alpha").unwrap();
    db.notes_add(&label, "implementation", "n1", 100)?;
    db.notes_add(&label, "design", "n2", 200)?;
    assert_eq!(db.notes_list(Some(&label), None)?.len(), 2);

    // Drop the CacheDb handle so its connection lock cannot collide with
    // the side-channel connection below. The cascade depends on
    // PRAGMA foreign_keys = ON, which CacheDb::open already enables for
    // its own connection — the side-channel must enable it explicitly.
    drop(db);
    let conn = rusqlite::Connection::open(&db_path)?;
    conn.execute_batch("PRAGMA foreign_keys = ON;")?;
    let removed = conn.execute(
        "DELETE FROM specs WHERE label = ?1",
        rusqlite::params![label.as_str()],
    )?;
    assert_eq!(removed, 1, "exactly one specs row must be deleted");
    drop(conn);

    let db = CacheDb::open(&db_path)?;
    let surviving = db.notes_list(Some(&label), None)?;
    assert!(
        surviving.is_empty(),
        "ON DELETE CASCADE must wipe child notes in the same statement; got {} rows",
        surviving.len(),
    );
    Ok(())
}

#[test]
fn open_wipes_legacy_todo_cursor_meta_keys() -> Result<()> {
    // v4→v5 migration: any `todo_cursor:<label>` row surviving from an
    // older binary is deleted on open. The cursor concept is replaced by
    // the molecule's `loom.base_commit` bead metadata; legacy rows are
    // dead state that must not bleed into v5 callers.
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");

    {
        let conn = rusqlite::Connection::open(&db_path)?;
        conn.execute_batch(
            "CREATE TABLE specs (label TEXT PRIMARY KEY);
            CREATE TABLE molecules (
                id              TEXT PRIMARY KEY,
                spec_label      TEXT NOT NULL REFERENCES specs(label),
                base_commit     TEXT,
                iteration_count INTEGER NOT NULL DEFAULT 0
            );
            CREATE TABLE companions (
                spec_label     TEXT NOT NULL REFERENCES specs(label),
                companion_path TEXT NOT NULL,
                PRIMARY KEY (spec_label, companion_path)
            );
            CREATE TABLE notes (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                spec_label TEXT NOT NULL REFERENCES specs(label) ON DELETE CASCADE,
                kind       TEXT NOT NULL,
                text       TEXT NOT NULL,
                created_at INTEGER NOT NULL
            );
            CREATE INDEX idx_notes_spec_kind ON notes(spec_label, kind);
            CREATE TABLE meta (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            INSERT INTO meta(key, value) VALUES ('schema_version', '4');
            INSERT INTO meta(key, value) VALUES ('current_spec', 'alpha');
            INSERT INTO meta(key, value) VALUES ('todo_cursor:alpha', 'deadbeef');
            INSERT INTO meta(key, value) VALUES ('todo_cursor:beta', 'cafebabe');",
        )?;
    }

    let _db = CacheDb::open(&db_path)?;

    let version = list_table(
        &db_path,
        "SELECT value FROM meta WHERE key='schema_version'",
    )?;
    assert_eq!(version, vec![vec!["9".to_string()]]);

    let legacy = list_table(
        &db_path,
        "SELECT key FROM meta WHERE key LIKE 'todo_cursor:%' ORDER BY key",
    )?;
    assert!(
        legacy.is_empty(),
        "v4→v5 migration must wipe legacy todo_cursor:<label> rows: {legacy:?}",
    );

    Ok(())
}

/// At the state-DB layer, `rebuild` mirrors the single-query resolver's
/// invariant: a spec may carry at most one active molecule. When the input
/// list pairs two molecules with the same `spec_label`, rebuild MUST refuse
/// with [`CacheError::DuplicateSpecEpics`] naming every conflicting id,
/// not silently insert both. Spec: `harness.md` *Auxiliary commands*
/// `loom init --rebuild` aborts on this case rather than papering over the
/// invariant break.
#[test]
fn todo_resolution_is_single_query_with_invariant_violation_refusal() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n")?;

    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let molecules = ["lm-aaa", "lm-bbb"].map(|id| {
        RebuildEpic::Spec(SpecEpicRow {
            epic_id: MoleculeId::new(id).unwrap(),
            spec_label: SpecLabel::new("alpha").unwrap(),
            todo_cursor: None,
        })
    });
    let err = db.rebuild(workspace, &molecules).unwrap_err();
    match err {
        CacheError::DuplicateSpecEpics { label, ids } => {
            assert_eq!(label, "alpha");
            assert!(
                ids.contains("lm-aaa") && ids.contains("lm-bbb"),
                "expected every conflicting id in the error, got {ids:?}",
            );
        }
        other => return Err(anyhow!("expected DuplicateSpecEpics, got {other:?}")),
    }
    Ok(())
}

#[test]
fn cache_db_round_trips_specs_epics_notes_and_criteria() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db = CacheDb::open(dir.path().join("cache.db"))?;
    let label = SpecLabel::new("alpha").unwrap();
    let spec = loom_driver::state::SpecRow {
        label: label.clone(),
        spec_path: "specs/alpha.md".to_string(),
    };
    let spec_epic = loom_driver::state::SpecEpicRow {
        spec_label: label.clone(),
        epic_id: MoleculeId::new("lm-alpha").unwrap(),
        todo_cursor: Some("abc123".to_string()),
    };
    let work_epic = loom_driver::state::WorkEpicRow {
        epic_id: MoleculeId::new("lm-work").unwrap(),
        base_commit: Some("def456".to_string()),
        todo_fingerprint: Some("fp".to_string()),
        is_active: true,
        iteration_count: 2,
    };
    let criterion = loom_driver::state::CriterionEvidenceRow {
        spec_label: label.clone(),
        criterion_id: "crit-1".to_string(),
        annotation_json: r#"{"tier":"test","target":"unit"}"#.to_string(),
        result: "pass".to_string(),
        last_timestamp_ms: Some(9),
        last_commit: Some("abc123".to_string()),
        evidence: Some("ok".to_string()),
    };

    db.upsert_spec(&label, &spec.spec_path)?;
    db.upsert_spec_epic(&spec_epic)?;
    db.upsert_work_epic(&work_epic)?;
    let note_id = db.notes_add(&label, "implementation", "note", 7)?;
    db.upsert_criterion_evidence(&criterion)?;

    assert_eq!(db.spec(&label)?, spec);
    assert_eq!(db.spec_epic(&label)?.context("spec epic")?, spec_epic);
    assert_eq!(
        db.work_epic(&work_epic.epic_id)?.context("work epic")?,
        work_epic
    );
    assert_eq!(
        db.notes_list(Some(&label), Some("implementation"))?,
        vec![loom_driver::state::NoteRow {
            id: note_id,
            spec_label: "alpha".to_string(),
            kind: "implementation".to_string(),
            text: "note".to_string(),
            created_at_ms: 7,
        }]
    );
    assert_eq!(db.criterion_evidence_for_spec(&label)?, vec![criterion]);
    Ok(())
}

#[test]
fn cache_rebuild_cross_checks_spec_index_and_files() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    std::fs::create_dir_all(workspace.join("docs"))?;
    std::fs::create_dir_all(workspace.join("specs"))?;
    std::fs::write(
        workspace.join("docs/README.md"),
        "| [alpha.md](../specs/alpha.md) | x | lm-a | p |\n",
    )?;
    std::fs::write(workspace.join("specs/beta.md"), "# beta\n")?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let err = db.rebuild(workspace, &[]).unwrap_err();
    assert!(matches!(err, CacheError::SpecIndexMismatch { .. }));
    Ok(())
}

#[test]
fn cache_rebuild_requires_one_spec_epic_per_indexed_spec() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    std::fs::create_dir_all(workspace.join("docs"))?;
    std::fs::create_dir_all(workspace.join("specs"))?;
    std::fs::write(
        workspace.join("docs/README.md"),
        "| [alpha.md](../specs/alpha.md) | x | lm-a | p |\n",
    )?;
    std::fs::write(workspace.join("specs/alpha.md"), "# alpha\n")?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let err = db.rebuild(workspace, &[]).unwrap_err();
    assert!(matches!(err, CacheError::SpecIndexMismatch { .. }));
    Ok(())
}

#[test]
fn cache_db_rebuild_populates_specs_epics_and_companions() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    std::fs::create_dir_all(workspace.join("docs"))?;
    std::fs::create_dir_all(workspace.join("specs"))?;
    std::fs::write(
        workspace.join("docs/README.md"),
        "| [alpha.md](../specs/alpha.md) | x | lm-a | p |\n",
    )?;
    std::fs::write(
        workspace.join("specs/alpha.md"),
        "# alpha\n\n## Companions\n\n- `lib/a/`\n",
    )?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let report = db.rebuild(
        workspace,
        &epic_fixture(
            MoleculeId::new("lm-alpha").unwrap(),
            SpecLabel::new("alpha").unwrap(),
            Some("abc".to_string()),
        )?,
    )?;
    assert_eq!(report.specs, 1);
    assert_eq!(report.spec_epics, 1);
    assert_eq!(report.companions, 1);
    assert_eq!(
        db.spec_epic(&SpecLabel::new("alpha").unwrap())?
            .context("spec epic")?
            .epic_id
            .as_str(),
        "lm-alphaspec"
    );
    Ok(())
}

#[test]
fn cache_rebuild_resets_work_epic_counters() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let workspace = dir.path();
    write_spec(workspace, "alpha", "# alpha\n")?;
    let db = CacheDb::open(workspace.join(".loom/cache.db"))?;
    let molecules = epic_fixture(
        MoleculeId::new("lm-alpha").unwrap(),
        SpecLabel::new("alpha").unwrap(),
        None,
    )?;
    db.rebuild(workspace, &molecules)?;
    db.increment_iteration(&MoleculeId::new("lm-alpha").unwrap())?;
    db.rebuild(workspace, &molecules)?;
    assert_eq!(
        db.work_epic(&MoleculeId::new("lm-alpha").unwrap())?
            .context("work epic")?
            .iteration_count,
        0
    );
    Ok(())
}

#[test]
fn cache_rebuild_rolls_back_partial_replacement_on_duplicate_work_ids() -> Result<()> {
    let directory = tempfile::tempdir()?;
    write_spec(directory.path(), "alpha", "# alpha")?;
    let db = CacheDb::open(directory.path().join("cache.db"))?;
    let id = MoleculeId::new("lm-work")?;
    let label = SpecLabel::new("alpha")?;
    let mut epics = epic_fixture(id.clone(), label.clone(), Some("anchor".into()))?.to_vec();
    db.rebuild(directory.path(), &epics)?;
    db.set_iteration(&id, 7)?;
    db.notes_add(&label, "implementation", "keep on failure", 1)?;
    epics.push(epics[1].clone());
    assert!(db.rebuild(directory.path(), &epics).is_err());
    assert_eq!(
        db.work_epic(&id)?
            .context("preserved work epic")?
            .iteration_count,
        7
    );
    assert_eq!(db.notes_list(Some(&label), None)?.len(), 1);
    Ok(())
}

#[test]
fn cache_rebuild_rejects_empty_present_index() -> Result<()> {
    let directory = tempfile::tempdir()?;
    write_spec(directory.path(), "alpha", "# alpha")?;
    std::fs::create_dir(directory.path().join("docs"))?;
    std::fs::write(directory.path().join("docs/README.md"), "# empty index")?;
    let db = CacheDb::open(directory.path().join("cache.db"))?;
    assert!(matches!(
        db.rebuild(directory.path(), &[]),
        Err(CacheError::SpecIndexMismatch { .. })
    ));
    Ok(())
}

#[test]
fn cache_corruption_recovery_never_implies_clean_todo() -> Result<()> {
    let dir = tempfile::tempdir()?;
    let db_path = dir.path().join("cache.db");
    std::fs::write(&db_path, "not sqlite")?;
    assert!(CacheDb::open(&db_path).is_err());
    let db = CacheDb::recreate(&db_path)?;
    db.upsert_spec(&SpecLabel::new("alpha").unwrap(), "specs/alpha.md")?;
    assert_eq!(
        db.criterion_evidence_for_spec(&SpecLabel::new("alpha").unwrap())?,
        [] as [loom_driver::state::CriterionEvidenceRow; 0]
    );
    Ok(())
}
