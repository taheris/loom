use std::ffi::OsString;
use std::path::{Path, PathBuf};
use std::process::ExitStatus;
use std::sync::Arc;
use std::time::{Duration, UNIX_EPOCH};

use tokio::task::spawn_blocking;
use tracing::{info, warn};

use crate::bd::{BdClient, CommandRunner};
use crate::clock::{Clock, SystemClock};
use crate::identifier::{BeadId, MoleculeId, SpecLabel};

use loom_protocol::oid::GitOid;

use super::error::GitError;

const GIT_TIMEOUT: Duration = Duration::from_mins(1);
/// Default timeout for git operations whose hooks can legitimately run
/// for minutes — pre-push fires the workspace's pre-push CI stage
/// (nextest + nix build), which on a warm sccache takes a few minutes.
/// The timeout surfaces true hangs (deadlocked subprocess, runaway
/// network); it must not abort legitimate CI. Overridable per client via
/// [`GitClient::with_hook_timeout`], which production threads from
/// `[loom] git_hook_timeout_secs`.
const GIT_HOOK_TIMEOUT: Duration = Duration::from_mins(10);
const WORKTREE_BASE: &str = ".loom/beads";
const BRANCH_PREFIX: &str = "loom";
/// Path of the loom-owned integration workspace relative to the workspace
/// root the `GitClient` is opened against. Materialized by `loom init` and
/// used by [`GitClient::merge_branch`], [`GitClient::push`],
/// [`GitClient::delete_branch`], and [`GitClient::create_worktree`] as the
/// cwd / clone source so bead integration never touches the operator's
/// working tree.
const LOOM_WORKSPACE_REL: &str = ".loom/integration";
/// Number of times an index-mutating git invocation in the loom workspace
/// retries against git lock-file contention before surfacing
/// [`GitError::IndexLocked`]. Cross-spec `loom loop` invocations share one
/// loom workspace; the rebase + ff critical section is serialized by git's
/// own `index.lock` (specs/harness.md § Concurrency). The loop's command
/// that loses the race observes git's "Unable to create '…/index.lock':
/// File exists" failure — having mutated nothing — and retries from its
/// current view of the integration branch. Bounded so a crashed peer that
/// left a stale lock cannot loop forever.
const INDEX_LOCK_RETRIES: u32 = 100;
/// Backoff between [`INDEX_LOCK_RETRIES`] attempts. The lock is held only
/// for the duration of a peer's single index write (rebase / checkout /
/// ff-merge run no hooks, so milliseconds), so a short fixed pause drains
/// realistic contention well inside the retry budget; the product
/// (`RETRIES * BACKOFF` ≈ 2s) is the worst-case wait before a stale lock is
/// reported.
const INDEX_LOCK_BACKOFF: Duration = Duration::from_millis(20);
/// Retry budget for a push whose remote transport drops after the
/// pre-push hook chain has already run. The second `git push` is expected
/// to hit wrix's push-verified stamp and skip already-passed checks for
/// the same commit.
const PUSH_TRANSPORT_RETRIES: u32 = 1;
const SIGPIPE_SIGNAL: i32 = 13;
/// Fallback integration branch when the caller opens a `GitClient` via
/// [`GitClient::open`] / [`GitClient::open_with_clock`] without naming
/// one. Production paths thread `[loom] integration_branch` from
/// `LoomConfig`; only test fixtures and one-shot CLI utilities take the
/// default.
const DEFAULT_INTEGRATION_BRANCH: &str = "main";
const RECOVERY_STASH_SELECTOR: &str = "stash@{0}";

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ActualPushRange {
    pub range: String,
    pub tree_oid: GitOid,
    pub remote_ref: String,
}

/// Single typed surface for git operations.
///
/// Backend split is internal: `gix` handles read-only inspection (status,
/// diff, refs, commit graph, worktree iteration); the `git` CLI handles
/// worktree mutation and merge-back. Callers see only the methods on this
/// struct — neither `gix` nor `Command::new("git")` is exposed.
///
/// The injected [`Clock`] drives the per-subprocess timeout so tests can
/// substitute [`crate::clock::MockClock`].
pub struct GitClient {
    repo: gix::ThreadSafeRepository,
    workdir: PathBuf,
    clock: Arc<dyn Clock>,
    integration_branch: String,
    /// Timeout for hook-running git operations (currently [`Self::push`]).
    /// Defaults to [`GIT_HOOK_TIMEOUT`]; production overrides it from
    /// `[loom] git_hook_timeout_secs` via [`Self::with_hook_timeout`].
    hook_timeout: Duration,
    /// Context-stable repository Git policy selected at `loom loop` startup.
    repo_git_policy: Option<super::signing::RepoGitPolicy>,
    #[cfg(any(test, feature = "test-support"))]
    prek_hooks_path_override: Option<PathBuf>,
}

impl GitClient {
    /// Open an existing repository at `path` using a [`SystemClock`] for
    /// subprocess timeouts and the default integration branch (`main`).
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub fn open(path: impl AsRef<Path>) -> Result<Self, GitError> {
        Self::open_with_clock(path, Arc::new(SystemClock::new()))
    }

    /// Open an existing repository at `path` with an explicit clock for
    /// subprocess timeouts. Integration branch defaults to `main`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub fn open_with_clock(
        path: impl AsRef<Path>,
        clock: Arc<dyn Clock>,
    ) -> Result<Self, GitError> {
        Self::open_with(path, clock, DEFAULT_INTEGRATION_BRANCH.to_string())
    }

    /// Open an existing repository at `path` and pin the integration
    /// branch the loom workspace has checked out. Production callers
    /// pass the value of `[loom] integration_branch` from `LoomConfig`;
    /// the field is consulted by [`Self::merge_branch`] (rebase target)
    /// and [`Self::push`] (origin push target) instead of querying
    /// `HEAD` or relying on `git push`'s upstream defaulting.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub fn open_with_integration_branch(
        path: impl AsRef<Path>,
        integration_branch: String,
    ) -> Result<Self, GitError> {
        Self::open_with(path, Arc::new(SystemClock::new()), integration_branch)
    }

    fn open_with(
        path: impl AsRef<Path>,
        clock: Arc<dyn Clock>,
        integration_branch: String,
    ) -> Result<Self, GitError> {
        let path = path.as_ref();
        let repo = gix::ThreadSafeRepository::open(path).map_err(|source| GitError::OpenRepo {
            path: path.to_path_buf(),
            source: Box::new(source),
        })?;
        let workdir = repo
            .work_dir()
            .map_or_else(|| path.to_path_buf(), Path::to_path_buf);
        Ok(Self {
            repo,
            workdir,
            clock,
            integration_branch,
            hook_timeout: GIT_HOOK_TIMEOUT,
            repo_git_policy: None,
            #[cfg(any(test, feature = "test-support"))]
            prek_hooks_path_override: None,
        })
    }

    /// Override the timeout used for hook-running git operations
    /// (currently [`Self::push`]). Production threads
    /// `[loom] git_hook_timeout_secs` here; absent an override the client
    /// uses the default hook timeout.
    #[must_use]
    pub const fn with_hook_timeout(mut self, hook_timeout: Duration) -> Self {
        self.hook_timeout = hook_timeout;
        self
    }

    /// Install the repository Git policy selected by the CLI startup preflight.
    #[must_use]
    pub fn with_repo_git_policy(mut self, policy: super::signing::RepoGitPolicy) -> Self {
        self.repo_git_policy = Some(policy);
        self
    }

    /// Whether this client explicitly permits ambient host Git authority.
    pub fn uses_host_key(&self) -> bool {
        self.repo_git_policy
            .as_ref()
            .is_some_and(super::signing::RepoGitPolicy::uses_host_key)
    }

    async fn apply_repo_git_policy(&self, workspace: &Path) -> Result<(), GitError> {
        let Some(policy) = self.repo_git_policy.clone() else {
            return Ok(());
        };
        let workspace = workspace.to_path_buf();
        spawn_blocking(move || policy.apply(&workspace)).await??;
        Ok(())
    }

    /// Test-only: force [`Self::create_worktree`] / push-gate hook
    /// validation to use `path` instead of resolving `$WRIX_PREK_HOOKS`.
    /// Gated behind `cfg(test)` / the `test-support` feature (RS-14).
    #[cfg(any(test, feature = "test-support"))]
    #[doc(hidden)]
    pub fn set_prek_hooks_path_override(&mut self, path: PathBuf) {
        self.prek_hooks_path_override = Some(path);
    }

    fn resolve_prek_hooks_path(&self) -> Result<PathBuf, GitError> {
        #[cfg(any(test, feature = "test-support"))]
        if let Some(path) = &self.prek_hooks_path_override {
            super::hooks::ensure_prek_hooks_dir(path)?;
            return Ok(path.clone());
        }
        let test_hooks = self.workdir.join(".loom/test-prek-hooks");
        if test_hooks.exists() {
            super::hooks::ensure_prek_hooks_dir(&test_hooks)?;
            return Ok(test_hooks);
        }
        super::hooks::resolve_prek_hooks_path_for_workspace(&self.workdir)
    }

    /// Name of the integration branch this client targets (the branch
    /// loaded from `[loom] integration_branch`).
    pub fn integration_branch(&self) -> &str {
        &self.integration_branch
    }

    /// The repository's working-tree root. Callers outside `loom-driver` use
    /// this to derive a workspace-relative subprocess `current_dir` without
    /// re-opening or duplicating the path they already passed to
    /// [`Self::open`].
    pub fn workdir(&self) -> &Path {
        &self.workdir
    }

    /// Path of the loom-owned integration workspace —
    /// `<workdir>/.loom/integration`. This is where bead branches
    /// are pushed, rebased, and fast-forward-merged into the integration
    /// branch; the operator's `<workdir>` itself is never the target of
    /// loom-driven merges or origin pushes.
    pub fn loom_workspace(&self) -> PathBuf {
        self.workdir.join(LOOM_WORKSPACE_REL)
    }

    /// Working tree status against HEAD.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn status(&self) -> Result<Vec<StatusEntry>, GitError> {
        let repo = self.repo.clone();
        spawn_blocking(move || -> Result<Vec<StatusEntry>, GitError> {
            let repo = repo.to_thread_local();
            let platform = repo
                .status(gix::progress::Discard)
                .map_err(|e| GitError::Gix(e.to_string()))?;
            let iter = platform
                .into_iter(None)
                .map_err(|e| GitError::Gix(e.to_string()))?;
            let mut out = Vec::new();
            for item in iter {
                let item = item.map_err(|e| GitError::Gix(e.to_string()))?;
                out.push(StatusEntry::from_item(&item));
            }
            Ok(out)
        })
        .await?
    }

    /// Unified diff of `HEAD` against its first parent (`HEAD~`).
    ///
    /// Returns an empty string when `HEAD` has no parent (initial commit).
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn diff_head_parent(&self) -> Result<String, GitError> {
        let repo = self.repo.clone();
        spawn_blocking(move || -> Result<String, GitError> {
            let repo = repo.to_thread_local();
            let head = repo
                .head_commit()
                .map_err(|e| GitError::Gix(e.to_string()))?;
            let parents: Vec<_> = head.parent_ids().collect();
            let Some(parent_id) = parents.first() else {
                return Ok(String::new());
            };
            let parent = repo
                .find_object(*parent_id)
                .map_err(|e| GitError::Gix(e.to_string()))?
                .try_into_commit()
                .map_err(|e| GitError::Gix(e.to_string()))?;
            let head_tree = head.tree().map_err(|e| GitError::Gix(e.to_string()))?;
            let parent_tree = parent.tree().map_err(|e| GitError::Gix(e.to_string()))?;
            let mut changes = parent_tree
                .changes()
                .map_err(|e| GitError::Gix(e.to_string()))?;
            let mut buf = String::new();
            changes
                .for_each_to_obtain_tree(
                    &head_tree,
                    |change| -> Result<_, std::convert::Infallible> {
                        use std::fmt::Write as _;
                        let _ = writeln!(buf, "{}", change.location());
                        Ok(std::ops::ControlFlow::Continue(()))
                    },
                )
                .map_err(|e| GitError::Gix(e.to_string()))?;
            Ok(buf)
        })
        .await?
    }

    /// Linked worktrees registered with the repository.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn worktrees(&self) -> Result<Vec<WorktreeInfo>, GitError> {
        let repo = self.repo.clone();
        spawn_blocking(move || -> Result<Vec<WorktreeInfo>, GitError> {
            let repo = repo.to_thread_local();
            let proxies = repo.worktrees().map_err(|e| GitError::Gix(e.to_string()))?;
            let mut out = Vec::with_capacity(proxies.len());
            for proxy in proxies {
                let path = proxy.base().map_err(|e| GitError::Gix(e.to_string()))?;
                let branch = proxy
                    .into_repo_with_possibly_inaccessible_worktree()
                    .ok()
                    .and_then(|wt| wt.head_name().ok().flatten())
                    .map(|name| name.shorten().to_string());
                out.push(WorktreeInfo { path, branch });
            }
            Ok(out)
        })
        .await?
    }

    /// Create a self-contained bead clone at `.loom/beads/<bead_id>/`
    /// with private Git objects and branch `loom/<bead_id>`. Its `origin`
    /// remains the integration checkout for host-side tracking and fetches.
    /// Existing independent clones are reused without discarding work.
    /// The label is accepted for source compatibility, not path construction.
    ///
    /// # Errors
    ///
    /// Rejects shared or indirect Git storage before modifying a reused clone,
    /// preserving its work for migration to an independent clone. Also returns
    /// repository inspection, Git execution, and output decoding failures.
    pub async fn create_worktree(
        &self,
        _label: &SpecLabel,
        bead_id: &BeadId,
    ) -> Result<CreatedWorktree, GitError> {
        let branch = format!("{BRANCH_PREFIX}/{bead_id}");
        let rel = PathBuf::from(WORKTREE_BASE).join(bead_id.as_str());
        let path = self.workdir.join(&rel);
        if path.exists() {
            ensure_private_bead_storage(&path).await?;
            self.apply_repo_git_policy(&path).await?;
            ensure_wrix_mount_dir(&path)?;
            self.repair_bead_hooks_path(&path).await?;
            return Ok(CreatedWorktree { path, branch });
        }
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }

        let loom_workspace = self.loom_workspace();
        let src_arg: OsString = loom_workspace.clone().into();
        let dst_arg: OsString = path.clone().into();
        run_git(
            &self.workdir,
            self.clock.as_ref(),
            [
                OsString::from("clone"),
                OsString::from("--local"),
                OsString::from("--no-hardlinks"),
                OsString::from("--quiet"),
                src_arg,
                dst_arg,
            ],
            None,
        )
        .await?;

        ensure_private_bead_storage(&path).await?;

        // Inherit user.email / user.name from the source's effective git
        // config (local + global) into the clone's local config so commits
        // inside the bead workspace work even when only the source repo
        // has the identity set (the nix build sandbox, CI images, and
        // bead containers all lack a global identity). `git clone --local`
        // does not copy `.git/config`, so without this inheritance the
        // first commit fails with "Author identity unknown".
        for key in ["user.email", "user.name"] {
            if let Some(value) =
                read_config_value(&loom_workspace, self.clock.as_ref(), key).await?
            {
                run_git(&path, self.clock.as_ref(), ["config", key, &value], None).await?;
            }
        }

        run_git(
            &path,
            self.clock.as_ref(),
            ["checkout", "-q", "-b", &branch],
            None,
        )
        .await?;

        let upstream = format!("origin/{}", self.integration_branch);
        run_git(
            &path,
            self.clock.as_ref(),
            ["branch", "--set-upstream-to", &upstream, &branch],
            None,
        )
        .await?;

        self.apply_repo_git_policy(&path).await?;
        ensure_wrix_mount_dir(&path)?;
        self.repair_bead_hooks_path(&path).await?;

        // `RepoGitPolicy` writes only Wrix context-stable helper tokens into
        // the clone. The helpers resolve the repository key from the current
        // process environment, so the same local config works for this
        // host-side preflight and for the container's fixed key paths.

        Ok(CreatedWorktree { path, branch })
    }

    /// Resolve the host key paths loom must hand to `wrix spawn` through
    /// the **launcher** environment (the child-process env, not the
    /// in-container [`SpawnConfig::env`](crate::agent::SpawnConfig::env) allowlist) so the wrapper can
    /// bind-mount the deploy + signing keys into the bead container.
    ///
    /// In repository mode, startup has already required both keys and this
    /// returns exact `WRIX_DEPLOY_KEY` / `WRIX_SIGNING_KEY` pairs. Generic
    /// non-loop clients retain the optional resolver for compatibility.
    ///
    /// The host paths never cross the sandbox boundary; wrix copies the
    /// keys to `/etc/wrix/keys/<basename>` in-container and resets
    /// `$WRIX_DEPLOY_KEY` / `$WRIX_SIGNING_KEY` to those paths (wrix
    /// `specs/security.md` § Credential Surfaces). See `specs/harness.md`
    /// § Repository Git isolation.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub fn launcher_key_env(&self) -> Result<Vec<(String, String)>, GitError> {
        if let Some(policy) = &self.repo_git_policy {
            return Ok(policy.launcher_env());
        }
        let loom_workspace = self.loom_workspace();
        let mut env = Vec::new();
        let signing = super::signing::resolve_signing_key(&loom_workspace)?;
        if let Some(key) = signing {
            env.push((
                super::signing::WRIX_SIGNING_KEY_ENV.to_string(),
                key.to_string_lossy().into_owned(),
            ));
        }
        if let Some(key) = super::signing::resolve_deploy_key(&loom_workspace)? {
            env.push((
                super::signing::WRIX_DEPLOY_KEY_ENV.to_string(),
                key.to_string_lossy().into_owned(),
            ));
        }
        Ok(env)
    }

    /// Preserve dirty bead-workspace state, align committed bead work with
    /// the current integration tip, and clean non-conflicted workspaces for
    /// dispatch.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn prepare_bead_clone(
        &self,
        path: &Path,
        bead_id: &BeadId,
    ) -> Result<BeadClonePreparation, GitError> {
        let status_before = self.status_short_branch_at(path).await?;
        let recovery = if status_short_branch_is_dirty(&status_before) {
            Some(
                self.create_workspace_recovery_stash(path, bead_id, &status_before)
                    .await?,
            )
        } else {
            None
        };
        let integration_ref = self.fetch_bead_integration_ref(path).await?;
        let integration_tip = self
            .rev_parse_at(path, &format!("{integration_ref}^{{commit}}"))
            .await?;
        let alignment = self.align_bead_clone(path, &integration_ref).await?;
        if !matches!(alignment, BeadCloneAlignment::Conflict { .. }) {
            self.reset_bead_clone(path).await?;
        }
        Ok(BeadClonePreparation {
            status_before,
            recovery,
            integration_tip,
            alignment,
        })
    }

    /// Reset a per-bead workspace's working tree to its current `HEAD` and
    /// drop everything outside the tracked content + the preserved
    /// scratch dirs. Runs `git reset --hard HEAD` followed by
    /// `git clean -fdx --exclude=target --exclude=.git --exclude=.wrix --exclude=.loom`.
    ///
    /// This is the destructive cleanup primitive. Dispatch paths that may
    /// encounter prior dirty work should call [`Self::prepare_bead_clone`]
    /// so the work is preserved before this reset/clean pair runs.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn reset_bead_clone(&self, path: &Path) -> Result<(), GitError> {
        run_git(
            path,
            self.clock.as_ref(),
            ["reset", "--hard", "--quiet", "HEAD"],
            None,
        )
        .await?;
        run_git(
            path,
            self.clock.as_ref(),
            [
                "clean",
                "-fdx",
                "--quiet",
                "--exclude=target",
                "--exclude=.git",
                "--exclude=.wrix",
                "--exclude=.loom",
            ],
            None,
        )
        .await
    }

    async fn status_short_branch_at(&self, path: &Path) -> Result<String, GitError> {
        let output = run_git_raw(
            path,
            self.clock.as_ref(),
            ["status", "--short", "--branch"],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        Ok(String::from_utf8(output.stdout)?)
    }

    async fn create_workspace_recovery_stash(
        &self,
        path: &Path,
        bead_id: &BeadId,
        pre_stash_status: &str,
    ) -> Result<BeadCloneRecovery, GitError> {
        let message = self.workspace_recovery_stash_message(bead_id)?;
        let output = run_git_raw(
            path,
            self.clock.as_ref(),
            ["stash", "push", "--include-untracked", "-m", &message],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let commit = self
            .rev_parse_at(path, &format!("{RECOVERY_STASH_SELECTOR}^{{commit}}"))
            .await?;
        Ok(BeadCloneRecovery {
            pre_stash_status: pre_stash_status.to_string(),
            stash: WorkspaceRecoveryStash {
                selector: RECOVERY_STASH_SELECTOR.to_string(),
                commit,
                message,
            },
        })
    }

    fn workspace_recovery_stash_message(&self, bead_id: &BeadId) -> Result<String, GitError> {
        let timestamp = self
            .clock
            .wall_now()
            .duration_since(UNIX_EPOCH)
            .map_err(GitError::ClockBeforeUnixEpoch)?
            .as_secs();
        Ok(format!("loom workspace-recovery {bead_id} {timestamp}"))
    }

    async fn fetch_bead_integration_ref(&self, path: &Path) -> Result<String, GitError> {
        let branch = self.integration_branch.as_str();
        let remote_ref = format!("refs/remotes/origin/{branch}");
        let refspec = format!("+refs/heads/{branch}:{remote_ref}");
        run_git(
            path,
            self.clock.as_ref(),
            ["fetch", "--quiet", "origin", &refspec],
            None,
        )
        .await?;
        Ok(remote_ref)
    }

    async fn align_bead_clone(
        &self,
        path: &Path,
        integration_ref: &str,
    ) -> Result<BeadCloneAlignment, GitError> {
        let previous_head = self.rev_parse_at(path, "HEAD^{commit}").await?;
        let local_commits = self
            .rev_count_at(path, &format!("{integration_ref}..HEAD"))
            .await?;
        if local_commits == 0 {
            let output = run_git_raw(
                path,
                self.clock.as_ref(),
                ["merge", "--ff-only", "--quiet", integration_ref],
                None,
            )
            .await?;
            if output.status.success() {
                return Ok(BeadCloneAlignment::Clean);
            }
            return Err(cli_error(&output));
        }

        let output =
            run_git_raw(path, self.clock.as_ref(), ["rebase", integration_ref], None).await?;
        if output.status.success() {
            let current_head = self.rev_parse_at(path, "HEAD^{commit}").await?;
            return Ok(BeadCloneAlignment::Rebased {
                previous_head,
                current_head,
            });
        }
        let files = self.unmerged_paths(path).await?;
        if files.is_empty() {
            return Err(cli_error(&output));
        }
        Ok(BeadCloneAlignment::Conflict { files })
    }

    async fn rev_parse_at(&self, path: &Path, rev: &str) -> Result<GitOid, GitError> {
        let output = run_git_raw(
            path,
            self.clock.as_ref(),
            ["rev-parse", "--verify", rev],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let raw = String::from_utf8(output.stdout)?;
        Ok(GitOid::new(raw.trim())?)
    }

    async fn rev_count_at(&self, path: &Path, range: &str) -> Result<u32, GitError> {
        let output = run_git_raw(
            path,
            self.clock.as_ref(),
            ["rev-list", "--count", range],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let stdout = String::from_utf8(output.stdout)?;
        stdout
            .trim()
            .parse()
            .map_err(|e: std::num::ParseIntError| GitError::GitCli {
                status: 0,
                stderr: format!("rev-list --count returned non-integer `{stdout}`: {e}"),
            })
    }

    /// Configure a bead clone's local `core.hooksPath` from wrix's
    /// canonical prek hooks directory.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn repair_bead_hooks_path(&self, path: &Path) -> Result<(), GitError> {
        let hooks_path = self.resolve_prek_hooks_path()?;
        let value = hooks_path.to_string_lossy().into_owned();
        run_git(
            path,
            self.clock.as_ref(),
            ["config", "core.hooksPath", &value],
            None,
        )
        .await
    }

    /// Reconcile and validate the loom integration workspace's local
    /// `core.hooksPath`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn validate_loom_hooks_path_configured(&self) -> Result<(), GitError> {
        let expected = self.resolve_prek_hooks_path()?;
        let workdir = self.loom_workspace();
        let expected_value = expected.to_string_lossy().into_owned();
        run_git(
            &workdir,
            self.clock.as_ref(),
            ["config", "core.hooksPath", &expected_value],
            None,
        )
        .await?;
        let actual = read_config_value(&workdir, self.clock.as_ref(), "core.hooksPath").await?;
        if actual.as_deref() == Some(expected_value.as_str()) {
            return Ok(());
        }
        Err(GitError::HooksPathInvalid {
            workdir,
            expected: expected_value,
            actual: actual.unwrap_or_else(|| "<unset>".to_string()),
        })
    }

    /// Remove a per-bead workspace directory.
    ///
    /// The workspace is a standalone clone (not a git-registered linked
    /// worktree), so cleanup is a recursive directory removal. Idempotent:
    /// a missing directory is not an error.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn remove_worktree(&self, path: &Path) -> Result<(), GitError> {
        if !path.exists() {
            return Ok(());
        }
        let path = path.to_path_buf();
        spawn_blocking(move || -> Result<(), GitError> {
            std::fs::remove_dir_all(&path)?;
            Ok(())
        })
        .await?
    }

    /// Enumerate `.loom/beads/` and remove each bead workspace whose
    /// bead is closed and parented by `molecule`. Called at `loom loop`
    /// startup, under the spec advisory lock, to reap orphans from crashed
    /// prior runs without touching another molecule's active workers.
    ///
    /// Failure modes are log-and-skip rather than abort, so a single
    /// corrupt orphan (unparsable directory name, `bd` lookup error,
    /// stuck removal) does not block `loom loop` from running:
    ///
    /// - directory whose name does not parse as a [`BeadId`] → skip
    /// - `bd show` failure (record gone, network blip) → skip
    /// - `remove_dir_all` failure → skip
    ///
    /// A missing `.loom/beads/` directory is a no-op (returns the
    /// empty vec). The returned paths are the workspaces actually
    /// removed during this sweep.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn sweep_orphan_bead_clones<R: CommandRunner>(
        &self,
        bd: &BdClient<R>,
        molecule: &MoleculeId,
    ) -> Result<Vec<PathBuf>, GitError> {
        let continuations = crate::workspace::Association::resolve(&self.workdir)
            .and_then(|association| association.verification_continuations())
            .map_err(std::io::Error::other)?;
        let base = self.workdir.join(WORKTREE_BASE);
        let entries = match std::fs::read_dir(&base) {
            Ok(it) => it,
            Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
            Err(e) => return Err(GitError::Io(e)),
        };
        let mut removed = Vec::new();
        for entry in entries {
            let entry = match entry {
                Ok(e) => e,
                Err(error) => {
                    warn!(
                        base = %base.display(),
                        ?error,
                        "sweep_orphan_bead_clones: failed to read entry — skipping",
                    );
                    continue;
                }
            };
            let path = entry.path();
            let file_type = match entry.file_type() {
                Ok(t) => t,
                Err(error) => {
                    warn!(
                        path = %path.display(),
                        ?error,
                        "sweep_orphan_bead_clones: failed to stat entry — skipping",
                    );
                    continue;
                }
            };
            if !file_type.is_dir() {
                continue;
            }
            let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
                warn!(
                    path = %path.display(),
                    "sweep_orphan_bead_clones: unreadable directory name — skipping",
                );
                continue;
            };
            let bead_id = match BeadId::new(name) {
                Ok(id) => id,
                Err(error) => {
                    warn!(
                        path = %path.display(),
                        ?error,
                        "sweep_orphan_bead_clones: directory name is not a bead id — skipping",
                    );
                    continue;
                }
            };
            if continuations.iter().any(|record| record.bead == bead_id) {
                continue;
            }
            let bead = match bd.show(&bead_id).await {
                Ok(b) => b,
                Err(error) => {
                    warn!(
                        bead = %bead_id,
                        path = %path.display(),
                        ?error,
                        "sweep_orphan_bead_clones: bd show failed — skipping",
                    );
                    continue;
                }
            };
            let in_current_molecule = bead
                .parent
                .as_ref()
                .is_some_and(|parent| parent.as_str() == molecule.as_str());
            if bead.status != crate::bd::Status::Closed || !in_current_molecule {
                continue;
            }
            match std::fs::remove_dir_all(&path) {
                Ok(()) => {
                    info!(
                        bead = %bead_id,
                        path = %path.display(),
                        "sweep_orphan_bead_clones: removed closed bead workspace",
                    );
                    removed.push(path);
                }
                Err(error) => {
                    warn!(
                        bead = %bead_id,
                        path = %path.display(),
                        ?error,
                        "sweep_orphan_bead_clones: removal failed — skipping",
                    );
                }
            }
        }
        Ok(removed)
    }

    /// Fetch any branch from an isolated checkout into the loom workspace.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn fetch_branch_from_path(
        &self,
        checkout_path: &Path,
        source_branch: &str,
        destination_branch: &str,
    ) -> Result<(), GitError> {
        let refspec = format!("+{source_branch}:refs/heads/{destination_branch}");
        run_git(
            &self.loom_workspace(),
            self.clock.as_ref(),
            [
                OsString::from("fetch"),
                OsString::from("--quiet"),
                checkout_path.into(),
                OsString::from(refspec),
            ],
            None,
        )
        .await
    }

    /// Fetch the bead branch `loom/<bead_id>` from the bead workspace at
    /// `bead_workspace_path` into the loom workspace, where
    /// [`Self::merge_branch`] rebases and fast-forwards it onto the
    /// integration branch.
    ///
    /// Runs `git fetch <bead-workspace-path> loom/<id>:loom/<id>` in the
    /// loom workspace ([`Self::loom_workspace`]), treating the bead
    /// workspace path as an ad-hoc filesystem URL — no network, no daemon.
    /// Under the A3 push-reliability model the worker never pushes; the
    /// driver pulls the branch over the filesystem path, which is always
    /// reachable from the host through the bead's lifetime (the bead
    /// container, by contrast, has no mount back to the loom workspace).
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn fetch_bead_branch(
        &self,
        bead_workspace_path: &Path,
        bead_id: &BeadId,
    ) -> Result<(), GitError> {
        let branch = format!("{BRANCH_PREFIX}/{bead_id}");
        self.fetch_branch_from_path(bead_workspace_path, &branch, &branch)
            .await
    }

    /// Create an isolated tune proposal checkout at `destination`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn create_tune_checkout(
        &self,
        destination: &Path,
        base: &str,
        branch: &str,
    ) -> Result<(), GitError> {
        if let Some(parent) = destination.parent() {
            std::fs::create_dir_all(parent)?;
        }
        run_git(
            &self.workdir,
            self.clock.as_ref(),
            [
                OsString::from("clone"),
                OsString::from("--no-local"),
                OsString::from("--no-checkout"),
                self.workdir.clone().into(),
                destination.into(),
            ],
            None,
        )
        .await?;
        run_git(
            destination,
            self.clock.as_ref(),
            ["checkout", "-B", branch, base],
            None,
        )
        .await?;
        run_git(
            destination,
            self.clock.as_ref(),
            ["config", "user.name", "Loom Tune"],
            None,
        )
        .await?;
        run_git(
            destination,
            self.clock.as_ref(),
            ["config", "user.email", "loom-tune@example.invalid"],
            None,
        )
        .await?;
        Ok(())
    }

    /// Commit every current worktree change, permitting an empty candidate.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn commit_all_allow_empty(&self, message: &str) -> Result<(), GitError> {
        run_git(&self.workdir, self.clock.as_ref(), ["add", "--all"], None).await?;
        run_git(
            &self.workdir,
            self.clock.as_ref(),
            ["commit", "--allow-empty", "-m", message],
            None,
        )
        .await
    }

    /// Force-delete the named branch in the loom workspace. Used by the
    /// parallel batch driver to reclaim the per-bead branch after agent
    /// failure (the worktree has already been removed by
    /// [`Self::remove_worktree`]). A non-existent branch surfaces as
    /// [`GitError::GitCli`] — call only when the branch is known to
    /// exist.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn delete_branch(&self, branch: &str) -> Result<(), GitError> {
        run_git(
            &self.loom_workspace(),
            self.clock.as_ref(),
            ["branch", "-D", branch],
            None,
        )
        .await?;
        Ok(())
    }

    /// Push the configured integration branch from the loom workspace
    /// to `origin`.
    ///
    /// Used by the push gate (`loom gate verify`). Routed through this client so
    /// `Command::new("git")` stays inside `loom-driver/src/git/`, satisfying
    /// the encapsulation rule asserted by `crates/loom/tests/style.rs`.
    /// Pushes `origin <integration_branch>` explicitly rather than
    /// relying on the current branch's upstream defaulting so the
    /// pushed ref name is unambiguous regardless of how the workspace
    /// was set up.
    ///
    /// On a transient transport drop (for example SSH closing the
    /// connection after long pre-push checks) the push retries once; wrix's
    /// push-verified stamp lets that second push reuse the already-passed
    /// hook result for the same commit. Other push failures, including
    /// non-fast-forward races and hook failures, surface as
    /// [`GitError::GitCli`] for the verdict gate to classify.
    ///
    /// Uses the repository Git policy installed at startup and
    /// the hook timeout (configurable via `[loom] git_hook_timeout_secs`)
    /// because the remote's pre-push hook (or loom's own pre-push hook on
    /// the GitHub publish) runs the workspace's pre-push CI stage.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn push(&self) -> Result<(), GitError> {
        self.run_push_command_with_transport_retry([
            "push",
            "origin",
            self.integration_branch.as_str(),
        ])
        .await
    }

    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn prepare_actual_push_range(&self) -> Result<ActualPushRange, GitError> {
        self.recover_publication_rebase().await?;
        self.validate_loom_hooks_path_configured().await?;
        let workdir = self.loom_workspace();
        let integration_branch = self.integration_branch.as_str();
        let remote_ref = format!("origin/{integration_branch}");
        run_git(
            &workdir,
            self.clock.as_ref(),
            ["fetch", "--quiet", "origin", integration_branch],
            None,
        )
        .await?;
        let before = self.rev_parse_in_loom("HEAD").await?;
        let onto = self.rev_parse_in_loom(&remote_ref).await?;
        let mut cohort = Vec::new();
        let journal = self.workdir.join(".git/loom-verification-continuations");
        let association = if journal.try_exists()? {
            Some(
                crate::workspace::Association::resolve(&self.workdir)
                    .map_err(std::io::Error::other)?,
            )
        } else {
            None
        };
        if let Some(association) = &association {
            let integration = GitClient::open(&workdir)?;
            if !integration.is_ancestor_of_head(onto.as_str()).await? {
                let common = run_git_raw(
                    &workdir,
                    self.clock.as_ref(),
                    ["merge-base", before.as_str(), onto.as_str()],
                    None,
                )
                .await?;
                if !common.status.success() {
                    return Err(cli_error(&common));
                }
                let common = GitOid::new(String::from_utf8(common.stdout)?.trim())?;
                for mut record in association
                    .verification_continuations()
                    .map_err(std::io::Error::other)?
                {
                    if !integration
                        .is_ancestor_of_head(record.candidate.as_str())
                        .await?
                    {
                        continue;
                    }
                    association
                        .validate_verification(&record)
                        .map_err(std::io::Error::other)?;
                    self.preserve_verification_candidate(&record.bead, &before)
                        .await?;
                    record.base = common.clone();
                    record.publication_rebase = Some(crate::workspace::PublicationRebase {
                        before: before.clone(),
                        onto: onto.clone(),
                        after: None,
                    });
                    association
                        .append_verification(&record)
                        .map_err(std::io::Error::other)?;
                    cohort.push(record);
                }
            }
        }
        let rebase_output =
            run_git_index_mut(&workdir, self.clock.as_ref(), ["rebase", &remote_ref], None).await?;
        if !rebase_output.status.success() {
            let _ = run_git_raw(&workdir, self.clock.as_ref(), ["rebase", "--abort"], None).await?;
            return Err(cli_error(&rebase_output));
        }
        let from_oid = self.rev_parse_in_loom(&remote_ref).await?;
        let to_oid = self.rev_parse_in_loom("HEAD").await?;
        if let Some(association) = &association {
            for record in cohort {
                self.finish_publication_rebase_record(association, record, &to_oid, &from_oid)
                    .await?;
            }
        }
        let tree_oid = self.rev_parse_in_loom("HEAD^{tree}").await?;
        Ok(ActualPushRange {
            range: format!("{from_oid}..{to_oid}"),
            tree_oid,
            remote_ref,
        })
    }

    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn run_pre_push_chain(&self) -> Result<(), GitError> {
        self.run_push_command_with_transport_retry([
            "push",
            "--dry-run",
            "origin",
            self.integration_branch.as_str(),
        ])
        .await
    }

    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn push_once(&self) -> Result<(), GitError> {
        self.run_push_command(["push", "origin", self.integration_branch.as_str()])
            .await
    }

    async fn run_push_command_with_transport_retry<const N: usize>(
        &self,
        args: [&str; N],
    ) -> Result<(), GitError> {
        let mut output = self.run_push_command_output(args).await?;
        for attempt in 0..PUSH_TRANSPORT_RETRIES {
            if output.status.success() {
                return Ok(());
            }
            if !is_retryable_push_transport_failure(&output) {
                return Err(cli_error(&output));
            }
            warn!(
                attempt = attempt + 1,
                args = %args.join(" "),
                "git push transport dropped after pre-push; retrying"
            );
            output = self.run_push_command_output(args).await?;
        }
        if output.status.success() {
            return Ok(());
        }
        Err(cli_error(&output))
    }

    async fn run_push_command<const N: usize>(&self, args: [&str; N]) -> Result<(), GitError> {
        let output = self.run_push_command_output(args).await?;
        if output.status.success() {
            return Ok(());
        }
        Err(cli_error(&output))
    }

    async fn run_push_command_output<const N: usize>(
        &self,
        args: [&str; N],
    ) -> Result<std::process::Output, GitError> {
        self.validate_loom_hooks_path_configured().await?;
        let workdir = self.loom_workspace();
        run_git_raw_with_timeout(&workdir, self.clock.as_ref(), self.hook_timeout, args, None).await
    }

    async fn rev_parse_in_loom(&self, rev: &str) -> Result<GitOid, GitError> {
        let output = run_git_raw(
            &self.loom_workspace(),
            self.clock.as_ref(),
            ["rev-parse", "--verify", rev],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let raw = String::from_utf8(output.stdout)?;
        Ok(GitOid::new(raw.trim())?)
    }

    /// `git rev-parse --verify <rev>^{commit}` — resolve a commit object.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn resolve_commit_sha(&self, rev: &str) -> Result<GitOid, GitError> {
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["rev-parse", "--verify", &format!("{rev}^{{commit}}")],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let raw = String::from_utf8(output.stdout)?;
        Ok(GitOid::new(raw.trim())?)
    }

    /// `git rev-parse --verify <rev>^{commit}` — true iff `rev` resolves to
    /// a commit object in this repository.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn rev_exists(&self, rev: &str) -> Result<bool, GitError> {
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            [
                "rev-parse",
                "--verify",
                "--quiet",
                &format!("{rev}^{{commit}}"),
            ],
            None,
        )
        .await?;
        Ok(output.status.success())
    }

    /// `git merge-base --is-ancestor <rev> HEAD` — true iff `rev` is an
    /// ancestor of the current `HEAD`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn is_ancestor_of_head(&self, rev: &str) -> Result<bool, GitError> {
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["merge-base", "--is-ancestor", rev, "HEAD"],
            None,
        )
        .await?;
        Ok(output.status.success())
    }

    /// `git diff <base> HEAD --name-only -- specs/` — repo-relative spec
    /// file paths changed since `base`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn changed_spec_files(&self, base: &str) -> Result<Vec<PathBuf>, GitError> {
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["diff", "--name-only", base, "HEAD", "--", "specs/"],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let stdout = String::from_utf8(output.stdout)?;
        Ok(stdout
            .lines()
            .filter(|line| !line.is_empty())
            .map(PathBuf::from)
            .collect())
    }

    /// `git diff --name-only <range> -- <pathspec>` — repo-relative paths
    /// changed across the supplied diff range, optionally filtered by a
    /// pathspec (e.g. `"specs/"`). `range` is forwarded verbatim, so any
    /// shape `git diff` accepts works (`A..B`, `A...B`, `A B`, etc.).
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn changed_files_in_range(
        &self,
        range: &str,
        pathspec: Option<&str>,
    ) -> Result<Vec<PathBuf>, GitError> {
        let mut args: Vec<&str> = vec!["diff", "--name-only", range];
        if let Some(p) = pathspec {
            args.push("--");
            args.push(p);
        }
        let output = run_git_raw(&self.workdir, self.clock.as_ref(), args, None).await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let stdout = String::from_utf8(output.stdout)?;
        Ok(stdout
            .lines()
            .filter(|line| !line.is_empty())
            .map(PathBuf::from)
            .collect())
    }

    /// `git diff HEAD --name-only -- specs/` — repo-relative paths of spec
    /// files whose working-tree contents differ from `HEAD`. Powers
    /// `loom todo`'s touched-set discovery: any spec edit visible in the
    /// working tree (committed or not) qualifies.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn workdir_changed_specs(&self) -> Result<Vec<PathBuf>, GitError> {
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["diff", "HEAD", "--name-only", "--", "specs/"],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let stdout = String::from_utf8(output.stdout)?;
        Ok(stdout
            .lines()
            .filter(|line| !line.is_empty())
            .map(PathBuf::from)
            .collect())
    }

    /// `git ls-files` — repo-relative paths tracked at the current worktree.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn tracked_files(&self) -> Result<Vec<PathBuf>, GitError> {
        let output = run_git_raw(&self.workdir, self.clock.as_ref(), ["ls-files"], None).await?;
        tracked_files_from_output(output)
    }

    /// Synchronous `git ls-files` for sync workflow phases such as `loom plan`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub fn tracked_files_sync(&self) -> Result<Vec<PathBuf>, GitError> {
        let output = sync_git_raw(&self.workdir, &["ls-files"])?;
        tracked_files_from_output(output)
    }

    /// Repository-relative tracked and nonignored new paths, preserving exact names.
    ///
    /// # Errors
    /// Returns Git execution or UTF-8 decoding errors rather than a partial inventory.
    pub fn repository_files_sync(&self) -> Result<Vec<PathBuf>, GitError> {
        let output = sync_git_raw(
            &self.workdir,
            &[
                "ls-files",
                "-z",
                "--cached",
                "--others",
                "--exclude-standard",
            ],
        )?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        Ok(String::from_utf8(output.stdout)?
            .split('\0')
            .filter(|path| !path.is_empty())
            .map(PathBuf::from)
            .collect())
    }

    /// `git diff HEAD -- <spec_path>` — working-tree diff for one spec file.
    /// Empty string when the file matches `HEAD`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn workdir_diff_spec(&self, spec_path: &Path) -> Result<String, GitError> {
        let path_str = spec_path.to_string_lossy().into_owned();
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["diff", "HEAD", "--", &path_str],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        Ok(String::from_utf8(output.stdout)?)
    }

    /// `git diff <base> HEAD -- <spec_path>` — unified diff of one spec
    /// file. Empty string when there is no diff.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn diff_spec(&self, base: &str, spec_path: &Path) -> Result<String, GitError> {
        let path_str = spec_path.to_string_lossy().into_owned();
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["diff", base, "HEAD", "--", &path_str],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        Ok(String::from_utf8(output.stdout)?)
    }

    /// `git diff --quiet <base> HEAD -- <path>` — true when `path` changed.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn path_changed_since(&self, base: &str, path: &Path) -> Result<bool, GitError> {
        let path_str = path.to_string_lossy().into_owned();
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["diff", "--quiet", base, "HEAD", "--", &path_str],
            None,
        )
        .await?;
        match output.status.code() {
            Some(0) => Ok(false),
            Some(1) => Ok(true),
            _ => Err(cli_error(&output)),
        }
    }

    /// `git show <rev>:<path>` — file contents at `rev`, or `None` if absent.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn file_at_revision(
        &self,
        rev: &str,
        path: &Path,
    ) -> Result<Option<String>, GitError> {
        let path_str = path.to_string_lossy();
        let spec = format!("{rev}:{path_str}");
        let output = run_git_raw(&self.workdir, self.clock.as_ref(), ["show", &spec], None).await?;
        if output.status.success() {
            return Ok(Some(String::from_utf8(output.stdout)?));
        }
        Ok(None)
    }

    /// `git rev-parse HEAD:<path>` — blob SHA for a path at HEAD.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn head_blob_sha(&self, path: &Path) -> Result<GitOid, GitError> {
        let path_str = path.to_string_lossy();
        let spec = format!("HEAD:{path_str}");
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["rev-parse", &spec],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let raw = String::from_utf8(output.stdout)?;
        Ok(GitOid::new(raw.trim())?)
    }

    /// Object identity for an exact path at a readable revision, if present.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn blob_sha_at_revision(
        &self,
        rev: &str,
        path: &Path,
    ) -> Result<Option<GitOid>, GitError> {
        let pathspec = format!(":(literal){}", path.to_string_lossy());
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            [
                "ls-tree",
                "-z",
                "--format=%(objectname)",
                rev,
                "--",
                &pathspec,
            ],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let raw = String::from_utf8(output.stdout)?;
        if raw.is_empty() {
            return Ok(None);
        }
        Ok(Some(GitOid::new(raw.trim_end_matches('\0'))?))
    }

    /// `git rev-list --count <commit>..HEAD` — number of commits between
    /// `commit` and the current `HEAD`. Returns `0` when `commit` is `HEAD`,
    /// and surfaces [`GitError::GitCli`] when `commit` does not resolve.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn commits_since(&self, commit: &str) -> Result<u32, GitError> {
        let range = format!("{commit}..HEAD");
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["rev-list", "--count", &range],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let stdout = String::from_utf8(output.stdout)?;
        let parsed: u32 = stdout
            .trim()
            .parse()
            .map_err(|e: std::num::ParseIntError| GitError::GitCli {
                status: 0,
                stderr: format!("rev-list --count returned non-integer `{stdout}`: {e}"),
            })?;
        Ok(parsed)
    }

    /// `git -C <workdir> status --porcelain` against an arbitrary linked
    /// worktree under this repo. Returns the raw porcelain output verbatim
    /// so callers can route it through
    /// the workflow's porcelain status parser without
    /// reopening a [`GitClient`] per worktree. Used by the run-phase
    /// verdict-gate tree-not-clean dispatcher.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn status_porcelain_at(&self, workdir: &Path) -> Result<String, GitError> {
        let output = run_git_raw(
            workdir,
            self.clock.as_ref(),
            ["status", "--porcelain"],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        Ok(String::from_utf8(output.stdout)?)
    }

    /// `git rev-parse HEAD` — full SHA of the current `HEAD`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn head_commit_sha(&self) -> Result<GitOid, GitError> {
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["rev-parse", "HEAD"],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let raw = String::from_utf8(output.stdout)?;
        Ok(GitOid::new(raw.trim())?)
    }

    /// `git rev-list --max-parents=0 HEAD` — root commit ids for the current
    /// history.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn root_commit_shas(&self) -> Result<Vec<GitOid>, GitError> {
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["rev-list", "--max-parents=0", "HEAD"],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let raw = String::from_utf8(output.stdout)?;
        let mut roots = raw
            .lines()
            .filter(|line| !line.is_empty())
            .map(GitOid::new)
            .collect::<Result<Vec<_>, _>>()?;
        roots.sort_by(|left, right| left.as_str().cmp(right.as_str()));
        Ok(roots)
    }

    /// Merge `branch` into the configured integration branch inside the
    /// loom workspace ([`Self::loom_workspace`]). Rebases `branch` onto
    /// the current integration-branch `HEAD` first so the merge is
    /// always a fast-forward — sequential dispatch (bead branch is a
    /// strict descendant of `HEAD`) is a rebase no-op; parallel
    /// dispatch's second-and-later beads pick up the moved `HEAD` from
    /// an earlier merge. True overlap surfaces as
    /// [`MergeResult::Conflict`]; other failures surface as [`GitError`].
    ///
    /// The integration-branch name comes from the constructor (via
    /// `[loom] integration_branch`) — never from a `symbolic-ref HEAD`
    /// query, so the value is unambiguously the operator's configured
    /// target rather than whatever happens to be checked out.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn merge_branch(&self, branch: &str) -> Result<MergeResult, GitError> {
        match self.rebase_onto_integration(branch).await? {
            RebaseOutcome::Conflict {
                detail,
                files,
                new_base_sha,
            } => Ok(MergeResult::Conflict {
                detail,
                files,
                new_base_sha,
            }),
            RebaseOutcome::Rebased => {
                self.ff_merge_integration(branch).await?;
                Ok(MergeResult::Ok)
            }
        }
    }

    /// Rebase `branch` onto the configured integration branch inside the
    /// loom workspace, replaying any rerere-recorded conflict resolution.
    /// On [`RebaseOutcome::Rebased`] the workspace is left checked out on
    /// the rewritten `branch`, whose `<integration-branch>..<branch>`
    /// range is the rebased commits ready for pass-2 signature
    /// verification; the integration branch has *not* moved yet — the
    /// fast-forward happens in [`Self::ff_merge_integration`]. Splitting
    /// the rebase from the ff-merge lets the verdict gate verify the
    /// rewritten commits between the two steps (per `specs/harness.md`
    /// § Bead dispatch — Bead branch flow), so a pass-2 failure leaves
    /// the integration line untouched.
    ///
    /// rerere (enabled in the loom workspace at `loom init`) replays a
    /// previously-recorded resolution before falling through to
    /// `integration-conflict` recovery. Because `rerere.autoupdate`
    /// stages the recorded resolution into the index but still pauses the
    /// rebase awaiting `--continue`, a paused rebase with no remaining
    /// unmerged paths means rerere resolved the conflict: the
    /// `--continue` drive loop below carries it to completion. Paths that
    /// stay unmerged are a conflict rerere has no record for — abort,
    /// restore the integration branch, and surface
    /// [`RebaseOutcome::Conflict`].
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn rebase_onto_integration(&self, branch: &str) -> Result<RebaseOutcome, GitError> {
        let workdir = self.loom_workspace();
        let integration_branch = self.integration_branch.as_str();

        // Upper bound on `--continue` drives: the rebase replays one
        // commit per step, so it can pause for a rerere-resolved conflict
        // at most once per replayed commit. The `+ 1` absorbs an
        // off-by-one when the final commit also conflicts; the bound
        // keeps a non-advancing `--continue` (e.g. a resolution that
        // emptied the commit) from spinning forever.
        let count_output = run_git_raw(
            &workdir,
            self.clock.as_ref(),
            [
                "rev-list",
                "--count",
                &format!("{integration_branch}..{branch}"),
            ],
            None,
        )
        .await?;
        if !count_output.status.success() {
            // A failed `rev-list --count` (bad range, spawn failure,
            // timeout) must not collapse to the sentinel 0 — that would
            // silently degrade `max_steps` to 1 and starve the `--continue`
            // drive loop below, indistinguishable from a legitimately empty
            // range (RS-11). Surface the CLI error instead.
            return Err(cli_error(&count_output));
        }
        let count_stdout = String::from_utf8(count_output.stdout)?;
        let max_steps = count_stdout
            .trim()
            .parse::<u32>()
            .map_err(|e: std::num::ParseIntError| GitError::GitCli {
                status: 0,
                stderr: format!("rev-list --count returned non-integer `{count_stdout}`: {e}"),
            })?
            .saturating_add(1);

        // The rebase / --continue / --abort / checkout below all take the
        // loom workspace's `index.lock`; a cross-spec peer holding it loses
        // the race to a clear, retryable error rather than a spurious
        // conflict (specs/harness.md § Concurrency).
        let mut output = run_git_index_mut(
            &workdir,
            self.clock.as_ref(),
            ["rebase", integration_branch, branch],
            None,
        )
        .await?;
        let mut steps = 0u32;
        while !output.status.success() {
            // Capture the unmerged-path set while the rebase is still
            // paused mid-conflict — `git rebase --abort` discards it. A
            // non-conflict refusal (unstaged changes) leaves no
            // diff-filter=U entries, so `files` comes back empty.
            let files = self.unmerged_paths(&workdir).await?;
            if files.is_empty() && steps < max_steps {
                // rerere staged a full resolution but the rebase paused
                // awaiting `--continue`; carry it forward.
                // `-c core.editor=true` keeps `--continue` from opening an
                // editor for the reused commit message.
                steps += 1;
                output = run_git_index_mut(
                    &workdir,
                    self.clock.as_ref(),
                    ["-c", "core.editor=true", "rebase", "--continue"],
                    None,
                )
                .await?;
                continue;
            }
            // Genuine conflict (or a stuck `--continue`). Capture stderr
            // BEFORE the abort+checkout so the caller sees the actual
            // rebase refusal (content conflict vs. "cannot rebase: You
            // have unstaged changes" vs. anything else) rather than the
            // cleanup commands' output.
            let detail = String::from_utf8_lossy(&output.stderr).trim().to_string();
            let _ = run_git_index_mut(&workdir, self.clock.as_ref(), ["rebase", "--abort"], None)
                .await?;
            let checkout = run_git_index_mut(
                &workdir,
                self.clock.as_ref(),
                ["checkout", "-q", integration_branch],
                None,
            )
            .await?;
            if !checkout.status.success() {
                return Err(cli_error(&checkout));
            }
            // The integration-branch tip is the base the rebase
            // targeted; the agent's retry rebases its branch onto this.
            let new_base_raw = run_git_raw(
                &workdir,
                self.clock.as_ref(),
                ["rev-parse", integration_branch],
                None,
            )
            .await?;
            let new_base_sha = GitOid::new(String::from_utf8_lossy(&new_base_raw.stdout).trim())?;
            return Ok(RebaseOutcome::Conflict {
                detail,
                files,
                new_base_sha,
            });
        }
        Ok(RebaseOutcome::Rebased)
    }

    /// Fast-forward the configured integration branch to the tip of the
    /// already-rebased `branch` (see [`Self::rebase_onto_integration`]).
    /// Checks out the integration branch and runs `git merge --ff-only`
    /// so history stays linear (no merge commits); a non-fast-forward
    /// refusal surfaces as [`GitError`].
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn ff_merge_integration(&self, branch: &str) -> Result<(), GitError> {
        let workdir = self.loom_workspace();
        let integration_branch = self.integration_branch.as_str();

        // Both the checkout and the ff-merge take the loom workspace's
        // `index.lock`; a cross-spec peer holding it loses the race to a
        // retryable [`GitError::IndexLocked`] rather than a spurious
        // failure (specs/harness.md § Concurrency).
        let checkout = run_git_index_mut(
            &workdir,
            self.clock.as_ref(),
            ["checkout", "-q", integration_branch],
            None,
        )
        .await?;
        if !checkout.status.success() {
            return Err(cli_error(&checkout));
        }

        let output = run_git_index_mut(
            &workdir,
            self.clock.as_ref(),
            ["merge", "--ff-only", branch],
            None,
        )
        .await?;
        if output.status.success() {
            return Ok(());
        }
        let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
        Err(GitError::GitCli {
            status: output.status.code().unwrap_or(-1),
            stderr,
        })
    }

    /// Pin a verified candidate before a reversible integration advance.
    ///
    /// # Errors
    /// Returns Git errors without replacing any existing candidate history.
    pub async fn preserve_verification_candidate(
        &self,
        bead: &BeadId,
        candidate: &GitOid,
    ) -> Result<String, GitError> {
        let reference = format!("refs/loom/verification/{bead}/{candidate}");
        self.create_verification_ref(&reference, candidate).await?;
        Ok(reference)
    }

    /// Recover an interrupted, driver-owned publication rebase without admitting coverage.
    ///
    /// # Errors
    /// Changed source identities, dirty checkouts and unrelated Git history remain preserved.
    pub async fn recover_publication_rebase(&self) -> Result<(), GitError> {
        let journal = self.workdir.join(".git/loom-verification-continuations");
        if !journal.try_exists()? {
            return Ok(());
        }
        let association =
            crate::workspace::Association::resolve(&self.workdir).map_err(std::io::Error::other)?;
        let records = association
            .verification_continuations()
            .map_err(std::io::Error::other)?;
        let integration = self.loom_workspace();
        for record in &records {
            let Some(intent) = &record.publication_rebase else {
                continue;
            };
            if intent.after.is_some() {
                continue;
            }
            association
                .validate_verification(record)
                .map_err(std::io::Error::other)?;
            let pin = format!("refs/loom/verification/{}/{}", record.bead, intent.before);
            if sync_rev_parse(&integration, &pin)? != intent.before {
                return Err(GitError::GitCli {
                    status: 1,
                    stderr: "publication rebase source pin changed".into(),
                });
            }
            // A completed peer event survives interruption between cohort journal appends.
            if let Some(after) = records.iter().find_map(|peer| {
                let witness = peer.publication_rebase.as_ref()?;
                (witness.before == intent.before && witness.onto == intent.onto)
                    .then_some(witness.after.as_ref())
                    .flatten()
                    .map(|after| (peer, after))
            }) {
                association
                    .validate_verification(after.0)
                    .map_err(std::io::Error::other)?;
                let pin = format!("refs/loom/verification/{}/{}", after.0.bead, after.1);
                if sync_rev_parse(&integration, &pin)? != *after.1 {
                    return Err(GitError::GitCli {
                        status: 1,
                        stderr: "publication rebase completion pin changed".into(),
                    });
                }
                if GitClient::open(&integration)?
                    .is_ancestor_of_head(after.1.as_str())
                    .await?
                {
                    self.finish_publication_rebase_record(
                        &association,
                        record.clone(),
                        after.1,
                        &intent.onto,
                    )
                    .await?;
                    continue;
                }
            }
            let rebase = integration.join(".git/rebase-merge");
            if rebase.try_exists()? {
                let before = std::fs::read_to_string(rebase.join("orig-head"))?;
                let onto = std::fs::read_to_string(rebase.join("onto"))?;
                let branch = std::fs::read_to_string(rebase.join("head-name"))?;
                if before.trim() != intent.before.as_str()
                    || onto.trim() != intent.onto.as_str()
                    || branch.trim() != format!("refs/heads/{}", self.integration_branch)
                {
                    return Err(GitError::GitCli {
                        status: 1,
                        stderr: "interrupted rebase belongs to different work; preserved".into(),
                    });
                }
                if !self
                    .status_porcelain_at(&integration)
                    .await?
                    .trim()
                    .is_empty()
                {
                    return Err(GitError::GitCli { status: 1, stderr: "interrupted publication rebase has uncommitted work; retained without abort or reset".into() });
                }
                let partial = sync_head_commit_sha(&integration)?;
                self.create_verification_ref(
                    &format!("refs/loom/recovery/publication-{}-{partial}", intent.before),
                    &partial,
                )
                .await?;
                run_git(
                    &integration,
                    self.clock.as_ref(),
                    ["rebase", "--abort"],
                    None,
                )
                .await?;
            }
            let head = sync_head_commit_sha(&integration)?;
            if head == intent.before || records.iter().any(|known| known.candidate == head) {
                continue;
            }
            if !self
                .status_porcelain_at(&integration)
                .await?
                .trim()
                .is_empty()
            {
                return Err(GitError::GitCli {
                    status: 1,
                    stderr: "publication recovery found dirty integration; preserved".into(),
                });
            }
            let reference = format!("refs/heads/{}", self.integration_branch);
            let previous = sync_rev_parse(&integration, &format!("{reference}@{{1}}"))?;
            let event = run_git_raw(
                &integration,
                self.clock.as_ref(),
                ["reflog", "show", "-1", "--format=%gs", &reference],
                None,
            )
            .await?;
            if !event.status.success() {
                return Err(cli_error(&event));
            }
            let expected = format!("rebase (finish): {reference} onto {}", intent.onto);
            if previous != intent.before
                || String::from_utf8(event.stdout)?.trim() != expected
                || sync_rev_parse(&integration, &reference)? != head
            {
                return Err(GitError::GitCli { status: 1, stderr: "publication recovery cannot attribute changed integration; all history preserved".into() });
            }
            // The reflog attributes only the interrupted Git transaction; fresh gates still own coverage.
            self.create_verification_ref(
                &format!("refs/loom/recovery/publication-{}-{head}", intent.before),
                &head,
            )
            .await?;
            let accepted = run_git_raw(
                &integration,
                self.clock.as_ref(),
                [
                    "merge-base",
                    "--is-ancestor",
                    head.as_str(),
                    &format!("refs/remotes/origin/{}", self.integration_branch),
                ],
                None,
            )
            .await?;
            if accepted.status.success() {
                self.finish_publication_rebase_record(
                    &association,
                    record.clone(),
                    &head,
                    &intent.onto,
                )
                .await?;
            } else if accepted.status.code() == Some(1) {
                self.reset_integration_to(intent.before.as_str()).await?;
            } else {
                return Err(cli_error(&accepted));
            }
        }
        let current = sync_head_commit_sha(&integration)?;
        let pending = association
            .verification_continuations()
            .map_err(std::io::Error::other)?;
        if let Some(intent) = pending
            .iter()
            .filter_map(|record| record.publication_rebase.as_ref())
            .find(|intent| intent.after.is_none() && intent.before == current)
        {
            if !self
                .status_porcelain_at(&integration)
                .await?
                .trim()
                .is_empty()
            {
                return Err(GitError::GitCli {
                    status: 1,
                    stderr: "publication replay has uncommitted work; preserved".into(),
                });
            }
            let output = run_git_index_mut(
                &integration,
                self.clock.as_ref(),
                ["rebase", intent.onto.as_str()],
                None,
            )
            .await?;
            if !output.status.success() {
                return Err(cli_error(&output));
            }
            let after = sync_head_commit_sha(&integration)?;
            for record in &pending {
                if record.publication_rebase.as_ref().is_some_and(|peer| {
                    peer.before == intent.before && peer.onto == intent.onto && peer.after.is_none()
                }) {
                    self.finish_publication_rebase_record(
                        &association,
                        record.clone(),
                        &after,
                        &intent.onto,
                    )
                    .await?;
                }
            }
        }
        Ok(())
    }

    /// Refresh only a protected publication transaction after origin advances again.
    ///
    /// # Errors
    /// Rejects changed source/checkouts/pins; does not admit coverage or reconcile unrelated work.
    pub async fn refresh_pending_publication_rebase(&self) -> Result<bool, GitError> {
        if !self
            .workdir
            .join(".git/loom-verification-continuations")
            .try_exists()?
        {
            return Ok(false);
        }
        let association =
            crate::workspace::Association::resolve(&self.workdir).map_err(std::io::Error::other)?;
        let integration = self.loom_workspace();
        let head = sync_head_commit_sha(&integration)?;
        if head != self.integration_commit_sha().await?
            || !self
                .status_porcelain_at(&integration)
                .await?
                .trim()
                .is_empty()
        {
            return Ok(false);
        }
        for record in association
            .verification_continuations()
            .map_err(std::io::Error::other)?
        {
            if record.candidate != head || record.publication_rebase.is_none() {
                continue;
            }
            association
                .validate_verification(&record)
                .map_err(std::io::Error::other)?;
            let pin = format!(
                "refs/loom/verification/{}/{}",
                record.bead, record.candidate
            );
            if sync_rev_parse(&integration, &pin)? != head {
                return Err(GitError::GitCli {
                    status: 1,
                    stderr: "publication refresh candidate pin changed".into(),
                });
            }
            self.prepare_actual_push_range().await?;
            return Ok(true);
        }
        Ok(false)
    }

    async fn finish_publication_rebase_record(
        &self,
        association: &crate::workspace::Association,
        mut record: crate::workspace::VerificationContinuation,
        after: &GitOid,
        onto: &GitOid,
    ) -> Result<(), GitError> {
        association
            .validate_verification(&record)
            .map_err(std::io::Error::other)?;
        self.preserve_verification_candidate(&record.bead, after)
            .await?;
        record.base = onto.clone();
        record.rollback = Some(onto.clone());
        record.candidate = after.clone();
        if let Some(intent) = &mut record.publication_rebase {
            intent.after = Some(after.clone());
        }
        association
            .append_verification(&record)
            .map_err(std::io::Error::other)?;
        Ok(())
    }

    /// Retain an unpublished integration tip owned by a protected verification continuation.
    ///
    /// This permits restart to reach the ordinary verifier; it admits no coverage and
    /// never reconciles unrelated or remotely diverged local work.
    ///
    /// # Errors
    /// Rejects changed authority, source identities or candidate pins.
    pub async fn has_pending_verification_tip(&self) -> Result<bool, GitError> {
        let association =
            crate::workspace::Association::resolve(&self.workdir).map_err(std::io::Error::other)?;
        let integration = self.loom_workspace();
        if !self
            .status_porcelain_at(&integration)
            .await?
            .trim()
            .is_empty()
        {
            return Ok(false);
        }
        let head = self.integration_commit_sha().await?;
        if sync_head_commit_sha(&integration)? != head {
            return Ok(false);
        }
        let origin = format!("refs/remotes/origin/{}", self.integration_branch);
        if !GitClient::open(&integration)?
            .is_ancestor_of_head(&origin)
            .await?
        {
            return Ok(false);
        }
        for record in association
            .verification_continuations()
            .map_err(std::io::Error::other)?
        {
            if record.candidate != head {
                continue;
            }
            association
                .validate_verification(&record)
                .map_err(std::io::Error::other)?;
            let reference = format!(
                "refs/loom/verification/{}/{}",
                record.bead, record.candidate
            );
            if sync_rev_parse(&integration, &reference)? != head {
                return Err(GitError::GitCli { status: 1, stderr: "pending verification candidate pin changed; source and integration preserved".into() });
            }
            association.recheck().map_err(std::io::Error::other)?;
            return Ok(true);
        }
        Ok(false)
    }

    /// Allocate a fresh driver continuation branch without overwriting interrupted history.
    ///
    /// # Errors
    /// Returns Git errors or bounded allocation exhaustion, preserving existing branches.
    pub async fn restore_verification_branch(
        &self,
        bead: &BeadId,
        candidate: &GitOid,
    ) -> Result<String, GitError> {
        for attempt in 0..1024 {
            let branch = format!("loom/verify-{bead}-{candidate}-{attempt}");
            let reference = format!("refs/heads/{branch}");
            let existing = run_git_raw(
                &self.loom_workspace(),
                self.clock.as_ref(),
                ["rev-parse", "--verify", "--quiet", &reference],
                None,
            )
            .await?;
            if existing.status.success() {
                continue;
            }
            let created = run_git_raw(
                &self.loom_workspace(),
                self.clock.as_ref(),
                [
                    "update-ref",
                    "--no-deref",
                    &reference,
                    candidate.as_str(),
                    "",
                ],
                None,
            )
            .await?;
            if created.status.success() {
                return Ok(branch);
            }
            let collision = run_git_raw(
                &self.loom_workspace(),
                self.clock.as_ref(),
                ["rev-parse", "--verify", "--quiet", &reference],
                None,
            )
            .await?;
            if !collision.status.success() {
                return Err(cli_error(&created));
            }
        }
        Err(GitError::GitCli {
            status: 1,
            stderr: "verification recovery branch budget exhausted; all prior branches retained"
                .into(),
        })
    }

    async fn create_verification_ref(
        &self,
        reference: &str,
        candidate: &GitOid,
    ) -> Result<(), GitError> {
        let workdir = self.loom_workspace();
        let previous = run_git_raw(
            &workdir,
            self.clock.as_ref(),
            ["rev-parse", "--verify", "--quiet", reference],
            None,
        )
        .await?;
        if previous.status.success() {
            if String::from_utf8_lossy(&previous.stdout).trim() == candidate.as_str() {
                return Ok(());
            }
            return Err(GitError::GitCli {
                status: 1,
                stderr: format!(
                    "preserved verification reference changed: {reference}; existing history retained"
                ),
            });
        }
        let output = run_git_raw(
            &workdir,
            self.clock.as_ref(),
            [
                "update-ref",
                "--no-deref",
                reference,
                candidate.as_str(),
                "",
            ],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        Ok(())
    }

    /// Commit SHA the integration branch currently points at, read in the
    /// loom workspace (`git rev-parse <integration-branch>`). Used to tell
    /// whether a bead's ff-merge actually advanced the integration line so
    /// the per-bead audit rollback fires only when there is a bead commit
    /// to unwind (`specs/harness.md` § Verdict Gate).
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn integration_commit_sha(&self) -> Result<GitOid, GitError> {
        let output = run_git_raw(
            &self.loom_workspace(),
            self.clock.as_ref(),
            ["rev-parse", self.integration_branch.as_str()],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        let raw = String::from_utf8(output.stdout)?;
        Ok(GitOid::new(raw.trim())?)
    }

    /// Keep a reversible verifier rollback from removing already published integration history.
    ///
    /// # Errors
    /// Returns unavailable/invalid Git history without changing the checkout.
    pub async fn bounded_verification_rollback(
        &self,
        proposed: &GitOid,
    ) -> Result<GitOid, GitError> {
        let integration = self.loom_workspace();
        let remote = format!("refs/remotes/origin/{}", self.integration_branch);
        let origin = sync_rev_parse(&integration, &remote)?;
        if !GitClient::open(&integration)?
            .is_ancestor_of_head(origin.as_str())
            .await?
        {
            return Ok(proposed.clone());
        }
        let result = run_git_raw(
            &integration,
            self.clock.as_ref(),
            [
                "merge-base",
                "--is-ancestor",
                proposed.as_str(),
                origin.as_str(),
            ],
            None,
        )
        .await?;
        if result.status.success() {
            Ok(origin)
        } else if result.status.code() == Some(1) {
            Ok(proposed.clone())
        } else {
            Err(cli_error(&result))
        }
    }

    /// Reset the integration branch to an exact commit in the loom workspace.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn reset_integration_to(&self, rev: &str) -> Result<(), GitError> {
        self.checkout_integration().await?;
        let output = run_git_index_mut(
            &self.loom_workspace(),
            self.clock.as_ref(),
            ["reset", "--hard", rev],
            None,
        )
        .await?;
        if output.status.success() {
            return Ok(());
        }
        Err(cli_error(&output))
    }

    /// Roll the integration branch back one commit (`git reset --hard
    /// HEAD~1`) in the loom workspace.
    ///
    /// The per-bead audit (`loom gate verify --diff`) runs after the
    /// ff-merge but before any origin push; an audit failure undoes the
    /// just-merged commit so the integration line returns to its
    /// pre-merge tip and the next iteration sees the cross-bead breakage
    /// (`specs/harness.md` § Verdict Gate — `post-integrate-fail`). Takes
    /// the loom workspace's `index.lock`; a cross-spec peer holding it
    /// loses the race to a retryable [`GitError::IndexLocked`].
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn rollback_integration(&self) -> Result<(), GitError> {
        let output = run_git_index_mut(
            &self.loom_workspace(),
            self.clock.as_ref(),
            ["reset", "--hard", "HEAD~1"],
            None,
        )
        .await?;
        if output.status.success() {
            return Ok(());
        }
        Err(cli_error(&output))
    }

    /// Check out the configured integration branch in the loom workspace.
    ///
    /// A successful [`Self::rebase_onto_integration`] leaves the workspace
    /// on the rewritten bead branch; the pass-2 signature-failure cleanup
    /// uses this to return to the integration branch before deleting that
    /// transient branch (git refuses to delete the checked-out branch) so a
    /// driver-side rejection leaves the integration line as the checked-out
    /// state with the transient ref gone. When the workspace is already on
    /// the integration branch (the pass-1 path) it is a no-op.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn checkout_integration(&self) -> Result<(), GitError> {
        let workdir = self.loom_workspace();
        let integration_branch = self.integration_branch.as_str();
        let checkout = run_git_index_mut(
            &workdir,
            self.clock.as_ref(),
            ["checkout", "-q", integration_branch],
            None,
        )
        .await?;
        if checkout.status.success() {
            return Ok(());
        }
        Err(cli_error(&checkout))
    }

    /// Unmerged paths in `workdir` (`git diff --name-only
    /// --diff-filter=U`). Used while a rebase is paused mid-conflict to
    /// tell a genuine conflict from a rerere-staged resolution. A clean
    /// index yields an empty list; a failed `git diff` surfaces as
    /// [`GitError`] rather than collapsing to an empty list, which the
    /// caller would otherwise mistake for a no-conflict result (RS-11).
    async fn unmerged_paths(&self, workdir: &Path) -> Result<Vec<PathBuf>, GitError> {
        let output = run_git_raw(
            workdir,
            self.clock.as_ref(),
            ["diff", "--name-only", "--diff-filter=U"],
            None,
        )
        .await?;
        if !output.status.success() {
            return Err(cli_error(&output));
        }
        Ok(String::from_utf8_lossy(&output.stdout)
            .lines()
            .map(|l| PathBuf::from(l.trim()))
            .filter(|p| !p.as_os_str().is_empty())
            .collect())
    }

    /// Path to the allowed-signers file used by per-bead integration.
    /// Repository mode uses Wrix's context-stable policy file; legacy
    /// non-loop clients retain the former Loom path.
    fn allowed_signers_path(&self) -> PathBuf {
        let workspace = self.loom_workspace();
        self.repo_git_policy
            .as_ref()
            .and_then(|policy| policy.allowed_signers_path(&workspace))
            .unwrap_or_else(|| workspace.join(".git/loom-allowed-signers"))
    }

    /// Whether driver-side signature verification is active. Default loop
    /// startup requires repository keys and Wrix creates this file; an absent
    /// file is permitted only for legacy callers or explicit host-key mode.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn signing_verification_enabled(&self) -> Result<bool, GitError> {
        // Propagate anomalous IO failures rather than silently disabling a
        // repository-mode security control.
        let path = self.allowed_signers_path();
        let exists = tokio::fs::try_exists(&path).await?;
        let repository_mode = self
            .repo_git_policy
            .as_ref()
            .and_then(|policy| policy.allowed_signers_path(&self.loom_workspace()))
            .is_some();
        if repository_mode && !exists {
            return Err(GitError::WrixPolicyInvalid {
                workdir: self.loom_workspace(),
                detail: format!(
                    "required allowed-signers file disappeared: {}",
                    path.display()
                ),
            });
        }
        Ok(exists)
    }

    /// Verify every commit in `range` (e.g. `main..loom/<id>`) against the
    /// loom workspace's `allowed_signers` file with `git verify-commit`.
    ///
    /// Returns [`SignatureCheck::Skipped`] only when verification is disabled
    /// by a legacy caller or explicit host-key mode. When enabled, walks the
    /// commits oldest-first and returns [`SignatureCheck::Failed`] on the first commit
    /// `git verify-commit` rejects, carrying the offending sha + stderr so
    /// the caller can route to `signature-verification-failed`.
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn verify_commit_range(&self, range: &str) -> Result<SignatureCheck, GitError> {
        if !self.signing_verification_enabled().await? {
            return Ok(SignatureCheck::Skipped);
        }
        let workdir = self.loom_workspace();
        let listed = run_git_raw(
            &workdir,
            self.clock.as_ref(),
            ["rev-list", "--reverse", range],
            None,
        )
        .await?;
        if !listed.status.success() {
            return Err(cli_error(&listed));
        }
        let shas: Vec<String> = String::from_utf8_lossy(&listed.stdout)
            .lines()
            .map(|s| s.trim().to_owned())
            .filter(|s| !s.is_empty())
            .collect();
        for sha in &shas {
            let out =
                run_git_raw(&workdir, self.clock.as_ref(), ["verify-commit", sha], None).await?;
            if !out.status.success() {
                return Ok(SignatureCheck::Failed {
                    commit: sha.clone(),
                    detail: String::from_utf8_lossy(&out.stderr).trim().to_string(),
                });
            }
        }
        Ok(SignatureCheck::Verified)
    }

    /// Authenticate the pinned operator factory in the repository that owns its object.
    ///
    /// # Errors
    /// Missing verification authority and Git execution errors remain fail-closed.
    pub(crate) async fn verify_operator_commit(
        &self,
        commit: &GitOid,
    ) -> Result<SignatureCheck, GitError> {
        if !self.signing_verification_enabled().await? {
            return Ok(SignatureCheck::Skipped);
        }
        let allowed_signers = format!(
            "gpg.ssh.allowedSignersFile={}",
            self.allowed_signers_path().display()
        );
        let output = run_git_raw(
            &self.workdir,
            self.clock.as_ref(),
            ["-c", &allowed_signers, "verify-commit", commit.as_str()],
            None,
        )
        .await?;
        if output.status.success() {
            Ok(SignatureCheck::Verified)
        } else {
            Ok(SignatureCheck::Failed {
                commit: commit.to_string(),
                detail: String::from_utf8_lossy(&output.stderr).trim().to_owned(),
            })
        }
    }

    /// Fast-forward the loom workspace's integration branch to
    /// `origin/<integration-branch>` before any bead clone is
    /// materialized, so every `loom/<id>` branch forks from published
    /// `HEAD` rather than a stale local base.
    ///
    /// Delegates to [`fast_forward_loom_workspace_to_origin`] inside
    /// `spawn_blocking`. A diverged integration line (local commits not on
    /// origin) surfaces as [`GitError::IntegrationDiverged`] so the caller
    /// fails loud instead of branching off a split-brained base (per
    /// `specs/harness.md` § Bead dispatch).
    ///
    /// # Errors
    ///
    /// Returns an error when repository inspection, Git execution, or output decoding fails.
    pub async fn fast_forward_integration_to_origin(&self) -> Result<FastForwardOutcome, GitError> {
        let loom_workspace = self.loom_workspace();
        let branch = self.integration_branch.clone();
        spawn_blocking(move || fast_forward_loom_workspace_to_origin(&loom_workspace, &branch))
            .await?
    }
}

/// Outcome of [`GitClient::fast_forward_integration_to_origin`] /
/// [`fast_forward_loom_workspace_to_origin`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum FastForwardOutcome {
    /// The loom workspace's integration branch already matched
    /// `origin/<branch>` — no ref moved.
    AlreadyUpToDate,
    /// The integration branch was fast-forwarded to `origin/<branch>`,
    /// advancing by `advanced` published commits.
    FastForwarded { advanced: u32 },
    /// No fast-forward was attempted: the loom workspace is absent or
    /// `origin/<branch>` does not resolve (fresh fixture, unpublished
    /// branch). The caller proceeds without reconciliation.
    Skipped,
}

/// Fast-forward the loom workspace's local `branch` to `origin/<branch>`
/// so bead clones always fork from published `HEAD`.
///
/// Fetches `origin <branch>`, then compares the local branch to
/// `origin/<branch>`: already equal → [`FastForwardOutcome::AlreadyUpToDate`];
/// origin strictly ahead → `git merge --ff-only` →
/// [`FastForwardOutcome::FastForwarded`]; local carries commits not on origin
/// (diverged) → [`GitError::IntegrationDiverged`] naming the divergent
/// commits. Returns [`FastForwardOutcome::Skipped`] when `loom_workspace`
/// does not exist or `origin/<branch>` does not resolve.
///
/// Synchronous: invoked directly from `loom init` and, via `spawn_blocking`,
/// from `loom loop` startup ([`GitClient::fast_forward_integration_to_origin`]).
///
/// # Errors
///
/// Returns an error when repository inspection, Git execution, or output decoding fails.
pub fn fast_forward_loom_workspace_to_origin(
    loom_workspace: &Path,
    branch: &str,
) -> Result<FastForwardOutcome, GitError> {
    if !loom_workspace.exists() {
        return Ok(FastForwardOutcome::Skipped);
    }
    let fetch = sync_git_raw(loom_workspace, &["fetch", "--quiet", "origin", branch])?;
    if !fetch.status.success() {
        return Err(cli_error(&fetch));
    }
    let remote_ref = format!("origin/{branch}");
    let resolve = sync_git_raw(
        loom_workspace,
        &[
            "rev-parse",
            "--verify",
            "--quiet",
            &format!("{remote_ref}^{{commit}}"),
        ],
    )?;
    if !resolve.status.success() {
        return Ok(FastForwardOutcome::Skipped);
    }
    let ahead = sync_rev_count(loom_workspace, &format!("{remote_ref}..{branch}"))?;
    if ahead > 0 {
        let commits = sync_git_capture(
            loom_workspace,
            &["rev-list", "--oneline", &format!("{remote_ref}..{branch}")],
        )?;
        return Err(GitError::IntegrationDiverged {
            branch: branch.to_string(),
            commits: commits.trim().to_string(),
        });
    }
    let behind = sync_rev_count(loom_workspace, &format!("{branch}..{remote_ref}"))?;
    if behind == 0 {
        return Ok(FastForwardOutcome::AlreadyUpToDate);
    }
    let merged = sync_git_raw(loom_workspace, &["merge", "--ff-only", &remote_ref])?;
    if !merged.status.success() {
        return Err(cli_error(&merged));
    }
    Ok(FastForwardOutcome::FastForwarded { advanced: behind })
}

/// Synchronous `git -C <workspace> <args>` returning the raw `Output`
/// (status preserved for skip / divergence classification). Spawn failures
/// surface as [`GitError::Spawn`]; non-zero exits are the caller's to
/// interpret.
fn sync_git_raw(workspace: &Path, args: &[&str]) -> Result<std::process::Output, GitError> {
    super::environment::std_git_command()
        .arg("-C")
        .arg(workspace)
        .args(args)
        .output()
        .map_err(GitError::Spawn)
}

fn tracked_files_from_output(output: std::process::Output) -> Result<Vec<PathBuf>, GitError> {
    if !output.status.success() {
        return Err(cli_error(&output));
    }
    let stdout = String::from_utf8(output.stdout)?;
    Ok(stdout
        .lines()
        .filter(|line| !line.is_empty())
        .map(PathBuf::from)
        .collect())
}

/// Synchronous `git -C <workspace> rev-list --count <range>` parsed to a
/// commit count. Used by [`fast_forward_loom_workspace_to_origin`] to
/// classify the local-vs-origin relationship.
fn sync_rev_count(workspace: &Path, range: &str) -> Result<u32, GitError> {
    let raw = sync_git_capture(workspace, &["rev-list", "--count", range])?;
    raw.trim()
        .parse()
        .map_err(|e: std::num::ParseIntError| GitError::GitCli {
            status: 0,
            stderr: format!("rev-list --count {range} returned non-integer `{raw}`: {e}"),
        })
}

/// Outcome of [`GitClient::verify_commit_range`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SignatureCheck {
    /// No allowed-signers file is active (legacy or explicit host-key mode).
    Skipped,
    /// Every commit in range carried a signature trusted by the loom
    /// workspace's `allowed_signers` file.
    Verified,
    /// `git verify-commit` rejected `commit`; `detail` is its stderr.
    Failed { commit: String, detail: String },
}

/// Initialize a real git repository at `path` with one `initial` commit
/// and a bare `origin` remote alongside it. The bare `origin` lives at a
/// sibling `<path>.git`; production `loom loop` pushes the integration
/// branch to `origin` after every successful per-bead merge, so tests
/// that exercise the merge-back path need a real push destination or the
/// post-merge push gate would fail.
///
/// Does **not** materialize the loom-owned
/// `.loom/integration/` workspace — `loom init` tests depend on
/// observing a clean state, and use [`run_loom_init`-equivalent] paths
/// to create it. Tests that need a ready-to-use loom workspace (most of
/// the driver / workflow integration suite) call
/// [`init_test_repo_with_integration`].
///
/// Exposed for cross-crate test consumption — production callers operate
/// on the caller-supplied workspace and never need to bootstrap one. The
/// function is the only sanctioned way for tests outside
/// `loom-driver/src/git/` to stand up a git repo: the workspace-level
/// `git_client_encapsulation` style lint rejects bare
/// `Command::new("git")` calls in tests under `crates/*/src/`.
///
/// Returns an opened [`GitClient`] rooted at `path`.
#[doc(hidden)]
pub fn init_test_repo(path: &Path) -> Result<GitClient, GitError> {
    init_bare_test_repo(path, DEFAULT_INTEGRATION_BRANCH)
}

/// Same as [`init_test_repo`] but additionally clones the loom-owned
/// integration workspace at `<path>/.loom/integration/` from the
/// bare origin so [`GitClient::create_worktree`],
/// [`GitClient::merge_branch`], [`GitClient::push`], and
/// [`GitClient::delete_branch`] all have their loom-workspace cwd ready.
#[doc(hidden)]
pub fn init_test_repo_with_integration(path: &Path) -> Result<GitClient, GitError> {
    init_test_repo_with_integration_branch(path, DEFAULT_INTEGRATION_BRANCH)
}

/// Like [`init_test_repo_with_integration`] but takes an explicit
/// integration-branch name — used by tests that exercise
/// `[loom] integration_branch = "<name>"` end-to-end without a
/// hard-coded `main`.
#[doc(hidden)]
pub fn init_test_repo_with_integration_branch(
    path: &Path,
    branch: &str,
) -> Result<GitClient, GitError> {
    init_bare_test_repo(path, branch)?;
    let origin_path = bare_origin_path(path);
    let origin_url = origin_path.to_string_lossy().into_owned();
    let loom_workspace = path.join(LOOM_WORKSPACE_REL);
    if let Some(parent) = loom_workspace.parent() {
        std::fs::create_dir_all(parent)?;
    }
    clone_loom_workspace(&origin_url, &loom_workspace, branch)?;
    run_test_git(
        &loom_workspace,
        &["config", "user.email", "test@example.com"],
    )?;
    run_test_git(&loom_workspace, &["config", "user.name", "Test"])?;
    run_test_git(&loom_workspace, &["config", "commit.gpgsign", "false"])?;
    let hooks = ensure_test_prek_hooks(path)?;
    super::hooks::write_hooks_config(&loom_workspace, &hooks)?;
    crate::workspace::Association::establish_with_state_home(path, &origin_path.join("loom-state"))
        .map_err(std::io::Error::other)?;
    GitClient::open_with_integration_branch(path, branch.to_string())
}

fn ensure_test_prek_hooks(path: &Path) -> Result<PathBuf, GitError> {
    use std::os::unix::fs::PermissionsExt;
    let hooks = path.join(".loom/test-prek-hooks");
    std::fs::create_dir_all(&hooks)?;
    for hook in ["pre-commit", "pre-push"] {
        let script = hooks.join(hook);
        std::fs::write(&script, "#!/bin/sh\nexit 0\n")?;
        std::fs::set_permissions(&script, std::fs::Permissions::from_mode(0o755))?;
    }
    Ok(hooks)
}

const TEST_PRE_COMMIT_CONFIG: &str = r"repos:
  - repo: local
    hooks:
      - id: pre-push
        name: Fixture pre-push
        language: system
        entry: bin/pre-push-checks --hook-id pre-push --hook-entry 'true' -- true
        stages: [pre-push]
";

fn init_bare_test_repo(path: &Path, branch: &str) -> Result<GitClient, GitError> {
    std::fs::create_dir_all(path)?;
    run_test_git(path, &["init", "-q", "-b", branch])?;
    run_test_git(path, &["config", "user.email", "test@example.com"])?;
    run_test_git(path, &["config", "user.name", "Test"])?;
    run_test_git(path, &["config", "commit.gpgsign", "false"])?;
    std::fs::write(path.join("README.md"), "initial\n")?;
    // Mirror the production `.gitignore` so the loom workspace at
    // `.loom/integration/` does not show as untracked in the
    // operator workspace's `git status`.
    std::fs::write(path.join(".gitignore"), ".loom/\n.wrix/\ntarget/\n")?;
    std::fs::write(path.join(".pre-commit-config.yaml"), TEST_PRE_COMMIT_CONFIG)?;
    run_test_git(
        path,
        &["add", "README.md", ".gitignore", ".pre-commit-config.yaml"],
    )?;
    run_test_git(path, &["commit", "-q", "-m", "initial"])?;
    let origin_path = bare_origin_path(path);
    if let Some(parent) = origin_path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    std::fs::create_dir_all(&origin_path)?;
    run_test_git(&origin_path, &["init", "-q", "--bare", "-b", branch])?;
    let origin_url = origin_path.to_string_lossy().into_owned();
    run_test_git(path, &["remote", "add", "origin", &origin_url])?;
    run_test_git(path, &["push", "-q", "-u", "origin", branch])?;
    GitClient::open(path)
}

/// Commit and synchronize an explicit disposable fixture baseline before workers start.
///
/// # Errors
/// Returns Git setup failures without bypassing dirty-tree checks.
#[doc(hidden)]
pub fn seed_test_baseline(path: &Path, paths: &[&str]) -> Result<(), GitError> {
    let mut add = vec!["add", "--"];
    add.extend_from_slice(paths);
    run_test_git(path, &add)?;
    run_test_git(
        path,
        &[
            "-c",
            "commit.gpgsign=false",
            "commit",
            "-qm",
            "Bind fixture workflow acceptance",
        ],
    )?;
    run_test_git(path, &["push", "-q", "origin", "HEAD"])?;
    run_test_git(&path.join(LOOM_WORKSPACE_REL), &["pull", "-q", "--ff-only"])?;
    Ok(())
}

/// Stage all changes in `workspace` and commit them with `msg`. Test
/// support for exercising the loom-workspace integration line (e.g. the
/// `post-integrate-fail` rollback) without callers outside this module
/// shelling `git`, which the git-client-encapsulation gate forbids.
#[doc(hidden)]
pub fn commit_all_in(workspace: &Path, msg: &str) -> Result<(), GitError> {
    run_test_git(workspace, &["add", "-A"])?;
    run_test_git(
        workspace,
        &["-c", "commit.gpgsign=false", "commit", "-q", "-m", msg],
    )
}

fn run_test_git(dir: &Path, args: &[&str]) -> Result<(), GitError> {
    let status = super::environment::std_git_command()
        .arg("-C")
        .arg(dir)
        .args(args)
        .status()
        .map_err(GitError::Spawn)?;
    if status.success() {
        return Ok(());
    }
    Err(GitError::GitCli {
        status: status.code().unwrap_or(-1),
        stderr: format!("git {args:?} exited {status}"),
    })
}

/// Read the URL of the `origin` remote at `workdir` using
/// `git config --get remote.origin.url`. Returns `Ok(None)` when `workdir`
/// is not a git repository (exit 128) or has no `origin` remote (exit 1).
///
/// Synchronous — used by `loom init`, which is a one-shot workspace
/// bootstrap and not driven by tokio.
///
/// # Errors
///
/// Returns an error when repository inspection, Git execution, or output decoding fails.
pub fn read_origin_url(workdir: &Path) -> Result<Option<String>, GitError> {
    let output = super::environment::std_git_command()
        .arg("-C")
        .arg(workdir)
        .args(["config", "--get", "remote.origin.url"])
        .output()
        .map_err(GitError::Spawn)?;
    if output.status.success() {
        let url = String::from_utf8(output.stdout)?.trim().to_string();
        return Ok((!url.is_empty()).then_some(url));
    }
    if matches!(output.status.code(), Some(1 | 128)) {
        return Ok(None);
    }
    Err(GitError::GitCli {
        status: output.status.code().unwrap_or(-1),
        stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
    })
}

/// Clone the integration workspace for `loom init`.
///
/// Runs `git clone --branch <branch> <origin_url> <dest>`. The caller
/// guarantees `dest` does not exist; the parent directory is created if missing.
///
/// Synchronous: `loom init` is not async, and the spec marks the operation
/// as one-shot + infrequent (see § Git operations table).
///
/// # Errors
///
/// Returns an error when repository inspection, Git execution, or output decoding fails.
pub fn clone_loom_workspace(origin_url: &str, dest: &Path, branch: &str) -> Result<(), GitError> {
    let parent = dest.parent().ok_or_else(|| GitError::GitCli {
        status: -1,
        stderr: format!(
            "clone destination {} has no parent directory",
            dest.display()
        ),
    })?;
    std::fs::create_dir_all(parent)?;
    let output = super::environment::std_git_command()
        .arg("-C")
        .arg(parent)
        .args(["clone", "--quiet", "--branch", branch])
        .arg(origin_url)
        .arg(dest)
        .output()
        .map_err(GitError::Spawn)?;
    if output.status.success() {
        return Ok(());
    }
    Err(GitError::GitCli {
        status: output.status.code().unwrap_or(-1),
        stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
    })
}

/// Resolve the current tree OID synchronously.
///
/// Used by `loom gate verify-marker`, which is a one-shot CLI helper that
/// does not justify the cost of standing up a tokio runtime for two
/// git invocations.
///
/// # Errors
///
/// Returns an error when repository inspection, Git execution, or output decoding fails.
pub fn head_tree_oid_sync(workspace: &Path) -> Result<GitOid, GitError> {
    let raw = sync_git_capture(workspace, &["rev-parse", "HEAD^{tree}"])?;
    Ok(GitOid::new(raw.trim())?)
}

/// Synchronous `git -C <workspace> rev-parse HEAD`. The informational
/// commit SHA stamped onto a freshly minted gate marker proof
/// (the load-bearing fingerprint is the tree OID, not the commit SHA).
///
/// # Errors
///
/// Returns an error when repository inspection, Git execution, or output decoding fails.
pub fn sync_head_commit_sha(workspace: &Path) -> Result<GitOid, GitError> {
    sync_rev_parse(workspace, "HEAD")
}

/// Synchronous `git -C <workspace> rev-parse --verify <rev>`.
///
/// # Errors
///
/// Returns an error when repository inspection, Git execution, or output decoding fails.
pub fn sync_rev_parse(workspace: &Path, rev: &str) -> Result<GitOid, GitError> {
    let raw = sync_git_capture(workspace, &["rev-parse", "--verify", rev])?;
    Ok(GitOid::new(raw.trim())?)
}

/// Synchronous `git -C <workspace> status --porcelain`. Paired with
/// [`head_tree_oid_sync`] for the marker fingerprint check.
///
/// # Errors
///
/// Returns an error when repository inspection, Git execution, or output decoding fails.
pub fn status_porcelain_sync(workspace: &Path) -> Result<String, GitError> {
    sync_git_capture(workspace, &["status", "--porcelain"])
}

fn sync_git_capture(workspace: &Path, args: &[&str]) -> Result<String, GitError> {
    let output = super::environment::std_git_command()
        .arg("-C")
        .arg(workspace)
        .args(args)
        .output()
        .map_err(GitError::Spawn)?;
    if !output.status.success() {
        return Err(GitError::GitCli {
            status: output.status.code().unwrap_or(-1),
            stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
        });
    }
    Ok(String::from_utf8(output.stdout)?)
}

/// Bare origin path used by [`init_test_repo`]. Exposed so tests that need
/// to inspect the published refs (e.g. assert that `main` advanced after a
/// per-bead push) can locate the bare repo without re-deriving the
/// suffix.
#[doc(hidden)]
pub fn bare_origin_path(workspace: &Path) -> PathBuf {
    let parent = workspace.parent().unwrap_or(workspace);
    let name = workspace.file_name().map_or_else(
        || "workspace".to_string(),
        |n| n.to_string_lossy().into_owned(),
    );
    parent.join(format!("{name}.git"))
}

/// Result of [`GitClient::create_worktree`].
#[derive(Debug, Clone)]
pub struct CreatedWorktree {
    pub path: PathBuf,
    pub branch: String,
}

/// Result of [`GitClient::prepare_bead_clone`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BeadClonePreparation {
    pub status_before: String,
    pub recovery: Option<BeadCloneRecovery>,
    pub integration_tip: GitOid,
    pub alignment: BeadCloneAlignment,
}

/// Dirty workspace state preserved before bead dispatch cleanup.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct BeadCloneRecovery {
    pub pre_stash_status: String,
    pub stash: WorkspaceRecoveryStash,
}

/// Git stash identity captured at bead-dispatch time.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct WorkspaceRecoveryStash {
    pub selector: String,
    pub commit: GitOid,
    pub message: String,
}

/// Committed bead-work alignment after dirty workspace preservation.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BeadCloneAlignment {
    Clean,
    Rebased {
        previous_head: GitOid,
        current_head: GitOid,
    },
    Conflict {
        files: Vec<PathBuf>,
    },
}

/// Linked worktree as reported by `gix`.
#[derive(Debug, Clone)]
pub struct WorktreeInfo {
    pub path: PathBuf,
    pub branch: Option<String>,
}

/// Working tree status entry.
#[derive(Debug, Clone)]
pub struct StatusEntry {
    pub path: String,
    pub kind: StatusKind,
}

impl StatusEntry {
    fn from_item(item: &gix::status::Item) -> Self {
        let path = item.location().to_string();
        let kind = match item {
            gix::status::Item::IndexWorktree(_) => StatusKind::WorktreeChange,
            gix::status::Item::TreeIndex(_) => StatusKind::IndexChange,
        };
        Self { path, kind }
    }
}

/// Kind of change reported by [`StatusEntry`]. Coarse on purpose — callers
/// that need richer detail (rename detection, etc.) should grow this enum.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum StatusKind {
    IndexChange,
    WorktreeChange,
}

/// Outcome of [`GitClient::rebase_onto_integration`].
///
/// Represents the rebase half of the per-bead integration step, split from the fast-forward
/// ([`GitClient::ff_merge_integration`]) so the verdict gate can verify
/// the rewritten commits in between.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum RebaseOutcome {
    /// `branch` was rebased onto the integration tip (replaying any
    /// rerere-recorded resolution). The workspace is checked out on the
    /// rewritten `branch`; the integration branch has not moved.
    Rebased,
    /// `git rebase` left unmerged paths rerere had no recorded resolution
    /// for. The rebase was aborted and the integration branch restored.
    /// `detail`/`files`/`new_base_sha` carry the same recovery payload as
    /// [`MergeResult::Conflict`].
    Conflict {
        detail: String,
        files: Vec<PathBuf>,
        new_base_sha: GitOid,
    },
}

/// Outcome of [`GitClient::merge_branch`].
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum MergeResult {
    Ok,
    /// `git rebase` exited non-zero. `detail` carries the rebase's
    /// stderr (newline-preserved, trailing whitespace trimmed) so the
    /// caller can distinguish a real content conflict from a
    /// "cannot rebase: You have unstaged changes" refusal — both used
    /// to map to the same opaque `Conflict` and the actual cause was
    /// lost at the warn! line. Empty string is allowed but unusual.
    ///
    /// `files` is the unmerged-path set captured (`git diff
    /// --name-only --diff-filter=U`) before the `git rebase --abort`,
    /// and `new_base_sha` is the integration-branch tip the rebase was
    /// targeting. Both ride out to the verdict gate's
    /// `integration-conflict` recovery so the agent's single retry can
    /// rebase its bead-workspace branch onto the new tip and resolve
    /// the named files (per `specs/harness.md` § Verdict Gate). For a
    /// non-conflict rebase refusal (e.g. unstaged changes) `files` is
    /// empty.
    Conflict {
        detail: String,
        files: Vec<PathBuf>,
        new_base_sha: GitOid,
    },
}

fn status_short_branch_is_dirty(status: &str) -> bool {
    status
        .lines()
        .any(|line| !line.trim().is_empty() && !line.starts_with("## "))
}

/// Run `git` with an explicit `-C <workdir>`, no shell, 60s ceiling. Returns
/// `Ok(())` only on a clean exit.
async fn run_git<I, S>(
    workdir: &Path,
    clock: &dyn Clock,
    args: I,
    trailing: Option<&OsString>,
) -> Result<(), GitError>
where
    I: IntoIterator<Item = S>,
    S: AsRef<std::ffi::OsStr>,
{
    run_git_with_timeout(workdir, clock, GIT_TIMEOUT, args, trailing).await
}

async fn run_git_with_timeout<I, S>(
    workdir: &Path,
    clock: &dyn Clock,
    timeout: Duration,
    args: I,
    trailing: Option<&OsString>,
) -> Result<(), GitError>
where
    I: IntoIterator<Item = S>,
    S: AsRef<std::ffi::OsStr>,
{
    let output = run_git_raw_with_timeout(workdir, clock, timeout, args, trailing).await?;
    if output.status.success() {
        return Ok(());
    }
    Err(cli_error(&output))
}

/// Construct `GitError::GitCli` from a `git` invocation's `Output`,
/// preserving natural newlines in stderr (and folding in stdout, under a
/// `[stdout]` heading, when it carries content too). `git push` failures
/// in particular emit multiple lines (`error:` + `hint:` + `! [rejected]`)
/// AND the rejecting pre-push hook (e.g. `nix flake check`) typically
/// writes its failure diagnostic to stdout while git itself only emits a
/// terse "failed to push some refs" on stderr — without the stdout fold,
/// hook-driven push failures bottom out at the one-line git wrapper and
/// the actual cause is lost. Trailing whitespace is stripped per-line;
/// fully-empty leading/trailing lines are dropped.
/// Classify a failed git invocation as loom-workspace lock contention.
/// When a concurrent process holds `index.lock`, git refuses to start the
/// index-mutating command and writes `fatal: Unable to create
/// '<path>/index.lock': File exists.` plus an "Another git process seems to
/// be running" hint to `stderr`, having mutated nothing. The
/// [`run_git_index_mut`] retry loop keys off this signature to distinguish
/// recoverable contention (retry) from a content failure or rebase conflict
/// (surface), matching on the `index.lock` lock-file name the spec names as
/// the serialization point rather than the variable cleanup output.
fn is_index_locked(output: &std::process::Output) -> bool {
    if output.status.success() {
        return false;
    }
    let stderr = String::from_utf8_lossy(&output.stderr);
    stderr.contains("index.lock")
        && (stderr.contains("File exists")
            || stderr.contains("Another git process seems to be running"))
}

/// Run an index-mutating git invocation in the loom workspace, retrying on
/// git lock-file contention ([`is_index_locked`]). Two `loom loop`
/// invocations on different specs share the loom workspace and collide on
/// its `index.lock` during the rebase + ff critical section; the command
/// that loses the race mutated nothing, so re-running it is safe and picks
/// up the winner's now-current integration tip (specs/harness.md §
/// Concurrency). Bounded by [`INDEX_LOCK_RETRIES`] with an
/// [`INDEX_LOCK_BACKOFF`] pause between attempts (clock-driven so paused-time
/// tests stay deterministic); exhaustion surfaces [`GitError::IndexLocked`]
/// rather than the raw CLI error so the caller can tell stale-lock
/// contention from a content failure. The returned `Output` is the first
/// attempt that was *not* lock-contended — its status may still be a
/// non-zero conflict the caller inspects.
async fn run_git_index_mut<I, S>(
    workdir: &Path,
    clock: &dyn Clock,
    args: I,
    trailing: Option<&OsString>,
) -> Result<std::process::Output, GitError>
where
    I: IntoIterator<Item = S> + Clone,
    S: AsRef<std::ffi::OsStr>,
{
    for _ in 0..INDEX_LOCK_RETRIES {
        let output = run_git_raw(workdir, clock, args.clone(), trailing).await?;
        if !is_index_locked(&output) {
            return Ok(output);
        }
        clock.sleep(INDEX_LOCK_BACKOFF).await;
    }
    Err(GitError::IndexLocked {
        workdir: workdir.to_path_buf(),
    })
}

fn is_retryable_push_transport_failure(output: &std::process::Output) -> bool {
    if output.status.success() {
        return false;
    }
    exit_status_is_sigpipe(output.status) || push_transport_disconnect(output)
}

fn exit_status_is_sigpipe(status: ExitStatus) -> bool {
    exit_status_signal(status) == Some(SIGPIPE_SIGNAL)
}

#[cfg(unix)]
fn exit_status_signal(status: ExitStatus) -> Option<i32> {
    use std::os::unix::process::ExitStatusExt;

    status.signal()
}

#[cfg(not(unix))]
fn exit_status_signal(_status: ExitStatus) -> Option<i32> {
    None
}

fn push_transport_disconnect(output: &std::process::Output) -> bool {
    let detail = format!(
        "{}\n{}",
        String::from_utf8_lossy(&output.stderr),
        String::from_utf8_lossy(&output.stdout),
    )
    .to_ascii_lowercase();
    detail.contains("closed by remote host")
        || detail.contains("remote end hung up unexpectedly")
        || detail.contains("unexpected disconnect")
        || detail.contains("broken pipe")
}

fn cli_error(output: &std::process::Output) -> GitError {
    fn trim_lines(buf: &[u8]) -> String {
        let s: String = String::from_utf8_lossy(buf)
            .lines()
            .map(str::trim_end)
            .collect::<Vec<_>>()
            .join("\n");
        s.trim().to_string()
    }
    let stderr = trim_lines(&output.stderr);
    let stdout = trim_lines(&output.stdout);
    let combined = match (stderr.is_empty(), stdout.is_empty()) {
        (true, true) => String::new(),
        (false, true) => stderr,
        (true, false) => format!("[stdout]\n{stdout}"),
        (false, false) => format!("{stderr}\n[stdout]\n{stdout}"),
    };
    GitError::GitCli {
        status: output.status.code().unwrap_or(-1),
        stderr: combined,
    }
}

/// Reject storage aliases without modifying the clone or its preserved work.
async fn ensure_private_bead_storage(workspace: &Path) -> Result<(), GitError> {
    let workspace = workspace.to_path_buf();
    spawn_blocking(move || {
        use std::os::unix::fs::MetadataExt;

        let git_dir = workspace.join(".git");
        let objects = git_dir.join("objects");
        for directory in [&workspace, &git_dir, &objects] {
            if !std::fs::symlink_metadata(directory)?.is_dir() {
                return Err(GitError::IndirectGitStorage {
                    path: directory.clone(),
                });
            }
        }
        for path in [
            git_dir.join("commondir"),
            objects.join("info/alternates"),
            objects.join("info/http-alternates"),
        ] {
            match std::fs::symlink_metadata(&path) {
                Ok(_) => return Err(GitError::IndirectGitStorage { path }),
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                Err(error) => return Err(error.into()),
            }
        }
        let mut directories = vec![objects];
        while let Some(directory) = directories.pop() {
            for entry in std::fs::read_dir(directory)? {
                let path = entry?.path();
                let metadata = std::fs::symlink_metadata(&path)?;
                if metadata.is_dir() {
                    directories.push(path);
                } else if !metadata.is_file() {
                    return Err(GitError::IndirectGitStorage { path });
                } else if metadata.nlink() != 1 {
                    return Err(GitError::SharedGitObject { path });
                }
            }
        }
        Ok(())
    })
    .await?
}

/// Create `<clone>/.wrix/` mode 0o777 so the container's dolt-socket
/// bind-mount target pre-exists and both the host user (post-session
/// pre-push hook) and container-namespace processes can write to it.
/// Without this, the container runtime mkdirs `.wrix/` as namespace-root
/// (host uid 100000) when materializing the mount, locking the host user
/// out of the dir and breaking the post-session push.
fn ensure_wrix_mount_dir(clone_path: &Path) -> Result<(), GitError> {
    use std::os::unix::fs::PermissionsExt;
    let dir = clone_path.join(".wrix");
    std::fs::create_dir_all(&dir)?;
    std::fs::set_permissions(&dir, std::fs::Permissions::from_mode(0o777))?;
    Ok(())
}

/// `git -C <workdir> config --get <key>` — returns the resolved value or
/// `Ok(None)` when the key is unset (git exits with code 1). Used by
/// [`GitClient::create_worktree`] to inherit the source's user identity
/// into the freshly-cloned bead workspace.
async fn read_config_value(
    workdir: &Path,
    clock: &dyn Clock,
    key: &str,
) -> Result<Option<String>, GitError> {
    let output = run_git_raw(workdir, clock, ["config", "--get", key], None).await?;
    if output.status.success() {
        let value = String::from_utf8(output.stdout)?.trim().to_string();
        return Ok(Some(value));
    }
    if output.status.code() == Some(1) {
        return Ok(None);
    }
    Err(GitError::GitCli {
        status: output.status.code().unwrap_or(-1),
        stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
    })
}

async fn run_git_raw<I, S>(
    workdir: &Path,
    clock: &dyn Clock,
    args: I,
    trailing: Option<&OsString>,
) -> Result<std::process::Output, GitError>
where
    I: IntoIterator<Item = S>,
    S: AsRef<std::ffi::OsStr>,
{
    run_git_raw_with_timeout(workdir, clock, GIT_TIMEOUT, args, trailing).await
}

async fn run_git_raw_with_timeout<I, S>(
    workdir: &Path,
    clock: &dyn Clock,
    timeout: Duration,
    args: I,
    trailing: Option<&OsString>,
) -> Result<std::process::Output, GitError>
where
    I: IntoIterator<Item = S>,
    S: AsRef<std::ffi::OsStr>,
{
    let mut cmd = super::environment::tokio_git_command();
    cmd.arg("-C").arg(workdir);
    let mut argv_for_log: Vec<String> = Vec::new();
    for arg in args {
        argv_for_log.push(arg.as_ref().to_string_lossy().into_owned());
        cmd.arg(arg);
    }
    if let Some(t) = trailing {
        argv_for_log.push(t.to_string_lossy().into_owned());
        cmd.arg(t);
    }

    crate::process::output(&mut cmd, clock, timeout)
        .await
        .map_err(|error| match error {
            crate::process::Error::Io(error) => GitError::Spawn(error),
            crate::process::Error::Cleanup(error) => GitError::Io(error),
            crate::process::Error::Timeout => GitError::GitTimeout {
                args: argv_for_log.join(" "),
                timeout_secs: timeout.as_secs(),
                workdir: workdir.to_path_buf(),
            },
        })
}

#[cfg(test)]
#[cfg(unix)]
mod timeout_tests {
    use super::*;
    use crate::process::tests::{Fixture, TriggerClock, bounded};

    /// A real Git shell alias models hooks/helpers whose descendants inherit its process group.
    #[tokio::test]
    async fn git_timeout_terminates_descendants_before_returning() {
        bounded(async {
            let fixture = Fixture::new().await;
            let directory = tempfile::tempdir().expect("git working directory");
            let mut args = vec!["-c".to_owned(), "alias.loom-fixture=!exec bash".to_owned(), "loom-fixture".to_owned()];
            args.extend(fixture.args());
            let (result, peers) = tokio::join!(
                run_git_raw_with_timeout(directory.path(), fixture.clock.as_ref(), Duration::from_secs(60), &args, None),
                async {
                    let peers = fixture.ready(2).await;
                    fixture.clock.expire();
                    peers
                },
            );
            assert!(matches!(result, Err(GitError::GitTimeout { args: actual, timeout_secs: 60, workdir }) if actual == args.join(" ") && workdir == directory.path()));
            fixture.assert_stopped(peers).await;
        }).await;
    }

    /// Real Git capture must preserve successful command output.
    #[tokio::test]
    async fn git_timeout_boundary_preserves_success() {
        bounded(async {
            let directory = tempfile::tempdir().expect("git working directory");
            let result = run_git_raw_with_timeout(
                directory.path(),
                &TriggerClock::default(),
                Duration::from_secs(60),
                ["--version"],
                None,
            )
            .await
            .expect("git version");
            assert!(result.status.success());
            assert!(result.stdout.starts_with(b"git version "));
        })
        .await;
    }

    /// A nonzero Git exit must retain its status and diagnostic pipes.
    #[tokio::test]
    async fn git_timeout_boundary_preserves_nonzero_exit() {
        bounded(async {
            let directory = tempfile::tempdir().expect("git working directory");
            let result = run_git_raw_with_timeout(
                directory.path(),
                &TriggerClock::default(),
                Duration::from_secs(60),
                [
                    "-c",
                    "alias.loom-fixture=!printf stdout; printf stderr >&2; exit 9",
                    "loom-fixture",
                ],
                None,
            )
            .await
            .expect("git output");
            assert_eq!(result.status.code(), Some(9));
            assert_eq!(result.stdout, b"stdout");
            assert_eq!(result.stderr, b"stderr");
        })
        .await;
    }
}
