//! Direct sessions emit live JSONL events and accept steering until completion.

use std::collections::VecDeque;
use std::io;

use loom_agent::direct::backend::{DirectCommand, DirectEvent};
use loom_agent::direct::tool::{
    Bash, Edit, Glob, Grep, OffloadRecord, Read, ToolContext, ToolContextError, Write,
};
use loom_driver::agent::SpawnConfig;
use loom_events::{AgentEvent, DriverEventPayload};
use loom_llm::api_key::ApiKey;
use loom_llm::cache::{CacheControl, CacheTtl};
use loom_llm::client::{
    AnthropicClient, BoxFuture, CompletionResponse, GeminiClient, LlmClient, LlmError, OpenAiClient,
};
use loom_llm::conversation::{ContextBudget, Conversation};
use loom_llm::model_id::{AnthropicModel, ModelId, SchemaKind};
use loom_llm::observer::{
    DoomLoopConfig as LlmDoomLoopConfig, DuplicateResultConfig as LlmDuplicateResultConfig,
};
use loom_llm::request::CompletionRequest;
use loom_llm::tool::Tool;
use tokio::io::{AsyncBufRead, AsyncBufReadExt, AsyncWrite, AsyncWriteExt};
use tokio::sync::mpsc;
use tracing::{debug, info, warn};

/// TTL the runner attaches to every user prompt so the underlying
/// provider treats each turn as a cache breakpoint. Anthropic honours
/// this directly; `OpenAI` / Gemini no-op the marker per
/// [`CacheControl`]'s contract.
const PROMPT_CACHE_TTL: CacheTtl = CacheTtl::Hours1;

/// Default Conversation model when the [`SpawnConfig`] omits one.
const DEFAULT_MODEL: ModelId = ModelId::Anthropic(AnthropicModel::ClaudeSonnet46);

/// Default request-context budget used before the runner trims ordinary
/// transcript turns while retaining the initial rendered prompt.
const DEFAULT_CONTEXT_BUDGET_BYTES: usize = 1_048_576;

/// Build the canonical six-tool registry the Direct backend registers
/// with every Conversation. Order matches the spec's tool list (`Read`,
/// `Write`, `Edit`, `Bash`, `Grep`, `Glob`).
pub fn six_tools(ctx: ToolContext) -> Vec<Box<dyn Tool>> {
    vec![
        Box::new(Read::new(ctx.clone())),
        Box::new(Write::new(ctx.clone())),
        Box::new(Edit::new(ctx.clone())),
        Box::new(Bash::new(ctx.clone())),
        Box::new(Grep::new(ctx.clone())),
        Box::new(Glob::new(ctx)),
    ]
}

/// Construct the [`Conversation`] driven by `loom-direct-runner`.
///
/// The model is resolved from [`SpawnConfig::model_id`] via [`str::parse`]; when
/// absent the runner falls back to `DEFAULT_MODEL`. The six sandbox-aware
/// tools are registered in the canonical order, and observer settings come
/// from [`SpawnConfig::observers`].
///
/// # Errors
/// Returns an error when the wire configuration carries a malformed model name.
pub fn build_conversation(config: &SpawnConfig) -> Result<Conversation, RunnerError> {
    build_conversation_with_context(config, tool_context(config))
}

fn build_conversation_with_context(
    config: &SpawnConfig,
    ctx: ToolContext,
) -> Result<Conversation, RunnerError> {
    let mut conv = Conversation::with_observer_configs(
        configured_model(config)?,
        llm_doom_loop_config(&config.observers.doom_loop),
        llm_duplicate_result_config(&config.observers.duplicate_result),
    );
    for tool in six_tools(ctx) {
        conv = conv.register_boxed(tool);
    }
    Ok(conv)
}

const fn llm_doom_loop_config(config: &loom_driver::config::DoomLoopConfig) -> LlmDoomLoopConfig {
    LlmDoomLoopConfig {
        enabled: config.enabled,
        window: config.window,
        threshold: config.threshold,
        stage_2_after_stage_1: config.stage_2_after_stage_1,
    }
}

const fn llm_duplicate_result_config(
    config: &loom_driver::config::DuplicateResultConfig,
) -> LlmDuplicateResultConfig {
    LlmDuplicateResultConfig {
        enabled: config.enabled,
        min_bytes: config.min_bytes,
    }
}

fn tool_context(config: &SpawnConfig) -> ToolContext {
    let max_inline_bytes = config
        .output_limits
        .map_or_else(loom_driver::config::InlineByteLimit::default, |limits| {
            limits.max_inline_bytes
        });
    ToolContext::new(config.scratch_dir.join("offload"), max_inline_bytes)
}

fn configured_model(config: &SpawnConfig) -> Result<ModelId, RunnerError> {
    config
        .model_id
        .as_deref()
        .or_else(|| config.model.as_ref().map(|sel| sel.model_id.as_str()))
        .map_or(Ok(DEFAULT_MODEL), |name| {
            name.parse().map_err(RunnerError::ModelName)
        })
}

/// Construct a client for the configured model schema.
///
/// Reads the matching credential from the per-schema environment variable and constructs the typed
/// per-schema [`LlmClient`] the runner drives. Returned boxed so the
/// runner does not branch on schema at the call site.
///
/// # Errors
///
/// Returns an error when the model schema is unsupported or its credential is unavailable.
pub fn build_client_for_config(
    config: &SpawnConfig,
) -> Result<Box<dyn LlmClient + Send + Sync>, RunnerError> {
    let model = configured_model(config)?;
    match model.schema() {
        SchemaKind::Anthropic => {
            let api_key = read_api_key("ANTHROPIC_API_KEY")?;
            Ok(Box::new(AnthropicClient::new(api_key)))
        }
        SchemaKind::OpenAi => {
            let api_key = read_api_key("OPENAI_API_KEY")?;
            Ok(Box::new(OpenAiClient::new(api_key)))
        }
        SchemaKind::Gemini => {
            let api_key = read_api_key("GEMINI_API_KEY")?;
            Ok(Box::new(GeminiClient::new(api_key)))
        }
        other => Err(RunnerError::UnsupportedSchema { schema: other }),
    }
}

fn read_api_key(var: &str) -> Result<ApiKey, RunnerError> {
    let raw = std::env::var(var).map_err(|source| RunnerError::ApiKeyEnv {
        var: var.to_string(),
        source,
    })?;
    ApiKey::new(raw).map_err(|err| RunnerError::ApiKey {
        var: var.to_string(),
        source: err,
    })
}

/// Drive one Direct session against `client`. Reads JSONL commands from
/// `stdin`, emits JSONL events to `stdout`, and lets commands received during
/// an active turn drain before a requested completion.
///
/// # Errors
///
/// Returns an error when command decoding, model execution, or event output fails.
pub async fn run_session<C, R, W>(
    client: C,
    config: SpawnConfig,
    stdin: R,
    stdout: W,
) -> Result<(), RunnerError>
where
    C: LlmClient + Sync,
    R: AsyncBufRead + Unpin,
    W: AsyncWrite + Unpin,
{
    run_session_with_context_budget(
        client,
        config,
        stdin,
        stdout,
        ContextBudget::max_request_bytes(DEFAULT_CONTEXT_BUDGET_BYTES),
    )
    .await
}

async fn run_session_with_context_budget<C, R, W>(
    client: C,
    config: SpawnConfig,
    stdin: R,
    stdout: W,
    context_budget: ContextBudget,
) -> Result<(), RunnerError>
where
    C: LlmClient + Sync,
    R: AsyncBufRead + Unpin,
    W: AsyncWrite + Unpin,
{
    let ctx = tool_context(&config);
    let mut conv =
        build_conversation_with_context(&config, ctx.clone())?.context_budget(context_budget);
    let (events, mut live_events) = mpsc::unbounded_channel();
    let recording = LiveClient {
        inner: client,
        events,
        ctx,
    };
    let mut emitter = Emitter::new(stdout);
    let mut lines = stdin.lines();
    let mut pending = VecDeque::new();
    let mut exit_code: i32 = 0;
    let mut initial_prompt_pending = true;
    let mut input_closed = false;
    let mut complete_requested = false;
    let mut abort_requested = false;

    loop {
        if abort_requested || (pending.is_empty() && (input_closed || complete_requested)) {
            break;
        }
        let input = match pending.pop_front() {
            Some(input) => input,
            None => {
                if let Some(line) = lines.next_line().await.map_err(RunnerError::Io)? {
                    let Some(input) = decode_input(&line) else {
                        continue;
                    };
                    input
                } else {
                    input_closed = true;
                    continue;
                }
            }
        };

        match input {
            PendingInput::Command(
                DirectCommand::Prompt { message } | DirectCommand::Steer { message },
            ) => {
                let pin_initial_prompt = initial_prompt_pending;
                if pin_initial_prompt {
                    debug!(bytes = message.len(), "received prompt");
                    initial_prompt_pending = false;
                } else {
                    debug!(bytes = message.len(), "received follow-up or steer");
                }

                let mut turn_result = None;
                let mut input_error = None;
                {
                    let turn = run_prompt(&mut conv, &recording, message, pin_initial_prompt);
                    tokio::pin!(turn);
                    loop {
                        tokio::select! {
                            biased;
                            line = lines.next_line(), if !input_closed => {
                                match line {
                                    Ok(Some(line)) => {
                                        if let Some(input) = decode_input(&line) {
                                            if matches!(
                                                input,
                                                PendingInput::Command(DirectCommand::Abort)
                                            ) {
                                                abort_requested = true;
                                                break;
                                            }
                                            pending.push_back(input);
                                        }
                                    }
                                    Ok(None) => input_closed = true,
                                    Err(err) => {
                                        input_error = Some(err);
                                        break;
                                    }
                                }
                            }
                            Some(event) = live_events.recv() => {
                                emitter.emit(&event.map_err(RunnerError::ToolContext)?).await?;
                            }
                            result = &mut turn => {
                                turn_result = Some(result);
                                break;
                            }
                        }
                    }
                }

                while let Ok(event) = live_events.try_recv() {
                    emitter
                        .emit(&event.map_err(RunnerError::ToolContext)?)
                        .await?;
                }
                if let Some(err) = input_error {
                    return Err(RunnerError::Io(err));
                }
                if abort_requested {
                    info!(
                        queued_commands = pending.len(),
                        "received abort, terminating session",
                    );
                    continue;
                }
                if let Some(Err(err)) = turn_result {
                    warn!(error = ?err, "prompt failed");
                    emitter
                        .emit(&DirectEvent::Error {
                            message: format!("{err:?}"),
                        })
                        .await?;
                    exit_code = 1;
                }
                emitter.emit(&DirectEvent::TurnEnd).await?;
            }
            PendingInput::Command(DirectCommand::Complete) => {
                info!(
                    queued_commands = pending.len(),
                    "received complete; draining queued session commands",
                );
                complete_requested = true;
            }
            PendingInput::Command(DirectCommand::Abort) => {
                info!(
                    queued_commands = pending.len(),
                    "received abort, terminating session",
                );
                abort_requested = true;
            }
            PendingInput::Malformed { line, error } => {
                warn!(error = ?error, line = %line, "malformed command frame");
                emitter
                    .emit(&DirectEvent::Error {
                        message: format!("invalid command frame: {error}"),
                    })
                    .await?;
                exit_code = 1;
            }
        }
    }

    emitter
        .emit(&DirectEvent::SessionComplete {
            exit_code,
            cost_usd: None,
        })
        .await?;
    Ok(())
}

enum PendingInput {
    Command(DirectCommand),
    Malformed { line: String, error: String },
}

fn decode_input(line: &str) -> Option<PendingInput> {
    let trimmed = line.trim_end_matches('\r');
    if trimmed.is_empty() {
        return None;
    }
    Some(match serde_json::from_str::<DirectCommand>(trimmed) {
        Ok(command) => PendingInput::Command(command),
        Err(error) => PendingInput::Malformed {
            line: trimmed.to_string(),
            error: error.to_string(),
        },
    })
}

async fn run_prompt<C: LlmClient + Sync>(
    conv: &mut Conversation,
    client: &C,
    message: String,
    pin_initial_prompt: bool,
) -> Result<(), RunnerError> {
    if pin_initial_prompt {
        conv.user_cached_pinned(message, CacheControl::Ephemeral(PROMPT_CACHE_TTL));
    } else {
        conv.user_cached(message, CacheControl::Ephemeral(PROMPT_CACHE_TTL));
    }
    conv.run(client).await.map_err(RunnerError::Llm)?;
    Ok(())
}

fn driver_event(event: &DriverEventPayload) -> DirectEvent {
    DirectEvent::DriverEvent {
        driver_kind: event.driver_kind.clone(),
        summary: event.summary.clone(),
        payload: event.payload.clone(),
    }
}

fn offload_event(record: &OffloadRecord) -> DirectEvent {
    driver_event(&DriverEventPayload::offload(
        record.tool.clone(),
        record.total_bytes,
    ))
}

/// Live frames retain occurrence order; the host owns final event stamping.
struct LiveClient<C> {
    inner: C,
    events: mpsc::UnboundedSender<Result<DirectEvent, ToolContextError>>,
    ctx: ToolContext,
}

impl<C> LiveClient<C> {
    fn send(&self, event: Result<DirectEvent, ToolContextError>) {
        if self.events.send(event).is_err() {
            warn!(channel = "direct_events", "session event receiver closed");
        }
    }
}

impl<C: LlmClient + Sync> LlmClient for LiveClient<C> {
    fn schema(&self) -> SchemaKind {
        self.inner.schema()
    }

    fn supports(&self, model: &ModelId) -> bool {
        self.inner.supports(model)
    }

    fn emit_driver_event(&self, event: DriverEventPayload) {
        self.send(Ok(driver_event(&event)));
    }

    fn emit_event(&self, event: &AgentEvent) {
        let frame = match event {
            AgentEvent::TextDelta { text, .. } => DirectEvent::TextDelta { text: text.clone() },
            AgentEvent::TextEnd { .. } => DirectEvent::TextEnd,
            AgentEvent::ToolCall {
                id,
                tool,
                params,
                parent_tool_call_id,
                ..
            } => DirectEvent::ToolCall {
                id: id.clone(),
                tool: tool.clone(),
                params: params.clone(),
                parent_tool_call_id: parent_tool_call_id.clone(),
            },
            AgentEvent::ToolResult {
                id,
                output,
                is_error,
                ..
            } => {
                match self.ctx.drain_offloads() {
                    Ok(records) => {
                        for record in records {
                            self.send(Ok(offload_event(&record)));
                        }
                    }
                    Err(err) => self.send(Err(err)),
                }
                DirectEvent::ToolResult {
                    id: id.clone(),
                    output: output.clone(),
                    is_error: *is_error,
                }
            }
            _ => return,
        };
        self.send(Ok(frame));
    }

    fn complete(
        &self,
        req: CompletionRequest,
    ) -> BoxFuture<'_, Result<CompletionResponse, LlmError>> {
        Box::pin(async move {
            let model = req.model.clone();
            let resp = self.inner.complete(req).await?;
            self.emit_driver_event(DriverEventPayload::token_usage(
                model.as_wire(),
                resp.usage.input,
                resp.usage.output,
                resp.usage.cache_read,
                resp.usage.cache_write,
            ));
            Ok(resp)
        })
    }

    fn complete_structured_raw(
        &self,
        req: CompletionRequest,
        schema: serde_json::Value,
        type_name: String,
    ) -> BoxFuture<'_, Result<String, LlmError>> {
        self.inner.complete_structured_raw(req, schema, type_name)
    }
}

/// Buffer-flushing JSONL writer. Each call to [`Emitter::emit`] writes
/// one line + `\n` and flushes so the host-side parser sees the frame
/// before the runner buffers the next.
struct Emitter<W: AsyncWrite + Unpin> {
    writer: W,
}

impl<W: AsyncWrite + Unpin> Emitter<W> {
    const fn new(writer: W) -> Self {
        Self { writer }
    }

    async fn emit(&mut self, event: &DirectEvent) -> Result<(), RunnerError> {
        let mut line = serde_json::to_string(event).map_err(RunnerError::EncodeJson)?;
        line.push('\n');
        self.writer
            .write_all(line.as_bytes())
            .await
            .map_err(RunnerError::Io)?;
        self.writer.flush().await.map_err(RunnerError::Io)?;
        Ok(())
    }
}

/// Errors the runner surfaces to its caller.
#[derive(Debug, displaydoc::Display, thiserror::Error)]
pub enum RunnerError {
    /// invalid configured model: {0}
    ModelName(#[source] loom_events::identifier::ParseModelNameError),
    /// stdin/stdout io failure: {0}
    Io(#[source] io::Error),
    /// failed to encode event frame: {0}
    EncodeJson(#[source] serde_json::Error),
    /// llm error during conversation run
    Llm(#[source] loom_llm::conversation::ConversationError),
    /// Direct tool context failure
    ToolContext(#[source] ToolContextError),
    /// failed to read API key env var {var}
    ApiKeyEnv {
        /// Name of the env var the runner read.
        var: String,
        /// Underlying environment lookup error.
        #[source]
        source: std::env::VarError,
    },
    /// invalid API key sourced from {var}: {source}
    ApiKey {
        /// Name of the env var the runner read.
        var: String,
        /// Underlying [`loom_llm::api_key::ApiKeyError`] from
        /// [`ApiKey::new`].
        #[source]
        source: loom_llm::api_key::ApiKeyError,
    },
    /// runner does not have a per-schema Client for {schema:?}
    UnsupportedSchema {
        /// Schema the configured model resolves to.
        schema: SchemaKind,
    },
}

#[cfg(test)]
mod tests {
    use super::*;
    use loom_llm::request::Message;

    #[test]
    fn malformed_wire_models_fail_before_conversation_or_credentials() {
        for name in ["", " ", "custom model", "bad\0model"] {
            let mut config = sample_config(Some(name));
            assert!(matches!(
                build_conversation(&config),
                Err(RunnerError::ModelName(_))
            ));
            assert!(matches!(
                build_client_for_config(&config),
                Err(RunnerError::ModelName(_))
            ));
            config.model_id = None;
            config.model = Some(loom_driver::agent::ModelSelection {
                provider: "custom".into(),
                model_id: name.into(),
            });
            assert!(matches!(
                build_conversation(&config),
                Err(RunnerError::ModelName(_))
            ));
        }
    }

    use loom_driver::agent::{LineParse, OutputLimits, RePinContent};
    use loom_driver::clock::{Clock, SystemClock};
    use loom_driver::config::{
        AgentObserversConfig, DoomLoopConfig, DuplicateResultConfig, LoomConfig, Phase,
    };
    use loom_events::identifier::{BeadId, SessionId};
    use loom_events::{AgentEvent, DriverKind, EnvelopeBuilder, SessionScope, Source};
    use loom_llm::client::{
        CompletionResponse, LlmError, ToolCallId as LlmToolCallId, ToolUseRequest,
    };
    use loom_llm::request::CompletionRequest;
    use loom_llm::usage::TokenUsage;
    use serde_json::{Value, json};
    use std::path::PathBuf;
    use std::sync::Mutex;
    use std::time::Duration;
    use tokio::io::{AsyncBufReadExt, AsyncWriteExt};

    const PLANNING_PROMPT_INTERVIEW_MODES: &str =
        include_str!("../../../tests/fixtures/planning_prompt_interview_modes.md");
    const POLISH_MODE_DEFINITION: &str = "- polish / do-a-polish: report-only mode. Review the proposed wording and report suggested edits, but do not modify files or apply edits unless the human explicitly asks you to make the edits.";
    const ONE_BY_ONE_MODE_DEFINITION: &str = "- one-by-one: ask exactly one design question per turn, then wait for the human's answer before asking the next question or changing topics.";

    fn sample_config(model_id: Option<&str>) -> SpawnConfig {
        SpawnConfig {
            image_ref: "localhost/wrix-test:direct".into(),
            image_source: PathBuf::from("/nix/store/zzz-test.tar"),
            image_source_kind: Some(loom_driver::agent::ImageSourceKind::NixDescriptor),
            wrix_launcher: None,
            profile_config: None,
            workspace: PathBuf::from("/workspace"),
            env: vec![("WRIX_AGENT".into(), "direct".into())],
            mounts: vec![],
            initial_prompt: "hello".into(),
            agent_args: vec![],
            repin: RePinContent {
                orientation: String::new(),
                pinned_context: String::new(),
                partial_bodies: vec![],
            },
            skills: None,
            event_metadata: None,
            scratch_dir: PathBuf::new(),
            model_id: model_id.map(str::to_string),
            model: None,
            thinking_level: None,
            observers: loom_driver::config::AgentObserversConfig::default(),
            output_limits: None,
            shutdown_grace: None,
            denied_tools: Vec::new(),
            handshake_timeout: None,
            stall_warn_interval: None,
            launcher_env: Vec::new(),
        }
    }

    /// Scripted client that hands back pre-baked responses in order.
    /// Mirrors the `ScriptedClient` pattern used by Conversation's own
    /// loop tests — the runner needs no live provider to exercise its
    /// JSONL wire emission.
    struct ScriptedClient {
        responses: Mutex<Vec<CompletionResponse>>,
    }

    impl ScriptedClient {
        fn new(responses: Vec<CompletionResponse>) -> Self {
            Self {
                responses: Mutex::new(responses),
            }
        }
    }

    impl LlmClient for ScriptedClient {
        fn schema(&self) -> SchemaKind {
            SchemaKind::Anthropic
        }

        fn supports(&self, _model: &ModelId) -> bool {
            true
        }

        fn complete(
            &self,
            _req: CompletionRequest,
        ) -> BoxFuture<'_, Result<CompletionResponse, LlmError>> {
            Box::pin(async move {
                let mut guard = self
                    .responses
                    .lock()
                    .unwrap_or_else(std::sync::PoisonError::into_inner);
                if guard.is_empty() {
                    Err(LlmError::Provider {
                        message: "scripted client exhausted".into(),
                    })
                } else {
                    Ok(guard.remove(0))
                }
            })
        }

        fn complete_structured_raw(
            &self,
            _req: CompletionRequest,
            _schema: serde_json::Value,
            _type_name: String,
        ) -> BoxFuture<'_, Result<String, LlmError>> {
            Box::pin(async move {
                Err(LlmError::Provider {
                    message: "structured not used in runner tests".into(),
                })
            })
        }
    }

    fn final_text(text: &str) -> CompletionResponse {
        CompletionResponse {
            text: text.into(),
            usage: TokenUsage::default(),
            tool_calls: Vec::new(),
        }
    }

    struct BlockingClient {
        started: std::sync::Arc<tokio::sync::Notify>,
    }

    impl LlmClient for BlockingClient {
        fn schema(&self) -> SchemaKind {
            SchemaKind::Anthropic
        }

        fn supports(&self, _model: &ModelId) -> bool {
            true
        }

        fn complete(
            &self,
            _req: CompletionRequest,
        ) -> BoxFuture<'_, Result<CompletionResponse, LlmError>> {
            Box::pin(async move {
                self.started.notify_one();
                std::future::pending().await
            })
        }

        fn complete_structured_raw(
            &self,
            _req: CompletionRequest,
            _schema: serde_json::Value,
            _type_name: String,
        ) -> BoxFuture<'_, Result<String, LlmError>> {
            Box::pin(async move {
                Err(LlmError::Provider {
                    message: "structured not used in runner tests".into(),
                })
            })
        }
    }

    struct PausedAfterToolClient {
        first: Mutex<Option<CompletionResponse>>,
        finish: Mutex<Option<tokio::sync::oneshot::Receiver<Result<CompletionResponse, LlmError>>>>,
    }

    impl LlmClient for PausedAfterToolClient {
        fn schema(&self) -> SchemaKind {
            SchemaKind::Anthropic
        }

        fn complete(
            &self,
            _req: CompletionRequest,
        ) -> BoxFuture<'_, Result<CompletionResponse, LlmError>> {
            Box::pin(async move {
                let first = self.first.lock().unwrap().take();
                if let Some(first) = first {
                    return Ok(first);
                }
                let finish = self.finish.lock().unwrap().take().expect("only two calls");
                finish.await.expect("test releases provider")
            })
        }

        fn complete_structured_raw(
            &self,
            _req: CompletionRequest,
            _schema: Value,
            _type_name: String,
        ) -> BoxFuture<'_, Result<String, LlmError>> {
            Box::pin(async { panic!("structured completion not requested") })
        }
    }

    async fn live_tool_history(fail: bool) {
        let dir = tempfile::tempdir().unwrap();
        let source = dir.path().join("source.txt");
        std::fs::write(&source, "alpha\nbeta\ngamma\n").unwrap();
        let mut first = final_text("checking");
        first.tool_calls.push(ToolUseRequest {
            call_id: LlmToolCallId::parse("read-live").unwrap(),
            name: "Read".into(),
            args: json!({"file_path": source}),
        });
        let (finish, wait) = tokio::sync::oneshot::channel();
        let client = PausedAfterToolClient {
            first: Mutex::new(Some(first)),
            finish: Mutex::new(Some(wait)),
        };
        let mut config = sample_config(None);
        config.scratch_dir = dir.path().join("scratch");
        config.output_limits = Some(OutputLimits {
            max_inline_bytes: 6.try_into().unwrap(),
        });
        config.observers.doom_loop.enabled = false;
        config.observers.duplicate_result.enabled = false;
        let (writer, reader) = tokio::io::duplex(4096);
        let runner = tokio::spawn(run_session(
            client,
            config,
            tokio::io::BufReader::new(&b"{\"type\":\"prompt\",\"message\":\"read\"}\n"[..]),
            writer,
        ));
        let mut reader = tokio::io::BufReader::new(reader);
        let mut before_release = Vec::new();
        for _ in 0..6 {
            before_release.push(next_direct_event(&mut reader).await);
        }
        assert!(matches!(&before_release[..], [
            DirectEvent::DriverEvent { driver_kind: DriverKind::TokenUsage, .. },
            DirectEvent::TextDelta { text }, DirectEvent::TextEnd,
            DirectEvent::ToolCall { id, .. },
            DirectEvent::DriverEvent { driver_kind: DriverKind::Offload, .. },
            DirectEvent::ToolResult { output, is_error: false, .. },
        ] if text == "checking" && id.as_str() == "read-live"
            && serde_json::from_str::<Value>(output).unwrap()["head_bytes"] == 6));
        assert!(
            !runner.is_finished(),
            "events must arrive while the next provider call is paused"
        );
        finish
            .send(if fail {
                Err(LlmError::Timeout)
            } else {
                Ok(final_text("done"))
            })
            .unwrap();
        let mut after_release = Vec::new();
        loop {
            let event = next_direct_event(&mut reader).await;
            let complete = matches!(event, DirectEvent::SessionComplete { .. });
            after_release.push(event);
            if complete {
                break;
            }
        }
        runner.await.unwrap().unwrap();
        assert!(!after_release.iter().any(|event| matches!(
            event,
            DirectEvent::ToolCall { .. }
                | DirectEvent::ToolResult { .. }
                | DirectEvent::DriverEvent {
                    driver_kind: DriverKind::Offload,
                    ..
                }
        )));
        assert_eq!(
            after_release
                .iter()
                .filter(|event| matches!(event, DirectEvent::Error { .. }))
                .count(),
            usize::from(fail)
        );
        assert!(
            matches!(after_release.last(), Some(DirectEvent::SessionComplete { exit_code, .. }) if *exit_code == i32::from(fail))
        );
    }

    #[tokio::test]
    async fn direct_streams_tool_and_offload_events_before_next_completion() {
        live_tool_history(false).await;
    }

    #[tokio::test]
    async fn direct_preserves_live_tool_history_when_later_completion_fails() {
        live_tool_history(true).await;
    }

    /// The runner registers exactly six tools by name, in the canonical
    /// order documented in `specs/agent.md` § Direct Backend.
    #[test]
    fn direct_runner_registers_canonical_six_tools() {
        let tools = six_tools(tool_context(&sample_config(None)));
        let names: Vec<&str> = tools.iter().map(|t| t.name()).collect();
        assert_eq!(names, vec!["Read", "Write", "Edit", "Bash", "Grep", "Glob"]);
    }

    /// Both default observers ship enabled when the runner builds its
    /// Conversation, matching `Conversation::new`'s defaults.
    #[test]
    fn direct_runner_composes_default_observers() {
        let conv = build_conversation(&sample_config(None)).expect("valid config");
        assert!(
            conv.doom_loop_enabled(),
            "DoomLoopObserver enabled by default in runner Conversation",
        );
        assert!(
            conv.duplicate_result_enabled(),
            "DuplicateResultObserver enabled by default in runner Conversation",
        );
    }

    /// Direct consumes Loom's `[agent.*]` observer settings from the serialized
    /// spawn config so CLI opt-outs affect the in-container Conversation.
    #[test]
    fn direct_runner_honours_spawn_config_observer_opt_outs() {
        let mut cfg = sample_config(None);
        cfg.observers = AgentObserversConfig {
            doom_loop: DoomLoopConfig {
                enabled: false,
                ..DoomLoopConfig::default()
            },
            duplicate_result: DuplicateResultConfig {
                enabled: false,
                ..DuplicateResultConfig::default()
            },
        };

        let conv = build_conversation(&cfg).expect("valid config");
        assert!(!conv.doom_loop_enabled());
        assert!(!conv.duplicate_result_enabled());
    }

    /// Per-phase direct config is installed on `SpawnConfig::model_id` before
    /// the runner constructs its `Conversation`, so the live config seam drives
    /// `ModelId::from_str` rather than a test-populated model field.
    #[test]
    fn direct_model_id_respects_phase_config() {
        let cfg = LoomConfig::from_toml_str(
            "[phase.gate.review]\nagent.backend = \"direct\"\nagent.model_id = \"claude-sonnet-4-6\"\n",
        )
        .expect("parse config");
        let selection = cfg.agent_for(Phase::Review);
        let mut spawn = sample_config(None);
        selection.apply_to_spawn_config(&mut spawn, cfg.direct_output_limits());

        let conv = build_conversation(&spawn).expect("valid config");
        assert_eq!(
            *conv.model(),
            ModelId::Anthropic(AnthropicModel::ClaudeSonnet46),
        );
    }

    /// The `model_id` field from `SpawnConfig` resolves through
    /// `ModelId::from_str` so a known string like `claude-sonnet-4-6`
    /// produces the typed variant rather than falling through to
    /// `Other`. Unknown strings round-trip via `Other` so external
    /// consumers can name not-yet-supported models without a minor bump.
    #[test]
    fn direct_runner_uses_spawn_config_model_id() {
        let conv =
            build_conversation(&sample_config(Some("claude-sonnet-4-6"))).expect("valid config");
        assert_eq!(
            *conv.model(),
            ModelId::Anthropic(AnthropicModel::ClaudeSonnet46),
        );

        let conv_unknown =
            build_conversation(&sample_config(Some("claude-future-x"))).expect("valid config");
        assert_eq!(
            *conv_unknown.model(),
            ModelId::Anthropic(AnthropicModel::Other(
                "claude-future-x".parse().expect("model name")
            )),
        );

        let conv_default = build_conversation(&sample_config(None)).expect("valid config");
        assert_eq!(*conv_default.model(), DEFAULT_MODEL);
    }

    /// End-to-end JSONL drive: feed the runner one prompt frame against
    /// a scripted client that returns final assistant text, and assert
    /// the emitted JSONL frames match the wire shape the host's
    /// `DirectParser` decodes. Pins compatibility with the Pi/Claude
    /// per-frame line discipline (one JSON object + `\n`) and the
    /// `DirectEvent` tag/variant set.
    #[test]
    fn direct_runner_emits_agent_event_jsonl_compatible_with_common_agent_events() {
        let lines = tokio_test::block_on(async {
            let client = ScriptedClient::new(vec![final_text("hello back")]);
            let (mut stdin_host, stdin_runner) = tokio::io::duplex(1024);
            let (stdout_runner, stdout_host) = tokio::io::duplex(4096);
            let handle = tokio::spawn(run_session(
                client,
                sample_config(Some("claude-sonnet-4-6")),
                tokio::io::BufReader::new(stdin_runner),
                stdout_runner,
            ));
            let command = command_frame(&DirectCommand::Prompt {
                message: "hi".to_string(),
            });
            stdin_host
                .write_all(command.as_bytes())
                .await
                .expect("write prompt");
            stdin_host.flush().await.expect("flush prompt");

            let mut stdout = tokio::io::BufReader::new(stdout_host);
            let mut lines = Vec::new();
            loop {
                let mut line = String::new();
                let read = SystemClock::new()
                    .timeout(Duration::from_secs(5), stdout.read_line(&mut line))
                    .await
                    .expect("session_complete without closing stdin")
                    .expect("read stdout line");
                assert_ne!(read, 0, "stdout closed before session_complete");
                let line = line
                    .trim_end_matches('\n')
                    .trim_end_matches('\r')
                    .to_string();
                let kind = serde_json::from_str::<Value>(&line)
                    .expect("json")
                    .get("type")
                    .and_then(Value::as_str)
                    .expect("event type")
                    .to_string();
                lines.push(line);
                if kind == "turn_end" {
                    stdin_host
                        .write_all(command_frame(&DirectCommand::Complete).as_bytes())
                        .await
                        .expect("write complete after turn end");
                    stdin_host.flush().await.expect("flush complete");
                }
                if kind == "session_complete" {
                    break;
                }
            }
            handle
                .await
                .expect("runner task joins")
                .expect("run_session completes");
            lines
        });

        let parsed: Vec<DirectEvent> = lines
            .iter()
            .map(|l| serde_json::from_str(l).expect("each line parses as DirectEvent"))
            .collect();

        let kinds: Vec<&str> = lines
            .iter()
            .map(|l| {
                serde_json::from_str::<Value>(l)
                    .expect("json")
                    .get("type")
                    .and_then(Value::as_str)
                    .map_or("<missing>", |s| match s {
                        "text_delta" => "text_delta",
                        "text_end" => "text_end",
                        "driver_event" => "driver_event",
                        "turn_end" => "turn_end",
                        "session_complete" => "session_complete",
                        other => panic!("unexpected event type {other}"),
                    })
            })
            .collect();
        assert_eq!(
            kinds,
            vec![
                "driver_event",
                "text_delta",
                "text_end",
                "turn_end",
                "session_complete",
            ],
        );

        match &parsed[1] {
            DirectEvent::TextDelta { text } => assert_eq!(text, "hello back"),
            other => panic!("expected TextDelta, got {other:?}"),
        }
        match &parsed[4] {
            DirectEvent::SessionComplete {
                exit_code,
                cost_usd,
            } => {
                assert_eq!(*exit_code, 0);
                assert!(cost_usd.is_none());
            }
            other => panic!("expected SessionComplete, got {other:?}"),
        }
    }

    /// Tool calls precede their results, interleaved with per-completion usage.
    #[test]
    fn direct_runner_emits_tool_call_and_result_frames_in_order() {
        let dir = tempfile::tempdir().expect("tempdir");
        let target = dir.path().join("hello.txt");
        std::fs::write(&target, "hi\n").expect("write fixture");

        let with_call = CompletionResponse {
            text: String::new(),
            usage: TokenUsage::default(),
            tool_calls: vec![ToolUseRequest {
                call_id: LlmToolCallId::parse("call-1").expect("test tool call id parses"),
                name: "Read".into(),
                args: json!({ "file_path": target }),
            }],
        };
        let client = ScriptedClient::new(vec![with_call, final_text("done")]);
        let stdin = b"{\"type\":\"prompt\",\"message\":\"please read\"}\n".to_vec();
        let mut stdout: Vec<u8> = Vec::new();

        tokio_test::block_on(run_session(
            client,
            sample_config(None),
            tokio::io::BufReader::new(&stdin[..]),
            &mut stdout,
        ))
        .expect("run_session completes");

        let mut iter = std::str::from_utf8(&stdout)
            .expect("utf-8")
            .lines()
            .map(|line| serde_json::from_str::<DirectEvent>(line).expect("parse line"));
        assert!(matches!(
            iter.next(),
            Some(DirectEvent::DriverEvent {
                driver_kind: DriverKind::TokenUsage,
                ..
            })
        ));
        match iter.next().expect("tool_call") {
            DirectEvent::ToolCall {
                id, tool, params, ..
            } => {
                assert_eq!(id.as_str(), "call-1");
                assert_eq!(tool, "Read");
                assert!(
                    params.get("file_path").is_some(),
                    "params forwarded: {params}"
                );
            }
            other => panic!("expected ToolCall, got {other:?}"),
        }
        match iter.next().expect("tool_result") {
            DirectEvent::ToolResult {
                id,
                is_error,
                output,
            } => {
                assert_eq!(id.as_str(), "call-1");
                assert!(!is_error, "Read of real file succeeds: {output}");
            }
            other => panic!("expected ToolResult, got {other:?}"),
        }
        let kinds: Vec<&'static str> = iter
            .map(|e| match e {
                DirectEvent::TextDelta { .. } => "text_delta",
                DirectEvent::TextEnd => "text_end",
                DirectEvent::DriverEvent { .. } => "driver_event",
                DirectEvent::TurnEnd => "turn_end",
                DirectEvent::SessionComplete { .. } => "session_complete",
                other => panic!("unexpected trailing event {other:?}"),
            })
            .collect();
        assert_eq!(
            kinds,
            vec![
                "driver_event",
                "text_delta",
                "text_end",
                "turn_end",
                "session_complete",
            ],
        );
    }

    #[tokio::test]
    async fn failed_turn_closes_before_controlled_completion() {
        let client = ScriptedClient::new(Vec::new());
        let (mut stdin_host, stdin_runner) = tokio::io::duplex(4096);
        let (stdout_runner, stdout_host) = tokio::io::duplex(4096);
        let runner = tokio::spawn(run_session(
            client,
            sample_config(None),
            tokio::io::BufReader::new(stdin_runner),
            stdout_runner,
        ));
        let mut stdout = tokio::io::BufReader::new(stdout_host);

        stdin_host
            .write_all(
                command_frame(&DirectCommand::Prompt {
                    message: "fail".to_string(),
                })
                .as_bytes(),
            )
            .await
            .expect("write prompt");
        stdin_host.flush().await.expect("flush prompt");
        assert!(matches!(
            next_direct_event(&mut stdout).await,
            DirectEvent::Error { .. }
        ));
        assert!(matches!(
            next_direct_event(&mut stdout).await,
            DirectEvent::TurnEnd
        ));
        stdin_host
            .write_all(command_frame(&DirectCommand::Complete).as_bytes())
            .await
            .expect("write complete");
        stdin_host.flush().await.expect("flush complete");
        assert!(matches!(
            next_direct_event(&mut stdout).await,
            DirectEvent::SessionComplete { exit_code: 1, .. }
        ));
        runner
            .await
            .expect("runner task joins")
            .expect("run_session completes");
    }

    /// Malformed JSONL on stdin emits an Error frame but does not crash
    /// the runner; the session-complete still fires at EOF so the host
    /// observes a clean termination.
    #[test]
    fn malformed_command_emits_error_and_keeps_session_alive() {
        let client = ScriptedClient::new(Vec::new());
        let stdin = b"not json\n".to_vec();
        let mut stdout: Vec<u8> = Vec::new();

        tokio_test::block_on(run_session(
            client,
            sample_config(None),
            tokio::io::BufReader::new(&stdin[..]),
            &mut stdout,
        ))
        .expect("run_session completes");

        let events: Vec<DirectEvent> = std::str::from_utf8(&stdout)
            .expect("utf-8")
            .lines()
            .map(|l| serde_json::from_str(l).expect("parse"))
            .collect();
        assert_eq!(events.len(), 2);
        assert!(
            matches!(events[0], DirectEvent::Error { .. }),
            "first event Error: {:?}",
            events[0],
        );
        match &events[1] {
            DirectEvent::SessionComplete { exit_code, .. } => assert_eq!(*exit_code, 1),
            other => panic!("expected SessionComplete, got {other:?}"),
        }
    }

    /// Client that captures every [`CompletionRequest`] the runner
    /// constructs into a shared [`Arc<Mutex<Vec<_>>>`] so a test can
    /// inspect the lowered messages and tool definitions without
    /// reaching a live provider. The shared handle stays alive after
    /// `run_session` consumes the client.
    type CapturedRequests = std::sync::Arc<Mutex<Vec<CompletionRequest>>>;

    struct CapturingClient {
        captured: CapturedRequests,
        response: CompletionResponse,
    }

    impl CapturingClient {
        fn new(response: CompletionResponse) -> (Self, CapturedRequests) {
            let captured = std::sync::Arc::new(Mutex::new(Vec::new()));
            (
                Self {
                    captured: captured.clone(),
                    response,
                },
                captured,
            )
        }
    }

    impl LlmClient for CapturingClient {
        fn schema(&self) -> SchemaKind {
            SchemaKind::Anthropic
        }

        fn supports(&self, _model: &ModelId) -> bool {
            true
        }

        fn complete(
            &self,
            req: CompletionRequest,
        ) -> BoxFuture<'_, Result<CompletionResponse, LlmError>> {
            Box::pin(async move {
                self.captured
                    .lock()
                    .unwrap_or_else(std::sync::PoisonError::into_inner)
                    .push(req);
                Ok(self.response.clone())
            })
        }

        fn complete_structured_raw(
            &self,
            _req: CompletionRequest,
            _schema: serde_json::Value,
            _type_name: String,
        ) -> BoxFuture<'_, Result<String, LlmError>> {
            Box::pin(async move {
                Err(LlmError::Provider {
                    message: "structured not used in runner tests".into(),
                })
            })
        }
    }

    fn command_frame(cmd: &DirectCommand) -> String {
        let mut line = serde_json::to_string(cmd).expect("command serializes");
        line.push('\n');
        line
    }

    async fn next_direct_event<R>(reader: &mut R) -> DirectEvent
    where
        R: AsyncBufRead + Unpin + Send,
    {
        let mut line = String::new();
        let read = SystemClock::new()
            .timeout(Duration::from_secs(5), reader.read_line(&mut line))
            .await
            .expect("Direct event within timeout")
            .expect("read Direct event");
        assert_ne!(read, 0, "stdout closed before next Direct event");
        serde_json::from_str(line.trim_end()).expect("parse Direct event")
    }

    fn forced_budget_planning_request() -> CompletionRequest {
        let (client, captured) = CapturingClient::new(final_text("ok"));
        let stale_history = [
            "ordinary history alpha: prior assistant summary and tool chatter".repeat(8),
            "ordinary history beta: stale grep/read/bash outputs".repeat(8),
        ];
        let current_prompt = "Current request: continue the planning interview.";
        let stdin = [
            command_frame(&DirectCommand::Prompt {
                message: PLANNING_PROMPT_INTERVIEW_MODES.to_string(),
            }),
            command_frame(&DirectCommand::Steer {
                message: stale_history[0].clone(),
            }),
            command_frame(&DirectCommand::Steer {
                message: stale_history[1].clone(),
            }),
            command_frame(&DirectCommand::Prompt {
                message: current_prompt.to_string(),
            }),
        ]
        .concat()
        .into_bytes();
        let mut stdout: Vec<u8> = Vec::new();

        tokio_test::block_on(run_session_with_context_budget(
            client,
            sample_config(Some("claude-sonnet-4-6")),
            tokio::io::BufReader::new(&stdin[..]),
            &mut stdout,
            ContextBudget::max_request_bytes(1),
        ))
        .expect("run_session completes");

        let requests = captured
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone();
        assert_eq!(
            requests.len(),
            4,
            "the initial prompt, two steers, and current prompt each reach the client",
        );
        requests.last().expect("current prompt request").clone()
    }

    fn assert_pinned_planning_prompt_survives(request: &CompletionRequest) {
        let texts: Vec<String> = request.messages.iter().map(Message::text_content).collect();
        assert_eq!(
            texts,
            vec![
                PLANNING_PROMPT_INTERVIEW_MODES.to_string(),
                "Current request: continue the planning interview.".to_string(),
            ],
            "forced budget should keep the pinned initial prompt and active turn only",
        );
        let request_text = texts.join("\n---\n");
        assert!(
            request_text.contains(POLISH_MODE_DEFINITION),
            "polish mode definition missing from request: {request_text}",
        );
        assert!(
            request_text.contains(ONE_BY_ONE_MODE_DEFINITION),
            "one-by-one mode definition missing from request: {request_text}",
        );
        assert!(
            request_text.contains("## Context Pinning"),
            "instruction/context section missing from request: {request_text}",
        );
        assert!(
            request_text.contains("## Final Protocol"),
            "phase protocol section missing from request: {request_text}",
        );
        assert!(
            !request_text.contains("ordinary history alpha"),
            "ordinary history alpha should be trimmed before pinned prompt: {request_text}",
        );
        assert!(
            !request_text.contains("ordinary history beta"),
            "ordinary history beta should be trimmed before pinned prompt: {request_text}",
        );
    }

    /// Direct context-budget trimming treats the first rendered phase
    /// prompt as pinned instruction context. Under forced byte pressure,
    /// ordinary history is dropped while the planning prompt's Interview
    /// Modes section stays verbatim in the LLM request.
    #[test]
    fn direct_context_budget_preserves_initial_prompt_pin() {
        let request = forced_budget_planning_request();
        assert_pinned_planning_prompt_survives(&request);
    }

    /// Hard-limit fallback preserves instruction, phase protocol, and
    /// mode sections before ordinary transcript turns. This is the
    /// Direct-backed verifier for the harness compaction-recovery
    /// fallback contract.
    #[test]
    fn hard_limit_fallback_preserves_pinned_instruction_sections() {
        let request = forced_budget_planning_request();
        assert_pinned_planning_prompt_survives(&request);
    }

    /// A steer sent after the host observes the first `turn_end` starts the
    /// next Conversation turn. Completion is withheld until that turn's own
    /// steering window closes.
    #[tokio::test]
    async fn direct_runner_steer_reaches_next_conversation_turn() {
        let (client, captured) = CapturingClient::new(final_text("ok"));
        let (mut stdin_host, stdin_runner) = tokio::io::duplex(4096);
        let (stdout_runner, stdout_host) = tokio::io::duplex(4096);
        let runner = tokio::spawn(run_session(
            client,
            sample_config(Some("claude-sonnet-4-6")),
            tokio::io::BufReader::new(stdin_runner),
            stdout_runner,
        ));
        let mut stdout = tokio::io::BufReader::new(stdout_host);
        let parser = loom_agent::direct::backend::DirectParser;

        let prompt = parser
            .encode_prompt("orient me on spec X")
            .expect("encode prompt");
        stdin_host
            .write_all(prompt.as_bytes())
            .await
            .expect("write prompt");
        stdin_host.flush().await.expect("flush prompt");
        loop {
            let event = next_direct_event(&mut stdout).await;
            assert!(
                !matches!(event, DirectEvent::SessionComplete { .. }),
                "session completed before first steering window",
            );
            if matches!(event, DirectEvent::TurnEnd) {
                break;
            }
        }

        let steer = parser.encode_steer("focus on cache").expect("encode steer");
        stdin_host
            .write_all(steer.as_bytes())
            .await
            .expect("write steer");
        stdin_host.flush().await.expect("flush steer");
        loop {
            let event = next_direct_event(&mut stdout).await;
            assert!(
                !matches!(event, DirectEvent::SessionComplete { .. }),
                "session completed before steered turn ended",
            );
            if matches!(event, DirectEvent::TurnEnd) {
                break;
            }
        }

        let complete = parser
            .encode_complete()
            .expect("encode complete")
            .expect("Direct complete frame");
        stdin_host
            .write_all(complete.as_bytes())
            .await
            .expect("write complete");
        stdin_host.flush().await.expect("flush complete");
        assert!(matches!(
            next_direct_event(&mut stdout).await,
            DirectEvent::SessionComplete { exit_code: 0, .. }
        ));
        runner
            .await
            .expect("runner task joins")
            .expect("run_session completes");

        let requests = captured
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone();
        assert_eq!(requests.len(), 2, "the steer must drive a second turn");
        assert_eq!(
            requests[1]
                .messages
                .iter()
                .map(Message::text_content)
                .collect::<Vec<_>>(),
            vec!["orient me on spec X", "focus on cache"],
        );
    }

    #[tokio::test]
    async fn direct_cache_control_propagates_to_anthropic_request() {
        use wiremock::matchers::{method, path};
        use wiremock::{Mock, MockServer, ResponseTemplate};

        let server = MockServer::start().await;
        Mock::given(method("POST"))
            .and(path("/v1/messages"))
            .respond_with(ResponseTemplate::new(200).set_body_json(json!({
                "id": "msg-fixture", "type": "message", "role": "assistant",
                "model": "claude-sonnet-4-6", "content": [{"type": "text", "text": "ok"}],
                "stop_reason": "end_turn", "stop_sequence": null,
                "usage": {"input_tokens": 10, "output_tokens": 2},
            })))
            .expect(2)
            .mount(&server)
            .await;
        let client = AnthropicClient::new(ApiKey::new("fixture-key".into()).unwrap())
            .with_endpoint_for_test(format!("{}/v1/", server.uri()).parse().unwrap());
        let stdin = b"{\"type\":\"prompt\",\"message\":\"orient me on spec X\"}\n{\"type\":\"steer\",\"message\":\"focus on cache\"}\n";
        let mut stdout = Vec::new();
        run_session(
            client,
            sample_config(Some("claude-sonnet-4-6")),
            tokio::io::BufReader::new(&stdin[..]),
            &mut stdout,
        )
        .await
        .unwrap();

        let requests = server.received_requests().await.unwrap();
        assert_eq!(requests.len(), 2);
        for (request, prompts) in requests.iter().zip([
            vec!["orient me on spec X"],
            vec!["orient me on spec X", "focus on cache"],
        ]) {
            let body: Value = serde_json::from_slice(&request.body).unwrap();
            assert_eq!(body["model"], "claude-sonnet-4-6");
            let blocks: Vec<_> = body["messages"]
                .as_array()
                .unwrap()
                .iter()
                .flat_map(|message| message["content"].as_array().unwrap())
                .filter(|block| !block["cache_control"].is_null())
                .collect();
            assert_eq!(blocks.len(), prompts.len());
            for (block, prompt) in blocks.iter().zip(prompts) {
                assert_eq!(block["text"], prompt);
                assert_eq!(
                    block["cache_control"],
                    json!({"type": "ephemeral", "ttl": "1h"})
                );
            }
        }
        let events: Vec<DirectEvent> = std::str::from_utf8(&stdout)
            .unwrap()
            .lines()
            .map(|line| serde_json::from_str(line).unwrap())
            .collect();
        assert!(
            !events
                .iter()
                .any(|event| matches!(event, DirectEvent::Error { .. })),
            "{events:?}"
        );
        assert_eq!(
            events
                .iter()
                .filter(|event| matches!(
                    event,
                    DirectEvent::DriverEvent {
                        driver_kind: DriverKind::TokenUsage,
                        ..
                    }
                ))
                .count(),
            2
        );
    }

    /// Spec contract (`specs/agent.md` § Direct Backend):
    /// `DriverKind::TokenUsage` event emits on every completion within
    /// Direct sessions. The runner wraps the LLM client so each
    /// `complete*` call records its `TokenUsage`; the typed driver frame
    /// reaches stdout in turn-completion order and the host's parser lifts it into an
    /// `AgentEvent::DriverEvent { driver_kind: TokenUsage, .. }` with
    /// `source: Source::Driver`.
    #[test]
    fn direct_emits_token_usage_per_completion() {
        let dir = tempfile::tempdir().expect("tempdir");
        let cargo = dir.path().join("Cargo.toml");
        std::fs::write(&cargo, "[package]\nname = \"x\"\n").expect("write fixture");

        let with_call = CompletionResponse {
            text: String::new(),
            usage: TokenUsage {
                input: 500,
                output: 120,
                cache_read: 200,
                cache_write: 50,
            },
            tool_calls: vec![ToolUseRequest {
                call_id: LlmToolCallId::parse("call-1").expect("test tool call id parses"),
                name: "Read".into(),
                args: json!({ "file_path": cargo }),
            }],
        };
        let final_resp = CompletionResponse {
            text: "done".into(),
            usage: TokenUsage {
                input: 800,
                output: 60,
                cache_read: 600,
                cache_write: 0,
            },
            tool_calls: Vec::new(),
        };

        let client = ScriptedClient::new(vec![with_call, final_resp]);
        let stdin = b"{\"type\":\"prompt\",\"message\":\"please read\"}\n".to_vec();
        let mut stdout: Vec<u8> = Vec::new();

        tokio_test::block_on(run_session(
            client,
            sample_config(Some("claude-sonnet-4-6")),
            tokio::io::BufReader::new(&stdin[..]),
            &mut stdout,
        ))
        .expect("run_session completes");

        let events: Vec<DirectEvent> = std::str::from_utf8(&stdout)
            .expect("utf-8")
            .lines()
            .map(|l| serde_json::from_str(l).expect("parse"))
            .collect();

        let usages: Vec<&DirectEvent> = events
            .iter()
            .filter(|e| {
                matches!(
                    e,
                    DirectEvent::DriverEvent {
                        driver_kind: DriverKind::TokenUsage,
                        ..
                    }
                )
            })
            .collect();
        assert_eq!(
            usages.len(),
            2,
            "one token-usage driver frame per completion (two completions for a tool-using turn): {events:?}",
        );

        match usages[0] {
            DirectEvent::DriverEvent { payload, .. } => {
                assert_eq!(payload["model"], "claude-sonnet-4-6");
                assert_eq!(payload["input"], 500);
                assert_eq!(payload["output"], 120);
                assert_eq!(payload["cache_read"], 200);
                assert_eq!(payload["cache_write"], 50);
            }
            other => panic!("expected token usage DriverEvent, got {other:?}"),
        }
        match usages[1] {
            DirectEvent::DriverEvent { payload, .. } => {
                assert_eq!(payload["model"], "claude-sonnet-4-6");
                assert_eq!(payload["input"], 800);
                assert_eq!(payload["output"], 60);
                assert_eq!(payload["cache_read"], 600);
                assert_eq!(payload["cache_write"], 0);
            }
            other => panic!("expected token usage DriverEvent, got {other:?}"),
        }
    }

    #[test]
    fn direct_runner_emits_observer_driver_events() {
        let dir = tempfile::tempdir().expect("tempdir");
        let target = dir.path().join("large.txt");
        std::fs::write(&target, "x".repeat(300)).expect("write fixture");
        let repeated_read = || CompletionResponse {
            text: String::new(),
            usage: TokenUsage::default(),
            tool_calls: vec![ToolUseRequest {
                call_id: LlmToolCallId::parse("call-read").expect("test tool call id parses"),
                name: "Read".into(),
                args: json!({ "file_path": target.clone() }),
            }],
        };
        let client = ScriptedClient::new(vec![
            repeated_read(),
            repeated_read(),
            repeated_read(),
            final_text("done"),
        ]);
        let stdin = b"{\"type\":\"prompt\",\"message\":\"please read\"}\n".to_vec();
        let mut stdout: Vec<u8> = Vec::new();

        tokio_test::block_on(run_session(
            client,
            sample_config(Some("claude-sonnet-4-6")),
            tokio::io::BufReader::new(&stdin[..]),
            &mut stdout,
        ))
        .expect("run_session completes");

        let events: Vec<DirectEvent> = std::str::from_utf8(&stdout)
            .expect("utf-8")
            .lines()
            .map(|l| serde_json::from_str(l).expect("parse"))
            .collect();
        assert!(
            events.iter().any(|event| matches!(
                event,
                DirectEvent::DriverEvent {
                    driver_kind: DriverKind::DoomLoopTripped,
                    ..
                }
            )),
            "doom-loop observer payload must reach the Direct wire: {events:?}",
        );
        assert!(
            events.iter().any(|event| matches!(
                event,
                DirectEvent::DriverEvent {
                    driver_kind: DriverKind::DuplicateToolResult,
                    ..
                }
            )),
            "duplicate-result observer payload must reach the Direct wire: {events:?}",
        );
    }

    /// Spec contract (`specs/agent.md` § Direct output bounding): every
    /// successful offload emits a driver event carrying the tool name and
    /// offloaded byte count. The test drives a real `Read` tool call over
    /// the cap, observes the runner's offload driver frame, and
    /// verifies the host-side lift produces a `driver_event` with
    /// `DriverKind::Offload`.
    #[test]
    fn offload_emits_driver_event_with_tool_and_byte_count() {
        let dir = tempfile::tempdir().expect("tempdir");
        let target = dir.path().join("large.txt");
        let body = "alpha\nbeta\n";
        std::fs::write(&target, body).expect("write fixture");

        let with_call = CompletionResponse {
            text: String::new(),
            usage: TokenUsage::default(),
            tool_calls: vec![ToolUseRequest {
                call_id: LlmToolCallId::parse("call-1").expect("test tool call id parses"),
                name: "Read".into(),
                args: json!({ "file_path": target }),
            }],
        };
        let client = ScriptedClient::new(vec![with_call, final_text("done")]);
        let stdin = b"{\"type\":\"prompt\",\"message\":\"please read\"}\n".to_vec();
        let mut stdout: Vec<u8> = Vec::new();
        let mut config = sample_config(Some("claude-sonnet-4-6"));
        config.scratch_dir = dir.path().join("scratch");
        config.output_limits = Some(OutputLimits {
            max_inline_bytes: "alpha".len().try_into().unwrap(),
        });

        tokio_test::block_on(run_session(
            client,
            config,
            tokio::io::BufReader::new(&stdin[..]),
            &mut stdout,
        ))
        .expect("run_session completes");

        let events: Vec<DirectEvent> = std::str::from_utf8(&stdout)
            .expect("utf-8")
            .lines()
            .map(|l| serde_json::from_str(l).expect("parse"))
            .collect();
        let offloads: Vec<&DirectEvent> = events
            .iter()
            .filter(|event| {
                matches!(
                    event,
                    DirectEvent::DriverEvent {
                        driver_kind: DriverKind::Offload,
                        ..
                    }
                )
            })
            .collect();
        assert_eq!(offloads.len(), 1, "one offload event: {events:?}");

        let offload = offloads[0];
        match offload {
            DirectEvent::DriverEvent { payload, .. } => {
                assert_eq!(payload["tool"], "Read");
                assert_eq!(payload["total_bytes"], body.len());
            }
            other => panic!("expected offload DriverEvent, got {other:?}"),
        }

        let mut builder = EnvelopeBuilder::new(
            SessionScope::bead(
                SessionId::new("sess-test").unwrap(),
                BeadId::new("lm-test").expect("valid id"),
                None,
                0,
            ),
            Source::Agent,
            || 1,
        );
        let agent_event = AgentEvent::from_parsed(offload.clone().into_parsed(), builder.build());
        match agent_event {
            AgentEvent::DriverEvent {
                envelope,
                driver_kind,
                summary,
                payload,
            } => {
                assert_eq!(envelope.source, Source::Driver);
                assert_eq!(driver_kind, DriverKind::Offload);
                assert_eq!(summary, format!("Read offloaded {} bytes", body.len()));
                assert_eq!(payload["tool"], "Read");
                assert_eq!(payload["total_bytes"], body.len());
            }
            other => panic!("expected DriverEvent, got {other:?}"),
        }
    }

    #[tokio::test]
    async fn abort_during_active_turn_cancels_conversation_and_completes() {
        let started = std::sync::Arc::new(tokio::sync::Notify::new());
        let client = BlockingClient {
            started: started.clone(),
        };
        let (mut stdin_host, stdin_runner) = tokio::io::duplex(4096);
        let (stdout_runner, stdout_host) = tokio::io::duplex(4096);
        let runner = tokio::spawn(run_session(
            client,
            sample_config(None),
            tokio::io::BufReader::new(stdin_runner),
            stdout_runner,
        ));
        let mut stdout = tokio::io::BufReader::new(stdout_host);

        stdin_host
            .write_all(
                command_frame(&DirectCommand::Prompt {
                    message: "wait".to_string(),
                })
                .as_bytes(),
            )
            .await
            .expect("write prompt");
        stdin_host.flush().await.expect("flush prompt");
        SystemClock::new()
            .timeout(Duration::from_secs(5), started.notified())
            .await
            .expect("active Conversation turn starts");
        stdin_host
            .write_all(command_frame(&DirectCommand::Abort).as_bytes())
            .await
            .expect("write abort");
        stdin_host.flush().await.expect("flush abort");

        assert!(matches!(
            next_direct_event(&mut stdout).await,
            DirectEvent::SessionComplete { exit_code: 0, .. }
        ));
        runner
            .await
            .expect("runner task joins")
            .expect("run_session completes");
    }

    /// `abort` halts the session immediately and emits a clean
    /// `session_complete` — no remaining stdin frames are processed.
    #[test]
    fn abort_command_terminates_loop_with_zero_exit() {
        let client = ScriptedClient::new(Vec::new());
        let stdin =
            b"{\"type\":\"abort\"}\n{\"type\":\"prompt\",\"message\":\"never seen\"}\n".to_vec();
        let mut stdout: Vec<u8> = Vec::new();

        tokio_test::block_on(run_session(
            client,
            sample_config(None),
            tokio::io::BufReader::new(&stdin[..]),
            &mut stdout,
        ))
        .expect("run_session completes");

        let events: Vec<DirectEvent> = std::str::from_utf8(&stdout)
            .expect("utf-8")
            .lines()
            .map(|l| serde_json::from_str(l).expect("parse"))
            .collect();
        assert_eq!(events.len(), 1);
        match &events[0] {
            DirectEvent::SessionComplete { exit_code, .. } => assert_eq!(*exit_code, 0),
            other => panic!("expected SessionComplete, got {other:?}"),
        }
    }
}
