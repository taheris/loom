//! Per-tool summary cells + body formatters.
//!
//! Each builtin tool gets a tailored one-line summary cell. Human modes
//! cap body at the Direct inline byte budget (16 KiB by default) with a
//! raw-log recovery hint line.
//!
//! ## Summary cells (per spec table)
//!
//! | Tool      | Cell                                                |
//! |-----------|-----------------------------------------------------|
//! | Read      | `<path>:<line-range>   <N> lines`                   |
//! | Edit      | `<path>   +<add> -<del>   diff↓`                    |
//! | Write     | `<path>   +<lines>   new file`                      |
//! | Grep      | `"<pattern>" in <path>   <N> files`                 |
//! | Glob      | `"<pattern>" in <path>   <N> files`                 |
//! | Bash      | `<cmd-truncated>   <duration> <✓\|✗ exit=N>`         |
//! | `WebFetch`  | `<url>   <bytes> <duration> <✓\|✗>`                |
//! | `WebSearch` | `"<query>"   <N> results`                         |
//! | Task      | `<description>   [agent:<subagent>]   <duration>`   |
//!
//! Unknown tools fall through to a generic `<tool>` cell.

use std::path::{Path, PathBuf};

use serde_json::Value;

use crate::osc8;

/// Default renderer byte budget for inline tool bodies.
pub const BODY_CAP_BYTES: usize = 16 * 1024;

/// OSC 8 support and workspace context for path-bearing summary cells.
///
/// Constructed once per renderer at session start — environment
/// detection lives at the call site, not inside this struct, so tests
/// can pin both branches without env mutation.
#[derive(Debug, Clone)]
#[must_use]
pub struct Osc8Context {
    pub supported: bool,
    pub cwd: PathBuf,
}

impl Osc8Context {
    /// OSC 8 wrapping suppressed — every `wrap` call returns the
    /// display string unchanged. Used by non-Pretty render modes and
    /// the default case when no terminal capability has been probed.
    pub const fn disabled() -> Self {
        Self {
            supported: false,
            cwd: PathBuf::new(),
        }
    }

    /// OSC 8 wrapping active. `cwd` is the workspace root, used to
    /// turn relative paths into absolute `file://` URLs so cmd-click
    /// resolves correctly regardless of the terminal's working dir.
    pub const fn enabled(cwd: PathBuf) -> Self {
        Self {
            supported: true,
            cwd,
        }
    }

    /// Set the workspace root on a context built via [`Self::disabled`]. Used
    /// when OSC 8 is unsupported but path normalization should still
    /// strip the workspace prefix from absolute paths in summary cells.
    pub fn with_cwd(mut self, cwd: PathBuf) -> Self {
        self.cwd = cwd;
        self
    }
}

impl Default for Osc8Context {
    fn default() -> Self {
        Self::disabled()
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ToolKind {
    Read,
    Edit,
    Write,
    Grep,
    Glob,
    Bash,
    WebFetch,
    WebSearch,
    Task,
}

pub(crate) fn tool_kind(tool: &str) -> Option<ToolKind> {
    let normalized = tool.trim().to_ascii_lowercase().replace(['-', ' '], "_");
    match normalized.as_str() {
        "read" | "read_file" => Some(ToolKind::Read),
        "edit" => Some(ToolKind::Edit),
        "write" => Some(ToolKind::Write),
        "grep" => Some(ToolKind::Grep),
        "glob" => Some(ToolKind::Glob),
        "bash" | "shell" | "run_shell" | "run_shell_command" => Some(ToolKind::Bash),
        "webfetch" | "web_fetch" => Some(ToolKind::WebFetch),
        "websearch" | "web_search" => Some(ToolKind::WebSearch),
        "task" => Some(ToolKind::Task),
        _ => None,
    }
}

pub(crate) fn renders_body_by_default(tool: &str) -> bool {
    matches!(
        tool_kind(tool),
        Some(
            ToolKind::Read
                | ToolKind::Bash
                | ToolKind::Grep
                | ToolKind::Glob
                | ToolKind::WebFetch
                | ToolKind::WebSearch
                | ToolKind::Task
        )
    )
}

/// Build a tool call's one-line summary cell.
pub fn summary_cell(tool: &str, params: &Value, osc8: &Osc8Context) -> String {
    match tool_kind(tool) {
        Some(ToolKind::Read) => read_summary(params, osc8),
        Some(ToolKind::Edit) => edit_summary(params, osc8),
        Some(ToolKind::Write) => write_summary(params, osc8),
        Some(ToolKind::Grep) => grep_or_glob_summary("Grep", params, osc8),
        Some(ToolKind::Glob) => grep_or_glob_summary("Glob", params, osc8),
        Some(ToolKind::Bash) => bash_summary(params),
        Some(ToolKind::WebFetch) => webfetch_summary(params, osc8),
        Some(ToolKind::WebSearch) => websearch_summary(params),
        Some(ToolKind::Task) => task_summary(params),
        None => tool.to_string(),
    }
}

fn string_param<'a>(params: &'a Value, keys: &[&str]) -> &'a str {
    keys.iter()
        .find_map(|key| params.get(key).and_then(Value::as_str))
        .unwrap_or("")
}

fn read_summary(params: &Value, osc8: &Osc8Context) -> String {
    let path = string_param(params, &["file_path", "path"]);
    let offset = params.get("offset").and_then(Value::as_i64);
    let limit = params.get("limit").and_then(Value::as_i64);
    let range = match (offset, limit) {
        (Some(o), Some(l)) => format!(":{o}-{}", o + l),
        (Some(o), None) => format!(":{o}-"),
        _ => String::new(),
    };
    let display_path = normalize_for_display(&osc8.cwd, path);
    let display = format!("{display_path}{range}");
    let line = offset.and_then(|o| u32::try_from(o).ok());
    let wrapped = wrap_path(osc8, path, line, &display);
    format!("Read   {wrapped}")
}

fn edit_summary(params: &Value, osc8: &Osc8Context) -> String {
    let path = string_param(params, &["file_path", "path"]);
    let old = string_param(params, &["old_string", "old"]);
    let new = string_param(params, &["new_string", "new"]);
    let (add, del) = diff_counts(old, new);
    let display = normalize_for_display(&osc8.cwd, path);
    let wrapped = wrap_path(osc8, path, None, &display);
    format!("Edit   {wrapped}   +{add} -{del}   diff↓")
}

fn write_summary(params: &Value, osc8: &Osc8Context) -> String {
    let path = string_param(params, &["file_path", "path"]);
    let content = string_param(params, &["content"]);
    let lines = content.lines().count();
    let display = normalize_for_display(&osc8.cwd, path);
    let wrapped = wrap_path(osc8, path, None, &display);
    format!("Write   {wrapped}   +{lines}   new file")
}

fn grep_or_glob_summary(tool: &str, params: &Value, osc8: &Osc8Context) -> String {
    let pattern = string_param(params, &["pattern", "query"]);
    let path = string_param(params, &["path", "file_path"]);
    let display = normalize_for_display(&osc8.cwd, path);
    let wrapped = wrap_path(osc8, path, None, &display);
    format!("{tool}   \"{pattern}\" in {wrapped}")
}

fn bash_summary(params: &Value) -> String {
    let cmd = string_param(params, &["command", "cmd"]);
    let truncated = truncate(cmd, 60);
    format!("Bash   {truncated}")
}

fn webfetch_summary(params: &Value, osc8: &Osc8Context) -> String {
    let url = string_param(params, &["url"]);
    let wrapped = if osc8.supported && !url.is_empty() {
        osc8::wrap(url, url, true)
    } else {
        url.to_string()
    };
    format!("WebFetch   {wrapped}")
}

fn wrap_path(osc8: &Osc8Context, path: &str, line: Option<u32>, display: &str) -> String {
    if !osc8.supported || path.is_empty() {
        return display.to_string();
    }
    let url = osc8::file_url(Path::new(&osc8.cwd), path, line);
    osc8::wrap(&url, display, true)
}

/// Strip the workspace prefix from an absolute display path when possible.
pub fn normalize_for_display(cwd: &Path, path: &str) -> String {
    if path.is_empty() || cwd.as_os_str().is_empty() {
        return path.to_string();
    }
    let abs = Path::new(path);
    if !abs.is_absolute() {
        return path.to_string();
    }
    match abs.strip_prefix(cwd) {
        Ok(rel) => {
            let rel_str = rel.to_string_lossy();
            if rel_str.is_empty() {
                ".".to_string()
            } else {
                rel_str.into_owned()
            }
        }
        Err(_) => path.to_string(),
    }
}

fn websearch_summary(params: &Value) -> String {
    let query = string_param(params, &["query"]);
    format!("WebSearch   \"{query}\"")
}

fn task_summary(params: &Value) -> String {
    let description = string_param(params, &["description", "prompt"]);
    let subagent = string_param(params, &["subagent_type", "agent", "agent_type"]);
    format!("Task   {description}   [agent:{subagent}]")
}

/// Compute `(added, removed)` line counts between two strings via
/// imara-diff. Used by Edit summary cells.
pub fn diff_counts(old: &str, new: &str) -> (usize, usize) {
    use imara_diff::{Algorithm, Diff, InternedInput};

    let input = InternedInput::new(old, new);
    let diff = Diff::compute(Algorithm::Histogram, &input);
    diff.hunks().fold((0, 0), |(added, removed), hunk| {
        (
            added + (hunk.after.end - hunk.after.start) as usize,
            removed + (hunk.before.end - hunk.before.start) as usize,
        )
    })
}

/// Truncate `s` to `max` chars, appending `…` if it exceeded.
pub fn truncate(s: &str, max: usize) -> String {
    let cleaned: String = s.chars().take_while(|c| *c != '\n').collect();
    if cleaned.chars().count() <= max {
        cleaned
    } else {
        let mut out: String = cleaned.chars().take(max.saturating_sub(1)).collect();
        out.push('…');
        out
    }
}

/// Cap a body to the default byte budget. When the cap trims content,
/// appends a recovery hint pointing at raw replay.
pub fn cap_body(body: &str, bead_id: &str, tool_call_id: &str) -> String {
    cap_body_with_limit(body, bead_id, tool_call_id, BODY_CAP_BYTES)
}

pub(crate) fn cap_body_with_limit(
    body: &str,
    bead_id: &str,
    tool_call_id: &str,
    max_bytes: usize,
) -> String {
    if let Some(offload_body) = offload_reference_body(body) {
        return offload_body;
    }
    if body.len() <= max_bytes {
        return body.to_string();
    }
    let prefix = utf8_prefix_at_byte_limit(body, max_bytes);
    let remaining = body.len() - prefix.len();
    let mut capped = prefix.to_string();
    if !capped.is_empty() && !capped.ends_with('\n') {
        capped.push('\n');
    }
    capped.push_str(&truncation_hint(
        remaining,
        max_bytes,
        bead_id,
        tool_call_id,
    ));
    capped
}

pub(crate) fn utf8_prefix_at_byte_limit(body: &str, max_bytes: usize) -> &str {
    let mut end = max_bytes.min(body.len());
    while !body.is_char_boundary(end) {
        end -= 1;
    }
    &body[..end]
}

fn offload_reference_body(body: &str) -> Option<String> {
    let trimmed = body.trim_start();
    if !trimmed.starts_with('{') || !trimmed.contains("\"offloaded\"") {
        return None;
    }
    let value: Value = serde_json::from_str(trimmed).ok()?;
    let object = value.as_object()?;
    if object.get("offloaded").and_then(Value::as_bool) != Some(true) {
        return None;
    }
    if let Some(head) = object.get("head").and_then(Value::as_str)
        && !head.is_empty()
    {
        return Some(head.to_string());
    }
    let path = object.get("path").and_then(Value::as_str)?;
    let total = object.get("total_bytes").and_then(Value::as_u64);
    Some(match total {
        Some(bytes) => format!("[offloaded: {bytes} bytes; full output at {path}]"),
        None => format!("[offloaded: full output at {path}]"),
    })
}

pub(crate) fn truncation_hint(
    remaining_bytes: usize,
    max_bytes: usize,
    bead_id: &str,
    tool_call_id: &str,
) -> String {
    format!(
        "  [display-only cap at {max_bytes} bytes; {remaining_bytes} bytes omitted; run `loom logs --raw -b {bead_id}` for observed event bytes; tool {tool_call_id}]"
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn disabled() -> Osc8Context {
        Osc8Context::disabled()
    }

    #[test]
    fn read_summary_includes_path_and_range() {
        let cell = summary_cell(
            "Read",
            &json!({"file_path": "src/lib.rs", "offset": 10, "limit": 20}),
            &disabled(),
        );
        assert!(cell.contains("src/lib.rs"), "{cell}");
        assert!(cell.contains(":10-30"), "{cell}");
    }

    #[test]
    fn edit_summary_includes_added_removed_counts() {
        let cell = summary_cell(
            "Edit",
            &json!({
                "file_path": "src/lib.rs",
                "old_string": "fn old() {}\n",
                "new_string": "fn new() {}\nfn extra() {}\n",
            }),
            &disabled(),
        );
        assert!(cell.contains("src/lib.rs"));
        assert!(cell.contains('+'));
        assert!(cell.contains('-'));
        assert!(cell.contains("diff"));
    }

    #[test]
    fn write_summary_includes_path_and_line_count() {
        let cell = summary_cell(
            "Write",
            &json!({"file_path": "src/new.rs", "content": "a\nb\nc\n"}),
            &disabled(),
        );
        assert!(cell.contains("src/new.rs"));
        assert!(cell.contains("+3"));
        assert!(cell.contains("new file"));
    }

    #[test]
    fn bash_summary_truncates_long_commands() {
        let cmd = "echo ".to_owned() + &"x".repeat(100);
        let cell = summary_cell("Bash", &json!({"command": cmd}), &disabled());
        assert!(cell.contains("Bash"));
        // 60-char cap leaves room for the leading "Bash   "
        let body_part = cell.trim_start_matches("Bash").trim();
        assert!(body_part.ends_with('…'), "{cell}");
    }

    #[test]
    fn lowercase_tool_aliases_use_summary_cells() {
        let read = summary_cell("read", &json!({"path": "src/lib.rs"}), &disabled());
        assert!(read.contains("Read"), "{read}");
        assert!(read.contains("src/lib.rs"), "{read}");

        let bash = summary_cell("bash", &json!({"cmd": "cargo test"}), &disabled());
        assert!(bash.contains("Bash"), "{bash}");
        assert!(bash.contains("cargo test"), "{bash}");
    }

    #[test]
    fn task_summary_includes_subagent_label() {
        let cell = summary_cell(
            "Task",
            &json!({
                "description": "Review changes",
                "subagent_type": "code-reviewer",
            }),
            &disabled(),
        );
        assert!(cell.contains("Task"));
        assert!(cell.contains("Review changes"));
        assert!(cell.contains("[agent:code-reviewer]"));
    }

    #[test]
    fn unknown_tool_falls_through_to_name() {
        assert_eq!(
            summary_cell("CustomTool", &json!({}), &disabled()),
            "CustomTool",
        );
    }

    /// Read/Edit/Write/Grep paths wrap in OSC 8 when supported. The
    /// display text stays the same; the escape brackets it.
    #[test]
    fn enabled_osc8_wraps_read_path() {
        let ctx = Osc8Context::enabled(PathBuf::from("/workspace"));
        let cell = summary_cell(
            "Read",
            &json!({"file_path": "src/lib.rs", "offset": 42, "limit": 0}),
            &ctx,
        );
        // OSC 8 wrap brackets the path; the start marker carries the
        // file URL with the line-number fragment from `offset`.
        assert!(
            cell.contains("\x1b]8;;file:///workspace/src/lib.rs#L42"),
            "{cell:?}"
        );
        assert!(cell.contains("src/lib.rs"), "{cell:?}");
        // BEL terminator after the display string.
        assert!(cell.contains('\x07'), "{cell:?}");
    }

    /// `WebFetch` URL wraps the same URL as both target and display so
    /// cmd-click opens the browser at the visible URL.
    #[test]
    fn enabled_osc8_wraps_webfetch_url() {
        let ctx = Osc8Context::enabled(PathBuf::from("/workspace"));
        let cell = summary_cell(
            "WebFetch",
            &json!({"url": "https://example.com/page"}),
            &ctx,
        );
        assert!(
            cell.contains("\x1b]8;;https://example.com/page"),
            "{cell:?}",
        );
    }

    /// `normalize_for_display` strips a leading workspace prefix so
    /// summary cells render repo-relative paths. The agent still uses
    /// the absolute form internally; this is display-only.
    #[test]
    fn normalize_for_display_strips_workspace_prefix() {
        let cwd = PathBuf::from("/workspace");
        assert_eq!(
            normalize_for_display(&cwd, "/workspace/src/lib.rs"),
            "src/lib.rs",
        );
        assert_eq!(
            normalize_for_display(&cwd, "/workspace/tests/foo.rs"),
            "tests/foo.rs",
        );
    }

    /// Already-relative paths pass through unchanged. Used by the
    /// agent's own relative-path calls.
    #[test]
    fn normalize_for_display_passes_relative_paths_through() {
        let cwd = PathBuf::from("/workspace");
        assert_eq!(normalize_for_display(&cwd, "src/lib.rs"), "src/lib.rs");
    }

    /// Paths outside the workspace render as-is (no aggressive "../"
    /// rewriting; absolute paths the agent uses for /tmp or system
    /// files stay readable).
    #[test]
    fn normalize_for_display_keeps_non_workspace_paths() {
        let cwd = PathBuf::from("/workspace");
        assert_eq!(normalize_for_display(&cwd, "/tmp/x.rs"), "/tmp/x.rs");
        assert_eq!(normalize_for_display(&cwd, "/etc/hosts"), "/etc/hosts");
    }

    /// Empty cwd disables normalization. Used by the `disabled`
    /// context when no workspace root has been configured.
    #[test]
    fn normalize_for_display_passthrough_when_cwd_empty() {
        let cwd = PathBuf::new();
        assert_eq!(
            normalize_for_display(&cwd, "/workspace/src/lib.rs"),
            "/workspace/src/lib.rs",
        );
    }

    /// Summary cells emit repo-relative paths even when the agent
    /// passes the absolute `/workspace/...` form. Pin the end-to-end
    /// path through `summary_cell` for the Read tool.
    #[test]
    fn read_summary_normalizes_absolute_workspace_path() {
        let ctx = Osc8Context::disabled().with_cwd(PathBuf::from("/workspace"));
        let cell = summary_cell("Read", &json!({"file_path": "/workspace/src/lib.rs"}), &ctx);
        assert!(cell.contains("src/lib.rs"), "{cell:?}");
        assert!(
            !cell.contains("/workspace/"),
            "absolute workspace prefix must be stripped: {cell:?}",
        );
    }

    /// Edit/Write/Grep cells also normalize. Walk each one with the
    /// same /workspace/... input to pin the consistent contract.
    #[test]
    fn edit_write_grep_summaries_normalize_paths() {
        let ctx = Osc8Context::disabled().with_cwd(PathBuf::from("/workspace"));
        for (tool, params) in [
            (
                "Edit",
                json!({
                    "file_path": "/workspace/a.rs",
                    "old_string": "x\n",
                    "new_string": "y\n",
                }),
            ),
            (
                "Write",
                json!({"file_path": "/workspace/a.rs", "content": "x"}),
            ),
            ("Grep", json!({"pattern": "TODO", "path": "/workspace/src"})),
        ] {
            let cell = summary_cell(tool, &params, &ctx);
            assert!(
                !cell.contains("/workspace/"),
                "{tool} cell still carries absolute workspace prefix: {cell:?}",
            );
        }
    }

    /// When OSC 8 is enabled, the URL must keep the absolute path
    /// (cmd-click needs to resolve it without depending on the
    /// terminal's cwd) but the display text is the relative form.
    #[test]
    fn osc8_enabled_keeps_absolute_url_with_relative_display() {
        let ctx = Osc8Context::enabled(PathBuf::from("/workspace"));
        let cell = summary_cell("Read", &json!({"file_path": "/workspace/src/lib.rs"}), &ctx);
        assert!(
            cell.contains("\x1b]8;;file:///workspace/src/lib.rs"),
            "OSC 8 URL must keep absolute path: {cell:?}",
        );
        // The display text after the BEL terminator is relative.
        assert!(
            cell.contains("\x07src/lib.rs\x1b]8;;"),
            "display text must be repo-relative: {cell:?}",
        );
    }

    /// Disabled context returns plain text — no escape bytes.
    #[test]
    fn disabled_osc8_leaves_text_unchanged() {
        let cell = summary_cell(
            "Read",
            &json!({"file_path": "src/lib.rs", "offset": 42, "limit": 0}),
            &disabled(),
        );
        assert!(!cell.contains('\x1b'), "no escapes when disabled: {cell:?}");
    }

    #[test]
    fn diff_counts_tracks_simple_replacement() {
        // imara-diff in histogram mode counts the changed-line spans.
        // A single-line replacement reports (1, 1).
        let (a, d) = diff_counts("old line\n", "new line\n");
        assert_eq!((a, d), (1, 1));
    }

    #[test]
    fn diff_counts_handles_pure_additions() {
        let (a, d) = diff_counts("a\n", "a\nb\nc\n");
        assert_eq!((a, d), (2, 0));
    }

    #[test]
    fn cap_body_keeps_short_bodies_unchanged() {
        let body = "line 1\nline 2\nline 3";
        assert_eq!(cap_body(body, "lm-1", "tc-1"), body);
    }

    #[test]
    fn default_tool_body_budget_has_no_line_cap() {
        let body: String = (1..=200)
            .map(|i| format!("line {i}"))
            .collect::<Vec<_>>()
            .join("\n");
        let out = cap_body(&body, "lm-1", "tc-1");
        assert_eq!(out, body);
        assert!(out.contains("line 200"), "{out}");
        assert!(!out.contains("display-only cap"), "{out}");
    }

    #[test]
    fn cap_body_preserves_offload_recovery_path() {
        let path = "/workspace/.loom/scratch/key/offload/payload.txt";
        let head = format!(
            "{}\n[truncated: full output at {path}; Read with offset 42 to continue]",
            "x".repeat(BODY_CAP_BYTES),
        );
        let body = json!({
            "offloaded": true,
            "path": path,
            "total_bytes": BODY_CAP_BYTES + 1,
            "total_lines": 99,
            "head_lines": 41,
            "head": head,
        })
        .to_string();

        let out = cap_body(&body, "lm-1", "tc-1");

        assert!(out.contains(path), "{out}");
        assert!(out.contains("Read with offset 42"), "{out}");
        assert!(!out.contains("display-only cap"), "{out}");
        assert!(!out.contains("\"offloaded\""), "{out}");
    }

    #[test]
    fn cap_body_truncates_over_byte_budget_with_recovery_hint() {
        let body = "x".repeat(BODY_CAP_BYTES + 20);
        let out = cap_body(&body, "lm-1", "tc-1");
        let (head, hint) = out.split_once('\n').expect("hint line");
        assert_eq!(head.len(), BODY_CAP_BYTES);
        assert!(hint.contains("display-only cap"), "{out}");
        assert!(hint.contains("20 bytes omitted"), "{out}");
        assert!(hint.contains("loom logs --raw -b lm-1"), "{out}");
        assert!(hint.contains("tool tc-1"), "{out}");
    }
}
