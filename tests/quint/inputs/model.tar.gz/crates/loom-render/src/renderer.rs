use std::io::{self, Write};
use std::sync::Arc;
use std::time::{Duration, Instant};

use serde_json::Value;

use crate::clock::{Clock, SystemClock};
use crate::in_place::CLEAR_TO_EOL;
use crate::tool_body;
use loom_events::identifier::{BeadId, ProfileName, ToolCallId};
use loom_events::{AgentEvent, InputKind};

/// Final outcome of a bead spawn — drives the closing line color and glyph.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BeadOutcome {
    /// Agent finished cleanly; closing line uses green ✓.
    Done,
    /// Agent failed; closing line uses red ✗.
    Failed,
    /// Run is being retried with previous-error context; line uses yellow.
    Retry,
}

/// Output mode for the renderer trait. Drives the per-impl selection
/// in [`build_renderer`] and the CLI flag wiring in `loom loop` /
/// `loom logs`.
///
/// Selection logic:
/// - TTY + no `--plain`/`--json`/`--raw` + no `NO_COLOR` → `Pretty`
/// - non-TTY OR `NO_COLOR` set OR `--plain` → `Plain`
/// - `--json` → `Json`
/// - `--raw` → `Raw`
///
/// `Verbose` and `VerbosePlain` are diagnostic human-rendering overlays
/// selected only after the Pretty/Plain format decision has been made.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RenderMode {
    /// Legacy terminal path for normal human transcript rendering.
    Default,
    /// Pretty diagnostic human rendering with event metadata.
    Verbose,
    /// Plain diagnostic human rendering with event metadata.
    VerbosePlain,
    /// Colored, glyph-decorated output for an interactive terminal.
    Pretty,
    /// ASCII glyphs, no color, no OSC 8 — pipe-safe.
    Plain,
    /// One pretty-printed JSON object per line; pure data, no chrome.
    Json,
    /// Passthrough JSONL: each event serialized as one compact JSON
    /// line. Used by `loom logs --raw` to reproduce the on-disk shape.
    Raw,
}

/// Explicit output-format override used during render-mode selection.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RenderFormat {
    Auto,
    Plain,
    Json,
    Raw,
}

impl RenderFormat {
    /// Resolve CLI format flags using raw-over-json-over-plain precedence.
    pub const fn from_flags(plain: bool, json: bool, raw: bool) -> Self {
        if raw {
            Self::Raw
        } else if json {
            Self::Json
        } else if plain {
            Self::Plain
        } else {
            Self::Auto
        }
    }
}

impl RenderMode {
    /// Auto-select the right mode for a given (TTY, flags, env) state.
    /// Pure function — every input is a parameter so tests can pin
    /// behavior without env mutation.
    pub const fn select(tty: bool, no_color_env: bool, format: RenderFormat) -> RenderMode {
        match format {
            RenderFormat::Raw => RenderMode::Raw,
            RenderFormat::Json => RenderMode::Json,
            RenderFormat::Plain => RenderMode::Plain,
            RenderFormat::Auto if !tty || no_color_env => RenderMode::Plain,
            RenderFormat::Auto => RenderMode::Pretty,
        }
    }
}

const ANSI_RESET: &str = "\x1b[0m";
const ANSI_GREEN: &str = "\x1b[32m";
const ANSI_RED: &str = "\x1b[31m";
const ANSI_YELLOW: &str = "\x1b[33m";
const ANSI_DIM: &str = "\x1b[2m";

/// Three-space gap between left-edge summary content and the right-edge
/// duration / status column on a single-line summary cell.
const SUMMARY_SEPARATOR: &str = "   ";

/// Worst-case display width reserved for the right-edge column when
/// deciding whether a single-line summary cell fits. Covers the longest
/// in-flight indicator text we ever emit (`"running... 999.9s"` = 17
/// columns) so an indicator that opens single-line stays single-line
/// for the entire duration without wrapping at the terminal edge.
const RIGHT_COL_RESERVE: usize = 17;

/// Fallback terminal width used when `crossterm::terminal::size` fails
/// or returns 0 — both legitimate "no real width" states (pipes, CI
/// runners without a pty). 80 keeps the math sensible without aborting
/// rendering.
const FALLBACK_TERM_WIDTH: usize = 80;

/// Convert a `ts_ms` delta (signed millis) to a non-negative
/// [`Duration`]. Negative deltas (clock skew across producers, malformed
/// logs) saturate to zero so the renderer never panics on `from_millis`.
fn ts_ms_delta(start: i64, end: i64) -> Duration {
    let delta = end.saturating_sub(start);
    Duration::from_millis(u64::try_from(delta).unwrap_or(0))
}

fn renderable_snapshot_suffix<'a>(previous: &str, suffix: &'a str) -> &'a str {
    if previous.is_empty() || previous.ends_with('\n') {
        suffix
    } else {
        suffix.strip_prefix('\n').unwrap_or(suffix)
    }
}

/// Detect terminal width via crossterm. Returns the column count of the
/// underlying tty or [`FALLBACK_TERM_WIDTH`] when no real width is
/// available.
fn detect_term_width() -> usize {
    crossterm::terminal::size()
        .ok()
        .and_then(|(cols, _)| (cols > 0).then_some(usize::from(cols)))
        .unwrap_or(FALLBACK_TERM_WIDTH)
}

/// Visible width of `s` in terminal columns. Skips ANSI CSI escapes
/// (`\x1b[...<alpha>`) and OSC 8 hyperlink envelopes
/// (`\x1b]8;;url\x07display\x1b]8;;\x07`) so the count reflects what the
/// user sees, not the raw byte length. Multi-column characters are
/// counted as one column — sufficient for the ASCII-and-symbol summary
/// cells the renderer produces today.
fn display_width(s: &str) -> usize {
    let mut width = 0usize;
    let mut iter = s.chars().peekable();
    while let Some(c) = iter.next() {
        match c {
            '\x1b' => match iter.peek() {
                Some(']') => {
                    iter.next();
                    while let Some(c2) = iter.next() {
                        if c2 == '\x07' {
                            break;
                        }
                        if c2 == '\x1b' && iter.peek() == Some(&'\\') {
                            iter.next();
                            break;
                        }
                    }
                }
                Some('[') => {
                    iter.next();
                    for c2 in iter.by_ref() {
                        if c2.is_ascii_alphabetic() {
                            break;
                        }
                    }
                }
                _ => {}
            },
            '\x07' => {}
            _ => width += 1,
        }
    }
    width
}

fn driver_event_is_warning(payload: &Value) -> bool {
    payload
        .get("severity")
        .and_then(Value::as_str)
        .is_some_and(|severity| severity == "warning")
}

const fn input_kind_label(kind: InputKind) -> &'static str {
    match kind {
        InputKind::InitialPrompt => "initial_prompt",
        InputKind::FollowUp => "follow_up",
        InputKind::Steer => "steer",
        InputKind::Repin => "repin",
    }
}

const DIAGNOSTIC_JSON_MAX_CHARS: usize = 240;
const DIAGNOSTIC_STRING_MAX_CHARS: usize = 80;

const fn source_label(source: loom_events::Source) -> &'static str {
    match source {
        loom_events::Source::Agent => "agent",
        loom_events::Source::Driver => "driver",
    }
}

const fn event_kind(event: &AgentEvent) -> &'static str {
    match event {
        AgentEvent::AgentStart { .. } => "agent_start",
        AgentEvent::AgentInput { .. } => "agent_input",
        AgentEvent::AgentEnd { .. } => "agent_end",
        AgentEvent::TurnStart { .. } => "turn_start",
        AgentEvent::TextDelta { .. } => "text_delta",
        AgentEvent::TextEnd { .. } => "text_end",
        AgentEvent::ThinkingDelta { .. } => "thinking_delta",
        AgentEvent::ThinkingEnd { .. } => "thinking_end",
        AgentEvent::ToolcallDelta { .. } => "toolcall_delta",
        AgentEvent::ToolCall { .. } => "tool_call",
        AgentEvent::ToolResult { .. } => "tool_result",
        AgentEvent::ToolProgress { .. } => "tool_progress",
        AgentEvent::TurnEnd { .. } => "turn_end",
        AgentEvent::SessionComplete { .. } => "session_complete",
        AgentEvent::CompactionStart { .. } => "compaction_start",
        AgentEvent::CompactionEnd { .. } => "compaction_end",
        AgentEvent::AutoRetry { .. } => "auto_retry",
        AgentEvent::Error { .. } => "error",
        AgentEvent::DriverEvent { .. } => "driver_event",
    }
}

const fn event_is_streaming_delta(event: &AgentEvent) -> bool {
    matches!(
        event,
        AgentEvent::TextDelta { .. }
            | AgentEvent::ThinkingDelta { .. }
            | AgentEvent::ToolcallDelta { .. }
    )
}

fn diagnostic_metadata_line(event: &AgentEvent) -> String {
    let envelope = event.envelope();
    let mut parts = vec![
        format!("kind={}", event_kind(event)),
        format!("seq={}", envelope.seq),
        format!("ts_ms={}", envelope.ts_ms),
        format!("source={}", source_label(envelope.source)),
        format!("session={}", envelope.session_id.as_str()),
    ];
    if let Some(bead_id) = &envelope.bead_id {
        parts.push(format!("bead={}", bead_id.as_str()));
    }
    if let Some(molecule_id) = &envelope.molecule_id {
        parts.push(format!("molecule={}", molecule_id.as_str()));
    }
    if let Some(iteration) = envelope.iteration {
        parts.push(format!("iteration={iteration}"));
    }
    match event {
        AgentEvent::AgentStart {
            schema_version,
            title,
            profile,
            spec_label,
            started_at_ms,
            parent_tool_call_id,
            ..
        } => {
            parts.push(format!("schema={schema_version}"));
            parts.push(format!("title={}", quoted_summary(title)));
            parts.push(format!("profile={}", profile.as_str()));
            parts.push(format!("spec={}", spec_label.as_str()));
            parts.push(format!("started_at_ms={started_at_ms}"));
            if let Some(parent) = parent_tool_call_id {
                parts.push(format!("parent_tool_call_id={}", parent.as_str()));
            }
        }
        AgentEvent::AgentInput {
            input_kind,
            text,
            redactions,
            ..
        } => {
            parts.push(format!("input_kind={}", input_kind_label(*input_kind)));
            parts.push(format!("bytes={}", text.len()));
            if let Some(redactions) = redactions {
                parts.push(format!("redactions={}", redactions.len()));
            }
        }
        AgentEvent::ToolcallDelta { id, delta, .. } => {
            parts.push(format!("id={}", id.as_str()));
            parts.push(format!("bytes={}", delta.len()));
        }
        AgentEvent::ToolCall {
            id,
            tool,
            params,
            parent_tool_call_id,
            ..
        } => {
            parts.push(format!("id={}", id.as_str()));
            parts.push(format!("tool={}", quoted_summary(tool)));
            if let Some(parent) = parent_tool_call_id {
                parts.push(format!("parent_tool_call_id={}", parent.as_str()));
            }
            parts.push(format!("params={}", safe_json_summary(params)));
        }
        AgentEvent::ToolResult {
            id,
            output,
            is_error,
            ..
        } => {
            parts.push(format!("id={}", id.as_str()));
            parts.push(format!("is_error={is_error}"));
            parts.push(format!("bytes={}", output.len()));
        }
        AgentEvent::ToolProgress { id, text, .. } => {
            parts.push(format!("id={}", id.as_str()));
            parts.push(format!("bytes={}", text.len()));
        }
        AgentEvent::TextDelta { text, .. } | AgentEvent::ThinkingDelta { text, .. } => {
            parts.push(format!("bytes={}", text.len()));
        }
        AgentEvent::SessionComplete {
            exit_code,
            cost_usd,
            ..
        } => {
            parts.push(format!("exit_code={exit_code}"));
            if let Some(cost_usd) = cost_usd {
                parts.push(format!("cost_usd={cost_usd}"));
            }
        }
        AgentEvent::CompactionStart { reason, .. } => {
            parts.push(format!("reason={}", compaction_reason_label(*reason)));
        }
        AgentEvent::CompactionEnd { aborted, .. } => {
            parts.push(format!("aborted={aborted}"));
        }
        AgentEvent::AutoRetry {
            attempt,
            max_attempts,
            delay_ms,
            error_message,
            ..
        } => {
            parts.push(format!("attempt={attempt}"));
            parts.push(format!("max_attempts={max_attempts}"));
            parts.push(format!("delay_ms={delay_ms}"));
            parts.push(format!("error={}", quoted_summary(error_message)));
        }
        AgentEvent::Error { message, .. } => {
            parts.push(format!("message={}", quoted_summary(message)));
        }
        AgentEvent::DriverEvent {
            driver_kind,
            summary,
            payload,
            ..
        } => {
            parts.push(format!("driver_kind={}", driver_kind.as_wire()));
            parts.push(format!("summary={}", quoted_summary(summary)));
            parts.push(format!("payload={}", safe_json_summary(payload)));
        }
        AgentEvent::AgentEnd { .. }
        | AgentEvent::TurnStart { .. }
        | AgentEvent::TextEnd { .. }
        | AgentEvent::ThinkingEnd { .. }
        | AgentEvent::TurnEnd { .. } => {}
    }
    format!("[event {}]", parts.join(" "))
}

const fn compaction_reason_label(reason: loom_events::event::CompactionReason) -> &'static str {
    match reason {
        loom_events::event::CompactionReason::ContextLimit => "context_limit",
        loom_events::event::CompactionReason::UserRequested => "user_requested",
        loom_events::event::CompactionReason::Unknown => "unknown",
    }
}

fn quoted_summary(value: &str) -> String {
    match serde_json::to_string(&truncate_chars(value, DIAGNOSTIC_STRING_MAX_CHARS)) {
        Ok(encoded) => encoded,
        Err(error) => format!("<json-error:{error}>"),
    }
}

fn safe_json_summary(value: &Value) -> String {
    let summarized = summarize_json_value(value);
    match serde_json::to_string(&summarized) {
        Ok(encoded) => truncate_chars(&encoded, DIAGNOSTIC_JSON_MAX_CHARS),
        Err(error) => format!("<json-error:{error}>"),
    }
}

fn summarize_json_value(value: &Value) -> Value {
    match value {
        Value::Object(map) => {
            let mut summarized = serde_json::Map::new();
            for (key, item) in map {
                let value = if sensitive_json_key(key) {
                    Value::String("[REDACTED]".to_string())
                } else if bulky_json_key(key) {
                    summarize_bulky_json_value(item)
                } else {
                    summarize_json_value(item)
                };
                summarized.insert(key.clone(), value);
            }
            Value::Object(summarized)
        }
        Value::Array(items) => {
            let mut summarized: Vec<Value> =
                items.iter().take(4).map(summarize_json_value).collect();
            if items.len() > summarized.len() {
                summarized.push(Value::String(format!(
                    "... {} more",
                    items.len() - summarized.len()
                )));
            }
            Value::Array(summarized)
        }
        Value::String(text) => Value::String(truncate_chars(text, DIAGNOSTIC_STRING_MAX_CHARS)),
        other => other.clone(),
    }
}

fn summarize_bulky_json_value(value: &Value) -> Value {
    match value {
        Value::String(text) => Value::String(format!("<{} bytes>", text.len())),
        Value::Array(items) => Value::String(format!("<{} items>", items.len())),
        Value::Object(map) => Value::String(format!("<{} fields>", map.len())),
        other => summarize_json_value(other),
    }
}

fn sensitive_json_key(key: &str) -> bool {
    let lower = key.to_ascii_lowercase();
    lower.contains("api_key")
        || lower.contains("apikey")
        || lower.contains("credential")
        || lower.contains("oauth")
        || lower.contains("password")
        || lower.contains("secret")
        || lower.contains("token")
}

fn bulky_json_key(key: &str) -> bool {
    matches!(
        key,
        "content"
            | "delta"
            | "message"
            | "new_string"
            | "old_string"
            | "output"
            | "prompt"
            | "stderr"
            | "stdout"
            | "text"
    )
}

fn truncate_chars(value: &str, max_chars: usize) -> String {
    let mut out = String::new();
    for (idx, ch) in value.chars().enumerate() {
        if idx == max_chars {
            out.push('…');
            return out;
        }
        out.push(ch);
    }
    out
}

/// State captured at `ToolCall` time so the matching `ToolResult` can
/// finalize the pair with the same context. The spec calls this out
/// explicitly as the `HashMap<ToolCallId, PendingToolCall>` that lets a
/// `tool_call` + `tool_result` collapse into one rendered block with a
/// duration computed from `envelope.ts_ms` deltas.
#[derive(Debug, Clone)]
struct PendingToolCall {
    /// Builtin tool name (e.g. `"Bash"`, `"Edit"`). Drives per-tool body
    /// rendering policy at `ToolResult` time: failures render prominently,
    /// content-returning successes render bounded excerpts, and concise
    /// edit/write successes stay summary-only.
    tool: String,
    /// Rendered one-line summary captured at `ToolCall` time. If progress
    /// output forces the pending line to close before `ToolResult`, the final
    /// status row repeats this summary instead of degrading to a detached
    /// `✓ 0.0s` line.
    summary: String,
    /// Nesting indent paired with `summary`; stored as rendered spaces so the
    /// result path can reproduce the same row even after pending state moved
    /// through progress/output rendering.
    indent: String,
    /// `envelope.ts_ms` of the originating `ToolCall`. Used to compute
    /// the pair's duration on `ToolResult` without consulting the wall
    /// clock — same code path for live and replay.
    ts_ms: i64,
}

struct DisplayFlags {
    parallel: bool,
    color: bool,
    indicator_enabled: bool,
}

struct StreamFlags {
    text_needs_newline: bool,
    thinking_open: bool,
    thinking_needs_newline: bool,
}

struct LifecycleFlags {
    header_printed: bool,
    closed: bool,
}

/// Per-bead terminal renderer.
///
/// One renderer is constructed per bead spawn. The driver creates it via
/// [`TerminalRenderer::new`], emits the header, drives [`TerminalRenderer::render_event`] for
/// every [`AgentEvent`], and finally emits the closing line via
/// [`TerminalRenderer::finish`]. With `--parallel N > 1`, the renderer is constructed in
/// `Parallel` mode so tool-call lines carry a `[bead-id]` prefix for
/// attribution.
#[must_use]
pub struct TerminalRenderer {
    out: Box<dyn Write + Send>,
    mode: RenderMode,
    bead_id: BeadId,
    display: DisplayFlags,
    clock: Arc<dyn Clock>,
    started: Instant,
    tool_count: u32,
    /// Per-tool-call nesting depth. Populated when a `ToolCall` arrives
    /// — depth = parent's depth + 1 when `parent_tool_call_id` is set,
    /// 0 otherwise. The renderer indents the rendered line by
    /// `depth * 2` spaces. Cleared lazily; entries only matter while
    /// the corresponding tool is in flight.
    indent_by_tool: std::collections::HashMap<loom_events::identifier::ToolCallId, usize>,
    /// Per-tool-call state captured at `ToolCall` time so the matching
    /// `ToolResult` can finalize the pair. Stores tool name plus
    /// `ts_ms`, letting the result line render its duration from the
    /// event envelope rather than wall clock.
    pending_calls: std::collections::HashMap<loom_events::identifier::ToolCallId, PendingToolCall>,
    /// Last complete tool-output snapshot observed for each tool call.
    /// Backends may send progress/result as cumulative snapshots; this
    /// state lets the renderer append only the newly observed suffix.
    observed_tool_output: std::collections::HashMap<loom_events::identifier::ToolCallId, String>,
    /// In-place "running indicator" state for the top-level tool call
    /// currently in-flight. When `Some((id, started, summary, indent))`,
    /// a `\r`-overwritable line has been written for that call and the
    /// matching `ToolResult` should finalize it.
    /// Any other event must clear/finalize the line first so it does
    /// not interleave with running-state text.
    running: Option<(ToolCallId, Instant, String, String)>,
    /// Top-level call whose summary cell would not fit on the same line
    /// as the right-edge column at the current terminal width. The
    /// renderer suppresses the in-place indicator for the call entirely
    /// — emitting nothing at `ToolCall` time — and writes a two-line
    /// layout (right-edge column right-aligned on line 1, full summary
    /// on a body-indented continuation line on line 2) when the matching
    /// `ToolResult` arrives. Mutually exclusive with [`running`]: each
    /// top-level call lands in one bucket or the other.
    buffered_overflow: Option<(ToolCallId, Instant, String, String)>,
    /// `true` when the renderer should drive the in-place running
    /// indicator. Disabled in `Plain`/`Json`/`Raw` modes, when running
    /// in parallel (multiple `\r` regions don't compose), and when
    /// the writer is known to be non-TTY. The CLI surface decides this
    /// and wires it through `RenderMode::select`.
    /// Byte budget for visible tool-output content. Live Direct sessions and
    /// replay load this from `[direct].max_inline_bytes`.
    tool_body_limit: usize,
    /// OSC 8 hyperlink wrapping for path-bearing summary cells.
    /// Default is disabled; callers in supported terminals enable via
    /// [`TerminalRenderer::with_osc8`].
    osc8: tool_body::Osc8Context,
    /// Override for the detected terminal width. Tests inject a fixed
    /// width via [`TerminalRenderer::with_term_width`] so the overflow
    /// behavior pins deterministically without a real terminal. `None`
    /// in production — each emission queries crossterm so SIGWINCH
    /// resizes take effect immediately.
    term_width_override: Option<usize>,
    stream: StreamFlags,
    lifecycle: LifecycleFlags,
}

impl TerminalRenderer {
    /// Build a renderer that writes to `out` using a [`SystemClock`] for the
    /// elapsed-time line at finish. Defaults to `live = true` — events
    /// stream from a running agent. Replay callers (`loom logs`) use
    /// [`TerminalRenderer::new_replay`] to flip the `live` bool.
    pub fn new(
        out: impl Write + Send + 'static,
        mode: RenderMode,
        bead_id: BeadId,
        parallel: bool,
        color: bool,
    ) -> Self {
        Self::with_clock(
            out,
            mode,
            bead_id,
            parallel,
            color,
            true,
            SystemClock::new(),
        )
    }

    /// Build a renderer in replay mode — events are read from a saved
    /// JSONL log rather than a running agent, so the in-place running
    /// indicator is suppressed and pair durations come from `ts_ms`
    /// deltas. The "live: bool" parameter lives here.
    pub fn new_replay(
        out: impl Write + Send + 'static,
        mode: RenderMode,
        bead_id: BeadId,
        parallel: bool,
        color: bool,
    ) -> Self {
        Self::with_clock(
            out,
            mode,
            bead_id,
            parallel,
            color,
            false,
            SystemClock::new(),
        )
    }

    /// Build a renderer with an explicit clock. Tests inject
    /// the test-only mock clock so the elapsed-time output is deterministic
    /// without wall-clock dependence.
    pub fn with_clock(
        out: impl Write + Send + 'static,
        mode: RenderMode,
        bead_id: BeadId,
        parallel: bool,
        color: bool,
        live: bool,
        clock: Arc<dyn Clock>,
    ) -> Self {
        let started = clock.now();
        Self {
            out: Box::new(out),
            mode,
            bead_id,
            display: DisplayFlags {
                parallel,
                color,
                indicator_enabled: color && !parallel && live,
            },
            clock,
            started,
            tool_count: 0,
            indent_by_tool: std::collections::HashMap::new(),
            pending_calls: std::collections::HashMap::new(),
            observed_tool_output: std::collections::HashMap::new(),
            running: None,
            buffered_overflow: None,
            // Indicator is enabled by default when color is on, we're
            // not in parallel mode, and events arrive live. Each
            // condition is a proxy for a real constraint: color → TTY,
            // !parallel → single \r-region on screen, live → there's
            // something to spin while we wait for. Tests pass
            // `color=false` to disable the indicator so captured-buffer
            // assertions stay stable.
            tool_body_limit: tool_body::BODY_CAP_BYTES,
            osc8: tool_body::Osc8Context::disabled(),
            term_width_override: None,
            stream: StreamFlags {
                text_needs_newline: false,
                thinking_open: false,
                thinking_needs_newline: false,
            },
            lifecycle: LifecycleFlags {
                header_printed: false,
                closed: false,
            },
        }
    }

    /// Pin the terminal width used for summary-cell overflow decisions.
    /// Production callers omit this — the renderer queries crossterm on
    /// every emission so the layout adapts to SIGWINCH. Tests use it to
    /// reproduce a narrow terminal (e.g. 40 columns) without spawning a
    /// real pty.
    pub const fn with_term_width(mut self, width: usize) -> Self {
        self.term_width_override = Some(width);
        self
    }

    /// Resolve the terminal width for overflow decisions. Honors the
    /// test override when set; otherwise queries crossterm with the
    /// 80-column fallback for non-TTY paths.
    fn term_width(&self) -> usize {
        self.term_width_override.unwrap_or_else(detect_term_width)
    }

    const fn diagnostic_metadata_enabled(&self) -> bool {
        matches!(self.mode, RenderMode::Verbose | RenderMode::VerbosePlain)
    }

    fn render_diagnostic_metadata(&mut self, event: &AgentEvent) -> io::Result<()> {
        if !self.diagnostic_metadata_enabled() || event_is_streaming_delta(event) {
            return Ok(());
        }
        self.close_stream_lines()?;
        self.close_in_flight("…")?;
        let prefix = self.prefix_str();
        let line = diagnostic_metadata_line(event);
        self.out.write_all(format!("{prefix}{line}\n").as_bytes())?;
        self.out.flush()
    }

    /// Line prefix shared by every tool-summary line. `Parallel` mode
    /// adds the bead-id bracket for cross-bead attribution; otherwise
    /// just the two-space base indent.
    fn prefix_str(&self) -> String {
        if self.display.parallel {
            format!("  [{}] ", self.bead_id.as_str())
        } else {
            "  ".to_string()
        }
    }

    /// Set the raw UTF-8 byte budget used for inline tool-output content.
    pub const fn with_tool_body_limit(mut self, max_inline_bytes: usize) -> Self {
        self.tool_body_limit = max_inline_bytes;
        self
    }

    /// Enable OSC 8 hyperlink wrapping for path-bearing summary cells.
    /// Production callers in `loom loop` probe `TERM_PROGRAM` / `TERM`
    /// via [`crate::osc8::supports_osc8`] and pass the workspace root
    /// as `cwd`. Tests pin both branches without env mutation by
    /// passing the boolean directly. Chainable; returns the renderer.
    pub fn with_osc8(mut self, ctx: tool_body::Osc8Context) -> Self {
        self.osc8 = ctx;
        self
    }

    fn close_text_line(&mut self) -> io::Result<()> {
        if self.stream.text_needs_newline {
            self.out.write_all(b"\n")?;
            self.out.flush()?;
        }
        self.stream.text_needs_newline = false;
        Ok(())
    }

    fn close_thinking_line(&mut self) -> io::Result<()> {
        if self.stream.thinking_needs_newline {
            self.out.write_all(b"\n")?;
            self.out.flush()?;
        }
        self.stream.thinking_needs_newline = false;
        self.stream.thinking_open = false;
        Ok(())
    }

    fn close_stream_lines(&mut self) -> io::Result<()> {
        self.close_text_line()?;
        self.close_thinking_line()
    }

    fn write_prefixed_fragment(
        &mut self,
        text: &str,
        prefix: &str,
        line_open: bool,
        style: Option<(&str, &str)>,
    ) -> io::Result<bool> {
        if text.is_empty() {
            return Ok(line_open);
        }
        let mut needs_prefix = !line_open;
        for segment in text.split_inclusive('\n') {
            let mut chunk = String::new();
            if needs_prefix {
                chunk.push_str(prefix);
            }
            let has_newline = segment.ends_with('\n');
            let body = if has_newline {
                &segment[..segment.len() - 1]
            } else {
                segment
            };
            if !body.is_empty() {
                if let Some((open, close)) = style {
                    chunk.push_str(open);
                    chunk.push_str(body);
                    chunk.push_str(close);
                } else {
                    chunk.push_str(body);
                }
            }
            if has_newline {
                chunk.push('\n');
            }
            self.out.write_all(chunk.as_bytes())?;
            needs_prefix = has_newline;
        }
        Ok(!text.ends_with('\n'))
    }

    fn render_text_delta(&mut self, text: &str) -> io::Result<()> {
        self.close_thinking_line()?;
        self.close_in_flight("…")?;
        if self.display.parallel {
            let prefix = self.prefix_str();
            self.stream.text_needs_newline =
                self.write_prefixed_fragment(text, &prefix, self.stream.text_needs_newline, None)?;
        } else {
            self.out.write_all(text.as_bytes())?;
            if !text.is_empty() {
                self.stream.text_needs_newline = !text.ends_with('\n');
            }
        }
        self.out.flush()?;
        Ok(())
    }

    fn render_thinking_delta(&mut self, text: &str) -> io::Result<()> {
        self.close_text_line()?;
        self.close_in_flight("…")?;
        if self.display.parallel {
            let prefix = format!("{}thinking: ", self.prefix_str());
            let style = self.display.color.then_some((ANSI_DIM, ANSI_RESET));
            self.stream.thinking_needs_newline = self.write_prefixed_fragment(
                text,
                &prefix,
                self.stream.thinking_needs_newline,
                style,
            )?;
            self.stream.thinking_open = self.stream.thinking_needs_newline;
            self.out.flush()?;
            return Ok(());
        }
        if !self.stream.thinking_open {
            let prefix = "  thinking: ";
            if self.display.color {
                self.out.write_all(ANSI_DIM.as_bytes())?;
            }
            self.out.write_all(prefix.as_bytes())?;
            self.stream.thinking_open = true;
        } else if self.display.color {
            self.out.write_all(ANSI_DIM.as_bytes())?;
        }
        self.out.write_all(text.as_bytes())?;
        if self.display.color {
            self.out.write_all(ANSI_RESET.as_bytes())?;
        }
        self.out.flush()?;
        self.stream.thinking_needs_newline = !text.is_empty() && !text.ends_with('\n');
        if !self.stream.thinking_needs_newline {
            self.stream.thinking_open = false;
        }
        Ok(())
    }

    /// Print the per-bead header line.
    ///
    /// `▸ <bead-id>  <title>    [profile:<name>]`
    ///
    /// Atomically printed (single write call) so parallel renderers do not
    /// interleave the header itself.
    ///
    /// # Errors
    ///
    /// Returns an I/O error when writing or flushing the header fails.
    pub fn header(&mut self, title: &str, profile: &ProfileName) -> io::Result<()> {
        let line = format!(
            "▸ {id}  {title}    [profile:{profile}]\n",
            id = self.bead_id.as_str(),
            title = title,
            profile = profile.as_str(),
        );
        self.out.write_all(line.as_bytes())?;
        self.out.flush()?;
        self.lifecycle.header_printed = true;
        Ok(())
    }

    /// Render one [`AgentEvent`].
    ///
    /// Normal human modes render the faithful transcript: Loom inputs,
    /// assistant prose, exposed thinking, tool blocks, and driver rows.
    /// Diagnostic modes add event metadata without widening transcript
    /// visibility or tool-output caps.
    ///
    /// # Errors
    ///
    /// Returns an I/O error when rendering or flushing any event output fails.
    pub fn render_event(&mut self, event: &AgentEvent) -> io::Result<()> {
        self.render_diagnostic_metadata(event)?;
        match event {
            AgentEvent::AgentInput {
                input_kind,
                text,
                redactions,
                ..
            } => {
                self.close_stream_lines()?;
                self.close_in_flight("…")?;
                let prefix = self.prefix_str();
                let label = input_kind_label(*input_kind);
                self.out
                    .write_all(format!("{prefix}⇢ agent_input {label}\n").as_bytes())?;
                if text.is_empty() {
                    self.out
                        .write_all(format!("{prefix}  (empty)\n").as_bytes())?;
                } else {
                    for line in text.lines() {
                        self.out
                            .write_all(format!("{prefix}  {line}\n").as_bytes())?;
                    }
                }
                if let Some(redactions) = redactions {
                    for redaction in redactions {
                        self.out.write_all(
                            format!(
                                "{prefix}  redaction {} ({})\n",
                                redaction.marker,
                                redaction.class.as_wire(),
                            )
                            .as_bytes(),
                        )?;
                    }
                }
                self.out.flush()?;
            }
            AgentEvent::ToolCall {
                envelope,
                id,
                tool,
                params,
                parent_tool_call_id,
            } => {
                self.close_stream_lines()?;
                // If another tool's running line (or buffered overflow)
                // is in flight, finalize it before laying down a nested
                // or sibling call.
                self.close_in_flight("…")?;
                self.tool_count += 1;
                let depth = match parent_tool_call_id {
                    Some(parent) => self.indent_by_tool.get(parent).copied().unwrap_or(0) + 1,
                    None => 0,
                };
                self.indent_by_tool.insert(id.clone(), depth);
                let summary = tool_body::summary_cell(tool, params, &self.osc8);
                let indent: String = "  ".repeat(depth);
                self.pending_calls.insert(
                    id.clone(),
                    PendingToolCall {
                        tool: tool.clone(),
                        summary: summary.clone(),
                        indent: indent.clone(),
                        ts_ms: envelope.ts_ms,
                    },
                );
                let use_indicator = self.display.indicator_enabled
                    && parent_tool_call_id.is_none()
                    && !self.diagnostic_metadata_enabled();
                let prefix = self.prefix_str();
                if use_indicator {
                    // Decide between the single-line indicator (summary
                    // shares its row with the right-edge column) and the
                    // buffered overflow case (right-edge column gets its
                    // own row at result time, summary wraps below).
                    let single_width = display_width(&prefix)
                        + display_width(&indent)
                        + display_width(&summary)
                        + SUMMARY_SEPARATOR.len()
                        + RIGHT_COL_RESERVE;
                    if single_width <= self.term_width() {
                        let running_line =
                            format!("{prefix}{indent}{summary}{SUMMARY_SEPARATOR}running... 0.0s");
                        self.out.write_all(running_line.as_bytes())?;
                        self.out.flush()?;
                        self.running = Some((id.clone(), self.clock.now(), summary, indent));
                    } else {
                        // Suppress the indicator: writing `running...` on
                        // the same line would mangle the \r-overwrite
                        // region once the terminal wrapped the long
                        // summary. Defer the entire summary cell until
                        // result time and emit the spec'd two-line layout
                        // there (right column first, indented continuation
                        // beneath).
                        self.buffered_overflow =
                            Some((id.clone(), self.clock.now(), summary, indent));
                    }
                } else {
                    let line = format!("{prefix}{indent}{summary}\n");
                    self.out.write_all(line.as_bytes())?;
                    self.out.flush()?;
                }
            }
            AgentEvent::ToolResult {
                envelope,
                id,
                output,
                is_error,
            } => {
                self.close_stream_lines()?;
                // Finalize the running indicator if this result matches
                // the open call. Non-matching results (which shouldn't
                // happen in practice but might under nesting) close any
                // open running line first to avoid orphaned `\r`
                // regions.
                let matches_running = self
                    .running
                    .as_ref()
                    .is_some_and(|(running_id, _, _, _)| running_id == id);
                let matches_buffered = self
                    .buffered_overflow
                    .as_ref()
                    .is_some_and(|(buffered_id, _, _, _)| buffered_id == id);
                let pending = self.pending_calls.remove(id);
                let pair_duration = pending
                    .as_ref()
                    .map(|p| ts_ms_delta(p.ts_ms, envelope.ts_ms));
                let tool_name = pending.as_ref().map_or("", |p| p.tool.as_str());
                let glyph = if *is_error { "✗" } else { "✓" };
                if matches_running {
                    self.finalize_running_with_glyph_dur(glyph, pair_duration)?;
                } else if matches_buffered {
                    self.finalize_buffered_with_glyph_dur(glyph, pair_duration)?;
                } else {
                    self.close_in_flight("…")?;
                    self.write_tool_status_line(id, glyph, pair_duration, pending.as_ref())?;
                }
                let body = if matches!(
                    self.mode,
                    RenderMode::Default
                        | RenderMode::Pretty
                        | RenderMode::Plain
                        | RenderMode::Verbose
                        | RenderMode::VerbosePlain
                ) && Self::should_render_default_body(tool_name, *is_error, output)
                {
                    let body = self.new_tool_output_body(id, output);
                    if body.is_empty() { None } else { Some(body) }
                } else {
                    None
                };
                if let Some(body) = body {
                    self.write_body_lines(id, &body)?;
                }
            }
            AgentEvent::ToolProgress { id, text, .. } => {
                self.close_stream_lines()?;
                let matches_running = self
                    .running
                    .as_ref()
                    .is_some_and(|(running_id, _, _, _)| running_id == id);
                let matches_buffered = self
                    .buffered_overflow
                    .as_ref()
                    .is_some_and(|(buffered_id, _, _, _)| buffered_id == id);
                if matches_running {
                    self.finalize_running_with_glyph_dur("…", None)?;
                } else if matches_buffered {
                    self.finalize_buffered_with_glyph_dur("…", None)?;
                } else {
                    self.close_in_flight("…")?;
                }
                let body = self.new_tool_output_body(id, text);
                if !body.is_empty() {
                    self.write_progress_lines(id, &body)?;
                }
            }
            AgentEvent::TextDelta { text, .. }
                if matches!(
                    self.mode,
                    RenderMode::Default
                        | RenderMode::Verbose
                        | RenderMode::VerbosePlain
                        | RenderMode::Pretty
                        | RenderMode::Plain
                ) =>
            {
                self.render_text_delta(text)?;
            }
            AgentEvent::TextEnd { .. } => {
                self.close_text_line()?;
            }
            AgentEvent::ThinkingDelta { text, .. }
                if matches!(
                    self.mode,
                    RenderMode::Default
                        | RenderMode::Verbose
                        | RenderMode::VerbosePlain
                        | RenderMode::Pretty
                        | RenderMode::Plain
                ) =>
            {
                self.render_thinking_delta(text)?;
            }
            AgentEvent::ThinkingEnd { .. }
                if matches!(
                    self.mode,
                    RenderMode::Default
                        | RenderMode::Verbose
                        | RenderMode::VerbosePlain
                        | RenderMode::Pretty
                        | RenderMode::Plain
                ) =>
            {
                self.close_thinking_line()?;
            }
            AgentEvent::Error { message, .. } => {
                self.close_stream_lines()?;
                self.close_in_flight("✗")?;
                let line = if self.display.parallel {
                    format!("  [{}] error: {message}\n", self.bead_id.as_str())
                } else {
                    format!("  error: {message}\n")
                };
                self.out.write_all(line.as_bytes())?;
                self.out.flush()?;
            }
            AgentEvent::DriverEvent {
                driver_kind,
                summary,
                payload,
                ..
            } => {
                self.close_stream_lines()?;
                self.close_in_flight("…")?;
                let kind_wire = driver_kind.as_wire();
                let warning = driver_event_is_warning(payload);
                let glyph = if warning { "⚠" } else { "→" };
                let glyph = if warning && self.display.color {
                    format!("{ANSI_YELLOW}{glyph}{ANSI_RESET}")
                } else {
                    glyph.to_string()
                };
                let line = if self.display.parallel {
                    format!(
                        "  [{}] {glyph} {kind_wire}: {summary}\n",
                        self.bead_id.as_str(),
                    )
                } else {
                    format!("  {glyph} {kind_wire}: {summary}\n")
                };
                self.out.write_all(line.as_bytes())?;
                self.out.flush()?;
            }
            _ => {}
        }
        Ok(())
    }

    /// Close the in-place running line — if one is open — with a final
    /// `\r` + clear-to-EOL + `<summary>   <glyph> Ns\n` line. `glyph` is
    /// `✓` on clean `ToolResult`, `✗` on errored `ToolResult`, `…` when an
    /// intervening event preempted the result. The caller may pass a
    /// duration derived from `ts_ms` deltas instead of falling back to
    /// the local clock; `loom logs` replay drives this with the event
    /// envelope's `ts_ms` so the rendered duration matches what the
    /// producer recorded. Idempotent — a `running = None` call is a
    /// no-op so cleanup paths can invoke unconditionally.
    fn finalize_running_with_glyph_dur(
        &mut self,
        glyph: &str,
        pair_duration: Option<Duration>,
    ) -> io::Result<()> {
        let Some((_, started, summary, indent)) = self.running.take() else {
            return Ok(());
        };
        let elapsed =
            pair_duration.unwrap_or_else(|| self.clock.now().saturating_duration_since(started));
        let secs = elapsed.as_secs_f64();
        self.out.write_all(b"\r")?;
        self.out.write_all(CLEAR_TO_EOL.as_bytes())?;
        let prefix = self.prefix_str();
        let final_line =
            format!("{prefix}{indent}{summary}{SUMMARY_SEPARATOR}{glyph} {secs:.1}s\n");
        self.out.write_all(final_line.as_bytes())?;
        self.out.flush()?;
        Ok(())
    }

    /// Close any in-flight summary cell — running indicator OR buffered
    /// overflow case — with the given glyph. Both inner finalizers are
    /// idempotent no-ops when their state is empty, so callers can
    /// invoke unconditionally before laying down a new event line.
    fn close_in_flight(&mut self, glyph: &str) -> io::Result<()> {
        self.finalize_running_with_glyph_dur(glyph, None)?;
        self.finalize_buffered_with_glyph_dur(glyph, None)
    }

    fn write_tool_status_line(
        &mut self,
        id: &ToolCallId,
        glyph: &str,
        pair_duration: Option<Duration>,
        pending: Option<&PendingToolCall>,
    ) -> io::Result<()> {
        let secs = pair_duration.unwrap_or(Duration::ZERO).as_secs_f64();
        let line = if let Some(pending) = pending {
            let prefix = self.prefix_str();
            format!(
                "{prefix}{}{}{}{} {secs:.1}s\n",
                pending.indent, pending.summary, SUMMARY_SEPARATOR, glyph,
            )
        } else {
            let depth = self.indent_by_tool.get(id).copied().unwrap_or(0);
            let indent: String = "  ".repeat(depth + 1);
            if self.display.parallel {
                format!("  [{}] {indent}{glyph} {secs:.1}s\n", self.bead_id.as_str())
            } else {
                format!("  {indent}{glyph} {secs:.1}s\n")
            }
        };
        self.out.write_all(line.as_bytes())?;
        self.out.flush()
    }

    fn write_body_lines(&mut self, id: &ToolCallId, body: &str) -> io::Result<()> {
        let depth = self.indent_by_tool.get(id).copied().unwrap_or(0);
        let indent: String = "  ".repeat(depth + 1);
        for body_line in body.lines() {
            let line = if self.display.parallel {
                format!("  [{}] {indent}{body_line}\n", self.bead_id.as_str())
            } else {
                format!("{indent}{body_line}\n")
            };
            self.out.write_all(line.as_bytes())?;
        }
        self.out.flush()
    }

    fn write_progress_lines(&mut self, id: &ToolCallId, text: &str) -> io::Result<()> {
        let body = if text.is_empty() {
            "…".to_string()
        } else {
            text.lines()
                .map(|line| format!("… {line}"))
                .collect::<Vec<_>>()
                .join("\n")
        };
        self.write_body_lines(id, &body)
    }

    fn new_tool_output_body(&mut self, id: &ToolCallId, snapshot: &str) -> String {
        let body = match self.observed_tool_output.get(id) {
            Some(previous) if snapshot == previous => String::new(),
            Some(previous) if snapshot.starts_with(previous) => {
                self.cumulative_tool_output_body(id, previous, snapshot)
            }
            Some(previous) if previous.starts_with(snapshot) => String::new(),
            Some(_) | None => tool_body::cap_body_with_limit(
                snapshot,
                self.bead_id.as_str(),
                id.as_str(),
                self.tool_body_limit,
            ),
        };
        if self.should_store_tool_snapshot(id, snapshot) {
            self.observed_tool_output
                .insert(id.clone(), snapshot.to_string());
        }
        body
    }

    fn cumulative_tool_output_body(
        &self,
        id: &ToolCallId,
        previous: &str,
        snapshot: &str,
    ) -> String {
        let cap = self.tool_body_limit;
        let start = previous.len();
        if start > cap {
            return String::new();
        }
        if start == cap {
            if snapshot.len() > cap {
                return tool_body::truncation_hint(
                    snapshot.len() - cap,
                    cap,
                    self.bead_id.as_str(),
                    id.as_str(),
                );
            }
            return String::new();
        }
        if snapshot.len() <= cap {
            return renderable_snapshot_suffix(previous, &snapshot[start..]).to_string();
        }
        let visible_end = tool_body::utf8_prefix_at_byte_limit(snapshot, cap).len();
        let mut body =
            renderable_snapshot_suffix(previous, &snapshot[start..visible_end]).to_string();
        if !body.is_empty() && !body.ends_with('\n') {
            body.push('\n');
        }
        body.push_str(&tool_body::truncation_hint(
            snapshot.len() - visible_end,
            cap,
            self.bead_id.as_str(),
            id.as_str(),
        ));
        body
    }

    fn should_store_tool_snapshot(&self, id: &ToolCallId, snapshot: &str) -> bool {
        self.observed_tool_output.get(id).is_none_or(|previous| {
            snapshot.len() >= previous.len() || !previous.starts_with(snapshot)
        })
    }

    fn should_render_default_body(tool_name: &str, is_error: bool, output: &str) -> bool {
        !output.is_empty() && (is_error || tool_body::renders_body_by_default(tool_name))
    }

    /// Emit the two-line summary cell for a buffered (overflow) top-level
    /// tool call: right-edge column right-aligned on line 1 so it stays
    /// fully visible at the terminal edge, followed by the full left-edge
    /// summary on a body-indented continuation line. Mirrors the spec's
    /// "right-edge column alone on the first line, full content wraps
    /// onto a single indented continuation line beneath it" rule.
    fn finalize_buffered_with_glyph_dur(
        &mut self,
        glyph: &str,
        pair_duration: Option<Duration>,
    ) -> io::Result<()> {
        let Some((_, started, summary, indent)) = self.buffered_overflow.take() else {
            return Ok(());
        };
        let elapsed =
            pair_duration.unwrap_or_else(|| self.clock.now().saturating_duration_since(started));
        let secs = elapsed.as_secs_f64();
        let right_col = format!("{glyph} {secs:.1}s");
        let prefix = self.prefix_str();
        let prefix_w = display_width(&prefix);
        let right_w = display_width(&right_col);
        let pad_w = self.term_width().saturating_sub(prefix_w + right_w);
        let pad = " ".repeat(pad_w);
        // Continuation indent is one extra level deeper than the summary.
        let body_indent = format!("{indent}  ");
        let line1 = format!("{prefix}{pad}{right_col}\n");
        let line2 = format!("{prefix}{body_indent}{summary}\n");
        self.out.write_all(line1.as_bytes())?;
        self.out.write_all(line2.as_bytes())?;
        self.out.flush()?;
        Ok(())
    }

    /// Print the closing line and consume the renderer.
    ///
    /// `✓ done  (N tool calls, Ms)` for [`BeadOutcome::Done`],
    /// `✗ failed  (N tool calls, Ms)` for [`BeadOutcome::Failed`],
    /// `↻ retry  (N tool calls, Ms)` for [`BeadOutcome::Retry`].
    ///
    /// Status color is applied to the leading glyph + word only when
    /// `color = true`; the rest of the line is plain.
    ///
    /// # Errors
    ///
    /// Returns an I/O error when closing active output or writing the final
    /// status line fails.
    pub fn finish(mut self, outcome: BeadOutcome) -> io::Result<()> {
        let elapsed = self.clock.now().saturating_duration_since(self.started);
        self.write_finish(outcome, elapsed)
    }

    fn write_finish(&mut self, outcome: BeadOutcome, elapsed: Duration) -> io::Result<()> {
        self.close_stream_lines()?;
        // Close out any open running line before the bead's closing
        // summary so a cancelled / failed bead doesn't leave a dangling
        // `\r` region for the next renderer to inherit.
        let cleanup_glyph = match outcome {
            BeadOutcome::Done => "✓",
            BeadOutcome::Failed => "✗",
            BeadOutcome::Retry => "↻",
        };
        self.close_in_flight(cleanup_glyph)?;
        let (glyph, word, color) = match outcome {
            BeadOutcome::Done => ("✓", "done", ANSI_GREEN),
            BeadOutcome::Failed => ("✗", "failed", ANSI_RED),
            BeadOutcome::Retry => ("↻", "retry", ANSI_YELLOW),
        };
        let prefix = if self.display.color {
            format!("{color}{glyph} {word}{ANSI_RESET}")
        } else {
            format!("{glyph} {word}")
        };
        let body = format!(
            "  ({tools} tool calls, {secs}s)\n",
            tools = self.tool_count,
            secs = elapsed.as_secs(),
        );
        let line = if self.display.parallel {
            format!("[{}] {prefix}{body}", self.bead_id.as_str())
        } else {
            format!("  {prefix}{body}")
        };
        self.out.write_all(line.as_bytes())?;
        self.out.flush()?;
        self.lifecycle.closed = true;
        Ok(())
    }

    /// Number of `ToolCall` events observed since construction.
    pub const fn tool_count(&self) -> u32 {
        self.tool_count
    }

    /// Whether the header line has been printed.
    pub const fn header_printed(&self) -> bool {
        self.lifecycle.header_printed
    }
}

impl Drop for TerminalRenderer {
    /// Best-effort cleanup of any open in-place running line so a
    /// panicking / dropped renderer never leaves a dangling `\r`
    /// region. The explicit cleanup contract still lives in
    /// [`Self::finish`] — Drop is the safety net.
    fn drop(&mut self) {
        if self.stream.text_needs_newline || self.stream.thinking_needs_newline {
            let _ = self.close_stream_lines();
        }
        if self.running.is_some() || self.buffered_overflow.is_some() {
            let _ = self.close_in_flight("⚠");
        }
    }
}

/// Output target for one bead's event stream.
///
/// `loom loop` and `loom logs` share these impls — the `live` /
/// replay distinction is encoded in how they feed events to the
/// renderer, not in the renderer itself. H3-H6 add per-tool body
/// rendering, in-place running indicators, OSC 8 hyperlinks, and
/// Task subagent nesting on top of this trait.
pub trait Renderer: Send {
    /// Optional per-bead header — `Pretty`/`Plain` print it; `Json`/`Raw`
    /// suppress (header is chrome, not data). Default impl is a no-op
    /// so simpler impls don't have to override.
    ///
    /// # Errors
    ///
    /// Implementations return an I/O error when header output fails.
    fn header(&mut self, _title: &str, _profile: &ProfileName) -> io::Result<()> {
        Ok(())
    }

    /// Render one event. The renderer owns its `Write` sink.
    ///
    /// # Errors
    ///
    /// Returns an I/O error when event output fails.
    fn render_event(&mut self, event: &AgentEvent) -> io::Result<()>;

    /// Close the renderer with the bead outcome. `&mut self` (not
    /// consuming) so trait-object call through `Box<dyn Renderer>`
    /// stays straightforward without `Box<Self>` indirection.
    ///
    /// # Errors
    ///
    /// Returns an I/O error when final output or flushing fails.
    fn finish(&mut self, outcome: BeadOutcome, elapsed: Duration) -> io::Result<()>;
}

impl Renderer for TerminalRenderer {
    fn header(&mut self, title: &str, profile: &ProfileName) -> io::Result<()> {
        TerminalRenderer::header(self, title, profile)
    }
    fn render_event(&mut self, event: &AgentEvent) -> io::Result<()> {
        TerminalRenderer::render_event(self, event)
    }
    fn finish(&mut self, outcome: BeadOutcome, elapsed: Duration) -> io::Result<()> {
        self.write_finish(outcome, elapsed)
    }
}

/// Colored interactive output backed by [`TerminalRenderer`].
pub struct PrettyRenderer {
    inner: TerminalRenderer,
}

impl PrettyRenderer {
    pub fn new(
        out: impl Write + Send + 'static,
        bead_id: BeadId,
        parallel: bool,
        live: bool,
    ) -> Self {
        let inner = if live {
            TerminalRenderer::new(out, RenderMode::Default, bead_id, parallel, true)
        } else {
            TerminalRenderer::new_replay(out, RenderMode::Default, bead_id, parallel, true)
        };
        Self { inner }
    }
}

impl Renderer for PrettyRenderer {
    fn header(&mut self, title: &str, profile: &ProfileName) -> io::Result<()> {
        self.inner.header(title, profile)
    }
    fn render_event(&mut self, event: &AgentEvent) -> io::Result<()> {
        self.inner.render_event(event)
    }
    fn finish(&mut self, outcome: BeadOutcome, elapsed: Duration) -> io::Result<()> {
        self.inner.write_finish(outcome, elapsed)
    }
}

/// `Plain` mode — same shape as `Pretty` but with `color = false`.
/// Pipe-safe; no ANSI escapes; no OSC 8. The `live` parameter follows
/// the same contract as [`PrettyRenderer::new`].
pub struct PlainRenderer {
    inner: TerminalRenderer,
}

impl PlainRenderer {
    pub fn new(
        out: impl Write + Send + 'static,
        bead_id: BeadId,
        parallel: bool,
        live: bool,
    ) -> Self {
        let inner = if live {
            TerminalRenderer::new(out, RenderMode::Default, bead_id, parallel, false)
        } else {
            TerminalRenderer::new_replay(out, RenderMode::Default, bead_id, parallel, false)
        };
        Self { inner }
    }
}

impl Renderer for PlainRenderer {
    fn header(&mut self, title: &str, profile: &ProfileName) -> io::Result<()> {
        self.inner.header(title, profile)
    }
    fn render_event(&mut self, event: &AgentEvent) -> io::Result<()> {
        self.inner.render_event(event)
    }
    fn finish(&mut self, outcome: BeadOutcome, elapsed: Duration) -> io::Result<()> {
        self.inner.write_finish(outcome, elapsed)
    }
}

/// `Json` mode — one pretty-printed JSON object per line. No header,
/// no closing line; the consumer is expected to parse the stream.
pub struct JsonRenderer {
    out: Box<dyn Write + Send>,
}

impl JsonRenderer {
    pub fn new(out: impl Write + Send + 'static) -> Self {
        Self { out: Box::new(out) }
    }
}

impl Renderer for JsonRenderer {
    fn render_event(&mut self, event: &AgentEvent) -> io::Result<()> {
        let line = serde_json::to_string_pretty(event)
            .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
        self.out.write_all(line.as_bytes())?;
        self.out.write_all(b"\n")?;
        self.out.flush()
    }
    fn finish(&mut self, _outcome: BeadOutcome, _elapsed: Duration) -> io::Result<()> {
        self.out.flush()
    }
}

/// One compact JSON line per event, matching the on-disk shape.
pub struct RawRenderer {
    out: Box<dyn Write + Send>,
}

impl RawRenderer {
    pub fn new(out: impl Write + Send + 'static) -> Self {
        Self { out: Box::new(out) }
    }
}

impl Renderer for RawRenderer {
    fn render_event(&mut self, event: &AgentEvent) -> io::Result<()> {
        let line = serde_json::to_string(event)
            .map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
        self.out.write_all(line.as_bytes())?;
        self.out.write_all(b"\n")?;
        self.out.flush()
    }
    fn finish(&mut self, _outcome: BeadOutcome, _elapsed: Duration) -> io::Result<()> {
        self.out.flush()
    }
}

/// Construct the [`Renderer`] selected by `mode`.
pub fn build_renderer(
    mode: RenderMode,
    out: Box<dyn Write + Send>,
    bead_id: BeadId,
    parallel: bool,
    live: bool,
) -> Box<dyn Renderer> {
    build_renderer_with_tool_body_limit(
        mode,
        out,
        bead_id,
        parallel,
        live,
        tool_body::BODY_CAP_BYTES,
    )
}

/// Construct a renderer with the configured Direct inline-output budget.
pub fn build_renderer_with_tool_body_limit(
    mode: RenderMode,
    out: Box<dyn Write + Send>,
    bead_id: BeadId,
    parallel: bool,
    live: bool,
    max_inline_bytes: usize,
) -> Box<dyn Renderer> {
    let color = matches!(mode, RenderMode::Pretty | RenderMode::Verbose);
    match mode {
        RenderMode::Pretty
        | RenderMode::Plain
        | RenderMode::Default
        | RenderMode::Verbose
        | RenderMode::VerbosePlain => {
            let renderer = if live {
                TerminalRenderer::new(out, mode, bead_id, parallel, color)
            } else {
                TerminalRenderer::new_replay(out, mode, bead_id, parallel, color)
            };
            Box::new(renderer.with_tool_body_limit(max_inline_bytes))
        }
        RenderMode::Json => Box::new(JsonRenderer::new(out)),
        RenderMode::Raw => Box::new(RawRenderer::new(out)),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use loom_events::DriverKind;
    use loom_events::EventEnvelope;
    use loom_events::Source;
    use loom_events::identifier::{SessionId, ToolCallId};
    use serde_json::json;

    /// Fixture envelope for renderer tests. Carries a fully-valid
    /// `lm-test` bead id; the renderer reads `ts_ms` / `seq` / `source`
    /// but does not dispatch on `bead_id`, so the fixture is reused
    /// across every test that does not need to vary the envelope.
    fn sample_envelope() -> EventEnvelope {
        EventEnvelope {
            session_id: SessionId::new("sess-render").unwrap(),
            bead_id: Some(BeadId::new("lm-test").expect("valid bead id")),
            molecule_id: None,
            iteration: Some(0),
            source: Source::Agent,
            ts_ms: 0,
            seq: 0,
        }
    }

    struct CaptureSink {
        inner: std::sync::Arc<std::sync::Mutex<Vec<u8>>>,
    }

    impl Write for CaptureSink {
        fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
            self.inner
                .lock()
                .map_err(|_| io::Error::other("poisoned"))?
                .extend_from_slice(buf);
            Ok(buf.len())
        }

        fn flush(&mut self) -> io::Result<()> {
            Ok(())
        }
    }

    fn capture<F>(mode: RenderMode, parallel: bool, color: bool, f: F) -> String
    where
        F: FnOnce(&mut TerminalRenderer),
    {
        capture_with_limit(mode, parallel, color, tool_body::BODY_CAP_BYTES, f)
    }

    fn capture_with_limit<F>(
        mode: RenderMode,
        parallel: bool,
        color: bool,
        max_inline_bytes: usize,
        f: F,
    ) -> String
    where
        F: FnOnce(&mut TerminalRenderer),
    {
        let buf: Vec<u8> = Vec::new();
        let cell = std::sync::Arc::new(std::sync::Mutex::new(buf));
        let cell_for_writer = cell.clone();
        let mut r = TerminalRenderer::new(
            CaptureSink {
                inner: cell_for_writer,
            },
            mode,
            BeadId::new("lm-1").expect("valid bead id"),
            parallel,
            color,
        )
        .with_tool_body_limit(max_inline_bytes);
        f(&mut r);
        let guard = cell.lock().expect("not poisoned");
        String::from_utf8(guard.clone()).expect("utf-8")
    }

    #[test]
    fn default_mode_streams_message_deltas_as_prose() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::TextDelta {
                envelope: sample_envelope(),
                text: "hello world".to_string(),
            })
            .expect("render");
        });
        assert_eq!(out, "hello world");
    }

    #[test]
    fn verbose_mode_streams_message_deltas_verbatim() {
        let out = capture(RenderMode::Verbose, false, false, |r| {
            r.render_event(&AgentEvent::TextDelta {
                envelope: sample_envelope(),
                text: "hel".to_string(),
            })
            .expect("render");
            r.render_event(&AgentEvent::TextDelta {
                envelope: sample_envelope(),
                text: "lo".to_string(),
            })
            .expect("render");
        });
        assert_eq!(out, "hello");
    }

    #[test]
    fn tool_call_line_in_default_mode_shows_path() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("t1").unwrap(),
                tool: "Read".to_string(),
                params: json!({"file_path": "src/lib.rs"}),
                parent_tool_call_id: None,
            })
            .expect("render");
        });
        assert!(out.contains("Read"), "{out:?}");
        assert!(out.contains("src/lib.rs"), "{out:?}");
        assert!(out.ends_with('\n'));
    }

    #[test]
    fn parallel_mode_prefixes_tool_lines_with_bead_id() {
        let out = capture(RenderMode::Default, true, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("t1").unwrap(),
                tool: "Bash".to_string(),
                params: json!({"command": "cargo build"}),
                parent_tool_call_id: None,
            })
            .expect("render");
        });
        assert!(out.contains("[lm-1]"), "{out:?}");
        assert!(out.contains("Bash"));
    }

    #[test]
    fn header_line_includes_id_title_profile() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.header("Implement parser", &ProfileName::new("rust").unwrap())
                .expect("header");
        });
        assert!(out.contains("lm-1"), "{out:?}");
        assert!(out.contains("Implement parser"));
        assert!(out.contains("[profile:rust]"));
        assert!(out.ends_with('\n'));
    }

    #[test]
    fn finish_done_includes_tool_count_and_secs() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("t1").unwrap(),
                tool: "Read".to_string(),
                params: json!({"file_path": "a"}),
                parent_tool_call_id: None,
            })
            .expect("render");
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("t2").unwrap(),
                tool: "Edit".to_string(),
                params: json!({"file_path": "b"}),
                parent_tool_call_id: None,
            })
            .expect("render");
            r.write_finish(BeadOutcome::Done, std::time::Duration::from_secs(47))
                .expect("finish");
        });
        assert!(out.contains("done"));
        assert!(out.contains("2 tool calls"));
        assert!(out.contains("47s"));
    }

    #[test]
    fn finish_failed_emits_red_ansi_code() {
        let out = capture(RenderMode::Default, false, true, |r| {
            r.write_finish(BeadOutcome::Failed, std::time::Duration::from_secs(1))
                .expect("finish");
        });
        assert!(out.contains(ANSI_RED), "{out:?}");
        assert!(out.contains(ANSI_RESET));
    }

    #[test]
    fn finish_done_emits_green_ansi_code() {
        let out = capture(RenderMode::Default, false, true, |r| {
            r.write_finish(BeadOutcome::Done, std::time::Duration::from_secs(1))
                .expect("finish");
        });
        assert!(out.contains(ANSI_GREEN), "{out:?}");
        assert!(out.contains(ANSI_RESET));
    }

    #[test]
    fn finish_retry_emits_yellow_ansi_code() {
        let out = capture(RenderMode::Default, false, true, |r| {
            r.write_finish(BeadOutcome::Retry, std::time::Duration::from_secs(1))
                .expect("finish");
        });
        assert!(out.contains(ANSI_YELLOW), "{out:?}");
        assert!(out.contains(ANSI_RESET));
    }

    #[test]
    fn finish_with_color_off_omits_ansi_codes() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.write_finish(BeadOutcome::Done, std::time::Duration::from_secs(1))
                .expect("finish");
        });
        assert!(!out.contains(ANSI_GREEN), "{out:?}");
        assert!(!out.contains(ANSI_RESET), "{out:?}");
        assert!(out.contains("done"), "{out:?}");
    }

    // -- summary-cell tests ------------------------------------------------

    /// `ToolCall` lines use the per-tool spec cell — `Read   <path>:<range>`,
    /// `Edit   <path>   +N -M   diff↓`, `Bash   <cmd>`. The cell shape comes
    /// from `tool_body::summary_cell`; this test pins that the renderer
    /// dispatches through it.
    #[test]
    fn tool_call_line_uses_summary_cell_shape() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("e1").unwrap(),
                tool: "Edit".into(),
                params: json!({
                    "file_path": "src/lib.rs",
                    "old_string": "fn old() {}\n",
                    "new_string": "fn new() {}\nfn extra() {}\n",
                }),
                parent_tool_call_id: None,
            })
            .expect("render");
        });
        assert!(out.contains("Edit"), "{out:?}");
        assert!(out.contains("src/lib.rs"), "{out:?}");
        assert!(out.contains('+'), "{out:?}");
        assert!(out.contains('-'), "{out:?}");
        assert!(out.contains("diff"), "{out:?}");
    }

    #[test]
    fn terminal_renderer_honours_non_default_tool_body_limit() {
        let max_inline_bytes = 37;
        let body = format!("{}tail", "x".repeat(max_inline_bytes));
        let out = capture_with_limit(
            RenderMode::Plain,
            false,
            false,
            max_inline_bytes,
            |renderer| {
                renderer
                    .render_event(&AgentEvent::ToolCall {
                        envelope: sample_envelope(),
                        id: ToolCallId::new("configured-cap").unwrap(),
                        tool: "Bash".into(),
                        params: json!({"command": "emit bytes"}),
                        parent_tool_call_id: None,
                    })
                    .expect("render call");
                renderer
                    .render_event(&AgentEvent::ToolResult {
                        envelope: sample_envelope(),
                        id: ToolCallId::new("configured-cap").unwrap(),
                        output: body,
                        is_error: false,
                    })
                    .expect("render result");
            },
        );

        assert!(out.contains(&"x".repeat(max_inline_bytes)), "{out:?}");
        assert!(out.contains("display-only cap at 37 bytes"), "{out:?}");
        assert!(out.contains("4 bytes omitted"), "{out:?}");
    }

    #[test]
    fn verbose_mode_uses_normal_tool_result_body_byte_cap() {
        let big_body = "x".repeat(tool_body::BODY_CAP_BYTES + 32);
        let out = capture(RenderMode::Verbose, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "echo hi"}),
                parent_tool_call_id: None,
            })
            .expect("render call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                output: big_body,
                is_error: false,
            })
            .expect("render result");
        });
        assert!(out.contains("Bash"), "{out:?}");
        assert!(
            out.contains("display-only cap"),
            "missing cap hint: {out:?}"
        );
        assert!(out.contains("32 bytes omitted"), "{out:?}");
        assert!(out.contains("loom logs --raw -b lm-1"), "{out:?}");
        assert!(out.contains("tool b1"), "{out:?}");
    }

    /// Default mode renders a bounded Bash success excerpt.
    #[test]
    fn default_mode_renders_bash_body_on_success() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "echo hi"}),
                parent_tool_call_id: None,
            })
            .expect("render call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                output: "result body".into(),
                is_error: false,
            })
            .expect("render result");
        });
        assert!(out.contains("Bash"), "{out:?}");
        assert!(out.contains("result body"), "{out:?}");
    }

    /// Default mode renders the Bash body when `exit != 0` (`is_error=true`),
    /// capped with the standard recovery hint when the output exceeds
    /// the byte budget.
    #[test]
    fn default_mode_renders_bash_body_on_error_capped_by_bytes() {
        let big_body = "e".repeat(tool_body::BODY_CAP_BYTES + 12);
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "false"}),
                parent_tool_call_id: None,
            })
            .expect("render call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                output: big_body,
                is_error: true,
            })
            .expect("render result");
        });
        assert!(out.contains('✗'), "{out:?}");
        assert!(
            out.contains("display-only cap"),
            "missing cap line: {out:?}"
        );
        assert!(out.contains("12 bytes omitted"), "{out:?}");
        assert!(
            out.contains("loom logs --raw -b lm-1") && out.contains("tool b1"),
            "cap line must reference raw replay and the tool call id: {out:?}",
        );
    }

    /// Default mode renders the full Bash body when `exit != 0` and the
    /// output is at or under the byte cap — no cap line is emitted.
    #[test]
    fn default_mode_renders_bash_body_on_error_short_output_no_cap_line() {
        let body = "line1\nline2\nline3";
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "false"}),
                parent_tool_call_id: None,
            })
            .expect("render call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                output: body.into(),
                is_error: true,
            })
            .expect("render result");
        });
        assert!(out.contains("line1"), "{out:?}");
        assert!(out.contains("line3"), "{out:?}");
        assert!(
            !out.contains("display-only cap"),
            "no cap line when body is at or below the byte cap: {out:?}",
        );
    }

    /// Default mode renders non-Bash error bodies because failures need
    /// prominent output regardless of the tool that produced them.
    #[test]
    fn default_mode_renders_non_bash_error_body() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("r1").unwrap(),
                tool: "Read".into(),
                params: json!({"file_path": "src/lib.rs"}),
                parent_tool_call_id: None,
            })
            .expect("render call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("r1").unwrap(),
                output: "file-contents".into(),
                is_error: true,
            })
            .expect("render result");
        });
        assert!(out.contains("Read"), "{out:?}");
        assert!(out.contains("file-contents"), "{out:?}");
    }

    /// Renderer wraps `ToolCall` summary cells in OSC 8 hyperlinks when
    /// the OSC 8 context is enabled. Cmd-click on `src/lib.rs` in the
    /// rendered line opens the file in the user's editor.
    #[test]
    fn tool_call_line_wraps_paths_in_osc8_when_enabled() {
        let buf: Vec<u8> = Vec::new();
        let cell = std::sync::Arc::new(std::sync::Mutex::new(buf));
        let cell_for_writer = cell.clone();
        let mut r = TerminalRenderer::new(
            CaptureSink {
                inner: cell_for_writer,
            },
            RenderMode::Default,
            BeadId::new("lm-1").expect("valid bead id"),
            false,
            false,
        )
        .with_osc8(tool_body::Osc8Context::enabled(std::path::PathBuf::from(
            "/workspace",
        )));
        r.render_event(&AgentEvent::ToolCall {
            envelope: sample_envelope(),
            id: ToolCallId::new("e1").unwrap(),
            tool: "Edit".into(),
            params: json!({
                "file_path": "src/lib.rs",
                "old_string": "old\n",
                "new_string": "new\n",
            }),
            parent_tool_call_id: None,
        })
        .expect("render");
        let out = String::from_utf8(cell.lock().expect("not poisoned").clone()).expect("utf-8");
        assert!(
            out.contains("\x1b]8;;file:///workspace/src/lib.rs"),
            "Edit summary cell must wrap the path in OSC 8: {out:?}",
        );
        assert!(
            out.contains("src/lib.rs"),
            "display text still present: {out:?}"
        );
    }

    /// Without OSC 8 (default), the rendered line contains plain text
    /// with no escape bytes around the path. Silent degradation.
    #[test]
    fn tool_call_line_no_osc8_by_default() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("e1").unwrap(),
                tool: "Edit".into(),
                params: json!({
                    "file_path": "src/lib.rs",
                    "old_string": "old\n",
                    "new_string": "new\n",
                }),
                parent_tool_call_id: None,
            })
            .expect("render");
        });
        assert!(out.contains("src/lib.rs"), "{out:?}");
        assert!(
            !out.contains("\x1b]8;;"),
            "default context must not emit OSC 8 escapes: {out:?}",
        );
    }

    #[test]
    fn verbose_mode_keeps_tool_error_body_without_extra_detail_gate() {
        let out = capture(RenderMode::Verbose, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "false"}),
                parent_tool_call_id: None,
            })
            .expect("render call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                output: "exit 1".into(),
                is_error: true,
            })
            .expect("render result");
        });
        assert!(out.contains("exit 1"), "{out:?}");
        assert!(!out.contains("[tool error]"), "{out:?}");
    }

    // -- H2 tests ----------------------------------------------------------

    fn captured() -> (
        std::sync::Arc<std::sync::Mutex<Vec<u8>>>,
        impl Write + Send + 'static,
    ) {
        let buf = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let writer = SharedWriter(buf.clone());
        (buf, writer)
    }

    struct SharedWriter(std::sync::Arc<std::sync::Mutex<Vec<u8>>>);

    impl Write for SharedWriter {
        fn write(&mut self, b: &[u8]) -> io::Result<usize> {
            self.0
                .lock()
                .map_err(|_| io::Error::other("poisoned"))?
                .extend_from_slice(b);
            Ok(b.len())
        }
        fn flush(&mut self) -> io::Result<()> {
            Ok(())
        }
    }

    fn captured_str(buf: &std::sync::Arc<std::sync::Mutex<Vec<u8>>>) -> String {
        let g = buf.lock().expect("not poisoned");
        String::from_utf8(g.clone()).expect("utf-8")
    }

    fn sample_text_delta() -> AgentEvent {
        AgentEvent::TextDelta {
            envelope: sample_envelope(),
            text: "hello".into(),
        }
    }

    fn sample_tool_call() -> AgentEvent {
        AgentEvent::ToolCall {
            envelope: sample_envelope(),
            id: ToolCallId::new("t1").unwrap(),
            tool: "Read".into(),
            params: json!({"file_path": "src/lib.rs"}),
            parent_tool_call_id: None,
        }
    }

    /// All four spec'd render modes are present and `build_renderer`
    /// dispatches to a concrete impl for each.
    #[test]
    fn renderer_modes_present() {
        let bead = BeadId::new("lm-1").expect("valid id");
        for mode in [
            RenderMode::Pretty,
            RenderMode::Plain,
            RenderMode::Json,
            RenderMode::Raw,
        ] {
            let (_, writer) = captured();
            let r = build_renderer(mode, Box::new(writer), bead.clone(), false, true);
            drop(r); // sanity — each mode constructs without panic
        }
    }

    /// TTY + no env / flags → Pretty.
    #[test]
    fn pretty_selected_on_tty() {
        assert_eq!(
            RenderMode::select(true, false, RenderFormat::Auto),
            RenderMode::Pretty,
        );
    }

    /// Non-TTY → Plain (NO_COLOR-agnostic).
    #[test]
    fn plain_selected_on_non_tty() {
        assert_eq!(
            RenderMode::select(false, false, RenderFormat::Auto),
            RenderMode::Plain,
        );
    }

    /// `NO_COLOR=1` on TTY → Plain (no-color.org contract).
    #[test]
    fn plain_selected_when_no_color_env() {
        assert_eq!(
            RenderMode::select(true, true, RenderFormat::Auto),
            RenderMode::Plain,
        );
    }

    /// `--json` beats TTY-detect → Json regardless of env.
    #[test]
    fn json_flag_wins_over_tty() {
        assert_eq!(
            RenderMode::select(true, false, RenderFormat::Json),
            RenderMode::Json,
        );
    }

    /// `--raw` beats `--json` per the spec's exclusivity contract.
    /// (clap enforces this at parse time but the selector is
    /// defensive: raw > json > plain > pretty.)
    #[test]
    fn raw_flag_wins_over_json() {
        assert_eq!(
            RenderMode::select(true, false, RenderFormat::Raw),
            RenderMode::Raw,
        );
    }

    /// `JsonRenderer` writes pretty-printed JSON, one object per line.
    /// Pretty-printing means newlines INSIDE the object, then the
    /// terminator newline.
    #[test]
    fn json_mode_pretty_prints() {
        let (buf, writer) = captured();
        let mut r = JsonRenderer::new(writer);
        r.render_event(&sample_text_delta()).expect("render");
        let out = captured_str(&buf);
        assert!(out.starts_with('{'), "json must start with `{{`: {out}");
        // Pretty-printing keeps fields on separate lines.
        assert!(
            out.contains("\n  \"kind\""),
            "json output must be pretty-printed: {out}",
        );
        assert!(out.ends_with('\n'));
    }

    /// H6 — when a `ToolCall` carries `parent_tool_call_id = Some(parent)`,
    /// the renderer prints it indented by 2 spaces beyond the parent.
    /// Tracks indent depth per `tool_call_id` so nested chains layer
    /// correctly (Task → Read → Edit etc.).
    #[test]
    fn task_subagent_nesting_indents_nested_tool_calls() {
        let out = capture(RenderMode::Default, false, false, |r| {
            // Top-level Task call — no parent, depth 0.
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("task1").unwrap(),
                tool: "Task".into(),
                params: json!({}),
                parent_tool_call_id: None,
            })
            .expect("render task");
            // Nested call inside the Task — depth 1, prefixed with two
            // extra spaces.
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("read1").unwrap(),
                tool: "Read".into(),
                params: json!({"file_path": "a"}),
                parent_tool_call_id: Some(ToolCallId::new("task1").unwrap()),
            })
            .expect("render nested");
        });
        let lines: Vec<&str> = out.lines().collect();
        assert_eq!(lines.len(), 2, "expected 2 lines, got: {out:?}");
        // Top-level: 2-space prefix (the renderer's base indent).
        assert!(lines[0].starts_with("  Task"), "{}", lines[0]);
        // Nested: base 2 + indent 2 = 4 spaces before the tool name.
        assert!(lines[1].starts_with("    Read"), "{}", lines[1]);
    }

    /// `RawRenderer` writes a compact JSON line — no embedded newlines
    /// in the object, terminator newline at end. Round-trips back to
    /// `AgentEvent` cleanly.
    #[test]
    fn raw_mode_passthrough() {
        let (buf, writer) = captured();
        let mut r = RawRenderer::new(writer);
        r.render_event(&sample_tool_call()).expect("render");
        let out = captured_str(&buf);
        let trimmed = out.trim_end_matches('\n');
        // Compact form has no internal newlines.
        assert!(
            !trimmed.contains('\n'),
            "raw output must be one compact line: {out}",
        );
        // Parses back to the same variant.
        let back: AgentEvent = serde_json::from_str(trimmed).expect("parse back");
        assert!(matches!(back, AgentEvent::ToolCall { .. }));
    }

    /// Build a `ToolCall` + `ToolResult` pair with explicit `ts_ms`
    /// values so the test can pin pair duration without touching
    /// either the wall clock or the renderer's `Clock` injection.
    fn tool_pair_with_ts(
        id: &str,
        tool: &str,
        params: serde_json::Value,
        call_ts: i64,
        result_ts: i64,
    ) -> (AgentEvent, AgentEvent) {
        let call_env = EventEnvelope {
            ts_ms: call_ts,
            ..sample_envelope()
        };
        let result_env = EventEnvelope {
            ts_ms: result_ts,
            ..sample_envelope()
        };
        (
            AgentEvent::ToolCall {
                envelope: call_env,
                id: ToolCallId::new(id).unwrap(),
                tool: tool.to_string(),
                params,
                parent_tool_call_id: None,
            },
            AgentEvent::ToolResult {
                envelope: result_env,
                id: ToolCallId::new(id).unwrap(),
                output: String::new(),
                is_error: false,
            },
        )
    }

    /// H2 + spec criterion `test_tool_call_result_pairing` — a paired
    /// `tool_call` + `tool_result` renders as a single closing line
    /// whose `Ns` duration comes from the events' `ts_ms` delta. We
    /// use the live + indicator path (color=true) because that is the
    /// branch where pair collapse is visible — the in-place line is
    /// rewritten with the final glyph + duration.
    #[test]
    fn tool_call_result_pairing_collapses_with_ts_ms_duration() {
        // color=true → indicator on (live + non-parallel). Pair the
        // result with a 3.5s ts_ms delta so the test can pin the
        // rendered duration independent of wall clock.
        let out = capture(RenderMode::Default, false, true, |r| {
            let (call, result) = tool_pair_with_ts(
                "t1",
                "Bash",
                serde_json::json!({"command": "cargo test"}),
                1_000,
                4_500,
            );
            r.render_event(&call).expect("render call");
            r.render_event(&result).expect("render result");
        });
        // After ToolResult, the running line is finalized — `\r` +
        // clear-to-EOL + the closing summary with the pair duration.
        assert!(out.contains("Bash"), "{out:?}");
        assert!(out.contains("cargo test"), "{out:?}");
        // ts_ms delta = 3500ms → "3.5s".
        assert!(out.contains("3.5s"), "expected pair duration 3.5s: {out:?}");
        // Single combined block: only one trailing newline after the
        // final summary, i.e. no separate ToolResult line.
        let trailing_newlines = out.chars().rev().take_while(|c| *c == '\n').count();
        assert_eq!(trailing_newlines, 1, "{out:?}");
    }

    /// H2 + spec criterion `test_live_vs_replay_distinction` — the
    /// `PrettyRenderer` (and `TerminalRenderer`) take a `live: bool`
    /// switch. Live emits the in-place `running...` indicator while a
    /// tool is in flight; replay suppresses it entirely and computes
    /// the pair's duration from `ts_ms` deltas.
    #[test]
    fn live_vs_replay_distinction_pretty_renderer() {
        // Live path: indicator appears between ToolCall and ToolResult.
        let (live_buf, live_writer) = captured();
        let mut live_pretty =
            PrettyRenderer::new(live_writer, BeadId::new("lm-1").expect("id"), false, true);
        let (call, result) = tool_pair_with_ts(
            "t1",
            "Bash",
            serde_json::json!({"command": "sleep 3"}),
            0,
            3_000,
        );
        live_pretty.render_event(&call).expect("live call");
        // Snapshot mid-pair: the running line is present.
        let mid = captured_str(&live_buf);
        assert!(
            mid.contains("running..."),
            "live mode must emit in-place running indicator: {mid:?}",
        );
        live_pretty.render_event(&result).expect("live result");
        let live_final = captured_str(&live_buf);
        assert!(live_final.contains("3.0s"), "{live_final:?}");

        // Replay path: indicator is suppressed; the ToolCall summary
        // prints once and the ToolResult appends a closing line under
        // it with the ts_ms-derived duration.
        let (replay_buf, replay_writer) = captured();
        let mut replay_pretty = PrettyRenderer::new(
            replay_writer,
            BeadId::new("lm-1").expect("id"),
            false,
            false,
        );
        replay_pretty.render_event(&call).expect("replay call");
        let mid_replay = captured_str(&replay_buf);
        assert!(
            !mid_replay.contains("running..."),
            "replay must NOT emit the running indicator: {mid_replay:?}",
        );
        replay_pretty.render_event(&result).expect("replay result");
        let replay_final = captured_str(&replay_buf);
        assert!(
            replay_final.contains("3.0s"),
            "replay duration from ts_ms delta: {replay_final:?}",
        );
    }

    /// Spec criterion `test_logs_reuses_renderer` — the `Renderer`
    /// trait + impls are reused between `loom loop` and `loom logs`. We
    /// pin this by deserializing events from a JSONL line (the on-disk
    /// shape `loom logs` reads) and feeding them through the same
    /// `build_renderer` path `loom loop` uses. The renderer trait
    /// object is the only contract both share.
    #[test]
    fn logs_reuses_renderer_via_jsonl_round_trip() {
        let bead = BeadId::new("lm-1").expect("id");
        let (call, result) = tool_pair_with_ts(
            "t1",
            "Bash",
            serde_json::json!({"command": "echo hi"}),
            0,
            2_000,
        );
        // Round-trip through JSONL — same path `loom logs` would take
        // when replaying a saved log file.
        let lines = [
            serde_json::to_string(&call).expect("ser call"),
            serde_json::to_string(&result).expect("ser result"),
        ];
        let replayed: Vec<AgentEvent> = lines
            .iter()
            .map(|s| serde_json::from_str::<AgentEvent>(s).expect("deser"))
            .collect();

        // Build via `build_renderer` (the public selection function
        // shared by `loom loop` and `loom logs`) with `live=false`.
        let (buf, writer) = captured();
        let mut r = build_renderer(RenderMode::Plain, Box::new(writer), bead, false, false);
        for ev in &replayed {
            r.render_event(ev).expect("render");
        }
        r.finish(BeadOutcome::Done, Duration::from_secs(2))
            .expect("finish");
        let out = captured_str(&buf);
        assert!(out.contains("Bash"), "{out:?}");
        // Replay path emits a closing glyph + ts_ms-derived duration
        // for the pair.
        assert!(out.contains("2.0s"), "{out:?}");
    }

    fn driver_event(kind: &str, summary: &str, payload: serde_json::Value) -> AgentEvent {
        AgentEvent::DriverEvent {
            envelope: EventEnvelope {
                source: loom_events::Source::Driver,
                ..sample_envelope()
            },
            driver_kind: DriverKind::from_wire(kind),
            summary: summary.to_string(),
            payload,
        }
    }

    #[test]
    fn normal_rendering_shows_llm_visible_transcript() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::AgentInput {
                envelope: EventEnvelope {
                    source: loom_events::Source::Driver,
                    ..sample_envelope()
                },
                input_kind: InputKind::InitialPrompt,
                text: "system prompt visible to the model".into(),
                redactions: None,
            })
            .expect("agent input");
            r.render_event(&AgentEvent::TextDelta {
                envelope: sample_envelope(),
                text: "visible assistant reply\n".into(),
            })
            .expect("text");
            r.render_event(&AgentEvent::ThinkingDelta {
                envelope: sample_envelope(),
                text: "exposed reasoning\n".into(),
            })
            .expect("thinking");
            r.render_event(&AgentEvent::ThinkingEnd {
                envelope: sample_envelope(),
            })
            .expect("thinking end");
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "printf transcript"}),
                parent_tool_call_id: None,
            })
            .expect("tool call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                output: "inline tool output".into(),
                is_error: false,
            })
            .expect("tool result");
            r.render_event(&driver_event(
                "push_gate_walk",
                "driver progress row",
                json!({"lane": "verify"}),
            ))
            .expect("driver");
        });
        for expected in [
            "agent_input initial_prompt",
            "system prompt visible to the model",
            "visible assistant reply",
            "thinking: exposed reasoning",
            "Bash",
            "inline tool output",
            "driver progress row",
        ] {
            assert!(out.contains(expected), "missing {expected:?}: {out:?}");
        }
    }

    #[test]
    fn pretty_tool_block_updates_from_pending_to_success_or_error() {
        let out = capture(RenderMode::Default, false, true, |r| {
            let (call, result) =
                tool_pair_with_ts("t1", "Bash", json!({"command": "cargo test"}), 0, 2_000);
            r.render_event(&call).expect("call");
            r.render_event(&AgentEvent::ToolProgress {
                envelope: sample_envelope(),
                id: ToolCallId::new("t1").unwrap(),
                text: "running unit tests".into(),
            })
            .expect("progress");
            r.render_event(&result).expect("result");

            let (err_call, err_result) =
                tool_pair_with_ts("t2", "Bash", json!({"command": "false"}), 3_000, 4_000);
            r.render_event(&err_call).expect("error call");
            let AgentEvent::ToolResult {
                envelope,
                id,
                output,
                ..
            } = err_result
            else {
                panic!("expected tool result");
            };
            r.render_event(&AgentEvent::ToolResult {
                envelope,
                id,
                output,
                is_error: true,
            })
            .expect("error result");
        });
        assert!(out.contains("running..."), "{out:?}");
        assert!(out.contains("running unit tests"), "{out:?}");
        assert!(out.contains('✓'), "{out:?}");
        assert!(out.contains('✗'), "{out:?}");
        assert!(out.contains("2.0s"), "{out:?}");
        assert!(out.contains("1.0s"), "{out:?}");
    }

    #[test]
    fn tool_progress_result_keeps_status_attached_to_summary() {
        let out = capture(RenderMode::Default, false, true, |r| {
            let (call, result) =
                tool_pair_with_ts("t1", "Bash", json!({"command": "cargo test"}), 0, 2_000);
            r.render_event(&call).expect("call");
            r.render_event(&AgentEvent::ToolProgress {
                envelope: sample_envelope(),
                id: ToolCallId::new("t1").unwrap(),
                text: "running unit tests".into(),
            })
            .expect("progress");
            r.render_event(&result).expect("result");
        });

        let success_lines: Vec<&str> = out.lines().filter(|line| line.contains('✓')).collect();
        assert!(
            success_lines
                .iter()
                .any(|line| line.contains("Bash") && line.contains("cargo test")),
            "final success row must repeat the tool summary after progress: {out:?}",
        );
        assert!(
            success_lines
                .iter()
                .all(|line| !line.trim_start().starts_with('✓')),
            "success must not degrade to a detached status-only row: {out:?}",
        );
    }

    #[test]
    fn lowercase_read_result_renders_summary_and_body() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("r1").unwrap(),
                tool: "read".into(),
                params: json!({"path": "crates/wrix-sandbox/Cargo.toml"}),
                parent_tool_call_id: None,
            })
            .expect("call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("r1").unwrap(),
                output: "[package]\nname = \"wrix-sandbox\"".into(),
                is_error: false,
            })
            .expect("result");
        });

        assert!(out.contains("Read"), "{out:?}");
        assert!(out.contains("crates/wrix-sandbox/Cargo.toml"), "{out:?}");
        assert!(out.contains("wrix-sandbox"), "{out:?}");
    }

    #[test]
    fn cumulative_tool_output_snapshots_render_only_new_content() {
        let first = "fetch dep alpha\ncompile crate beta";
        let second = format!("{first}\ncompile crate gamma");
        let final_output = format!("{second}\nlink final binary");
        let out = capture(RenderMode::Default, false, true, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "nix build"}),
                parent_tool_call_id: None,
            })
            .expect("tool call");
            r.render_event(&AgentEvent::ToolProgress {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                text: first.into(),
            })
            .expect("first progress");
            r.render_event(&AgentEvent::ToolProgress {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                text: second,
            })
            .expect("second progress");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                output: final_output,
                is_error: false,
            })
            .expect("result");
        });

        for expected in [
            "fetch dep alpha",
            "compile crate beta",
            "compile crate gamma",
            "link final binary",
        ] {
            assert_eq!(out.match_indices(expected).count(), 1, "{out:?}");
        }
        assert!(out.contains('✓'), "{out:?}");
    }

    #[test]
    fn cumulative_tool_output_snapshots_share_one_byte_budget() {
        let first = "a".repeat(tool_body::BODY_CAP_BYTES - 4);
        let second = format!("{first}bbbbcccc");
        let out = capture(RenderMode::Default, false, true, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "nix build"}),
                parent_tool_call_id: None,
            })
            .expect("tool call");
            r.render_event(&AgentEvent::ToolProgress {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                text: first,
            })
            .expect("first progress");
            r.render_event(&AgentEvent::ToolProgress {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                text: second,
            })
            .expect("second progress");
        });

        assert!(out.contains("bbbb"), "{out:?}");
        assert!(!out.contains("cccc"), "{out:?}");
        assert!(out.contains("4 bytes omitted"), "{out:?}");
        assert_eq!(out.match_indices("display-only cap").count(), 1, "{out:?}");
    }

    fn strip_metadata_lines(output: &str) -> String {
        let mut stripped = output
            .lines()
            .filter(|line| !line.trim_start().starts_with("[event "))
            .collect::<Vec<_>>()
            .join("\n");
        if output.ends_with('\n') && !stripped.is_empty() {
            stripped.push('\n');
        }
        stripped
    }

    #[test]
    fn verbose_adds_event_metadata_without_changing_transcript() {
        let body: String = (1..=15)
            .map(|i| format!("file-line-{i}"))
            .collect::<Vec<_>>()
            .join("\n");
        let events = vec![
            AgentEvent::ToolCall {
                envelope: EventEnvelope {
                    seq: 7,
                    ts_ms: 1234,
                    ..sample_envelope()
                },
                id: ToolCallId::new("r1").unwrap(),
                tool: "Read".into(),
                params: json!({"file_path": "src/lib.rs", "api_key": "secret"}),
                parent_tool_call_id: None,
            },
            AgentEvent::ToolResult {
                envelope: EventEnvelope {
                    seq: 8,
                    ts_ms: 2234,
                    ..sample_envelope()
                },
                id: ToolCallId::new("r1").unwrap(),
                output: body,
                is_error: false,
            },
            driver_event(
                "push_gate_walk",
                "driver detail",
                json!({"lane": "verify", "token": "secret"}),
            ),
        ];
        let normal = capture(RenderMode::Default, false, false, |r| {
            for event in &events {
                r.render_event(event).expect("normal render");
            }
        });
        let verbose = capture(RenderMode::VerbosePlain, false, false, |r| {
            for event in &events {
                r.render_event(event).expect("verbose render");
            }
        });

        assert_eq!(strip_metadata_lines(&verbose), normal);
        for expected in [
            "[event kind=tool_call seq=7 ts_ms=1234",
            "id=r1",
            "params={\"api_key\":\"[REDACTED]\",\"file_path\":\"src/lib.rs\"}",
            "[event kind=tool_result seq=8 ts_ms=2234",
            "bytes=185",
            "[event kind=driver_event",
            "payload={\"lane\":\"verify\",\"token\":\"[REDACTED]\"}",
        ] {
            assert!(
                verbose.contains(expected),
                "missing {expected:?}: {verbose:?}"
            );
        }
        assert!(normal.contains("file-line-15"), "{normal:?}");
        assert!(verbose.contains("file-line-15"), "{verbose:?}");
        assert!(!normal.contains("display-only cap"), "{normal:?}");
        assert!(!verbose.contains("display-only cap"), "{verbose:?}");
    }

    #[test]
    fn driver_events_render_interleaved_with_agent_events() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&AgentEvent::TextDelta {
                envelope: sample_envelope(),
                text: "agent before".into(),
            })
            .expect("text before");
            r.render_event(&driver_event(
                "push_gate_walk",
                "driver middle",
                json!({"lane": "verify"}),
            ))
            .expect("driver");
            r.render_event(&AgentEvent::TextDelta {
                envelope: sample_envelope(),
                text: "agent after".into(),
            })
            .expect("text after");
        });
        let before = out.find("agent before").expect("before text");
        let middle = out.find("driver middle").expect("driver text");
        let after = out.find("agent after").expect("after text");
        assert!(before < middle && middle < after, "{out:?}");
    }

    /// `driver_event` variants render with the `→` arrow glyph followed by
    /// `<driver_kind>: <summary>`. Pins the rendered shape for every
    /// known `driver_kind` the spec enumerates.
    #[test]
    fn driver_event_renders_arrow_glyph() {
        for kind in [
            "verdict_gate",
            "retry_dispatch",
            "push_gate_walk",
            "push_gate_refuse",
            "push_gate_clean",
            "container_spawn",
            "container_oom",
            "infra_failure",
            "stall_watchdog",
            "token_usage",
            "offload",
            "duplicate_tool_result",
            "doom_loop_tripped",
            "epic_auto_closed",
            "bead_branch_pushed",
            "merge_ok",
            "merge_conflict",
            "integration_conflict",
            "signature_verification_failed",
            "worktree_cleanup_ok",
            "tree_not_clean",
            "workspace_recovery",
            "gate_run_start",
            "gate_run_scope",
            "gate_run_lane",
            "gate_run_end",
            "gate_run_skipped",
        ] {
            let out = capture(RenderMode::Default, false, false, |r| {
                r.render_event(&driver_event(kind, "summary text", json!({})))
                    .expect("render");
            });
            assert!(
                out.contains('→'),
                "driver_event must render with `→` glyph for kind={kind}: {out:?}",
            );
            assert!(
                out.contains(kind),
                "driver_event line must include kind {kind}: {out:?}",
            );
            assert!(
                out.contains("summary text"),
                "driver_event line must include summary: {out:?}",
            );
        }
    }

    /// Unknown `driver_kind` strings — new event types added without
    /// schema bumps — render as the same generic `→ <kind>: <summary>`
    /// fallback as known kinds. Renderer never errors on an unrecognized
    /// `driver_kind`.
    #[test]
    fn unknown_driver_kind_renders_generic_arrow_summary() {
        let out = capture(RenderMode::Default, false, false, |r| {
            r.render_event(&driver_event(
                "totally_new_driver_kind",
                "future event body",
                json!({"detail": 7}),
            ))
            .expect("render");
        });
        assert!(out.contains('→'), "unknown kind needs arrow glyph: {out:?}");
        assert!(
            out.contains("totally_new_driver_kind: future event body"),
            "fallback line is `<kind>: <summary>`: {out:?}",
        );
    }

    /// Driver events render in `Parallel` mode with the bead-id prefix
    /// just like tool-call lines, so multi-bead UIs attribute the event
    /// to its source bead.
    #[test]
    fn driver_event_parallel_mode_prefixes_bead_id() {
        let out = capture(RenderMode::Default, true, false, |r| {
            r.render_event(&driver_event(
                "push_gate_walk",
                "evaluating verdict",
                json!({}),
            ))
            .expect("render");
        });
        assert!(out.contains("[lm-1]"), "{out:?}");
        assert!(out.contains("→"), "{out:?}");
        assert!(out.contains("push_gate_walk"), "{out:?}");
    }

    #[test]
    fn parallel_rendering_prefixes_lines_and_disables_spinners() {
        let out = capture(RenderMode::Verbose, true, true, |r| {
            r.render_event(&AgentEvent::TextDelta {
                envelope: sample_envelope(),
                text: "assistant one\nassistant two".into(),
            })
            .expect("text");
            r.render_event(&AgentEvent::TextEnd {
                envelope: sample_envelope(),
            })
            .expect("text end");
            r.render_event(&AgentEvent::ThinkingDelta {
                envelope: sample_envelope(),
                text: "thought one\nthought two".into(),
            })
            .expect("thinking");
            r.render_event(&AgentEvent::ThinkingEnd {
                envelope: sample_envelope(),
            })
            .expect("thinking end");
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                tool: "Bash".into(),
                params: json!({"command": "cargo test"}),
                parent_tool_call_id: None,
            })
            .expect("tool call");
            r.render_event(&AgentEvent::ToolResult {
                envelope: sample_envelope(),
                id: ToolCallId::new("b1").unwrap(),
                output: "body one\nbody two".into(),
                is_error: false,
            })
            .expect("tool result");
            r.render_event(&driver_event(
                "push_gate_walk",
                "driver row",
                json!({"lane": "verify"}),
            ))
            .expect("driver");
            r.write_finish(BeadOutcome::Done, Duration::from_secs(3))
                .expect("finish");
        });

        assert!(!out.contains("running..."), "{out:?}");
        assert!(!out.contains('\r'), "{out:?}");
        for line in out.lines().filter(|line| !line.trim().is_empty()) {
            assert!(
                line.starts_with("  [lm-1] ") || line.starts_with("[lm-1] "),
                "parallel line must carry bead prefix: {line:?} in {out:?}",
            );
        }
        for expected in [
            "assistant one",
            "assistant two",
            "thought one",
            "thought two",
            "Bash",
            "body one",
            "body two",
            "driver row",
            "done",
        ] {
            assert!(out.contains(expected), "missing {expected:?}: {out:?}");
        }
    }

    // -- Summary-cell overflow tests ---------------------------------------

    /// Run a `TerminalRenderer` callback against a captured buffer with
    /// a pinned terminal width — the overflow tests depend on knowing
    /// exactly how many columns are available without relying on the
    /// host pty.
    fn capture_with_width<F>(parallel: bool, color: bool, width: usize, live: bool, f: F) -> String
    where
        F: FnOnce(&mut TerminalRenderer),
    {
        let buf: Vec<u8> = Vec::new();
        let cell = std::sync::Arc::new(std::sync::Mutex::new(buf));
        let cell_for_writer = cell.clone();
        let sink = CaptureSink {
            inner: cell_for_writer,
        };
        let renderer = if live {
            TerminalRenderer::new(
                sink,
                RenderMode::Default,
                BeadId::new("lm-1").expect("id"),
                parallel,
                color,
            )
        } else {
            TerminalRenderer::new_replay(
                sink,
                RenderMode::Default,
                BeadId::new("lm-1").expect("id"),
                parallel,
                color,
            )
        };
        let mut r = renderer.with_term_width(width);
        f(&mut r);
        let guard = cell.lock().expect("not poisoned");
        String::from_utf8(guard.clone()).expect("utf-8")
    }

    /// A short Bash command with the indicator on (live, color, single-
    /// bead) lays the summary cell + right-edge column on one line — the
    /// "fits as today" case from the spec. Terminal width is wide enough
    /// to hold the full single-line form, so no continuation appears.
    #[test]
    fn summary_overflow_short_command_stays_single_line() {
        let out = capture_with_width(false, true, 120, true, |r| {
            let (call, result) = tool_pair_with_ts("t1", "Bash", json!({"command": "ls"}), 0, 500);
            r.render_event(&call).expect("call");
            r.render_event(&result).expect("result");
        });
        // Single-line layout: summary + spacer + right-edge column on
        // one row. The pair collapses into one printed line (one final
        // newline) after the \r overwrite.
        assert!(out.contains("Bash"), "{out:?}");
        assert!(out.contains("ls"), "{out:?}");
        assert!(out.contains("0.5s"), "{out:?}");
        let lines: Vec<&str> = out.split('\n').filter(|l| !l.is_empty()).collect();
        assert_eq!(lines.len(), 1, "fits case must be single line: {out:?}");
        assert!(
            lines[0].contains("ls") && lines[0].contains("0.5s"),
            "summary and right-col must share the line: {out:?}",
        );
    }

    /// When the summary cell + right-edge column would overrun the
    /// terminal width, the renderer suppresses the in-place indicator
    /// and emits a two-line layout at result time: right-edge column
    /// alone on line 1 (right-aligned so the duration / glyph stays at
    /// the terminal edge), full summary on a body-indented continuation
    /// line beneath it.
    #[test]
    fn summary_overflow_wraps_to_continuation_line() {
        // 40-col terminal — narrow enough that a long Bash command can't
        // share a row with the right-edge column.
        let out = capture_with_width(false, true, 40, true, |r| {
            let (call, result) = tool_pair_with_ts(
                "t1",
                "Bash",
                json!({
                    "command": "cargo test --workspace --all-features",
                }),
                0,
                1_200,
            );
            r.render_event(&call).expect("call");
            r.render_event(&result).expect("result");
        });
        let lines: Vec<&str> = out.split('\n').filter(|l| !l.is_empty()).collect();
        assert_eq!(
            lines.len(),
            2,
            "overflow case must emit right-col line + continuation: {out:?}",
        );
        // Line 1: right-edge column right-aligned to the terminal width.
        // Line 2: full summary on the body-indented continuation line.
        assert!(
            lines[0].trim_end().ends_with("1.2s"),
            "line 1 must end with the duration / right-edge column: {out:?}",
        );
        assert!(
            lines[0].contains('✓'),
            "line 1 must carry the status glyph: {out:?}",
        );
        assert!(
            !lines[0].contains("cargo"),
            "line 1 must NOT carry the summary content: {out:?}",
        );
        assert!(
            lines[1].contains("cargo test --workspace --all-features"),
            "line 2 must carry the full summary: {out:?}",
        );
        // Right-edge column must stay within the terminal width — the
        // hard spec contract.
        let line1_width = display_width(lines[0]);
        assert!(
            line1_width <= 40,
            "right-edge column line must not exceed terminal width: {line1_width} > 40 in {out:?}",
        );
        // Continuation indent — the summary sits at one level deeper
        // than the top-level depth indent ("  " + "  " = 4 leading
        // spaces for a depth-0 call).
        assert!(
            lines[1].starts_with("    "),
            "continuation line must use the body indent (4 spaces for depth 0): {out:?}",
        );
    }

    /// Every per-tool summary cell goes through the same overflow path.
    /// Walk Read / Edit / Write / Grep / Glob / Bash / `WebFetch` /
    /// `WebSearch` / Task / a custom unknown tool and pin that the
    /// right-edge column survives intact when the left content blows
    /// past the terminal width.
    #[test]
    fn summary_overflow_applies_to_every_per_tool_cell() {
        let long = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        let cases: Vec<(&str, serde_json::Value)> = vec![
            (
                "Read",
                json!({"file_path": format!("very/deep/path/to/some/{long}.rs")}),
            ),
            (
                "Edit",
                json!({
                    "file_path": format!("deep/{long}.rs"),
                    "old_string": "x\n",
                    "new_string": "y\n",
                }),
            ),
            (
                "Write",
                json!({"file_path": format!("deep/{long}.rs"), "content": "a"}),
            ),
            ("Grep", json!({"pattern": long, "path": "src"})),
            ("Glob", json!({"pattern": long, "path": "src"})),
            ("Bash", json!({"command": format!("echo {long}")})),
            (
                "WebFetch",
                json!({"url": format!("https://example.com/{long}")}),
            ),
            ("WebSearch", json!({"query": long})),
            (
                "Task",
                json!({"description": long, "subagent_type": "general-purpose"}),
            ),
            // Generic fallback path — unknown tools render as the tool
            // name verbatim, so the overflow trigger is a long name.
            (
                "ACustomUnknownToolWithAnExceptionallyLongIdentifier",
                json!({"anything": long}),
            ),
        ];
        for (tool, params) in cases {
            let mut env_a = sample_envelope();
            env_a.ts_ms = 0;
            let mut env_b = sample_envelope();
            env_b.ts_ms = 1_000;
            let call = AgentEvent::ToolCall {
                envelope: env_a,
                id: ToolCallId::new("t1").unwrap(),
                tool: tool.to_string(),
                params,
                parent_tool_call_id: None,
            };
            let result = AgentEvent::ToolResult {
                envelope: env_b,
                id: ToolCallId::new("t1").unwrap(),
                output: String::new(),
                is_error: false,
            };
            let out = capture_with_width(false, true, 40, true, |r| {
                r.render_event(&call).expect("call");
                r.render_event(&result).expect("result");
            });
            let lines: Vec<&str> = out.split('\n').filter(|l| !l.is_empty()).collect();
            assert!(
                lines.len() >= 2,
                "{tool} overflow must produce >=2 lines: {out:?}",
            );
            // Right-edge column visible on the first line and within
            // the terminal width.
            assert!(
                lines[0].contains('✓') && lines[0].contains("1.0s"),
                "{tool} right-edge column missing on line 1: {out:?}",
            );
            let line1_width = display_width(lines[0]);
            assert!(
                line1_width <= 40,
                "{tool} right-edge column line overflows terminal width \
                 ({line1_width} > 40): {out:?}",
            );
            // Tool name surfaces on the continuation line (for the
            // generic / custom case, this is just the tool string).
            assert!(
                lines[1].contains(tool),
                "{tool} continuation line must carry the tool name: {out:?}",
            );
        }
    }

    /// Once the in-place indicator decides the line fits, it must keep
    /// fitting for the duration of the call — i.e. the reserve covers
    /// the running counter's worst case. Pin this by checking that the
    /// initial `running... 0.0s` line never exceeds the terminal width
    /// when the renderer chose the single-line path.
    #[test]
    fn summary_overflow_indicator_reserve_covers_running_text() {
        // Choose a summary length that just barely fits the threshold
        // at 40 cols. With prefix=2, separator=3, reserve=17 the
        // summary budget is 40 - 22 = 18 cols. A `Bash   echo hi`
        // summary (15 cols) sits below that.
        let out = capture_with_width(false, true, 40, true, |r| {
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("t1").unwrap(),
                tool: "Bash".to_string(),
                params: json!({"command": "echo hi"}),
                parent_tool_call_id: None,
            })
            .expect("call");
        });
        // The indicator opened — the line carries `running...` text
        // and stays within 40 columns including the right column.
        assert!(out.contains("running..."), "indicator must open: {out:?}");
        let line_width = display_width(out.trim_end_matches('\n'));
        assert!(
            line_width <= 40,
            "running line width {line_width} must fit in 40 cols: {out:?}",
        );
    }

    /// Buffered overflow plays well with sibling preemption: if a new
    /// tool call arrives before the result of the buffered one, the
    /// renderer flushes the buffered cell with `…` so the user sees the
    /// in-flight tool was preempted rather than silently dropping it.
    #[test]
    fn summary_overflow_preempts_buffered_call_on_sibling() {
        let out = capture_with_width(false, true, 40, true, |r| {
            // First call: long Bash → buffered.
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("t1").unwrap(),
                tool: "Bash".to_string(),
                params: json!({"command": "echo this command is far too long for 40 cols"}),
                parent_tool_call_id: None,
            })
            .expect("first call");
            // Second call: short, fits — preempts the first.
            r.render_event(&AgentEvent::ToolCall {
                envelope: sample_envelope(),
                id: ToolCallId::new("t2").unwrap(),
                tool: "Read".to_string(),
                params: json!({"file_path": "a"}),
                parent_tool_call_id: None,
            })
            .expect("second call");
        });
        assert!(
            out.contains('…'),
            "preempted buffered cell must carry the preempt glyph: {out:?}",
        );
        assert!(
            out.contains("echo this command is far too long for 40 cols"),
            "preempted summary must still print on the continuation line: {out:?}",
        );
    }
}
